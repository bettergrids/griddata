
------------------------------ Create User "graph" ---------------------------------------
 As root:

# adduser graph

    ----- Set and confirm the new user's password at the prompt ------

    Set password prompts:
    Enter new UNIX password:
    Retype new UNIX password:
    passwd: password updated successfully

    ----- Follow the prompts to set the new user's information ------
          (It is fine to accept the defaults to leave all of this
           information blank)

    User information prompts:
    Changing the user information for username
    Enter the new value, or press ENTER for the default
        Full Name []:
        Room Number []:
        Work Phone []:
        Home Phone []:
        Other []:
    Is the information correct? [Y/n]

------ Create folder ------

# mkdir /home/dspace/postgresql
# chown postgres postgresql

-------------------------------- Create database -----------------------------------------

-- in postgres#

CREATE ROLE graph WITH LOGIN ENCRYPTED PASSWORD 'graph';
ALTER USER graph with superuser;
ALTER USER graph with createrole;
ALTER USER graph with createDB;
CREATE TABLESPACE graphts OWNER graph LOCATION '/home/dspace/postgresql';

DROP DATABASE graph;
CREATE DATABASE graph OWNER graph TABLESPACE graphts;

-- in graph

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS pg_prewarm;
CREATE EXTENSION IF NOT EXISTS plpgsql;

------------------------------- Create base tables ----------------------------

create table  _modelInfo(
 modeluid     uuid    PRIMARY KEY,  -- bitstream UID
 modelname    varchar,
 filepath     varchar,
 format       varchar,
 tablename    varchar,
 visible      boolean,
 description  text
);

create table  _model2(
 _oid         bigserial PRIMARY KEY,
 modeluid     uuid      REFERENCES _modelinfo(modeluid),
 nodetype     varchar,
 tablename    varchar,
 _from        varchar,
 _to          varchar,
 length       double precision,
 linkup       text[],
 hopsup       int[],
 distup       double precision[],
 linkdown     text[],
 hopsdown     int[],  
 distdown     double precision[]
);

CREATE TABLE _paths(
 modeluid UUID    REFERENCES _modelinfo(modeluid),
 paths    int[]
);

CREATE INDEX path_modeluid_idx ON _paths(modeluid);

create table  _ipaddr(
 ipaddr       inet    PRIMARY KEY,  
 country      text,
 state        text,
 city         text,
 postal       text,
 latitude     double precision,
 longitude    double precision
);

create table  _query(
 _oid         bigserial PRIMARY KEY,
 useruid      uuid,
 ipaddr       inet      REFERENCES _ipaddr(ipaddr),
 created      timestamp with time zone,
 query        text,
 status       integer  -- 0- not recognized; 1- recognized
);

------------------------------------------------------------------------------------------
--                           B a s e    F  u  n  c  t  i  o  n  s 
------------------------------------------------------------------------------------------

--========================================================================================
-- Returns common information about models by types
--========================================================================================

CREATE OR REPLACE FUNCTION getRepositoryInfo(p_modelTabName text default '_model',
                                             p_tableName    text default 'tablename',
                                             p_modelType    text default 'modeltype')
RETURNS TABLE (format    text,
               modelcnt  bigint,
               objectcnt bigint) AS
$func$
DECLARE
   sql_s        text     := '';
   tabNum       int;
   tableName_sa text[]   := null;
   modelType_sa text[]   := null;
   modelCnt_sa  bigint[] := null;

BEGIN
   EXECUTE format('SELECT array_agg(%s), array_agg(%s), array_agg(cnt) FROM 
                   (SELECT %s, %s, count(*) cnt FROM %s GROUP BY %s, %s) AS t1',
                   p_tableName, p_modelType, p_tableName, p_modelType, p_modelTabName, 
                   p_tableName, p_modelType)
   INTO tableName_sa, modelType_sa, modelCnt_sa;

   IF tableName_sa IS NULL OR modelType_sa IS NULL OR modelCnt_sa IS NULL THEN 
      RETURN;
   END IF; 

   --- Build SQL query -----

   tabNum = array_length(tableName_sa, 1);

   FOR i IN 1..tabNum LOOP  
      sql_s := sql_s || 'SELECT ''' || modelType_sa[i] || '''::TEXT modelType,' || 
               modelCnt_sa[i] || '::bigint modelCnt, count(*)::bigint objectCnt FROM ' ||
               tableName_sa[i];

      IF i < tabNum THEN
         sql_s := sql_s || ' UNION ';
      END IF;
   END LOOP;

   --- sql_s := 'SELECT row_number() over() rnum, * FROM(' || sql_s || ') AS t1';

   RETURN QUERY EXECUTE sql_s;
END;
$func$ LANGUAGE 'plpgsql';


--------------------------------------------------------------------
--------------------------------------------------------------------

CREATE OR REPLACE FUNCTION getInsideCntInt(p_array   int[],
                                           p_elemOut int,
                                           p_elenIn  int)   
RETURNS int
AS '
SELECT coalesce(cardinality(array_positions(p_array[(array_positions(p_array, p_elemOut))[1]:
               (array_positions(p_array, p_elemOut))[array_length((array_positions(p_array, p_elemOut)), 1)]], 
               p_elenIn)), 0);
' LANGUAGE SQL;
