
--========================================================================================

--                                  F U N C T I O N S

--========================================================================================

CREATE OR REPLACE FUNCTION processModel(p_file         text,
                                        p_origFileName text,
                                        p_modelId      text default NULL, 
                                        p_criteria     text default 'dist',  -- 'dist' or 'hop'                                      
                                        p_vertexTable  text default '_gridlab',
                                        p_edgeTable    text default '_gridlab',
                                        p_nodeType     text default 'nodetype',
                                        p_modelIdName  text default 'modelid',
                                        p_fromName     text default '_from',
                                        p_toName       text default '_to',
                                        p_nodeName     text default '_name',
                                        p_pathName     text default '_paths',
                                        p_lenghtName   text default 'length',
                                        p_parentName   text default 'parent',
                                        p_inclusName   text default 'inclusions',
                                        p_connName     text default '_connections',
                                        p_distName     text default '_distances',
                                        p_hopsName     text default '_hops', 
                                        p_schemaName   text default 'public') 
RETURNS boolean AS
$func$
DECLARE
   res_b     boolean;
   l_modelId text := p_modelId;
BEGIN
   --- Get modelId from the file name if it is NULL ------

   IF p_modelId IS NULL THEN
      l_modelId := modelFromFile(p_file);
   END IF;

   --- Load model file to the flat table ------

   res_b := loadGridLabFlat(p_file, l_modelId, p_nodeType, p_vertexTable, p_schemaName);
   IF res_b = false THEN
      RETURN false;
   END IF;

   --- Calculate and set paths (fill up column 'paths') ------

   res_b := gldFindPaths(l_modelId, p_vertexTable, p_vertexTable, p_modelIdName, 
                         p_nodeName, p_pathName, p_fromName, p_toName);
   IF res_b = false THEN
      RETURN false;
   END IF;
   
   --- Calculate and set parent-child relations (fill up column 'inclusions') ------

   res_b := gldAllParentChains(l_modelId, p_vertexTable, p_modelIdName,p_parentName, 
                               p_nodeName, p_inclusName, p_schemaName);
   IF res_b = false THEN
      RETURN false;
   END IF;

   --- Calculate all connections between nodes, distances, and number of hops ------

   res_b := setAllConnections(l_modelId, p_criteria, p_vertexTable, p_edgeTable,
                              p_modelIdName, p_nodeName, p_pathName, p_lenghtName, 
                              p_fromName, p_toName, p_connName, p_distName, p_hopsName);

   IF res_b = false THEN
      RETURN false;
   END IF;

   RETURN res_b;
END;
$func$ LANGUAGE plpgsql VOLATILE;

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION loadGridLabFlat(p_file        text,
                                           p_modelId     text default NULL,
                                           p_nodeType    text default 'nodetype',
                                           p_outputTable text default '_gridLab',
                                           p_modelTable  text default '_model',
                                           p_schemaName  text default 'public')
RETURNS boolean AS
$func$
DECLARE
   obj_const        CONSTANT text := 'object';
   type_dlm         CONSTANT text := ':';
   comments_dlm     CONSTANT text := '//';
   attr_dlm         CONSTANT text := ' ';
   line_dlm         CONSTANT text := ';';
   open_dlm         CONSTANT text := '{';
   close_dlm        CONSTANT text := '}';
   modelId_const    CONSTANT text := 'modelid';
   oid_const        CONSTANT text := '_oid';
   name_const       CONSTANT text := '_name';
   objectIdx_const  CONSTANT text := 'objectidx';
   dspaceId_const   CONSTANT text := 'dspace_id';
   intIdxName_const CONSTANT text := '_int_';
   start_idx_const  CONSTANT int  := 4;       -- start from 5: because 1 - modelId;   2 - p_nodeType, 3 - objectIdx;

   idx       int := start_idx_const;  
   line_s    text;
   file_s    text;
   table_s   text; 
   r_cur     refcursor;
   in_b      boolean := false;
   obj_b     boolean := false;
   type_s    text;
   attr_sa   text[];
   val_sa    text[];
   attr_s    text;
   val_s     text;
   res_b     boolean := false;
   l_modelId text    := p_modelId;
   l_pos     int;
   
   l_outputTable text := keywordTranslate(trim(lower(p_outputTable)));
   l_nodeType    text := keywordTranslate(trim(lower(p_nodeType)));

BEGIN
   ----- Get modelId as a file name if it's null ------

   IF p_modelId IS NULL THEN
      l_modelId := modelFromFile(p_file);
   END IF;

   ----- Create temporary table and copy file to one text column ------
   -- one line -> one row

   file_s  := quote_literal(p_file);
   table_s := quote_ident(uuid_generate_v4()::text);

   EXECUTE 'CREATE TEMP TABLE ' || table_s || ' (content text)';
   EXECUTE 'COPY '|| table_s || ' FROM ' || file_s || ' DELIMITER E''\x1f''';

   ----- Create output flat table if not exists ------

   EXECUTE 'CREATE TABLE IF NOT EXISTS ' || p_schemaName || '.' || l_outputTable || 
           '(' || oid_const || ' bigserial primary key,' || name_const || ' text,' || 
            l_nodeType || ' text,' || objectIdx_const || ' text,' || dspaceId_const || ' text)'; 

   ----- Read data and parse data from column 'content' ------ 

   OPEN r_cur FOR EXECUTE 'SELECT content FROM ' || table_s; 
   FETCH NEXT FROM r_cur INTO line_s;
   WHILE FOUND LOOP

      line_s := trim(regexp_replace(line_s, '[[:space:]]+', ' ', 'g'));

      --- Comments and empty lines ----

      IF position(comments_dlm IN line_s) = 1 OR trim(line_s) = '' THEN
         FETCH NEXT FROM r_cur INTO line_s; 
         CONTINUE;
      END IF;

      --- Process object line ----

      IF obj_b = false THEN
         IF position(obj_const IN line_s) = 1 THEN
            type_s     := gldGetType(line_s, obj_const, open_dlm, type_dlm);
            idx        := start_idx_const;
            attr_sa[1] := modelId_const;
            val_sa[1]  := l_modelId;
            attr_sa[2] := l_nodeType;
            val_sa[2]  := type_s;
            attr_sa[3] := objectIdx_const;
            val_sa[3]  := gldObjectIdx(line_s, open_dlm, type_dlm);
            obj_b      := true;           

            -- RAISE NOTICE 'Object: % : %;', type_s, val_sa[3];
         END IF;       

      --- Process object attributes ----

      ELSE     
         --- Get attributes -----
            
         attr_s := keywordTranslate(trim(split_part(line_s, ' ', 1)));
         val_s  := trim(split_part(substring(trim(line_s), position(' ' IN trim(line_s))), line_dlm, 1)); 

         IF attr_s = name_const THEN
            val_s := replace(val_s, ' ', '_');	  -- remove ' ' from the name
         END IF;

         -- RAISE NOTICE 'idx: %; attr: %; value: %;', idx, attr_s, val_s; 

         --- End of object -----

         IF position(close_dlm IN attr_s) > 0 THEN
            obj_b := false;

            --- Insert all attributes as columns ----

            res_b := insertAttrs(l_outputTable, attr_sa, val_sa, p_schemaName);
            IF res_b = false THEN
               RAISE NOTICE 'ERROR: insertAttrs: attrs: %; vals: %', attr_sa, val_sa; 
               RETURN false;
            END IF;

            attr_sa := ARRAY[]::text[];		-- reset arrays
            val_sa  := ARRAY[]::text[];
         ELSE
	    attr_sa[idx] := attr_s;
            val_sa[idx]  := val_s;
            idx          := idx + 1;
         END IF;
      END IF;   
 
      FETCH NEXT FROM r_cur INTO line_s; 
   END LOOP;
   CLOSE r_cur; 

   --- Set _name value for rows where _name is null -----

   EXECUTE format('UPDATE %s SET %s = (SELECT CASE WHEN %s IS NULL OR %s =''''
                   THEN %s || ''%s'' || %s ELSE %s || ''%s'' || %s END) WHERE 
                  %s = %L AND %s is NULL',   
                  p_outputTable, name_const, objectIdx_const, objectIdx_const, 
                  p_nodeType, intIdxName_const, oid_const, 
                  p_nodeType, type_dlm, objectIdx_const,
                  modelId_const, l_modelId, name_const);

   GET DIAGNOSTICS idx = ROW_COUNT;
   RAISE NOTICE 'Updated rows with NULL names: %',  idx;

   ---  Find and make unique all duplicate name values -----
    
   EXECUTE format('UPDATE %s SET %s = %s || ''_'' || %s WHERE %s = %L 
                   AND %s IN (SELECT %s FROM (SELECT %s, count(*) FROM %s 
                   WHERE %s = %L GROUP BY %s having count(*) > 1)t1)',
                   p_outputTable, name_const, name_const, oid_const,
                   modelId_const, l_modelId, name_const, name_const,
                   name_const, p_outputTable, modelId_const, l_modelId,
                   name_const);
   
   GET DIAGNOSTICS idx = ROW_COUNT;
   -- RAISE NOTICE 'Updated rows with duplicate names: %',  idx;

   --- Delete temporary table -----

   EXECUTE 'DROP TABLE ' || table_s;

   RETURN true;
END;
$func$ LANGUAGE plpgsql VOLATILE;

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION gldGetType(p_line     text, 
                                      p_object   text,
                                      p_open_dlm text,
                                      p_type_dlm text) 
RETURNS text AS 
$func$
DECLARE
   pos1   int;
   pos2   int;
   type_s text;

BEGIN
   pos1 = position(p_object IN p_line) + char_length(p_object);
   pos2 = position(p_open_dlm IN p_line);

   type_s = trim(split_part(substring(p_line, pos1, pos2 - pos1), p_type_dlm, 1));
   type_s = lower(translate(type_s, ' ,.', '_,_'));
   
   RETURN type_s;
END;
$func$ LANGUAGE plpgsql IMMUTABLE;

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION gldObjectIdx(p_line     text,
                                        p_open_dlm text,
                                        p_type_dlm text) 
RETURNS text AS 
$func$
DECLARE
   pos1   int;
   pos2   int;
   type_s text;

BEGIN
   pos1 = position(p_type_dlm IN p_line) + 1;
   pos2 = position(p_open_dlm IN p_line);

   IF pos1 = 1 OR pos2 = 0 THEN 
      RETURN '';
   END IF; 

   type_s = lower(trim(substring(p_line, pos1, pos2 - pos1)));
   
   RETURN type_s;
END;
$func$ LANGUAGE plpgsql IMMUTABLE;

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION insertAttrs(p_tableName  text,
                                       p_attrs      text[],
                                       p_vals       text[],
                                       p_schemaName text default 'public')
RETURNS boolean AS
$func$
DECLARE
   i int;
   l_attrsLen int  := array_length(p_attrs, 1);
   l_valsLen  int  := array_length(p_vals,  1);
   l_nameIdx  int  := -1;
   l_attrs_s  text := '';
   l_vals_s   text := '';
   l_tmp_s    text;

BEGIN
   --- Verification -----

   IF l_attrsLen != l_valsLen AND (l_attrsLen <= 0 OR l_valsLen <= 0) THEN
      RETURN false;
   END IF;

   --- Create columns if it's needed -----

   FOR i IN 1..l_attrsLen LOOP      
      l_tmp_s := lower(replace(replace(p_attrs[i], '.', '_'), ' ', '_'));
      PERFORM add_column(p_tableName, l_tmp_s, 'text', false, p_schemaName);
   END LOOP;
 
   --- Prepare text values to INSERT ---

   FOR i IN 1..l_valsLen LOOP
      l_tmp_s   := lower(replace(replace(p_attrs[i], '.', '_'), ' ', '_'));
      l_attrs_s := l_attrs_s || l_tmp_s   || ','; 
      l_vals_s  := l_vals_s  || '''' || p_vals[i] || ''',';
   END LOOP;

   l_attrs_s := trim(l_attrs_s, ',');
   l_vals_s  := trim(l_vals_s,  ',');

   --- Insert value p_vals[i] to the column p_attrs[i] -----

   EXECUTE 'INSERT INTO ' || p_tableName || ' (' || l_attrs_s || ') VALUES (' || l_vals_s || ')';   

   --FOR i IN 1..l_valsLen LOOP 
   --   IF p_name != p_attrs[i] THEN
   --      PERFORM upsert_unique(p_tableName, p_name, p_vals[l_nameIdx], p_attrs[i], p_vals[i]);
   --   END IF;
   --END LOOP;

   RETURN true;
END;
$func$ LANGUAGE plpgsql VOLATILE;

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION gldFindPaths(p_modelId      text,
                                        p_tableSource  text default '_gridlab',
                                        p_tableTarget  text default '_gridlab',
                                        p_modelIdName  text default 'modelid',
                                        p_name         text default '_name',
                                        p_paths        text default '_paths', 
                                        p_fromName     text default '_from',
                                        p_toName       text default '_to')
RETURNS boolean AS
$func$
DECLARE
   i        int;
   k        int;
   from_sa  text[];
   from_len int;
   in_sa    text[];
   out_sa   text[];
   out_len  int;
   l_tmp_s  text := '';
 
   stop_const CONSTANT text := 'xxx_STOP_xxx';

BEGIN
   --- Get all rows where _from and is not null -----

   EXECUTE format('SELECT ARRAY(SELECT DISTINCT %s FROM %s WHERE %s IS NOT NULL AND 
                   %s IS NOT NULL AND %s = %L)', 
                   p_fromName, p_tableSource, p_fromName, p_toName, p_modelIdName, 
                   p_modelId) 
   INTO from_sa;

   from_len := array_length(from_sa, 1);
   RAISE NOTICE 'Array Length: %', from_len;
 
   IF from_sa IS NULL OR from_len IS NULL OR from_len <= 0 THEN
      RETURN false;
   END IF;

   --- Create 'paths' column if its needed -----

   PERFORM add_column(p_tableTarget, p_paths, 'text[]', false);

   --- Loop for each node name (from) -----

   FOR i IN 1..from_len LOOP
      in_sa[1] := from_sa[i];           -- init value for recursive fucntion 
      
      out_sa  := gldPathRecursive(p_tableSource, p_modelId, in_sa, p_modelIdName,  -- path down
                                  p_fromName, p_toName) || 
                 gldPathRecursive(p_tableSource, p_modelId, in_sa, p_modelIdName,  -- path up
                                  p_toName, p_fromName);    

      out_len := array_length(out_sa, 1);
      RAISE NOTICE '%: %', in_sa[1], chr(9) || out_len;
    
      --- Remove 'stop' element and first (starting) node ----- 

      FOR k IN 1..out_len LOOP
         out_sa[k] := replace(out_sa[k], ',' || stop_const, '');
         -- out_sa[k] := substring(out_sa[k] from position(',' in out_sa[k]) + 1);
      END LOOP;

      --- Insert paths to vertex 'from' node and to all 
      --- 'edge' nodes which have current '_from'

      l_tmp_s := formatArray1D(out_sa);

      EXECUTE format('UPDATE %s SET %s = %s WHERE %s = %L AND (%s = $1 OR %s = $2)'::text,
                     p_tableTarget, p_paths, l_tmp_s, p_modelIdName, p_modelId,
                     p_name, p_fromName) 
      USING from_sa[i], from_sa[i];

   END LOOP;
   RETURN true;
END;
$func$ LANGUAGE plpgsql;

------------------------------------------------------------------------------------------
--  Recursive function return last downward node (object)
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION gldPathRecursive(p_tableName   text,
                                            p_modelId     text, 
                                            p_path        text[], -- existing path
                                            p_modelIdName text default 'modelid',
                                            p_fromName    text    default '_from',
                                            p_toName      text    default '_to') 
RETURNS text[] AS
$func$
DECLARE
   stop_const  CONSTANT text := 'xxx_STOP_xxx';
   delim_const CONSTANT text := ',';

   i        int;    -- index of input array
   j        int;    -- index of output array
   k        int;    -- index of result array
   m        int;
   out_sa   text[];
   res_sa   text[];
   tmp_sa   text[];
   res_len  int;
   last_s   text;   -- last (current) path element 
   path_len int     := array_length(p_path, 1);
   done_b   boolean := true;
   exs_b    boolean := false;

BEGIN

  -- RAISE NOTICE 'path_len: %;', path_len;

   IF p_path IS NULL OR path_len IS NULL OR path_len <= 0 THEN
      RAISE NOTICE 'ERROR: path array is NULL or empty. Table: %;', p_tableName;
      RETURN NULL;
   END IF;
 
   j := 1;
   FOR i IN 1..path_len LOOP
      last_s := replace(replace(regexp_replace(p_path[i], '^.*,', ''),'{',''),'}',''); -- get the last node
      
      IF last_s = stop_const THEN
      	out_sa[j] := p_path[i];    -- dead end. Keep it "as is"
        j := j + 1;
        CONTINUE;
      END IF;

      EXECUTE format('SELECT ARRAY(SELECT %s FROM %s WHERE %s = %L AND %s  = %L)', 
                      p_toName, p_tableName, p_modelIdName, p_modelId, 
                      p_fromName, last_s) 
      INTO res_sa;
      
      res_len := array_length(res_sa, 1);

      --- No more nodes in the path -----
   
      IF res_sa IS NULL OR res_len IS NULL OR res_len <= 0 THEN
         out_sa[j] := p_path[i] || delim_const || stop_const;         -- this path is done
         j := j + 1;
         CONTINUE;
      END IF;

      --- Extend and add new paths -----

      FOR k IN 1..res_len LOOP

         --- Check if the new node already exists in the path (to avoid infinite loops) -----
         
         exs_b := doesNodeExist(p_path, res_sa[k]);
         IF exs_b = true THEN
            out_sa[j] := p_path[i] || delim_const || stop_const;
         ELSE
            out_sa[j] := p_path[i] || delim_const || res_sa[k]; --- Add new node to the path 
            done_b    := false;
         END IF;
         j := j + 1;
      END LOOP;
   END LOOP;
   
   --- Recursive function call -----

   IF done_b = false THEN
      out_sa := gldPathRecursive(p_tableName, p_modelId, out_sa, p_modelIdName, 
                                 p_fromName, p_toName);
   END IF;

   --RAISE NOTICE 'out_sa: %', out_sa;
   
RETURN out_sa;

END;
$func$ LANGUAGE plpgsql VOLATILE;

------------------------------------------------------------------------------------------
-- select setAllConnections('GC-12.47-1');
-- select setAllConnections('AL0001_glmfile_ts');
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION setAllConnections(p_modelId     text,
                                             p_criteria    text default 'dist',    -- 'dist' or 'hop'
                                             p_vertexTable text default '_gridlab',
                                             p_edgeTable   text default '_gridlab',
                                             p_modelidname text default 'modelid',
                                             p_nodeName    text default '_name',
                                             p_pathName    text default '_paths',
                                             p_lenghtName  text default 'length',
                                             p_fromName    text default '_from',
                                             p_toName      text default '_to',
                                             p_connName    text default '_connections',
                                             p_distName    text default '_distances',
                                             p_hopsName    text default '_hops')      
RETURNS boolean AS
$func$
DECLARE 
   i        int;
   node_sa  text[];
   node_len int;
   res_b    boolean;
   l_tmp_s  text;

BEGIN
   --- Create output columns if its needed -----

   PERFORM add_column(p_vertexTable, p_connName, 'text[]',    false);
   PERFORM add_column(p_vertexTable, p_distName, 'numeric[]', false);
   PERFORM add_column(p_vertexTable, p_hopsName, 'int[]',     false);

   --- Get all vertex names -----

   EXECUTE format('SELECT ARRAY(SELECT %s FROM %s WHERE %s IS NOT NULL AND %s = %L)', 
                   p_nodeName, p_vertexTable, p_pathName, p_modelidname, p_modelId) 
   INTO node_sa;
 
   node_len := array_length(node_sa, 1);
   
   FOR i IN 1..node_len LOOP
      res_b := setNodeConnections(p_modelId, node_sa[i], p_criteria, p_vertexTable, 
                                  p_edgeTable, p_modelidname, p_nodeName, p_pathName, 
                                  p_lenghtName, p_fromName, p_toName, p_connName, 
                                  p_distName, p_hopsName); 

      IF res_b = false THEN       
         RAISE NOTICE 'ERROR: setAllConnections. Node = %; Processed % vertices of %', 
                      node_sa[i], i - 1, node_len; 
         RETURN false;
      END IF;

      -- RAISE NOTICE 'Vertex name: %. Processed.', node_sa[i];
   END LOOP;

   RETURN true;
END; 
$func$ LANGUAGE 'plpgsql';

------------------------------------------------------------------------------------------
-- select setNodeConnections('R1-12-47-1_node_58');
-- 
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION setNodeConnections(p_modelId     text,
                                              p_node        text, -- value of vertex name
                                              p_criteria    text  default 'dist',  -- 'dist' or 'hop'
                                              p_vertexTable text  default '_gridlab',
                                              p_edgeTable   text  default '_gridlab',
                                              p_modelidname text  default 'modelid',
                                              p_nodeName    text  default '_name',
                                              p_pathName    text  default '_paths',
                                              p_lenghtName  text  default 'length',
                                              p_fromName    text  default '_from',
                                              p_toName      text  default '_to',
                                              p_connName    text  default '_connections',
                                              p_distName    text  default '_distances',
                                              p_hopsName    text  default '_hops')      
RETURNS boolean AS
$func$
DECLARE 
   delim_const CONSTANT text := ',';
   dist_const  CONSTANT text := 'dist';
   hop_const   CONSTANT text := 'hop';

   i int; j int; 
   l_length   numeric := 0;
   l_res      boolean := true;
   path_sa    text[];
   path_len   int;
   node_sa    text[];
   node_len   int;
   con_sa     text[];
   con_len    int;
   hop_a      int[];
   dist_a     numeric[];
   dist_value numeric;
   hop_value  int;
   from_s     text;
   to_s       text;
   pos        int;
   down_b     boolean;
   newVert_s  text;

   l_formatConn text;
   l_formatDist text;
   l_formatHops text;

BEGIN 
   IF p_criteria != dist_const AND p_criteria != hop_const THEN
      RAISE NOTICE 'Criteria: % is not allowed. It can be "%" or "%"', 
                    p_criteria, dist_const, hop_const;
      RETURN false;
   END IF;

   --- Get all paths from this vertex -----

   EXECUTE format('SELECT %s FROM %s WHERE %s = %L AND %s = %L'::text, 
                   p_pathName, p_vertexTable, p_modelidname, p_modelId,
                   p_nodeName, p_node) 
   INTO path_sa;
     
   path_len := array_length(path_sa, 1);

   --- Process all paths to find shortest one or min hops -----

   FOR j IN 1..path_len LOOP
      node_sa  := string_to_array(path_sa[j], delim_const);
      node_len := array_length(node_sa, 1);

      IF node_len = 1 THEN
         CONTINUE;
      END IF;

      --- Check if it's a downward or upward path -----

      EXECUTE format('SELECT EXISTS(SELECT 1 FROM %s WHERE %s = %L AND %s = %L AND %s = %L)',
                     p_edgeTable, p_modelidname, p_modelId, p_fromName, node_sa[1], 
                     p_toName, node_sa[2])
      INTO down_b;

      dist_value := 0;
      hop_value  := 0;
      
      FOR i IN 1..node_len - 1 LOOP   -- cycle in specific path
         IF down_b = true THEN
            from_s := node_sa[i];
            to_s   := node_sa[i + 1];
         ELSE
            from_s := node_sa[i + 1];
            to_s   := node_sa[i];
         END IF;
         newVert_s := node_sa[i + 1];   -- new vertex for downward/upward

         con_len := coalesce(array_length(con_sa, 1), 0);  -- current length of 'connections'

         --- distance between two neighbor vertices (downward / upward) -----

         EXECUTE format('SELECT coalesce(split_part(%I, '' '', 1)::numeric, 0) ' ||
                        'FROM %s WHERE %s = %L AND %s = %L AND %s = %L', 
                         p_lenghtName, p_edgeTable, p_modelidname, p_modelId,
                         p_fromName, from_s, p_toName, to_s) 
         INTO l_length;
 
         dist_value := dist_value + l_length;  -- distance to the current vertex 
         IF l_length > 0 THEN
            hop_value := hop_value + 1;
         END IF; 

         --- Check if this is the shortest path and update if its needed ------         

         pos := array_search(con_sa, newVert_s);

         IF pos = 0 THEN                             -- add new vertex
            con_sa[con_len + 1] := newVert_s;
            dist_a[con_len + 1] := dist_value;
            hop_a[con_len  + 1] := hop_value;
         ELSE 
            IF (p_criteria = dist_const AND dist_value < dist_a[pos]) OR
               (p_criteria = hop_const  AND hop_value  < hop_a[pos]) THEN               
               dist_a[pos] := dist_value;
               hop_a[pos]  := hop_value;
            END IF;
         END IF;
      END LOOP;
   END LOOP;

   RAISE NOTICE '%.% Connections: %', p_node, chr(9), chr(9) || array_length(con_sa, 1);
   -- RAISE NOTICE '%', con_sa;
   -- RAISE NOTICE '%', dist_a;
   -- RAISE NOTICE '%', hop_a;

   --- Insert calculated values -----

   l_formatConn := formatArray1D(con_sa);
   l_formatDist := formatArray1D(dist_a, 'numeric');
   l_formatHops := formatArray1D(hop_a,  'int');

   EXECUTE format('UPDATE %s SET %s = %s, %s = %s, %s = %s WHERE %s = %L AND %s = %L',
                  p_vertexTable, p_connName, l_formatConn, p_distName, l_formatDist,
                  p_hopsName, l_formatHops, p_modelidname, p_modelId, p_nodeName, p_node);

   GET DIAGNOSTICS i = ROW_COUNT;
   -- RAISE NOTICE 'Updated rows: %',  i;
 
   IF i != 1 THEN
      RAISE NOTICE 'Failed in updating record _name = %. Diagnistic: %', p_node, i; 
      RETURN false;
   END IF;

RETURN true;
END; 
$func$ LANGUAGE 'plpgsql';

------------------------------------------------------------------------------------------
-- select gldAllParentChains('GC-12.47-1');
-- select gldAllParentChains('AL0001_glmfile_ts');

------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION gldAllParentChains(p_modelId     text,
                                              p_tableName   text default '_gridlab',
                                              p_modelIdName text default 'modelid',
                                              p_fromName    text default 'parent',
                                              p_toName      text default '_name',
                                              p_inclusName  text default 'inclusions',
                                              p_schemaName  text default 'public') 
RETURNS boolean AS
$func$
DECLARE

   i       bigint;
   l_tmp_s text;
   name_sa text[] := null;
   res_sa  text[];

BEGIN
   PERFORM add_column(p_tableName, p_inclusName, 'text[]', false, p_schemaName);

   EXECUTE format('SELECT ARRAY(select %s from %s t1 where %s = %L and exists 
                               (select 1 from %s where %s = %L and %s = t1.%s))',
                  p_toName, p_tableName, p_modelIdName, p_modelId, p_tableName,
                  p_modelIdName, p_modelId, p_fromName, p_toName)
   INTO name_sa;

   IF name_sa IS NULL OR array_length(name_sa, 1) IS NULL THEN 
      RETURN true;
   END IF; 

   FOR i IN 1..array_length(name_sa, 1) LOOP
      res_sa := gldParentChain(name_sa[i], p_modelId); 

      --- Insert inclusions into the main table ----

      l_tmp_s := formatArray1D(res_sa);

      EXECUTE format('UPDATE %s SET %s = %s WHERE %s = %L AND %s = %L',
                     p_tableName,  p_inclusName, l_tmp_s, p_modelIdName, 
                     p_modelId, p_toName, name_sa[i]);

      RAISE NOTICE 'name: %; inclusions: %;', name_sa[i], res_sa;
   END LOOP;

   RETURN true;
END;
$func$ LANGUAGE plpgsql VOLATILE;

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION gldParentChain(p_name        text,
                                          p_modelId     text,
                                          p_tableName   text default '_gridlab',
                                          p_modelIdName text default 'modelid',
                                          p_fromName    text default 'parent',
                                          p_toName      text default '_name') 
RETURNS text[] AS
$func$
DECLARE
   out_sa text[];

BEGIN
   EXECUTE format(
   'WITH RECURSIVE graph(points) AS
   (SELECT ARRAY(select distinct %s from %s where %s = %L and %s = %L)
      UNION ALL
   SELECT g.points || e1.p || e2.p
      FROM graph g
      LEFT JOIN LATERAL (SELECT ARRAY(select distinct %s 
                                        from %s
                                       where %s = %L
                                         and %s = ANY(g.points) 
                                         and %s <> ALL(g.points)
                                         and %s <> %L) AS p) e1 ON (true)
      LEFT JOIN LATERAL (SELECT ARRAY(select distinct %s
                                        from %s
                                       where %s = %L
                                         and %s = ANY(g.points)
                                         and %s <> ALL(g.points)
                                         and %s <> %L) AS p) e2 ON (true)
      WHERE e1.p <> ''{}'' OR e2.p <> ''{}''
   )
   SELECT ARRAY(SELECT DISTINCT unnest(points)
     FROM graph
    ORDER BY 1)',
   p_toName,   p_tableName, p_modelIdName, p_modelId, p_fromName, p_name,
   p_toName,   p_tableName, p_modelIdName, p_modelId, p_fromName, p_toName,   p_toName,   p_name,
   p_fromName, p_tableName, p_modelIdName, p_modelId, p_toName,   p_fromName, p_fromName, p_name)
   INTO out_sa;

   RETURN array_reverse(out_sa);
END;
$func$ LANGUAGE plpgsql VOLATILE;

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION add_column(table_name  TEXT, 
                                      column_name TEXT, 
                                      data_type   TEXT,
                                      is_unique   boolean,
                                      schema_name TEXT default 'public')
RETURNS BOOLEAN
AS
$BODY$
DECLARE
   _tmp     text;
   constr_s text;
   l_col_s  text;

BEGIN
   l_col_s := lower(replace(replace(column_name, '.', '_'), ' ', '_'));

   EXECUTE format('SELECT COLUMN_NAME 
                     FROM information_schema.columns 
                    WHERE table_schema=%L
                      AND table_name=%L
                      AND column_name=%L', 
                  schema_name, table_name, l_col_s)
   INTO _tmp;

   IF _tmp IS NOT NULL THEN
      -- RAISE NOTICE 'Column % already exists in %.%', column_name, schema_name, table_name;
      RETURN FALSE;
   END IF;

   EXECUTE format('ALTER TABLE %s.%s ADD COLUMN %s %s;', schema_name, table_name, column_name, data_type);
   
   IF is_unique = true THEN
      constr_s := table_name || '_' || column_name || '_constr'; 
      EXECUTE format('ALTER TABLE %s.%s ADD CONSTRAINT %s UNIQUE (%s)', 
                     schema_name, table_name, constr_s, column_name);
   END IF;

  --RAISE NOTICE 'Column % added to %.%', column_name, schema_name, table_name;

   RETURN TRUE; 
END;
$BODY$
LANGUAGE 'plpgsql';

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION doesNodeExist(p_arr  text[],  -- initial array of paths 
                                         p_node text)    -- node to be searched                                      
RETURNS boolean AS
$$
DECLARE 
   l_res boolean := false;

BEGIN 
   SELECT p_node=ANY(p_arr) INTO l_res;

RETURN coalesce(l_res, false);
END; 
$$ LANGUAGE 'plpgsql';

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION keywordTranslate(p_column  text)
RETURNS text AS
$func$ 
DECLARE
   l_keywords_sa text[];
   l_res boolean;
   i int;

BEGIN 
   SELECT EXISTS(SELECT FROM pg_get_keywords() 
    WHERE (catcode = 'R' OR catcode = 'U')
      AND word = p_column) INTO l_res;

   IF l_res = true THEN
      RETURN '_' || lower(p_column);
   END IF;
   RETURN lower(p_column);
END; 
$func$ LANGUAGE 'plpgsql'; 

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION array_search(haystack ANYARRAY, 
                                        needle   ANYELEMENT)
RETURNS int AS
$$
DECLARE
   ret int;
BEGIN
   SELECT i INTO ret FROM generate_subscripts($1, 1) AS i
   WHERE $1[i] = $2 ORDER BY i;

   RETURN coalesce(ret, 0);
END;
$$ LANGUAGE 'plpgsql' STABLE;

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION getArrayUniqueNodes(anyarray) 
RETURNS anyarray 
AS $f$
  SELECT array_agg(DISTINCT x) 
    FROM unnest($1) t(x)
   WHERE x IS NOT NULL
     AND x != 'xxx_STOP_xxx'
$f$ LANGUAGE SQL IMMUTABLE;

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION array_reverse(anyarray) 
RETURNS anyarray 
AS $$
SELECT ARRAY(
    SELECT $1[i]
    FROM generate_subscripts($1,1) AS s(i)
    ORDER BY i DESC
);
$$ LANGUAGE 'sql' STRICT IMMUTABLE;

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION modelFromFile(file_s text) 
RETURNS text 
AS $$
DECLARE
   l_modelId text := NULL;
BEGIN
   IF file_s IS NOT NULL THEN
      l_modelId := regexp_replace(file_s, '^.+[/\\]', '');   -- file name
      l_modelId := left(l_modelId, length(l_modelId) - position('.' in reverse(l_modelId)));
   END IF;
   RETURN l_modelId;
END;
$$ LANGUAGE 'plpgsql' STRICT IMMUTABLE;

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION formatArray1D(p_arr  ANYARRAY,
                                         p_type text default 'text')
RETURNS text AS
$$
DECLARE
   text_const CONSTANT text := 'text';
   i     int;
   arr_s text := '(ARRAY[';
   l_len int  := array_length(p_arr, 1);

BEGIN

   IF l_len IS NULL THEN
      RETURN NULL;
   END IF;

   --- Test type -----

   IF trim(lower(p_type)) = text_const THEN
      FOR i IN 1..l_len LOOP
         arr_s := format('%s''%s'',', arr_s, p_arr[i]);
      END LOOP;
   
      arr_s := substring(arr_s, 1, length(arr_s) - 1);  -- remove last comma
      arr_s := format('%s])', arr_s);                   -- add final bracket

   --- Numeric types -----

   ELSE
      FOR i IN 1..l_len LOOP
         arr_s := format('%s%s,', arr_s, p_arr[i]);
      END LOOP;
   
      arr_s := substring(arr_s, 1, length(arr_s) - 1);
      arr_s := format('%s])', arr_s);   
   END IF;

   RETURN arr_s;
END; 
$$ LANGUAGE 'plpgsql' STRICT IMMUTABLE;

--========================================================================================
--                           R e q u e s t   f u n c t i o n s
--
-- select * from requestConnections('R1-12.47-1', 'transformer','meter','<', 500, '<', 10);
-- select * from requestConnections('GC-12.47-1', 'node','meter','<', 500, '<', 10);
-- select * from requestConnections('R1-12.47-1', 'regulator','meter','<', 500, '<', 10);
--========================================================================================

CREATE OR REPLACE FUNCTION requestConnections(p_modelId      text, 
                                              p_typeParent   text,                                       
                                              p_typeChild    text,
                                              P_distCriteria text,
                                              p_distValue    numeric,
                                              p_hopsCriteria text,
                                              p_hopsValue    int)
RETURNS TABLE (name        text,
               type        text,
               count       bigint,
               connections text[]) AS
$func$
DECLARE
   sql_s text;

BEGIN
   sql_s := format('WITH t0 AS (SELECT * FROM _gridlab WHERE modelId = %L),
                         t1 AS (SELECT _name FROM t0 WHERE nodetype = %L),
                         t3 AS (SELECT t2._name, 
                                       t2.nodetype,  
                                       t2.inclusions,
                                       count(t1._name) cnt,  
                                       array_agg(t1._name) agg
                                  FROM t0 t2, t1
                                 WHERE nodetype = %L 
                                   AND _hops[array_search(_connections, t1._name)] %s%s
                                   AND _distances[array_search(_connections, t1._name)] %s%s
                                 GROUP BY t2._name, t2.nodetype, t2.inclusions)
                    SELECT t3._name, t3.nodetype, t3.cnt, t3.agg 
                      FROM t3
                     UNION
                    SELECT t5._name, t5.nodetype, t3.cnt, t3.agg
                      FROM t0 t5, t3
                     WHERE t5._name = ANY(t3.inclusions)',
                   p_modelId, p_typeChild, p_typeParent, p_hopsCriteria, p_hopsValue, 
                   P_distCriteria, p_distValue);  

   -- RAISE NOTICE '%', sql_s;

   RETURN QUERY EXECUTE sql_s;
   --USING ...;
END;
$func$ LANGUAGE 'plpgsql';

--========================================================================================
-- Returns common information about models by types. 
--========================================================================================

CREATE OR REPLACE FUNCTION getRepositoryInfo(p_modelTabName text default '_modelinfo',
                                             p_tableName    text default 'tablename',
                                             p_modelType    text default 'format')
RETURNS TABLE (format    text,
               modelcnt  bigint,
               objectcnt bigint) AS
$func$
DECLARE
   sql_s        text     := '';
   tabNum       int;
   tableName_sa text[]   := null;
   modelType_sa text[]   := null;
   modelCnt_sa  bigint[] := null;

BEGIN
   EXECUTE format('SELECT array_agg(%s), array_agg(%s), array_agg(cnt) FROM 
                   (SELECT %s, %s, count(*) cnt FROM %s GROUP BY %s, %s) AS t1',
                   p_tableName, p_modelType, p_tableName, p_modelType, p_modelTabName, 
                   p_tableName, p_modelType)
   INTO tableName_sa, modelType_sa, modelCnt_sa;

   IF tableName_sa IS NULL OR modelType_sa IS NULL OR modelCnt_sa IS NULL THEN 
      RETURN;
   END IF; 

   --- Build SQL query -----

   tabNum = array_length(tableName_sa, 1);

   FOR i IN 1..tabNum LOOP  
      sql_s := sql_s || 'SELECT ''' || modelType_sa[i] || '''::TEXT modelType,' || 
               modelCnt_sa[i] || '::bigint modelCnt, count(*)::bigint objectCnt FROM ' ||
               tableName_sa[i];

      IF i < tabNum THEN
         sql_s := sql_s || ' UNION ';
      END IF;
   END LOOP;

   --- sql_s := 'SELECT row_number() over() rnum, * FROM(' || sql_s || ') AS t1';

   RETURN QUERY EXECUTE sql_s || ' ORDER BY modelCnt DESC';
END;
$func$ LANGUAGE 'plpgsql';

--========================================================================================
-- Returns common information about models by types (faster version)
--========================================================================================

CREATE OR REPLACE FUNCTION getRepositoryInfo(p_modelTabName text default '_modelinfo',
                                             p_tableName    text default 'tablename',
                                             p_format       text default 'format',
                                             p_columnType   text default 'integer')
RETURNS TABLE (format    text,
               modelcnt  bigint,
               objectcnt bigint) AS
$func$
DECLARE
   columnNum    int;
   sql_s        text     := 'SUM(';
   schemaName_s text     := 'public';
   columnNames_sa text[] := null;

BEGIN
   EXECUTE format('SELECT array_agg(column_name::text) FROM information_schema.columns
                   WHERE table_schema = %L AND table_name = %L AND data_type = %L',
                   schemaName_s, p_modelTabName, p_columnType)
   INTO columnNames_sa;

   IF columnNames_sa IS NULL THEN 
      RETURN;
   END IF; 

   --- Build SQL query -----

   columnNum = array_length(columnNames_sa, 1);

   FOR i IN 1..columnNum LOOP        
      sql_s := sql_s || 'coalesce(' || columnNames_sa[i] || '::bigint,0)+';
   END LOOP;

   sql_s := substring(sql_s, 1, length(sql_s) - 1) || ')';  -- remove last comma and close SUM

   sql_s := 'SELECT ' || p_format || '::text, count(*)::bigint modelcnt,' || sql_s || 
            '::bigint objectcnt ' || 'FROM ' || p_modelTabName || ' GROUP BY ' || 
            p_format || ' ORDER BY modelcnt desc';
 
   RETURN QUERY EXECUTE sql_s;
END;
$func$ LANGUAGE 'plpgsql';

--========================================================================================
-- Returns common information about models by types (Faster version)
--========================================================================================

CREATE OR REPLACE FUNCTION getModelInfo(p_modelTabName text default '_modelinfo',
                                        p_tableName    text default 'tablename',
                                        p_format       text default 'format',
                                        p_columnType   text default 'integer')
RETURNS TABLE (format    text,
               modelcnt  bigint,
               objectcnt bigint) AS
$func$
DECLARE
   columnNum    int;
   sql_s        text     := 'SUM(';
   schemaName_s text     := 'public';
   columnNames_sa text[] := null;

BEGIN
   EXECUTE format('SELECT array_agg(column_name::text) FROM information_schema.columns
                   WHERE table_schema = %L AND table_name = %L AND data_type = %L',
                   schemaName_s, p_modelTabName, p_columnType)
   INTO columnNames_sa;

   IF columnNames_sa IS NULL THEN 
      RETURN;
   END IF; 

   --- Build SQL query -----

   columnNum = array_length(columnNames_sa, 1);

   FOR i IN 1..columnNum LOOP        
      sql_s := sql_s || 'coalesce(' || columnNames_sa[i] || '::bigint,0)+';
   END LOOP;

   sql_s := substring(sql_s, 1, length(sql_s) - 1) || ')';  -- remove last comma and close SUM

   sql_s := 'SELECT ' || p_format || '::text, count(*)::bigint modelcnt,' || sql_s || 
            '::bigint objectcnt ' || 'FROM ' || p_modelTabName || ' GROUP BY ' || 
            p_format || ' ORDER BY modelcnt desc';
 
   RETURN QUERY EXECUTE sql_s;
END;
$func$ LANGUAGE 'plpgsql';

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION getDeepGldAttrs(p_attrName  text[],
                                           p_attrValue text[],
                                           p_attrOps   text[],
                                           p_deepName  text[],
                                           p_deepValue text[],
                                           p_deepOps   text[])      
RETURNS text[] AS
$func$
DECLARE
   out_sa text[];
   l_tableName text := '_gridlab';

BEGIN
   --- Input data verification ----
   
   l_nameLen  int := array_length(p_attrName,  1);
   l_valueLen int := array_length(p_attrValue, 1);
   l_opsLen   int := array_length(p_attrOps,   1);

   IF l_nameLen != l_valueLen OR l_nameLen != l_opsLen THEN
      RETURN NULL;
   END IF;

   EXECUTE format(
   'WITH RECURSIVE graph(points) AS
   (SELECT ARRAY(select distinct %s from %s where %s = %L and %s = %L)
      UNION ALL
   SELECT g.points || e1.p || e2.p
      FROM graph g
      LEFT JOIN LATERAL (SELECT ARRAY(select distinct %s 
                                        from %s
                                       where %s = %L
                                         and %s = ANY(g.points) 
                                         and %s <> ALL(g.points)
                                         and %s <> %L) AS p) e1 ON (true)
      LEFT JOIN LATERAL (SELECT ARRAY(select distinct %s
                                        from %s
                                       where %s = %L
                                         and %s = ANY(g.points)
                                         and %s <> ALL(g.points)
                                         and %s <> %L) AS p) e2 ON (true)
      WHERE e1.p <> ''{}'' OR e2.p <> ''{}''
   )
   SELECT ARRAY(SELECT DISTINCT unnest(points)
     FROM graph
    ORDER BY 1)',
   p_toName,   p_tableName, p_modelIdName, p_modelId, p_fromName, p_name,
   p_toName,   p_tableName, p_modelIdName, p_modelId, p_fromName, p_toName,   p_toName,   p_name,
   p_fromName, p_tableName, p_modelIdName, p_modelId, p_toName,   p_fromName, p_fromName, p_name)
   INTO out_sa;

   RETURN array_reverse(out_sa);
END;
$func$ LANGUAGE plpgsql;

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION speedTest(p_num    bigint,
                                     p_search text)                                     
RETURNS void AS
$$
DECLARE 
   i      bigint;
   text_s text    := '1';
   arr_sa text[];
   res_s  text;
   res_i  bigint;
   t1     timestamp;
   t2     timestamp;

BEGIN 
   SELECT localtimestamp into t1;
   RAISE NOTICE 'start: %', CURRENT_TIMESTAMP;
   arr_sa[1] := '1';
   FOR i IN 2..p_num LOOP
      text_s := text_s || ',' || i::text;
      arr_sa[i] := i::text;
   END LOOP;
   SELECT localtimestamp into t2;
   RAISE NOTICE 'start: %', CURRENT_TIMESTAMP;
 

   --- Search in array -----

   SELECT localtimestamp into t1;
   res_s := doesNodeExist(arr_sa, p_search);
   SELECT localtimestamp into t2;
   RAISE NOTICE 'Search in array : %; %; %', t1, t2, res_s;

   SELECT localtimestamp into t1;
   res_i := strpos(text_s, p_search);
   SELECT localtimestamp into t2;
   RAISE NOTICE 'Search in text  : %; %; %', t1, t2, res_i;

RETURN;
END; 
$$ LANGUAGE 'plpgsql';

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------