package org.dspace.app.webui.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;

import org.dspace.core.ConfigurationManager;
import org.dspace.services.ConfigurationService;
import org.dspace.services.factory.DSpaceServicesFactory;
import org.dspace.storage.bitstore.DSBitStoreService;
import org.dspace.utils.DSpace;
import org.apache.log4j.Logger;

public class ModelProcess {
   
   /** log4j logger */
   private static final Logger log = Logger.getLogger(ModelProcess.class);
   
   
   public String getFilePath(String fileInfo_s,
                             String db_s) 
   {  
      // DSBitStoreService localStore = new DSpace().getServiceManager().getServicesByType(DSBitStoreService.class).get(0);      
      // File AssetStoreDir = localStore.getBaseDir();
      // String file_s = AssetStoreDir.getAbsolutePath();

      //..... Parse file info string ......
      
      String[] info_sa  = fileInfo_s.split(",");
      String assetDir_s = info_sa[0];               // C:\\dspace\\assetstore
      String baseURL_s  = info_sa[1];               // http://47.35.23.30:8080
      String context_s  = info_sa[2];               // /bettergrids
      String handle_s   = info_sa[3];               // 123456789/73
      String sequence_s = info_sa[4];               // 4
      String fileName_s = info_sa[5];               // R1-12.47-1.glm (encoded name)
      
      //..... Establish DB connection ......
      
      Connection conn = new DBConnection(db_s).getConn();
      
      
      
      System.getProperties().list(System.out);
      

         
    
      return "abc";
      
      //..... Parse URL. Get 
   
      
      
/*      
      select 'C:\dspace\assetstore\' ||
      substring(bit.internal_id, 1, 2) || '\' || 
      substring(bit.internal_id, 3, 2) || '\' || 
      substring(bit.internal_id, 5, 2) || '\' || 
      bit.internal_id 
from bitstream bit 
inner join bundle2bitstream b2b on b2b.bitstream_id = bit.uuid
inner join bundle b             on b.uuid           = b2b.bundle_id
inner join item2bundle i2b      on i2b.bundle_id    = b.uuid 
inner join handle h             on i2b.item_id      = h.resource_id 
where h.handle='123456789/73' 
 and bit.sequence_id =4;
  */    
      
      
   }
   
   public static boolean copyURItoTable(String uri_s)
   {
      
      
      
      return true;
   }
   
   public static boolean getModelFile (String url_s)
   {
      URL url;
      
      try {
         //..... Get URL content ......
                 
         url = new URL(url_s);
         URLConnection ucon = url.openConnection();
         
         //..... Open the stream into BufferedReader ......
         
         BufferedReader br = new BufferedReader(new InputStreamReader(ucon.getInputStream()));
         StringBuffer text_sb = new StringBuffer();
         String line_s;
         
         while ((line_s = br.readLine()) != null) {
            text_sb.append(line_s);
         }
         br.close();
      }
      catch (MalformedURLException em) {
         log.error(em);
         return false;
      }
      catch (IOException eio) {
         log.error(eio);
         return false;
      }
      return true;
   }
   
   
   

}
