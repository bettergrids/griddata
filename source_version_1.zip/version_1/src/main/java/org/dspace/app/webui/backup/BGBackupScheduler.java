package org.dspace.app.webui.backup;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;

public class BGBackupScheduler {

   private static final Logger log = Logger.getLogger(BGBackupScheduler.class);

   private ScheduledExecutorService executorService = Executors.newScheduledThreadPool(1);

   private final String   name;
   private final BGBackup backup;

   private final int startHour;
   private final int startMin;
   private final int startSec;

   private volatile boolean isBusy = false;
   private volatile ScheduledFuture<?> scheduledTask = null;

   private AtomicInteger completedTasks = new AtomicInteger(0);

   //..... Constructor ......
    
   public BGBackupScheduler(String   name,
                            BGBackup backup,
                            int      targetHour,
                            int      targetMin,
                            int      targetSec) 
   {
      this.name   = "Executor [" + name + "]";
      this.backup = backup;

      this.startHour = targetHour;
      this.startMin  = targetMin;
      this.startSec  = targetSec;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
    
   public void start() {
      scheduleNextTask(doTaskWork());
   }
   //----------------------------------------------------------------------------------------------
   
   public String getCurrentTime()
   {
      Calendar now = Calendar.getInstance();    // return current time     
      return new SimpleDateFormat("dd/MM/yyyy HH:mm").format(now.getTime());
   }
   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
    
   private Runnable doTaskWork() { 
      return () -> {
         log.info(name + " [" + completedTasks.get() + "] start: " + getCurrentTime());
         try {
            isBusy = true;
            backup.doBackup();
            log.info(name + " finish work in " + getCurrentTime());
         } 
         catch (Exception e) {
            log.error(name + " throw exception in " + getCurrentTime(), e);
         } 
         finally {
            isBusy = false;
         }
         scheduleNextTask(doTaskWork());
            
         log.info(name + " [" + completedTasks.get() + "] finish: " + getCurrentTime());
         log.info(name + " completed tasks: " + completedTasks.incrementAndGet());
      };
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   private void scheduleNextTask(Runnable task) 
   {
      log.info(name + " make schedule in " + getCurrentTime());
      long delay = computeNextDelay(startHour, startMin, startSec);
       
      log.info(name + " has delay in " + delay + " sec");
      scheduledTask = executorService.schedule(task, delay, TimeUnit.SECONDS);
   }
   //----------------------------------------------------------------------------------------------
   // Calculate delay for next execution
   //----------------------------------------------------------------------------------------------

   private static long computeNextDelay(int targetHour, 
                                        int targetMin, 
                                        int targetSec) 
   {
      LocalDateTime localNow        = LocalDateTime.now();
      ZoneId currentZone            = ZoneId.systemDefault();
      ZonedDateTime zonedNow        = ZonedDateTime.of(localNow, currentZone);
      ZonedDateTime zonedNextTarget = zonedNow.withHour(targetHour).withMinute(targetMin).withSecond(targetSec);
      
      if (zonedNow.compareTo(zonedNextTarget) > 0) {
         zonedNextTarget = zonedNextTarget.plusDays(1);
      }
      Duration duration = Duration.between(zonedNow, zonedNextTarget);
      return duration.getSeconds();
   }
   //----------------------------------------------------------------------------------------------
   // 
   //----------------------------------------------------------------------------------------------

   public void stop() 
   {
      log.info(name + " is stopping.");
      if (scheduledTask != null) {
         scheduledTask.cancel(false);
      }
      executorService.shutdown();
      log.info(name + " stopped.");
      
      try {
         log.info(name + " Wait Termination, start: isBusy [ " + isBusy + "]");
            
         // wait one minute to termination if busy and try again
         
         if (isBusy) {
            executorService.awaitTermination(1, TimeUnit.MINUTES);
         }
      } 
      catch (InterruptedException e) {
         log.error(name + " Wait Termination exception", e);
      } 
      finally {
         log.info(name + " Wait Termination, finish");
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public long getTimeForNextExecution()
   {
      return scheduledTask.getDelay(TimeUnit.MINUTES);
   }
   //----------------------------------------------------------------------------------------------
   //  Main function for testing
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {
      org.apache.log4j.BasicConfigurator.configure();

      BGBackup bp = new BGBackup();
      bp.setPrefix("123456789");
      
      BGBackupScheduler bs = new BGBackupScheduler("BG_Tester", bp, 15, 51, 0);
      bs.start();
   }
}
//======================================= End of File =============================================