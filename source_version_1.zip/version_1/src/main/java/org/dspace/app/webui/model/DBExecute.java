package org.dspace.app.webui.model;

import java.math.BigDecimal;
import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;

public class DBExecute implements DBTypes
{
   private static final Logger log = Logger.getLogger(DBExecute.class);
      
   //----------------------------------------------------------------------------------------------
   // 
   //----------------------------------------------------------------------------------------------
      
   public DBEntry execFunction(Connection         conn,
                               String             funcName,
                               ArrayList<Integer> types,
                               ArrayList<Object>  params)
   {
      int     sqlIdx;
      Object  valueObj   = null;

      //..... Prepare procedure string ......
      
      String sql_s = "SELECT * FROM " + funcName + "(";
      for (int i = 0; i < params.size(); i++) {
         sql_s += "?,";
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(",")) + ")";
      PreparedStatement stmt = null; 
 
      try {
         stmt = conn.prepareStatement(sql_s);

         //..... Setup parameters ......
         
         for (int i = 0; i < params.size(); i++) {
            sqlIdx   = i + 1;         
            valueObj = params.get(i);

            //..... Mapping ......
               
            switch(types.get(i)) {
            case typeInt:           stmt.setInt(sqlIdx,        (Integer)valueObj);     break;
            case typeBigInt:        stmt.setBigDecimal(sqlIdx, (BigDecimal)valueObj);  break;
            case typeSmallInt:      stmt.setInt(sqlIdx,        (Integer)valueObj);     break;
            case typeBoolean:       stmt.setBoolean(sqlIdx,    (Boolean)valueObj);     break; 
            case typeReal:          stmt.setFloat(sqlIdx,      (Float)valueObj);       break;
            case typeBouble:        stmt.setDouble(sqlIdx,     (Double)valueObj);      break;
            case typeNumeric:       stmt.setBigDecimal(sqlIdx, (BigDecimal)valueObj);  break;
            case typeChar:          stmt.setString(sqlIdx,     (String)valueObj);      break;
            case typeVarchar:       stmt.setString(sqlIdx,     (String)valueObj);      break;
            case typeLongVarchar:   stmt.setString(sqlIdx,     (String)valueObj);      break;
            case typeXML:           stmt.setSQLXML(sqlIdx,     (SQLXML)valueObj);      break;
            case typeDate:          stmt.setDate(sqlIdx,       (java.sql.Date)((Date)valueObj));      break;
            case typeTimestamp:     stmt.setTimestamp(sqlIdx,  (java.sql.Timestamp)((Date)valueObj)); break;        

            case typePgArray:       stmt.setArray(sqlIdx,      (Array)conn.createArrayOf("text", (String[])valueObj)); break;
               
            default:
                  log.error(types.get(i) + " not supported as a parameter type");
                  return null;
            }
         }
         conn.setAutoCommit(false);  
         
         //..... Get results ......   
         
         ResultSet rs = stmt.executeQuery();
         return parseResultSet((ResultSet)rs, null);
      }
      catch (SQLException sqle) {
         log.error("Error in processing procedure " + funcName + " : " + sqle.getMessage());
         System.out.println(sqle.getMessage());
      }
      catch (NullPointerException npe) {
         log.error("Error in PL/SQL procedure." + funcName + " : " + npe.getMessage());
      }
      catch (Exception e) {
         log.error("General Error." + funcName + " : " + e.getMessage());
         System.out.println(e.getMessage());
      }
      finally {
         if (stmt != null) {
            try {
               stmt.close();
            } 
            catch (SQLException sqle) {
               log.error("Error in getting/closing resultSet for the procedure " + funcName + " : " + sqle.getMessage());
            }
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public DBEntry execQuery(Connection conn,
                            String     sql_s,
                            String[]   exclusions)
   {
      Statement stmt = null; 
 
      try {
         stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql_s);
         return parseResultSet((ResultSet)rs, exclusions);
      }
      catch (SQLException sqle) {
         log.error("Error.execQuery: in SQL " + sql_s + " : " + sqle.getMessage());
         System.out.println(sqle.getMessage());
      }
      catch (NullPointerException npe) {
         log.error("Error in SQL: " + sql_s + " : " + npe.getMessage());
      }
      catch (Exception e) {
         log.error("General Error." + sql_s + " : " + e.getMessage());
         System.out.println(e.getMessage());
      }
      finally {
         if (stmt != null) {
            try {
               stmt.close();
            } 
            catch (SQLException sqle) {
               log.error("Error in getting/closing resultSet for the SQL " + sql_s + " : " + sqle.getMessage());
            }
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   protected DBEntry parseResultSet(ResultSet rs,
                                    String[]  eclusions)  // list of column which should not be returned
   {
      DBEntry entry = new DBEntry();
      DBTable tab   = new DBTable();
      entry.setTable(tab);
      
      try {
         ResultSetMetaData md = rs.getMetaData();
         int colNum = md.getColumnCount();         
         
         for (int i = 1; i <= colNum; i++) {
            String rsColName = md.getColumnName(i);           
            //rsColName = DBUtils.formColumnName(rsColName);  // format name for presentation
                       
            if (eclusions != null && DBUtils.contains(eclusions, rsColName)) continue;
                        
            DBColumn col = new DBColumn(rsColName, null, md.getColumnType(i), i - 1);
            tab.addColumn(i - 1, col);
         }
         while (rs.next()) {
            Map <Integer, Object> row = entry.newRow();

            for (Map.Entry<Integer, DBColumn> colEntry : tab.getColumns().entrySet()) {
               int rsIdx  = colEntry.getKey() + 1;   
               int colIdx = rsIdx - 1;        
               int typeIdx = tab.getColumn(colIdx).getTypeIdx();

               switch(typeIdx) {
               case typeInt:        
                  entry.setRowValue(row, colIdx, rs.getInt(rsIdx));   
                  break;
               case typeLong:        
                  entry.setRowValue(row, colIdx, rs.getBigDecimal(rsIdx));   
                  break;                  
               case typeDate:                  
                  Object value = rs.getTimestamp(rsIdx);
                  if (value != null) {
                     value = new java.util.Date(((java.sql.Timestamp)value).getTime());
                  }
                  entry.setRowValue(row, colIdx, value);
               case typePgArray:
                  Array arr = rs.getArray(rsIdx);
                  if (arr != null) {
                     entry.setRowValue(row, colIdx, (Object[])arr.getArray()); 
                  }
                  else {
                     entry.setRowValue(row, colIdx, null); 
                  }
                  break;
               case typeText:
                  entry.setRowValue(row, colIdx, rs.getString(rsIdx));   
                  break;
               case typeNumeric:
                  entry.setRowValue(row, colIdx, rs.getBigDecimal(rsIdx));   
                  break;
               default:
                  entry.setRowValue(row, colIdx, rs.getObject(rsIdx));   
                  break;
               }
            }
            entry.addRow(row);
         }
      }
      catch (SQLException e) {
         log.error("Error in parsing of resultSet: " + e.getMessage());
         return null;
      }      
      return entry;
   }
}
//======================================= End of Class ============================================ 
