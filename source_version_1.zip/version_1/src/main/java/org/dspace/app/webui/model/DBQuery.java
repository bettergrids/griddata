package org.dspace.app.webui.model;

import java.sql.Connection;
import java.util.ArrayList;

public class DBQuery implements DBTypes
{
   
   public static DBEntry getModelStat(String dbName,
                                      String modelId)
   {
      //..... get DB connection ......
      
      Connection conn = new DBConnection(dbName).getConn();
      
      //..... Prepare function params ......
      
      String funcName_s = "requestConnections";
      int paramNum      = 7;
      
      ArrayList<Integer> types = new ArrayList<Integer>();
      ArrayList<Object> params = new ArrayList<Object>();
      
      types.add(0, typeText);
      types.add(1, typeText);
      types.add(2, typeText);
      types.add(3, typeText);
      types.add(4, typeInt);
      types.add(5, typeText);
      types.add(6, typeInt);
      
      params.add(0, "R1-12.47-1");
      params.add(1, "node");
      params.add(2, "meter");
      params.add(3, "<");
      params.add(4, 500);
      params.add(5, "<");
      params.add(6, 10);
      
      DBExecute exec = new DBExecute();
      
      DBEntry entry = exec.execFunction(conn, funcName_s, types, params);
      
      //System.out.print(entry.toJSPString());
      
      
      return entry;
   }
   
   
   
}
