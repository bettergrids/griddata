package org.dspace.app.webui.model;

import java.sql.Connection;

public class DBFunctions implements DBTypes
{
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodeTypeList(String modelId_s,
                                         String modelIdName_s,
                                         String typeName_s,
                                         String tableName_s,
                                         String dbName_s)
   {
      Connection conn = new DBConnection(dbName_s).getConn();      // get DB connection
   
      //..... Prepare SQL ......
   
      String sql_s = "SELECT " + typeName_s + ", count(*) cnt FROM " + tableName_s +
                     ((modelId_s == null) ? "" : " WHERE " + modelIdName_s + "='" + modelId_s + "'") +
                     " GROUP BY " + typeName_s + " ORDER BY cnt DESC";
   
      DBExecute exec = new DBExecute();
   
      DBEntry entry = exec.execQuery(conn, sql_s, null);
      
      entry.setNumericColumns();    // set column types numeric/integer, based on data
      
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodeTypeList(String modelId_s)
   {
      return getNodeTypeList(modelId_s, "modelid", "nodetype", "_gridlab", "graph");
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodesByType(String   modelId_s,
                                        String   type_s,
                                        String[] exclusions, 
                                        String   nodeName_s,
                                        String   modelIdName_s,
                                        String   typeName_s,
                                        String   tableName_s,
                                        String   dbName_s)
   { 
      Connection conn = new DBConnection(dbName_s).getConn();      // get DB connection
      
      //..... Prepare SQL ......
      
      String sql_s = "SELECT * FROM " + tableName_s + " WHERE " +
                     ((modelId_s == null) ? "" :  modelIdName_s + "='" + modelId_s + "' AND ") +
                     typeName_s + "='" + type_s + "' ORDER BY " + nodeName_s;
      
      DBExecute exec = new DBExecute();
      
      DBEntry entry = exec.execQuery(conn, sql_s, exclusions);
      
      entry.setCompactTable();      // remove columns with all null values
      entry.setNumericColumns();    // set column types numeric/integer, based on data
      
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodesByType(String   modelId_s,
                                        String   type_s,
                                        String[] exclusions)
   {
      return getNodesByType(modelId_s, type_s, exclusions, "_name", "modelid", "nodetype", "_gridlab", "graph");
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodesByType(String   modelId_s,
                                        String   type_s)
   {
      return getNodesByType(modelId_s, type_s, calcColumns, "_name", "modelid", "nodetype", "_gridlab", "graph");
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodeStatistics(String  modelId_s,
                                           String  node_s,
                                           String  nodeName_s,
                                           String  typeName_s,
                                           String  parentName_s,
                                           String  linksName_s,
                                           String  distName_s,
                                           String  hopsName_s,
                                           String  inclusions_s,
                                           String  modelIdName_s,
                                           String  tableName_s,
                                           String  dbName_s)
   {
      Connection conn = new DBConnection(dbName_s).getConn();      // get DB connection
      
      //..... Prepare SQL ......
      
      String sql_s = "SELECT * FROM (WITH t1 AS " + 
                     "(SELECT unnest(" + linksName_s + ") nodes, unnest(" + hopsName_s + 
                     ") hops, unnest(" + distName_s + ") distance FROM " + tableName_s + 
                     " WHERE " + ((modelId_s == null) ? "" :  modelIdName_s + "='" + modelId_s + "' AND ") +
                     nodeName_s + "='" + node_s + "') " +
                     "SELECT t1.nodes, t2." + typeName_s + ", t1.hops, t1.distance, null::text childs FROM t1, "  + 
                     tableName_s + " t2 WHERE t1.nodes =" + "t2." + nodeName_s +
                     " UNION " +
                     "SELECT unnest(" + inclusions_s + ") nodes, " + typeName_s + 
                     ", 0 hops, 0 distance,'Object Included ' childs FROM " + tableName_s + 
                     " WHERE " + ((modelId_s == null) ? "" :  modelIdName_s + "='" + modelId_s + "' AND ") +
                     nodeName_s + "='" + node_s + "') t4 ORDER BY distance"; 
      
      DBExecute exec = new DBExecute();
      
      DBEntry entry = exec.execQuery(conn, sql_s, null);
      
      entry.setNumericColumns();    // set column types numeric/integer, based on data
      
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodeStatistics(String modelId_s,
                                           String node_s)
   {
      return getNodeStatistics(modelId_s, node_s, "_name", "nodetype", "parent", "_connections", 
                               "_distances", "_hops", "inclusions", "modelid", "_gridlab", "graph");
   }

}
//======================================= End of Class ============================================