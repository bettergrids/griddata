package org.dspace.app.webui.backup;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

/*-------------------------------------------------------------------------------------------------
 1. Backup AIP: 
    - Full repository: 
      dspace packager -r -a -f -t AIP -e admin@bettergrids.org <file path>

 2. Backup metadata: 
    ./dspace metadata-export -a -f <file>, where <file> is a cvs file containing metadata 
    
    Import metadata: As an admin -> Content->Import metadata
       
 3. Export usage statistics data from Solr for back-up purpouses:
    dspace solr-export-statistics 

 4. Dump the entire database and schema:
    pg_dump -h localhost -U dspace -d dspace -v -c --if-exists > <sql file path>

 5. Backup critical folders:
    - ./dspace/config
    - ./dspace/assetstore
    - ./dspace/solr/statistics

---------------------------------------------------------------------------------------------------*/

public class BGBackup implements BGBackupCommands
{
   private static final Logger log = Logger.getLogger(BGBackup.class);
   
   private static String userEmail     = emailDefault;
   private static String archiveFolder = archivePathDefault;
   private static String dspaceHome    = dspaceHomeDefault;

   private static String configFolder  = dspaceConfigFolder;
   private static String solrFolder    = dspaceSolrFolder;
   private static String assetFolder   = dspaceAssetFolder;
   
   private static String configArchive = dspaceConfigDefault;
   private static String solrArchive   = dspaceSolrDefault;
   private static String assetArchive  = dspaceAssetDefault;
   
   private static String prefix        = prefixDefault;
   
   public static String getPrefix() {
      return prefix;
   }
   
   public static String getDspaceHome() {
      return dspaceHome;
   }

   public static void setDspaceHome(String dspaceHome) {
      BGBackup.dspaceHome = dspaceHome;
   }

   public static String getAssetFolder() {
      return assetFolder;
   }

   public static void setAssetFolder(String assetFolder) {
      BGBackup.assetFolder = assetFolder;
   }

   public static void setPrefix(String prefix) {
      BGBackup.prefix = prefix;
   }

   public static String getAipFileName() {
      return aipFileName;
   }

   public static void setAipFileName(String aipFileName) {
      BGBackup.aipFileName = aipFileName;
   }

   private static String aipFileName   = aipPathDefault;


   public static String getUserEmail() {
      return userEmail;
   }

   public static void setUserEmail(String userEmail) {
      BGBackup.userEmail = userEmail;
   }

   public static String getConfigFolder() {
      return configFolder;
   }

   public static void setConfigFolder(String configFolder) {
      BGBackup.configFolder = configFolder;
   }

   public static String getSolrFolder() {
      return solrFolder;
   }

   public static void setSolrFolder(String solrFolder) {
      BGBackup.solrFolder = solrFolder;
   }

   public static String getConfigArchive() {
      return configArchive;
   }

   public static void setConfigArchive(String configArchive) {
      BGBackup.configArchive = configArchive;
   }

   public static String getSolrArchive() {
      return solrArchive;
   }

   public static void setSolrArchive(String solrArchive) {
      BGBackup.solrArchive = solrArchive;
   }
   
   public static String getAssetArchive() {
      return assetArchive;
   }

   public static void setAssetArchive(String assetArchive) {
      BGBackup.assetArchive = assetArchive;
   }


   private boolean muteMode = true;

   public boolean isMuteMode() {
      return muteMode;
   }

   public void setMuteMode(boolean muteMode) {
      this.muteMode = muteMode;
   }

   public static String getArchiveFolder() {
      return archiveFolder;
   }

   public static void setArchiveFolder(String archiveFolder) {
      BGBackup.archiveFolder = archiveFolder;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean doBackup() 
   {
      boolean status = true;
      
      String targetFolder = createTargetFolder();
      
      //..... Backaup DSpace AIP (full repository) ......
      
      String aipExportCmd = getFullAIPCommand(targetFolder, userEmail, prefix);
      status = execCommand(aipExportCmd);
      if (status == false) return status;
      
      //..... Backup DSpace PostgreSQL DB ......      
      
      String dbExportCmd   = getFullDBExportCommand(targetFolder);
      status = execCommand(dbExportCmd);
      if (status == false) return status;
      
      //..... Archive folders ......
      
      status = backupFolders(targetFolder);
      
      return status;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public String createTargetFolder(String archivePath)
   {      
      Calendar now = Calendar.getInstance();    
      
      SimpleDateFormat fmt = new SimpleDateFormat("dd-MM-yyyy-HH");
      String folderPath = archivePath + File.separator + fmt.format(now.getTime());
      
      if (createDirectory(folderPath) == false) {
         return null;
      }
      return folderPath;
   }   
   //----------------------------------------------------------------------------------------------
   
   public String createTargetFolder()
   {      
      return createTargetFolder(archivePathDefault);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean backupDB(String dbName)
   {
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean backupFolders(String targetFolder)
   {
      boolean status;
      String target = targetFolder + File.separator;
      
      BGArchiver ba = new BGArchiver();
      status = ba.zipFolder(configFolder, target + configArchive);
      if (status == false) return status;
      status = ba.zipFolder(assetFolder,  target + assetArchive);
      if (status == false) return status;
      
      // Solr directory is actively used by dsapce, so some file are "in use", so zipFolder 
      // generate exceptions. To fix it first copy solr directory to the destination folder
      // and pack it.

      String solrCopyFolder = targetFolder + File.separator + dspaceStatName;
      if (createDirectory(solrCopyFolder) == false) {
         return false;
      }
      try {
         File solrDir   = new File(solrFolder);
         File targetDir = new File(solrCopyFolder); 

         FileUtils.copyDirectory (solrDir, targetDir);
      } 
      catch (Exception e) {
         log.error("cannot copy: " + solrFolder + " to " + target + "; Exception: " + e.getMessage());
         return false;
      }
      status = ba.zipFolder(solrCopyFolder,  target + solrArchive);
      
      //..... Delete temporary Solr directory ......
      
      try {
         File solrCopyDir = new File(solrCopyFolder);
         FileUtils.deleteDirectory(solrCopyDir);
      }
      catch (Exception e) {
         log.error("cannot delete directory: " + solrCopyFolder + "; Exception: " + e.getMessage());
         return false;
      }
      return status;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public boolean execCommand(String cmd)
   {
      try {     
         ProcessBuilder builder = null;
         if (BGSystem.getOSType() == BGSystem._WINDOWS) {
            builder = new ProcessBuilder("cmd.exe", "/C", cmd);
         }
         else if (BGSystem.getOSType() == BGSystem._LINUX) {
            builder = new ProcessBuilder(cmd);
         }
         else {
            builder = new ProcessBuilder(cmd);
         }
         builder.redirectErrorStream(true);
         
         Process process = builder.start();
         
         BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
         BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));

         //..... Read command standard output ......
         
         String s;
         while ((s = stdInput.readLine()) != null) {
            if (muteMode == false) {
               System.out.println(s);
            }
         }
         //..... Read command errors ......
         
         while ((s = stdError.readLine()) != null) {
            if (muteMode == false) {
               System.err.println(s);
            }
         }
         //..... Finalize process ......
         
         process.waitFor();
         log.info("exit: " + process.exitValue() + "; cmd: " + cmd);
         process.destroy();
      } 
      catch (Exception e) {
         log.error("Executing command: " + cmd + "; Exception: " + e.getMessage());
         return false;
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private boolean createDirectory(String folderPath)
   {
      Path path = Paths.get(folderPath);
      if (!Files.exists(path)) {
         try {
            Files.createDirectories(path);
         }
         catch(Exception e) {
            log.error("Cannot create directory: " + folderPath + "; Exception: " + e.getMessage());
            return false;
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //  Main function for testing
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {
      org.apache.log4j.BasicConfigurator.configure();
      
      setPrefix("123456789");
      
      BGBackup bp = new BGBackup();
      bp.doBackup();
      log.info("Done!");
   }
}
//======================================= End of File =============================================