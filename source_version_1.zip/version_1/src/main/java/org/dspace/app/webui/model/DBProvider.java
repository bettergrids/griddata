package org.dspace.app.webui.model;

public class DBProvider 
{   
   //..... PostgreSQl settings ......
      
   static final String DSpaceAttr = "dspace";
   static final String DSpaceUser = "dspace";
   static final String DSpacePwd  = "dspace";
   static final String DSpaceDB   = "dspace";
   
   static final String GraphAttr  = "graph";
   static final String GraphUser  = "graph";
   static final String GraphPwd   = "graph";
   static final String GraphDB    = "graph";   
   
   static final String pgipaddr   = "localhost"; 
   static final int    pgport     = 5432; 
   
   //..... PostgreSQL connection parameters ......
   
   String database;
   String user;
   String pwd;
   String ipaddr;
   int    port;
   
   static String className = "org.postgresql.Driver";
   
   DBProvider(String db_s)
   {
      if (db_s.equals(DSpaceAttr)) {
         setUser(DSpaceUser);
         setPwd(DSpacePwd);
         setDatabase(DSpaceDB);
      }
      else if (db_s.equals(GraphAttr)) {
         setUser(GraphUser);
         setPwd(GraphPwd);
         setDatabase(GraphDB);
      }
      setIpaddr(pgipaddr);
      setPort(pgport);
      
   }
   //..... Getters/Setters ......
   
   public static String getClassName() {
      return className;
   }
   public static void setClassName(String _className) {
      className = _className;
   }
   public String getDatabase() {
      return database;
   }
   public void setDatabase(String database) {
      this.database = database;
   }
   public String getUser() {
      return user;
   }
   public void setUser(String user) {
      this.user = user;
   }
   public String getPwd() {
      return pwd;
   }
   public void setPwd(String pwd) {
      this.pwd = pwd;
   }
   public String getIpaddr() {
      return ipaddr;
   }
   public void setIpaddr(String ipaddr) {
      this.ipaddr = ipaddr;
   }
   public int getPort() {
      return port;
   }
   public void setPort(int port) {
      this.port = port;
   }  
   public String getConnURL() {
      return "jdbc:postgresql://" + ipaddr + ":" + port + "/" + database;
   }
}
