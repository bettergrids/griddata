package org.dspace.app.webui.model;

import java.sql.Types;

public interface DBTypes 
{
   //..... List of columns created by PostgreSQL Graph functions ......
   
   final static String[] calcColumns = {"_oid", "_paths", "_connections", "_distances", "_hops", "inclusions", 
                                        "nodetype", "modelid"}; 
   
   final static String[] nodeNames   = {"_name", "parent", "_from", "_to", "nodes"};
   
   
   //..... Java to PostgreSQL type mapping ......
   
   final static int typeInt         = Types.INTEGER;
   final static int typeLong        = -5;
   final static int typeBigInt      = Types.BIGINT;
   final static int typeSmallInt    = Types.SMALLINT;
   final static int typeBinary      = Types.BINARY;
   final static int typeLongBinary  = Types.LONGVARBINARY;
   final static int typeBit         = Types.BIT;
   final static int typeBoolean     = Types.BOOLEAN; 
   final static int typeReal        = Types.REAL;
   final static int typeBouble      = Types.DOUBLE;
   final static int typeNumeric     = Types.NUMERIC;

   final static int typeChar        = Types.CHAR;
   final static int typeVarchar     = Types.VARCHAR;
   final static int typeText        = Types.VARCHAR;
   final static int typeLongVarchar = Types.LONGNVARCHAR;
   
   final static int typeDate        = Types.DATE;
   final static int typeTimestamp   = Types.TIMESTAMP;
   
   final static int typeXML         = Types.SQLXML;
   final static int typeRefCursor   = Types.OTHER;
   
   final static int typePgArray     = Types.ARRAY;
   final static int typeTextArray   = Types.ARRAY;
   final static int typeBigIntArray = Types.ARRAY;
   final static int typeIntArray    = Types.ARRAY;
}
