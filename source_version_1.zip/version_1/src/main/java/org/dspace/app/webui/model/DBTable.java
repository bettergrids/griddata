package org.dspace.app.webui.model;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;

public class DBTable
{
   private static final Logger log = Logger.getLogger(DBTable.class);
   private static final int NEGATIVE_RESULT = -999;
   
   private Map<Integer, DBColumn> columns = new LinkedHashMap<Integer,DBColumn>();
   
   public Map<Integer, DBColumn> getColumns() {
      return columns;
   }

   public void setColumns(Map<Integer, DBColumn> columns) {
      this.columns = columns;
   }
  
   protected DBTable copy()
   {
      final DBTable newTable = new DBTable();
      for (Map.Entry<Integer, DBColumn> entry : this.columns.entrySet()) {
         newTable.columns.put(entry.getKey(), entry.getValue().copy());
      }
      return newTable;
   }
   
   public void addColumn (int idx, DBColumn column)
   {
      columns.put(idx, column);
   }
   
   public int findColumnIdx(String name_s)
   {
      for (Map.Entry<Integer, DBColumn> entry : columns.entrySet()) {
         int idx = entry.getKey();
         if (columns.get(idx).getName().equalsIgnoreCase(name_s)) {
            return idx;
         }
      }
      return NEGATIVE_RESULT;
   }
   
   public boolean deleteColumn(int colIdx)
   {
      if (columns == null) return false;    
      try {
         columns.remove(colIdx);
         return true;
      }
      catch (Exception e) {
         log.error("ERROR.deleteColumn: Column with internal index " + colIdx + "does not exists.");
      }
      return false;
   }
   
   public boolean deleteColumn(String name_s)
   {
      int colIdx = findColumnIdx(name_s);
      if (colIdx >= 0) {
         return deleteColumn(colIdx);
      }
      return false;
   }
   
   public DBColumn getColumn(int idx) 
   {
      return columns.get(idx);
   }
   
   public int getColumnNum()
   {
      return columns.size();
   }
}
//======================================= End of Class ============================================
