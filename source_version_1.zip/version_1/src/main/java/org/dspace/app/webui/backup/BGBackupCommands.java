package org.dspace.app.webui.backup;

import java.io.File;

public interface BGBackupCommands 
{
   static final String archivePathDefault   = "C:\\tmp_share";
   static final String dspaceHomeDefault    = "C:\\dspace";
   
   static final String dspaceStatName       = "statistics";
   static final String dspaceConfigFolder   = dspaceHomeDefault + File.separator + "config";
   static final String dspaceSolrFolder     = dspaceHomeDefault + File.separator + "solr" + File.separator + dspaceStatName;
   static final String dspaceAssetFolder    = dspaceHomeDefault + File.separator + "assetstore";
   
   static final String dspaceConfigDefault  = "configArchive.zip";
   static final String dspaceSolrDefault    = "solrStatArchive.zip";
   static final String dspaceAssetDefault   = "assetArchive.zip";
   
   static final String prefixDefault        = "1000";
   static final String aipPathDefault       = "dspace_full.zip";
   static final String emailDefault         = "admin@bettergrids.org";
   static final String fullAIPTemplate      = "dspace packager -u -d -a -t AIP -e " + emailDefault + " -i " +
                                              prefixDefault + "/0 " + archivePathDefault + File.separator +
                                              aipPathDefault;
   
   static final String dbNameDefault        = "dspace";
   static final String dbUserDefault        = "dspace";
   static final String dbPassDefault        = "dspace";
   static final String dbPathDefault        = "dspace_DB_dump.sql";

   static final String fullDBExportTemplate = "pg_dump --dbname=postgresql://" + dbUserDefault + ":" + 
                                              dbPassDefault + "@127.0.0.1:5432/" + dbNameDefault +
                                              " -v -c --if-exists >" + archivePathDefault + File.separator +
                                              dbPathDefault;        
   
   //----------------------------------------------------------------------------------------------
   
   default String getFullAIPCommand()
   {
      return fullAIPTemplate;
   }
   //----------------------------------------------------------------------------------------------
   
   default String getFullAIPCommand(String aipArchivePath,
                                    String email,
                                    String prefix)
   {
      String res_s = fullAIPTemplate.replace(archivePathDefault, aipArchivePath);
      res_s        = res_s.replace(emailDefault, email);
      res_s        = res_s.replace(prefixDefault, prefix);

      return res_s;
   }
   //----------------------------------------------------------------------------------------------
   
   default String getFullAIPCommand(String aipArchiveName)
   {
      return getFullAIPCommand(aipArchiveName, emailDefault, prefixDefault);
   }
   //----------------------------------------------------------------------------------------------
   
   default String getFullDBExportCommand(String dbPath,
                                         String dbUser,
                                         String dbPass,
                                         String dbName) 
   {
      String res_s = fullDBExportTemplate.replace(dbNameDefault, dbName);
      res_s        = res_s.replace(dbUserDefault, dbUser);
      res_s        = res_s.replace(dbPassDefault, dbPass);
      res_s        = res_s.replace(dbPathDefault, dbPath);
      
      return res_s;
   }
   //----------------------------------------------------------------------------------------------
   
   default String getFullDBExportCommand(String dbPath)
   {
      return fullDBExportTemplate.replace(archivePathDefault, dbPath);
   }
   //----------------------------------------------------------------------------------------------
   
   default String getFullDBExportCommand()
   {
      return fullDBExportTemplate;
   }
}
//====================================== End of File ==============================================