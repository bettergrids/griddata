package org.dspace.app.webui.model;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

public class DBEntry implements DBTypes
{
   private static final Logger log = Logger.getLogger(DBEntry.class);
   
   DBTable table;
   private List <Map <Integer, Object>>rows = new ArrayList<Map <Integer, Object>>();
   
   public List<Map <Integer, Object>> getRows() {
      return rows;
   }

   public void setRows(List<Map <Integer, Object>> rows) {
      this.rows = rows;
   }

   public DBTable getTable() {
      return table;
   }
   
   public void setTable(DBTable table) {
      this.table = table;
   }

   public Map<Integer, Object> newRow ()
   {
      return new HashMap<Integer, Object>();
   }
   
   public void addRow(Map<Integer, Object> row)
   {
      rows.add(row);
   }
   
   public void addNewRow()
   {
      rows.add(newRow ());
   }
  /* 
   public List <Map <Integer, Object>> copy()
   {
      List <Map <Integer, Object>>rows = new ArrayList<Map <Integer, Object>>();
      
   
   }
*/   
   public void setRowValue(Map<Integer, Object> row, 
                           int                  columnIdx, 
                           Object               value)
   {
      row.put(columnIdx, value);
   }
   
   public Object getRowValue(Map<Integer, Object> row, 
                             int                  columnIdx)
   {
      return row.get(columnIdx);
   }

   public Object getValue(int rowIdx, int columnIdx)
   {
      return rows.get(rowIdx).get(columnIdx);
   }
   
   public Object copyValue(Map<Integer, Object> row, 
                           int          columnIdx)
   {
      Object value = getRowValue(row, columnIdx);
      if (value == null) return null;
      
      if (value instanceof String) {
         return new String((String)value);
      }
      else if (value instanceof Integer) {
         return new Integer((Integer)value);
      }
      else if (value instanceof BigDecimal) {
         return new BigDecimal(((BigDecimal)value).toString());
      }
      else if (value instanceof Date) {
         Date newDate = new Date();
         newDate.setTime(((Date)value).getTime());
         return newDate;
      }
      else if (value instanceof String[]) {
         return String.join(";", (String[])value);
      }
      else if (value instanceof Integer[]) {
         return objArrayToString((Object[])value);
      }      
      else if (value instanceof BigDecimal[]) {
         return objArrayToString((Object[])value);
      }
      else {
         return value.toString();
      }
   }
   
   public String getStringValue(int rowIdx, int columnIdx)
   {
      Object value = getValue(rowIdx, columnIdx);      
      if (value == null) return "";
      
      String val_s = null;
      int typeIdx  = getTable().getColumn(columnIdx).getTypeIdx();
      
      switch (typeIdx) {
      case typePgArray: 
         if (value instanceof String[]) {
            val_s = String.join(";", (String[])value);
         }
         else {
            val_s = objArrayToString((Object[])value);
         }
         break;
      case typeDate:
         SimpleDateFormat form = new SimpleDateFormat("dd/MM/yyyy"); 
         val_s = form.format((Date)value);
         break;
      default:
         val_s = value.toString();
      }
      return DBUtils.formColumnName(val_s);
   }
   
   public int getRowNum()
   {
      return rows.size();
   }
   
   public DBTable getCompactTable()
   {
      if (table == null) return null;
      try {
         DBTable tabCompact = new DBTable();
         
         for (Map.Entry<Integer, DBColumn> colEntry : table.getColumns().entrySet()) {
            int colIdx = colEntry.getKey();
            
            boolean empty = true;
            for (Map <Integer, Object> row : rows) {   
               if (getRowValue(row, colIdx) != null) {
                  empty = false;
                  break;              
               }
            }
            if (empty == false) {
               tabCompact.addColumn(colIdx, colEntry.getValue().copy());
            }
         }
         return tabCompact;
      } 
      catch (NullPointerException en) {
         en.printStackTrace();
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   
   public void setCompactTable()
   {
      this.setTable(getCompactTable());
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public String toJSPString()
   {
      StringBuffer line_sb = new StringBuffer("idx\t");
      
      //..... Headers ......
      
      for (Map.Entry<Integer, DBColumn> colEntry : table.getColumns().entrySet()) {
         DBColumn column = colEntry.getValue();         
         line_sb.append(column.getName() + "\t\t");
      }
      line_sb.append("<br/>");
      
      //..... Data ......
      
      int idx = 0;
      for (int rowIdx = 0; rowIdx < rows.size(); rowIdx++) {
         line_sb.append(idx++ + "\t");
         
         for (Map.Entry<Integer, DBColumn> colEntry : table.getColumns().entrySet()) {
            line_sb.append(getStringValue(rowIdx, colEntry.getKey()) + "\t");
         }
         line_sb.append("<br/>");
      }
      return line_sb.toString();
   }
   //----------------------------------------------------------------------------------------------

   public void printTableContent(DBTable tab)
   {
      StringBuffer line_sb = new StringBuffer("idx\t");   
      
      //..... Headers ......
      
      for (Map.Entry<Integer, DBColumn> colEntry : tab.getColumns().entrySet()) {
         DBColumn column = colEntry.getValue();         
         line_sb.append(column.getName() + "\t\t");
      }
      System.out.println(line_sb.toString());
      
      int idx = 0;
      for (int rowIdx = 0; rowIdx < rows.size(); rowIdx++) {
         line_sb = new StringBuffer().append(idx++ + "\t");
         
         for (Map.Entry<Integer, DBColumn> colEntry : tab.getColumns().entrySet()) {
            line_sb.append(getStringValue(rowIdx, colEntry.getKey()) + "\t");
         }
         System.out.println(line_sb.toString());
      }
   }
   //----------------------------------------------------------------------------------------------
   
   public void printCompactContent()
   {
      printTableContent(getCompactTable());
   }
   
   public void printContent()
   {
      printTableContent(table);
   }
   //----------------------------------------------------------------------------------------------
     
   public String objArrayToString(Object[] arr)
   {
      if (arr == null) return "";
      StringBuffer val_sb = new StringBuffer();
      
      for (int i = 0; i < arr.length; i++) {
         if (arr[i] != null) {
            val_sb.append(arr[i].toString());
         }
      }
      return val_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   // Check is given text column numeric
   //----------------------------------------------------------------------------------------------
   
   protected void setNumericColumns()
   {
      if (rows == null || rows.isEmpty() || table == null) return;
      
      for (Map.Entry<Integer, DBColumn> colEntry : getTable().getColumns().entrySet()) {
         if (colEntry.getValue().getTypeIdx() != typeText) continue;  
         
         int     colIdx      = colEntry.getKey();
         boolean isNumeric_b = true;
         boolean isInteger_b = true;
         
         for (int rowIdx = 0; rowIdx < rows.size(); rowIdx++) {
            String val_s = (String)getValue(rowIdx, colIdx);
            if (val_s == null) continue;
            
            if (DBUtils.isNumeric(val_s) == false) {
               isNumeric_b = false;
               isInteger_b = false;
               break;
            }
            else if (!isInteger_b || DBUtils.isInteger(val_s) == false){
               isInteger_b = false;
            }
         }
         if (isNumeric_b == true) {
            if (isInteger_b == true) {
               colEntry.getValue().setTypeIdx(typeLong);
            }
            else {
               colEntry.getValue().setTypeIdx(typeNumeric);
            }
         }
      }
   }
}
//======================================= End of Class ============================================