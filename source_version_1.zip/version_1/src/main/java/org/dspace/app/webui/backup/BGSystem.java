package org.dspace.app.webui.backup;

import java.util.Locale;

public class BGSystem {
 
   public static final String _WINDOWS = "Windows";
   public static final String _MACOS   = "Mac";
   public static final String _LINUX   = "Linux";
   public static final String _OTHER   = "Other";

   protected static String nameOS = null;    // cached result of OS detection

   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String getOSType() 
   {
      if (nameOS == null) {
         String OS = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
     
         if ((OS.indexOf(_MACOS.toLowerCase()) >= 0) || (OS.indexOf("darwin") >= 0)) {
            nameOS = _MACOS;
         }
         else if (OS.indexOf(_WINDOWS.toLowerCase()) >= 0) {
            nameOS = _WINDOWS;
         } 
         else if (OS.indexOf(_LINUX.toLowerCase()) >= 0) {
            nameOS = _LINUX;
         } 
         else {
            nameOS = _OTHER;
         }
      }
      return nameOS;
   }
}




