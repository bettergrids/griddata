package org.dspace.app.webui.model;

import java.io.File;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import org.dspace.core.ConfigurationManager;

public class ModelTest implements DBTypes
{

   public static void main(String[] args) 
   {
      // String url_s = "http://47.35.23.30:8080/bettergrids/bitstream/123456789/73/4/R1-12.47-1.glm";
      
      // ModelProcess mdp = new ModelProcess();
      
      
      //String res_s = mdp.getFilePath("C:\\dspace\\assetstore,http://47.35.23.30:8080,/bettergrids,123456789/73,4,R1-12.47-1.glm");
      
      //ArrayList<String> a = new ArrayList<String>();
      
      //a.add(0,  "ABC");
      //a.add(1,  "123");
      //a.add(2,  "777");
      
      //a.remove(1);
      
//      String[] arr = {"abc,efg,drg", "123,34567,3345", "comex, top, syntex"};     
//      String val_s = String.join(";", (String[])arr); 
      
      //BigDecimal[] bg = {new BigDecimal(123.456), new BigDecimal(77.22), new BigDecimal(99.45)}
      //String val_s = bg.toString();
      
      String a = "-12890";
      boolean is = DBUtils.isFormatNumeric(a);
      is = DBUtils.isNumeric(a);
      is = DBUtils.isInteger(a);
      
      
      
      //String name_s = "_node_prod_25-1._23";
      //name_s = DBUtils.formColumnName(name_s);
      
      //DBEntry entry = DBFunctions.getNodeTypeList(null);
      //DBEntry entry = DBFunctions.getNodesByType("R1-12.47-1", "capacitor");
      
      //DBEntry entry = DBFunctions.getNodesByType("R1-12.47-1", "regulator", calcColumns);
      //DBEntry entry = DBFunctions.getNodesByType("R1-12.47-1", "node", calcColumns);
      DBEntry entry = DBFunctions.getNodesByType("R1-12.47-1", "node");
      //DBEntry entry = DBFunctions.getNodesByType("R1-12.47-1", "capacitor");
      
      //DBEntry entry = DBFunctions.getNodesByType("R1-12.47-1", "line_configuration");
      //DBEntry entry = DBFunctions.getNodesByType("R1-12.47-1", "transformer_configuration");
      
      //DBEntry entry = DBFunctions.getNodeStatistics("GC-12.47-1","GC-12-47-1_node_21");
      entry.setNumericColumns();
      
      System.out.println("Table: " + entry.getTable().getColumnNum());
      System.out.println("Table: " + entry.getCompactTable().getColumnNum());
      entry.printCompactContent();
      
      
      
     // entry.printContentWithValues();
      
      
     //DBExecute dbexec = new DBExecute();
     //dbexec.executeFunction("graph", "");
     //entry = DBQuery.getModelStat("graph", "R1-12.47-1");
    
     //DBTable tab1 = entry.getTable();
     
     //try {
      //DBTable tab2 = (DBTable)tab1.clone();
      
     //} 
    // catch (CloneNotSupportedException e) {
      // TODO Auto-generated catch block
     // e.printStackTrace();
    // }
     
     
    // String abc = entry.getValue(1, 2).toString(); 
    // System.out.println(abc);

   }
   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public boolean executeTest(String dbname_s,
                              String query_s) 
   {
      //..... get DB connection ......
      
      Connection conn = new DBConnection(dbname_s).getConn();
      
      //..... Prepare function params ......
      
      String funcName_s = "requestConnections";
      
      ArrayList<Integer> types = new ArrayList<Integer>();
      ArrayList<Object> params = new ArrayList<Object>();
      
      types.add(0, typeText);
      types.add(1, typeText);
      types.add(2, typeText);
      types.add(3, typeText);
      types.add(4, typeInt);
      types.add(5, typeText);
      types.add(6, typeInt);
      
      params.add(0, "R1-12.47-1");
      params.add(1, "node");
      params.add(2, "meter");
      params.add(3, "<");
      params.add(4, 500);
      params.add(5, "<");
      params.add(6, 10);
      
      DBExecute exec = new DBExecute();
      DBEntry entry = exec.execFunction(conn, funcName_s, types, params);
      
      //..... Results ......
      
      entry.printContent();
      
      try {
         conn.commit();
         conn.setAutoCommit(true);
         conn.close();
      } 
      catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      return true;
   }


}
