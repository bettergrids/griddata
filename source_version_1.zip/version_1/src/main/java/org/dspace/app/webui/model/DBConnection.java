package org.dspace.app.webui.model;

import java.sql.*;
import java.util.Properties;
import org.apache.log4j.Logger;

public class DBConnection extends DBProvider  
{
   private static final Logger log = Logger.getLogger(DBConnection.class);
   
   Connection conn = null;
   
   DBConnection (String db_s)
   {
      super(db_s);
   }
   
   public Connection getConn() 
   {
      try {
         Class.forName(getClassName());
         
         Properties props = new Properties();
         props.setProperty("user",     getUser());
         props.setProperty("password", getPwd());
         //props.setProperty("ssl","true");
         conn = DriverManager.getConnection(getConnURL(), props);
      }
      catch (ClassNotFoundException e) {
        log.error(e.getMessage());
        return null;
      }
      catch (SQLException e) {
        log.error(e.getMessage());
        return null;
      }      
      return conn;  
   }   
}
