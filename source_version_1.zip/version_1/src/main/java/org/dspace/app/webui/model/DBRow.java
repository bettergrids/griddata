package org.dspace.app.webui.model;

import java.util.ArrayList;
import java.util.List;

public class DBRow 
{
   DBTable  table;
   List<Object> values = new ArrayList<Object>();
   
   public DBTable getTable() {
      return table;
   }
   public void setTable(DBTable table) {
      this.table = table;
   }
   public void setValue(int idx, Object value)
   {
      values.add(idx, value);
   }
   
}
