package org.dspace.app.webui.model;

public class DBColumn 
{
   private String name;
   private String type;
   private int    typeIdx;
   private int    idx;
   private Object value;
   
   public DBColumn (String name,
                    String type,
                    int    typeIdx,
                    int    idx)
   {
      this.name    = name;
      this.type    = type;
      this.typeIdx = typeIdx;
      this.idx     = idx;
   }
   
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getType() {
      return type;
   }
   public void setType(String type) {
      this.type = type;
   }
   public int getTypeIdx() {
      return typeIdx;
   }
   public void setTypeIdx(int typeIdx) {
      this.typeIdx = typeIdx;
   }
   public Object getValue() {
      return value;
   }
   public void setValue(Object value) {
      this.value = value;
   }
   public int getIdx() {
      return idx;
   }
   public void setIdx(int idx) {
      this.idx = idx;
   }
   protected DBColumn copy()
   {
      DBColumn newColumn = new DBColumn(getName(), getType(), getTypeIdx(), getIdx());
      newColumn.value    = this.getValue();
      return newColumn;
   }
}
//======================================= End of Class ============================================
