package org.dspace.app.webui.model;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.dspace.app.webui.nlidb.Inflector;
import org.dspace.app.webui.util.BGUtils;

public class DBEntry implements DBTypes
{
   private static final Logger log = Logger.getLogger(DBEntry.class);
   
   //..... Constants ......
   
   public static final String EMPTY_TABLE  = "Empty Table";
   public static final String EMPTY_COLUMN = "Empty";
   
   public static final String ERROR_TABLE  = "Error Table";
   public static final String ERROR_COLUMN = "Message";
   
   //..... Members ......
   
   private DBTable table;
   private List <Map <Integer, Object>>rows = new ArrayList<Map <Integer, Object>>();
   private Integer  colIdxToSort = null;
   
   //..... Methods ......
      
   public Integer getColIdxToSort()
   {
      return colIdxToSort;
   }

   public void setColIdxToSort(Integer colIdxToSort)
   {
      this.colIdxToSort = colIdxToSort;
   }
   
   public int getRowNum()
   {
      return rows.size();
   }

   public List<Map <Integer, Object>> getRows() {
      return rows;
   }

   public void setRows(List<Map <Integer, Object>> rows) {
      this.rows = rows;
   }

   public DBTable getTable() {
      return table;
   }
   
   public void setTable(DBTable table) {
      this.table = table;
   }

   public Map<Integer, Object> newRow ()
   {
      return new HashMap<Integer, Object>();
   }
   
   public void addRow(Map<Integer, Object> row)
   {
      rows.add(row);
   }
   
   public int addNewRow()        // return row index
   {
      rows.add(newRow());
      return rows.size() - 1;
   }
 
   public Map<Integer, Object> getRow(int rowIdx)
   {
      if (rowIdx < 0 || rowIdx >= rows.size()) return null; 
      return rows.get(rowIdx);
   }
   
   public boolean isEmpty()
   {
      return rows.isEmpty();
   }
   
  /* 
   public List <Map <Integer, Object>> copy()
   {
      List <Map <Integer, Object>>rows = new ArrayList<Map <Integer, Object>>();
      
   
   }
*/   
   public void setRowValue(Map<Integer, Object> row, 
                           int                  columnIdx, 
                           Object               value)
   {
      row.put(columnIdx, value);
   }
      
   public Object getRowValue(Map<Integer, Object> row, 
                             int                  columnIdx)
   {
      return row.get(columnIdx);
   }

   public Object getRowValue(Map<Integer, Object> row, 
                             String       columnName)
   {
      int columnIdx = table.getColumnByName(columnName).getIdx();
      return getRowValue(row, columnIdx);
   }
   
   public void setValue(int    rowIdx, 
                        int    columnIdx, 
                        Object value)
   {
      rows.get(rowIdx).put(columnIdx, value);
   }

   public Object getValue(int rowIdx, int columnIdx)
   {
      return rows.get(rowIdx).get(columnIdx);
   }   
   
   public int findRowByColumnValue(String columnName,
                                   Object valueToFind)
   {
      for (int i = 0; i < rows.size(); i++) {
         Map<Integer, Object> row = rows.get(i);
         Object value = getRowValue(row, columnName);
         if (value.toString().trim().equalsIgnoreCase(valueToFind.toString().trim())) {
            return i;
         }
      }
      return -1;         
   }
   //----------------------------------------------------------------------------------------------
   // Return dummy (empty entry with table comprising one dummy column)
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getDummyEntry()
   {
      DBEntry dummyEntry = new DBEntry();
      DBTable table      = new DBTable();
      table.setName(EMPTY_TABLE);
      table.addColumn(0, new DBColumn(EMPTY_COLUMN, null, DBTypes.typeText, 0));
      dummyEntry.setTable(table);
      return dummyEntry;
   }
   //----------------------------------------------------------------------------------------------
   // Return error entry (empty entry with table comprising one message column)
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getErrorEntry(String errorMessage)
   {
      DBEntry errorEntry = new DBEntry();
      DBTable table      = new DBTable();
      table.setName(ERROR_TABLE);
      table.addColumn(0, new DBColumn(ERROR_COLUMN, null, DBTypes.typeText, 0));
      errorEntry.setTable(table);
      
      int rowIdx = errorEntry.addNewRow();
      Map<Integer,Object> row = errorEntry.getRow(rowIdx);
      errorEntry.setRowValue(row, 0, errorMessage);
      return errorEntry;
   }
   //----------------------------------------------------------------------------------------------
   // Form value for table navigation:
   //  - if the value is only number, e.g. "1" -> "bus_1"
   //  - if column have words like "from_" and "to_" remove them to get: "from_bus" -> "bus"
   //----------------------------------------------------------------------------------------------
   
   public Object getExtendedValue(int rowIdx, int columnIdx)
   {
      Object val_o = rows.get(rowIdx).get(columnIdx);
      
      if (val_o == null || val_o.toString().isEmpty()) return val_o;
      
      //..... Build name from integer value and column name ......

      Integer val_i = BGUtils.stringToInteger(val_o.toString());
      if (val_i == null) return val_o;
      
      String columnName = getTable().getColumn(columnIdx).getName();
      
      //..... Remove "from_" and "to_" and others from "removeFromName" array ......

      int idx = BGUtils.getStringStartIdx(columnName, removeFromName);
      if (idx >= 0) {
         int len = removeFromName[idx].length();
         if (columnName.length() > len) {
            columnName = columnName.substring(len);
         }
      }
      return columnName + "_" + val_i;
   }
   //----------------------------------------------------------------------------------------------
   
   public Object getValue(int rowIdx, String columnName)
   {
      int columnIdx = table.findColumnIdx(columnName);
      return rows.get(rowIdx).get(columnIdx);
   }

   //.....Java 8 variant of fucntion .....
   /*
   public Object getValue(int rowIdx, String columnName)
   {
      Object columnValue = rows.get(rowIdx).entrySet().stream()
                           .filter(e -> e.getValue().equals(columnName))
                           .map(Map.Entry::getKey).findFirst().orElse(null);
      return columnValue;
   }
*/
   
   
   public Object copyValue(Map<Integer, Object> row, 
                           int          columnIdx)
   {
      Object value = getRowValue(row, columnIdx);
      if (value == null) return null;
      
      if (value instanceof String) {
         return new String((String)value);
      }
      else if (value instanceof Integer) {
         return new Integer((Integer)value);
      }
      else if (value instanceof Boolean) {
         return new Boolean((Boolean)value);
      }
      else if (value instanceof BigDecimal) {
         return new BigDecimal(((BigDecimal)value).toString());
      }
      else if (value instanceof Date) {
         Date newDate = new Date();
         newDate.setTime(((Date)value).getTime());
         return newDate;
      }
      else if (value instanceof String[]) {
         return String.join(";", (String[])value);
      }
      else if (value instanceof Integer[]) {
         return objArrayToString((Object[])value);
      }      
      else if (value instanceof BigDecimal[]) {
         return objArrayToString((Object[])value);
      }
      else {
         return value.toString();
      }
   }
   //----------------------------------------------------------------------------------------------
   // Return all values of one column (by column name)
   //----------------------------------------------------------------------------------------------
   
   public List<Object> getColumnValues(String columnName)
   {
      int columnIdx = table.getColumnByName(columnName).getIdx();
      if (columnIdx < 0) return null;
      
      List<Object>colValues = new ArrayList<Object>();
      for (Map<Integer,Object>row : rows) {        
         colValues.add(this.getRowValue(row, columnIdx));
      }
      return colValues;
   }   
   //----------------------------------------------------------------------------------------------
   // Return column values as strings
   //----------------------------------------------------------------------------------------------
   
   public String getStringValue(int rowIdx, int columnIdx)
   {
      String val_s = getRawStringValue(rowIdx, columnIdx);
      return DBUtils.formColumnName(val_s);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public String[] getColumnStringValues(int      columnIdx, 
                                         String[] exclusions, 
                                         boolean  formName_b)
   {
      List<String> colValues_al = new ArrayList<String>();
   
      if (formName_b) {
         for (int rowIdx = 0; rowIdx < getRowNum(); rowIdx++) {
            String val_s = getRawStringValue(rowIdx, columnIdx);
            if (BGUtils.getStringIdx(val_s, exclusions) == -1) { 
               colValues_al.add(DBUtils.formColumnName(val_s).toLowerCase());
            }
         }
      }
      else {
         for (int rowIdx = 0; rowIdx < getRowNum(); rowIdx++) {
            String val_s = getRawStringValue(rowIdx, columnIdx);
            if (BGUtils.getStringIdx(val_s, exclusions) == -1) { 
               colValues_al.add(val_s.toLowerCase());
            }
         }         
      }
      return colValues_al.toArray(new String[colValues_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public String[] getColumnStringValues(String   columnName,  
                                         String[] exclusions, 
                                         boolean  formName_b)
   {
      if (getTable() == null) {
         log.error("DBEntry.getColumnStringValues. Entry table is null");
         return null;
      }
      int columnIdx = getTable().findColumnIdx(columnName);
      if (columnIdx < 0) {
         log.error("DBEntry.getColumnStringValues. Cannot find column " + columnName + 
                   " in the table " + getTable().getName());
      }
      return getColumnStringValues(columnIdx, exclusions, formName_b);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public String getRawStringValue(int rowIdx, int columnIdx)
   {
      Object value = getValue(rowIdx, columnIdx);      
      if (value == null) return "";
      
      String val_s = null;
      int typeIdx  = getTable().getColumn(columnIdx).getTypeIdx();
      
      switch (typeIdx) {
      case typePgArray: 
         if (value instanceof String[]) {
            val_s = String.join(";", (String[])value);
         }
         else {
            val_s = objArrayToString((Object[])value);
         }
         break;
      case typeDate:
         SimpleDateFormat form = new SimpleDateFormat("dd/MM/yyyy"); 
         val_s = form.format((Date)value);
         break;
      default:
         val_s = value.toString();
      }
      return val_s;
   }
   //----------------------------------------------------------------------------------------------
   
   public DBTable getCompactTable()
   {
      if (table == null) return null;
      try {
         DBTable tabCompact = new DBTable();
         
         for (Map.Entry<Integer, DBColumn> colEntry : table.getColumns().entrySet()) {
            int colIdx = colEntry.getKey();
            
            boolean empty = true;
            for (Map <Integer, Object> row : rows) {
               Object value = getRowValue(row, colIdx);
               if (value != null && value.toString().isEmpty() == false) {
                  empty = false;
                  break;              
               }
            }
            if (empty == false) {
               tabCompact.addColumn(colIdx, colEntry.getValue().copy());
            }
         }
         return tabCompact;
      } 
      catch (NullPointerException en) {
         en.printStackTrace();
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   
   public void setCompactTable()
   {
      this.setTable(getCompactTable());
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public String toJSPString()
   {
      StringBuffer line_sb = new StringBuffer("idx\t");
      
      //..... Headers ......
      
      for (Map.Entry<Integer, DBColumn> colEntry : table.getColumns().entrySet()) {
         DBColumn column = colEntry.getValue();         
         line_sb.append(column.getName() + "\t\t");
      }
      line_sb.append("<br/>");
      
      //..... Data ......
      
      int idx = 0;
      for (int rowIdx = 0; rowIdx < rows.size(); rowIdx++) {
         line_sb.append(idx++ + "\t");
         
         for (Map.Entry<Integer, DBColumn> colEntry : table.getColumns().entrySet()) {
            line_sb.append(getStringValue(rowIdx, colEntry.getKey()) + "\t");
         }
         line_sb.append("<br/>");
      }
      return line_sb.toString();
   }
   //----------------------------------------------------------------------------------------------

   public void printTableContent(DBTable tab)
   {
      StringBuffer line_sb = new StringBuffer("idx\t");   
      
      //..... Headers ......
      
      for (Map.Entry<Integer, DBColumn> colEntry : tab.getColumns().entrySet()) {
         DBColumn column = colEntry.getValue();         
         line_sb.append(column.getName() + "\t\t");
      }
      System.out.println(line_sb.toString());
      
      int idx = 0;
      for (int rowIdx = 0; rowIdx < rows.size(); rowIdx++) {
         line_sb = new StringBuffer().append(idx++ + "\t");
         
         for (Map.Entry<Integer, DBColumn> colEntry : tab.getColumns().entrySet()) {
            line_sb.append(getRawStringValue(rowIdx, colEntry.getKey()) + "\t");
         }
         System.out.println(line_sb.toString());
      }
   }
   //----------------------------------------------------------------------------------------------
   
   public String printToString()
   {
      StringBuffer line_sb = new StringBuffer("");   
      
      for (int rowIdx = 0; rowIdx < rows.size(); rowIdx++) {
         for (Map.Entry<Integer, DBColumn> colEntry : table.getColumns().entrySet()) {
            line_sb.append(getRawStringValue(rowIdx, colEntry.getKey()));
            if (table.getColumnNum() > 1) {
               line_sb.append("\t");
            }
         }
         line_sb.append("\n");
      }
      log.info("printToString. Result entry converted to string");
      return line_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   
   public void printCompactContent()
   {
      printTableContent(getCompactTable());
   }
   
   public void printContent()
   {
      printTableContent(table);
   }
   //----------------------------------------------------------------------------------------------
     
   public String objArrayToString(Object[] arr)
   {
      if (arr == null) return "";
      StringBuffer val_sb = new StringBuffer();
      
      for (int i = 0; i < arr.length; i++) {
         if (arr[i] != null) {
            val_sb.append(arr[i].toString());
         }
      }
      return val_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   // Check is given text column numeric
   //----------------------------------------------------------------------------------------------
   
   public void setNumericColumns()
   {
      if (rows == null || rows.isEmpty() || table == null) return;
      
      for (Map.Entry<Integer, DBColumn> colEntry : getTable().getColumns().entrySet()) {
         if (colEntry.getValue().getTypeIdx() != typeText) continue;  
         
         int     colIdx      = colEntry.getKey();
         boolean isNumeric_b = true;
         boolean isInteger_b = true;
         
         for (int rowIdx = 0; rowIdx < rows.size(); rowIdx++) {
            
            Object value = getValue(rowIdx, colIdx);
            if (value == null) continue;
            
            if (value instanceof Integer || value instanceof Double) {
               continue;
            }
            if (value instanceof String) {
               if (DBUtils.isNumeric((String)value) == false) {
                  isNumeric_b = false;
                  isInteger_b = false;
                  break;
               }
               else if (!isInteger_b || DBUtils.isInteger((String)value) == false){
                  isInteger_b = false;
               }
            }
         }
         if (isNumeric_b == true) {
            if (isInteger_b == true) {
               colEntry.getValue().setTypeIdx(typeLong);
            }
            else {
               colEntry.getValue().setTypeIdx(typeNumeric);
            }
         }
      }
   }
   //----------------------------------------------------------------------------------------------
   // Convert Entry to the Class bean array of objects 
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings({"unchecked", "rawtypes"})
   
   public Object[] getClassObjects(Class tabClass)
   {
      Object[] classObj_arr = new Object[rows.size()];

      try {
         Constructor constr = tabClass.getConstructor();
               
         for (int rowIdx = 0; rowIdx < rows.size(); rowIdx++) {     
            classObj_arr[rowIdx] = constr.newInstance(); 
         }
         //..... For every column/method ......
         
         for (Method method : tabClass.getMethods()) {
            String methodName = method.getName().toUpperCase();             
            if (!methodName.substring(0, 3).equalsIgnoreCase("set")) {     // work only with set methods
               continue;
            }
            Object val = null;

            String colName = methodName.substring(3);
            int    colIdx  = table.findColumnIdx(colName);
            if (colIdx < 0) {
               continue;
            }
            for (int rowIdx = 0; rowIdx < rows.size(); rowIdx++) {      // for each row
               val = getValue(rowIdx, colIdx);
               method.invoke(classObj_arr[rowIdx], val);
            }
         }
      }
      catch (Exception e) {
         log.error("getClassObjects. Cannot create object for Class " + tabClass.getSimpleName() + ". " + e.getMessage());
         return null;
      }
      return classObj_arr;
   }
   //----------------------------------------------------------------------------------------------
   // Add row to the entry from the class object
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("rawtypes")
   
   public boolean addRowFromObject(DBTableImage tabObj)
   {
      boolean res_b = true;
      if (table == null || tabObj == null) {
         log.error("addRowFromObject. Table and/or input object are nulls");
         return false;
      }
      Class objClass = tabObj.getClass();
      Map<Integer, Object> row = newRow();
      
      try {
         //..... For every column/method ......
         
         for (Method method : objClass.getDeclaredMethods()) {
            String methodName = method.getName().toUpperCase();             
            if (!methodName.substring(0, 3).equalsIgnoreCase("get")) {     // work only with get methods
               continue;
            }
            DBColumn column = table.getColumnByName(methodName.substring(3));
            if (column == null || column.isAutoIncrement()) {
               continue;
            }
            row.put(column.getIdx(), method.invoke(tabObj));
         }
         addRow(row);
      }
      catch (Exception e) {
         log.error("addRowFromObject. Method's exception: " + e.getMessage());
         return false;
      }
      return res_b;
   }      
   //----------------------------------------------------------------------------------------------
   // Merge two entries of the same table
   //----------------------------------------------------------------------------------------------

   public boolean addEntry(DBEntry entry)
   {
      //..... Check that tables are identical ......
      
      if (entry == null || entry.getRows() == null) return false;
      
      if (this.getTable().isIdenticalTable(entry.getTable()) == false) {
         log.error("DBEntry.addEntry. Table of adding entry: " + entry.getTable().getName() + 
                   " and current entry table: " + getTable().getName() + " are not identical");
         return false;
      }
      this.rows.addAll(entry.getRows());
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Merge two entries with different tables (concatenate entry rows to one row)
   //----------------------------------------------------------------------------------------------

   public boolean extendEntry(DBEntry entry,
                              String  matchColName)  // name of the column to match two entries
   {
      //..... Verifications ......
      
      if (entry == null || entry.getRows() == null || entry.getTable() == null) return false;
     
      if (this.getTable().isIdenticalTable(entry.getTable()) == true) {
         return addEntry(entry);
      }
      List<String>columnNames = table.getColumnNames();
      DBTable tableAdd = entry.getTable();
      
      if (!columnNames.contains(matchColName) || !tableAdd.getColumnNames().contains(matchColName)) {
         log.error("DBEntry.extendEntry. One of (or both) entries does/do not contain the matching column: " + 
                   matchColName);
         return false;
      }
      //..... Extend table ......
      
      int colIdx = table.getMaxColumnIndex() + 1;           // initial index to add a new column
      String tableNameAdd = tableAdd.getName();
      
      for (DBColumn columnAdd : entry.getTable().getColumns().values()) {
         String columnNameAdd = columnAdd.getName();
         if (columnNameAdd.equalsIgnoreCase(matchColName)) continue;
         
         if (columnNames.contains(columnNameAdd)) {
            columnAdd.setName(columnNameAdd + ((tableNameAdd.charAt(0) == '_') ? "" : "_") + tableNameAdd);
         }
         table.addColumn(colIdx++, columnAdd);        
      }
      //..... Add entry values ......
      
      for (int i = 0; i < this.getRowNum(); i++) {       // for each existing rows
         Map<Integer,Object>row = getRow(i);
         
         Object value = this.getRowValue(row, matchColName); 
         int rowAddIdx = entry.findRowByColumnValue(matchColName, value);
         if (rowAddIdx == -1) {
            continue;           
         }
         //..... Add new column values ......

         for (DBColumn columnAdd : tableAdd.getColumns().values()) {
            colIdx = table.findColumnIdx(columnAdd.getName());
            if (colIdx == -1) {
               log.error("DBEntry.extendEntry. Column: " + columnAdd.getName() + 
                         " was not added to the target entry");
               return false;
            }
            setRowValue(row, colIdx, entry.getValue(rowAddIdx, columnAdd.getIdx()));
         }         
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Sort entry rows by column value
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("unchecked")
   public boolean sortRows()
   {
      DBColumn column = table.getColumn(colIdxToSort);
      if (column == null) {
         log.error("sortRows. Cannot find column with index to sort: " + colIdxToSort + " in the entry table");
      }
      Comparator<Map<Integer, Object>> comp = new Comparator<Map<Integer, Object>>() { 
      
         @SuppressWarnings("rawtypes")
         public int compare(Map<Integer, Object> row1, Map<Integer, Object> row2) 
         {
            Object obj1 = row1.get(colIdxToSort);
            Object obj2 = row2.get(colIdxToSort);
            return ((Comparable)obj2).compareTo((Comparable)obj1);
         };
      };
      rows.sort(comp);
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Add exclusions (remove columns, mentioned in the list) 
   //----------------------------------------------------------------------------------------------
   
   public boolean applyExclusions(String[] exclusions)
   {
      if (exclusions == null || exclusions.length == 0) return true;
      
      //..... Modify table ......
      
      List<Integer>columnsToRemove = new ArrayList<Integer>();
      
      for (DBColumn column : table.getColumns().values()) {
         if (DBUtils.contains(exclusions, column.getName())) {
            columnsToRemove.add(column.getIdx());
         }
      }
      for (Integer colIdx : columnsToRemove) {
         table.deleteColumn(colIdx);
      }
      //..... Delete specified column values from data rows ......
      
      for (int colIdx = 0; colIdx <= table.getMaxColumnIndex(); colIdx++) {
         if (columnsToRemove.contains(colIdx) == false) continue;
         
         for (Map<Integer,Object>row : rows) {
            row.remove(colIdx);
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Add exclusions (remove columns, mentioned in the list) 
   //----------------------------------------------------------------------------------------------
   
   public DBEntry subEntry(String[] subColNames)
   {
      if (subColNames == null || subColNames.length == 0) return this;
      
      DBEntry subEntry = new DBEntry();
      
      //..... Create table ......
      
      DBTable subTable = new DBTable();
      subTable.setName(table.getName());
      
      List<Integer>parentColIdx = new ArrayList<Integer>();
      
      for (int idx = 0; idx < subColNames.length; idx++) {
         DBColumn col = table.getColumnByName(subColNames[idx]);
         if (col == null) continue;
            
         parentColIdx.add(col.getIdx());
         subTable.addColumn(idx, col);
      }
      //..... Create objects ...... 
         
      for (Map<Integer,Object>row : rows) {
         int subRowIdx = subEntry.addNewRow();

         for (int subColIdx = 0; subColIdx < subTable.getColumnNum(); subColIdx++) {
            subEntry.setValue(subRowIdx, subColIdx, row.get(parentColIdx.get(subColIdx)));
         }
      }
      return subEntry;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean singularizeColumn(String colName)
   {
      if (rows == null || rows.isEmpty() || table == null) return false;
      
      //..... Headers ......
      
      for (Map.Entry<Integer, DBColumn> colEntry : this.getTable().getColumns().entrySet()) {
         DBColumn column = colEntry.getValue();         
         
         if (column.getName().equalsIgnoreCase(colName)) {
            int columnIdx = table.findColumnIdx(colName);
            if (column.getTypeIdx() != Types.VARCHAR && column.getTypeIdx() != Types.LONGNVARCHAR) {
               return false;
            }            
            Inflector inf = new Inflector();
            
            for (int rowIdx = 0; rowIdx < rows.size(); rowIdx++) {
               String value = (String)getValue(rowIdx, columnIdx);
               setValue(rowIdx, columnIdx, inf.singularize(value));
            }
            return true;
         }
      }
      return false;
   }
}
//======================================= End of Class ============================================