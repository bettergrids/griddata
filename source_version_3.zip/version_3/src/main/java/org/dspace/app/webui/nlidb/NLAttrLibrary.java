package org.dspace.app.webui.nlidb;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBTypes;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.util.BGUtils;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class NLAttrLibrary
{
   private static final Logger log = Logger.getLogger(NLAttrLibrary.class);
   
   //..... Constants ......
   
   public static final String NOISE_CONST       = "";
   public static final String SLANG_CONST       = "slang";
   public static final String LEXICON_CONST     = "lexicon";
   public static final String COMMON_CONST      = "common";
   public static final String ATTRIBUTE_CONST   = "attribute";
   public static final String UNIT_CONST        = "unit";
   public static final String COEF_CONST        = "coef";

   public static final String NODE_TYPE_CONST   = "nodetype";
   public static final String NODE_NAME_CONST   = "nodename";
   public static final String ATTR_NAME_CONST   = "attrname";
   public static final String COLUMN_CONST      = "column";
   
   public static final String[] ATTR_ELEMENTS_SA = {NODE_TYPE_CONST, COLUMN_CONST, NODE_NAME_CONST, 
                                                    ATTR_NAME_CONST, UNIT_CONST};
   //..... Members ......
   
   private static JsonParser parser = new JsonParser();
   private static Gson gson = new Gson();
   
   private static List<String>                     noise_al    = new ArrayList<String>();
   private static LinkedHashMap<String,String[]>   slang_hm    = new LinkedHashMap<String,String[]>();
   private static LinkedHashMap<String,String[]>   lex_hm      = new LinkedHashMap<String,String[]>();
   private static LinkedHashMap<String,String[]>   common_hm   = new LinkedHashMap<String,String[]>();
   private static LinkedHashMap<String,NLAttrDesc> attrDesc_hm = new LinkedHashMap<String,NLAttrDesc>();
   private static LinkedHashMap<String,NLUnit>     unit_hm     = new LinkedHashMap<String,NLUnit>();
   private static LinkedHashMap<String,String[]>   nodetype_hm = new LinkedHashMap<String,String[]>();

   private static boolean status = false;
   
   //..... Methods ......
 
   public static List<String> getNoiseList()
   {
      return noise_al;
   }
   public static void setNoiseList(List<String> noise_al)
   {
      NLAttrLibrary.noise_al = noise_al;
   }
   public static LinkedHashMap<String, String[]> getSlangMap()
   {
      return slang_hm;
   }
   public static void setSlangMap(LinkedHashMap<String, String[]> slang_hm)
   {
      NLAttrLibrary.slang_hm = slang_hm;
   }
   public static LinkedHashMap<String, String[]> getLexMap()
   {
      return lex_hm;
   }
   public static void setLexMap(LinkedHashMap<String, String[]> lex_hm)
   {
      NLAttrLibrary.lex_hm = lex_hm;
   }
   public static LinkedHashMap<String, NLAttrDesc> getAttrDescMap()
   {
      return attrDesc_hm;
   }
   public static void setAttrDescMap(LinkedHashMap<String, NLAttrDesc> attrDesc_hm)
   {
      NLAttrLibrary.attrDesc_hm = attrDesc_hm;
   }
   public static LinkedHashMap<String, NLUnit> getUnitMap()
   {
      return unit_hm;
   }
   public static void setUnitMap(LinkedHashMap<String, NLUnit> unit_hm)
   {
      NLAttrLibrary.unit_hm = unit_hm;
   }
   public static LinkedHashMap<String, String[]> getNodetypeMap()
   {
      return nodetype_hm;
   }
   public static void setNodetypeMap(String[] nodetype_sa)
   {
      nodetype_hm.put(DBTypes.nodeType, nodetype_sa);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static boolean parseAttrFile(String filePath_s)
   {
      boolean res_b = true;
      
      //..... Check if it's already parsed ......
      
      if (status == true) return true;
      
      //..... Read JSON file with lexicon and attr.description .....
      
      String text_s = BGUtils.readFile(filePath_s);
      if (text_s == null) return false;
      
      //..... Parse JSON objects ......
      
      try {
         Object object      = parser.parse(text_s);        
         JsonObject jobject = getJsonObject((JsonObject)object);
         
         Set<Map.Entry<String, JsonElement>> set = jobject.entrySet();
         Iterator<Map.Entry<String, JsonElement>> iterator = set.iterator();
         
         //..... Iterate attributes ......
         
         while (iterator.hasNext()) {
            Map.Entry<String, JsonElement> entry = iterator.next();
            String name_s     = entry.getKey().toLowerCase().trim();       // attr.name
            JsonElement value = entry.getValue();                          // attr.value
            
            switch(name_s) {
            case NOISE_CONST:
               res_b &= parseNoise(value);
               break;
            case SLANG_CONST:
               res_b &= parseCollectArray(value, slang_hm);
               break;
            case LEXICON_CONST:
               res_b &= parseCollectArray(value, lex_hm);
               break;
            case COMMON_CONST:
               res_b &= parseCollectArray(value, common_hm);
               break;               
            case ATTRIBUTE_CONST:
               res_b &= parseAttributes(value);
               break;
            case UNIT_CONST:
               res_b &= parseUnits(value);
               break;               
            }            
         }
      }
      catch (Exception e) {
         log.error("parseObject. Error in parsing Attribute file: " + filePath_s +
               ". Stack Trace: " + ExceptionUtils.getStackTrace(e));
         return false;
      }
      status = true;
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Parse lexicon object
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("unchecked")
   private static boolean parseNoise(JsonElement  json_el)
   {
      boolean res_b = true;
      
      if (json_el.isJsonArray() == false) {
         String json_s = json_el.getAsString();
         log.error("parseAttributes. Attribute object is not an array: " + 
                   json_s.substring(0, Math.min(json_s.length(), 60)) + "...");
         return false;
      }
      //..... Parse attribute array ......
      
      JsonArray json_a = json_el.getAsJsonArray();
      if (json_a == null) return false;                  // expected array of attrs
     
      noise_al = (ArrayList<String>)gson.fromJson(json_a, ArrayList.class);
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Parse lexicon object
   //----------------------------------------------------------------------------------------------
   
   private static boolean parseLexBlock(JsonElement         json_el,
                                        Map<String, String> block_hm)
   {
      boolean res_b = true;
      
      if (json_el.isJsonObject()) {
         JsonObject jobject = getJsonObject((JsonObject)json_el);
         
         Set<Map.Entry<String, JsonElement>> set = jobject.entrySet();
         Iterator<Map.Entry<String, JsonElement>> iterator = set.iterator();
         
         while (iterator.hasNext()) {
            Map.Entry<String, JsonElement> entry = iterator.next();
            String name_s     = entry.getKey().toLowerCase().trim();       // attr.name
            JsonElement value = entry.getValue();                          // attr.value

            if (value != null && value.isJsonArray()) {
               JsonArray json_a = value.getAsJsonArray();
               if (json_a != null) {
                  for (JsonElement element : json_a) {
                     if (element != null && element.isJsonPrimitive()) {
                        String value_s = element.getAsString();
                        block_hm.put(value_s.toLowerCase().trim(), name_s);
                     }
                     else {
                        res_b = false;
                     }
                  }
               }
               else {
                  res_b = false;
               }
            }
            else {
               res_b = false;
            }
         }
      }
      else {
         res_b = false;
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Parse common terms, including sub-terms, like: "line" includes "overhead line", etc.
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("unchecked")
   private static boolean parseCollectArray(JsonElement                     json_el,
                                            LinkedHashMap<String, String[]> map_hm)
   {
      boolean res_b = true;
      
      if (json_el.isJsonObject()) {
         JsonObject jobject = getJsonObject((JsonObject)json_el);
         
         Set<Map.Entry<String, JsonElement>> set = jobject.entrySet();
         Iterator<Map.Entry<String, JsonElement>> iterator = set.iterator();
         
         while (iterator.hasNext()) {
            Map.Entry<String, JsonElement> entry = iterator.next();
            String name_s     = entry.getKey().toLowerCase().trim();       // group.name
            JsonElement value = entry.getValue();                          // array value

            if (value != null && value.isJsonArray()) {
               ArrayList<String>value_al = (ArrayList<String>)gson.fromJson(value, ArrayList.class);
               map_hm.put(name_s, value_al.toArray(new String[value_al.size()]));
            }
            else {
               res_b = false;
            }
         }
      }
      else {
         res_b = false;
      }
      return res_b;
   }   
   //----------------------------------------------------------------------------------------------
   // Parse attribute object, presented as an array
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("unchecked")
   private static boolean parseAttributes(JsonElement json_el)
   {
      boolean res_b = true;
      List<String>[] attr_elem_sal = new List[ATTR_ELEMENTS_SA.length];
      
      if (json_el.isJsonArray() == false) {
         String json_s = json_el.getAsString();
         log.error("parseAttributes. Attribute object is not an array: " + 
                   json_s.substring(0, Math.min(json_s.length(), 60)) + "...");
         return false;
      }
      //..... Parse attribute array ......
      
      int idx = 0;
      JsonArray json_a = json_el.getAsJsonArray();
      if (json_a == null) return false;    // expected array of attrs
         
      for (JsonElement attr_el : json_a) {
            
         //..... Parse particular attribute ......
            
         JsonObject attr_o = getJsonObject((JsonObject)attr_el);
         Set<Map.Entry<String, JsonElement>> set = attr_o.entrySet();
         Iterator<Map.Entry<String, JsonElement>> iterator = set.iterator();           
            
         while (iterator.hasNext()) {
            Map.Entry<String, JsonElement> entry = iterator.next();
            String name_s     = entry.getKey().toLowerCase().trim();    // element name
            JsonElement value = entry.getValue();                       // element value               

            int elemIdx = BGUtils.getStringIdx(name_s, ATTR_ELEMENTS_SA);
            if (elemIdx == -1) {
               log.error("parseAttributes. Attribute idx: " + idx + ". Unknown attr. element: " + name_s);
               res_b = false;
               break;                  
            }
            if (value.isJsonArray()) {
               attr_elem_sal[elemIdx] = (ArrayList<String>)gson.fromJson(value, ArrayList.class);
            }
            else if (value.isJsonPrimitive()) {
               attr_elem_sal[elemIdx] = new ArrayList<String>();
               attr_elem_sal[elemIdx].add(value.getAsString());
            }
         }
         //..... Populate attr.structure ......           
            
         for (int i = 0; i < BGModel.MODEL_FILE_FORMATS_SA.length; i++) {
            NLAttrDesc attrDesc = new NLAttrDesc();
               
            attrDesc.setFormat(BGModel.MODEL_FILE_FORMATS_SA[i]);
            attrDesc.setNodeType(attr_elem_sal[0].get(i));              // nodetype
            attrDesc.setColumnName(attr_elem_sal[1].get(i));            // column name
            attrDesc.setNodeName(attr_elem_sal[2].get(0));              // node name (single value)
            attrDesc.setName(attr_elem_sal[3].get(0));                  // attr name (single value)
            attrDesc.setUnit(attr_elem_sal[4].get(i));                  // unit name
            
            //..... Build attribute unique name and add attribute to array ......
            
            String uniqueName_s = String.join(".", attrDesc.getFormat(),
                                                   attrDesc.getNodeName(),
                                                   attrDesc.getName());
                     
            attrDesc_hm.put(uniqueName_s, attrDesc);
         }
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Parse lexicon object
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("unchecked")
   private static boolean parseUnits(JsonElement json_el)
   {
      boolean res_b = true;
      
      if (json_el.isJsonObject() == false) {
         String json_s = json_el.getAsString();
         log.error("parseAttributes. Units object is not a JSON object: " +
                   json_s.substring(0, Math.min(json_s.length(), 60)) + "...");
         return false;

      }
      JsonObject jobject = getJsonObject((JsonObject)json_el);
         
      Set<Map.Entry<String, JsonElement>> set = jobject.entrySet();
      Iterator<Map.Entry<String, JsonElement>> iterator = set.iterator();
         
      while (iterator.hasNext()) {
         Map.Entry<String, JsonElement> entry = iterator.next();
         String type_s     = entry.getKey().toLowerCase().trim();       // unit type, like "voltage" e.g.
         JsonElement value = entry.getValue();                          // unit value
        
         NLUnit unitObj = new NLUnit();
         unitObj.setType(type_s);

         if (value != null && value.isJsonObject()) {
            JsonObject unit_o = value.getAsJsonObject();
            if (unit_o != null) {
               JsonElement unit_a = unit_o.get(UNIT_CONST);
               JsonElement coef_a = unit_o.get(COEF_CONST);
               if (unit_a != null && coef_a != null && unit_a.isJsonArray() && coef_a.isJsonArray()) {
                  unitObj.setNames((ArrayList<String>)gson.fromJson(unit_a, ArrayList.class));
                  unitObj.setCoefs((ArrayList<Double>)gson.fromJson(coef_a, ArrayList.class));
                  unit_hm.put(type_s, unitObj);
               }
               else {
                  res_b = false;
               }
            }
            else {
               res_b = false;
            }
         }
         else {
            res_b = false;
         }
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // get Json object
   //----------------------------------------------------------------------------------------------

   private static JsonObject getJsonObject(JsonElement elem_e)
   {
      JsonObject jobject = null;
      try {
         jobject = (JsonObject)elem_e;
      }
      catch (Exception e2) {
         String js_s = elem_e.getAsString();
         jobject = gson.fromJson(js_s, JsonObject.class);
      }
      return jobject;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   /*
   public String getColumnName(String format,
                               String nodeName,
                               String attrName)
   {
      //..... Get base name for node and attribute ......
      
      String nodeBase = lex_hm.get(nodeName);
      if (nodeBase == null) nodeBase = nodeName;
      
      String attrBase = lex_hm.get(attrName);
      if (nodeBase == null) nodeBase = nodeName;
      
      String uniqueName_s = String.join(".", format, nodeBase, nodeName);      
      String columnName = attrDesc_hm.get(uniqueName_s).getColumnName();
      return columnName;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public String getUnitCoeff(String format,
                              String nodeName,
                              String attrName)
   {
      //..... Get base name for node and attribute ......
      
      String nodeBase = lex_hm.get(nodeName);
      if (nodeBase == null) nodeBase = nodeName;
      
      String attrBase = lex_hm.get(attrName);
      if (nodeBase == null) nodeBase = nodeName;
      
      String uniqueName_s = String.join(".", format, nodeBase, nodeName);      
      
      try {
         String unitName = attrDesc_hm.get(uniqueName_s).getUnit();
         String coef_s   = unit_hm.get(attrBase).getCoeff(unitName).toString();
         return coef_s;
      }
      catch (Exception e) {
         log.error("getUnitCoeff. Cannot find unit coef. for format: " + format +
                   "; node: " + nodeName + "; attribute: " + attrName);
         return null;
      }
   }
   */
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public static void main(String[] args) 
   {
      org.apache.log4j.BasicConfigurator.configure();
      
      String filePath_s = "C:\\dspace\\bettergrids\\bg-attributes.json";
      NLAttrLibrary.parseAttrFile(filePath_s);
      
   }
   
   
   
}
