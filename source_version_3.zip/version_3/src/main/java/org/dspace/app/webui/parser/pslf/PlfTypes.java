package org.dspace.app.webui.parser.pslf;

public interface PlfTypes {

   public static final int SECT_TITLE_IDX       = 0;
   public static final int SECT_COMMENTS_IDX    = 1;
   public static final int SECT_SOLUTION_IDX    = 2;
   public static final int SECT_SUBSTATION_IDX  = 3;
   public static final int SECT_BUS_IDX         = 4;
   public static final int SECT_BRANCH_IDX      = 5;
   public static final int SECT_TRANS_IDX       = 6;
   public static final int SECT_GEN_IDX         = 7;   
   public static final int SECT_LOAD_IDX        = 8;
   public static final int SECT_SHUNT_IDX       = 9;
   public static final int SECT_SVD_IDX         = 10;
   public static final int SECT_AREA_IDX        = 11;
   public static final int SECT_ZONE_IDX        = 12;
   public static final int SECT_INTERFACE_IDX   = 13;
   public static final int SECT_INF_BRANCH_IDX  = 14;
   public static final int SECT_DC_BUS_IDX      = 15;
   public static final int SECT_DC_LINE_IDX     = 16;
   public static final int SECT_DC_CONV_IDX     = 17;
   public static final int SECT_ZTABLE_IDX      = 18;
   public static final int SECT_GCD_IDX         = 19;
   public static final int SECT_TRANSACT_IDX    = 20;
   public static final int SECT_OWNER_IDX       = 21;
   public static final int SECT_INDUCT_IDX      = 22;
   public static final int SECT_LINE_IDX        = 23;
   public static final int SECT_GTABLE_IDX      = 24;
   public static final int SECT_BAREA_IDX       = 25;

   public static final String[] SECT_KEYWORD_SA = {"title", "comments", "solution parameters", "substation data", 
                                                   "bus data", "branch data", "transformer data", "generator data", 
                                                   "load data", "shunt data", "svd data", "area data", "zone data", 
                                                   "interface data", "interface branch data", "dc bus data", "dc line data",
                                                   "dc converter data", "z table data", "gcd data", "transaction data",
                                                   "owner data", "motor data", "line data", "qtable data", "ba data"};
     
   public static final String[] SECT_NAMES_SA  = {"title", "comments", "solution", "substation", "bus", "branch", 
                                                  "transformer", "generator", "load", "shunt", "controlled_shunt", 
                                                  "area", "zone", "interface","interface_branch", "DC_bus", "DC_line", 
                                                  "DC_Converter", "impedance_corr", "gcd", "transaction", "owner", 
                                                  "induction_motor", "line", "gen_table", "b_area"};

   //--------------------------------- Section attributes -----------------------------------------
      
   public static final String[] TITLE_ATTR_NAMES_SA    = {"title"}; 
   public static final String[] COMMENTS_ATTR_NAMES_SA = {"comments"}; 
   
   public static final String[] SOL_ATTR_NAMES_SA      = {"parameter", "value", "description", "control"}; 
   public static final String   SOL_CONTROL_VALUE      = "enabled";
   public static final String[] SOL_PARAMS_SA          = {"jump", "toler", "sbase"};
   
   public static final String[] SUB_ATTR_NAMES_SA = {"substation", "subname", "latitude", "longitude"};
   
   public static final String   BUS_NAME   = "bus";
   public static final String[] BUS_ATTR_NAMES_SA = {BUS_NAME, "bus_name", "kv", "ty", "vsched", "volt", "angle", "area", "zone", 
                                                     "vmax", "vmin", "date_in", "date_out", "proj_id", "level", "owner", "stisol",
                                                     "latitude", "longitude", "islnum", "island", "sdmon", "vmax1", "vmin1", 
                                                     "substation", "subname"};
   
   public static final String FROM_NAME   = "_from";
   public static final String TO_NAME     = "_to";
   public static final String LENGTH_NAME = "length";
   
   public static final String[] BRANCH_ATTR_NAMES_SA = {FROM_NAME, "from_name", "from_kv", TO_NAME, "to_name", "to_kv", 
                                                        "ck", "sec", "long_id", "st", "resist", "react", "charge", "rate1",
                                                        "rate2", "rate3", "rate4",
                                                        "aloss", LENGTH_NAME, "area", "zone", "gi", "tf", "tt", "date_in", "date_out", 
                                                        "proj_id", "nst", "type", "r5", "r6", "r7", "r8", "o1", "p1", "o2", "p2",
                                                        "o3", "p3", "o4", "p4", "o5", "p5", "o6", "p6", "o7", "p7", "o8",
                                                        "p8", "ohms"};

   public static final String[] TRANS_ATTR_NAMES_SA = {FROM_NAME, "from_name", "from_kv", TO_NAME, "to_name", "to_kv", "ck",
                                                       "long_id", "st", "type", "kreg_bus", "kreg_name", "kreg_bus_kv", "zt",
                                                       "iint_bus", "iint_name", "iint_bkv", "tert_bus", "tert_name", "tert_bkv",
                                                       "area", "zone", "tbase", "zpsr", "zpsx", "zptr", "zptx", "ztsr", "ztsx",
                                                       "vnomp", "vnoms", "vnomt", "anglp", "gmag", "bmag", "r1", "r2", "r3", 
                                                       "r4", "aloss", "tmax", "tmin", "vtmax", "vtmin", "stepp", "tapp", "tapfp",
                                                       "tapfs", "tapft", "date_in", "date_out", "projid", "stn", "r5", "r6",
                                                       "r7", "r8", "o1", "p1", "o2", "p2", "o3", "p3", "o4", "p4", "o5", "p5",
                                                       "o6", "p6", "o7", "p7", "o8", "p8", "ohms", "tbasept", "tbasets", "angls",
                                                       "anglt", "rs1", "rs2", "rs3", "rt1", "rt2", "rt3", "alosss", "alosst",
                                                       "rxunits", "gbunits", "tunits", "rcomp", "xcomp"};

   public static final String[] GEN_ATTR_NAMES_SA = {"bus", "bus_name", "bus_kv", "id", "long_id", "st", "igreg_bus", "igreg_name",
                                                     "igreg_kv", "prf", "qrf", "area", "zone", "pgen", "pmax", "pmin", "qgen",
                                                     "qmax", "qmin", "mbase", "rcomp", "xcomp", "zgenr", "zgenx", "h_bus",
                                                     "h_name", "h_bkv", "t_bus", "t_name", "t_bkv", "date_in", "date_out", "proj_id",
                                                     "stn", "rtr", "xtr", "gtap", "o1", "p1", "o2", "p2", "o3", "p3", "o4",
                                                     "p4", "o5", "p5", "o6", "p6", "o7", "p7", "o8", "p8", "gov_flag", 
                                                     "agc_flag", "dispatch_flag", "baseload_flag", "air_temp", "turbine_type",
                                                     "qtab", "pmax2"};        
         
   public static final String[] LOAD_ATTR_NAMES_SA = {"bus", "bus_name", "bus_kv", "id", "long_id", "st", "p", "q", "ip", "iq",
                                                      "g", "b", "area", "zone", "date_in", "date_out", "proj_id", "stn", "owner"};
   
   public static final String[] SHUNT_ATTR_NAMES_SA = {FROM_NAME, "from_name", "from_kv", "id", TO_NAME, "to_name", "to_kv", 
                                                       "ck", "sec", "long_id", 
                                                       "st", "area", "zone", "g", "b", "date_in", "date_out", "proj_id",
                                                       "nst", "owner_1", "part_1", "owner_2", "part_2", "owner_3", "part_3", 
                                                       "owner_4", "part_4", "reg_bus", "reg_name", "reg_kv"};
   
   public static final String[] SVD_ATTR_NAMES_SA = {"bus", "bus_name", "bus_kv", "id", "long_id", "st", "ty", "kreg_bus",
                                                     "kreg_name", "kreg_kv", "area", "zone", "g", "b", "bmin", "bmax",
                                                     "vband", "befmin", "befmax", "date_in", "date_out", "proj_id", "nst",
                                                     "o1", "p1", "o2", "p2", "o3", "p3", "o4", "p4", 
                                                     "n1", "b1", "n2", "b2", "n3", "b3", "n4", "b4", "n5", "b5", "n6", "b6",
                                                     "n7", "b7", "n8", "b8", "n9", "b9", "n10", "b10", "M", "st2"};
   
   public static final String[] AREA_ATTR_NAMES_SA = {"area", "area_name", "swing", "pnet_desised", "pnet_tol", "pnet", "qnet"};
   
   public static final String[] ZONE_ATTR_NAMES_SA = {"zone", "zone_name", "pznet", "qznet"};
   
   public static final String[] INTERFACE_ATTR_NAMES_SA = {"interface", "obj_name", "pnet", "qnet", "rate_1", "rate_2",
                                                           "rate_3", "rate_4", "rate_5", "rate_6", "rate_7", "rate_8"}; 
   
   public static final String[] INF_BRANCH_ATTR_NAMES_SA = {FROM_NAME, "from_name", "from_kv", TO_NAME, "to_name", 
                                                            "to_kv", "ck", "interface", "part_fac"};
   
   public static final String[] DC_BUS_ATTR_NAMES_SA = {"bus", "bus_name", "bus_kv", "ty", "area", "zone", "vsched", "dc_volt", 
                                                        "date_in","date_out", "pid", "owner", "M"};

   public static final String[] DC_LINE_ATTR_NAMES_SA = {FROM_NAME, "from_name", "from_kv", TO_NAME, "to_name", "to_kv", 
                                                         "ck", "long_id", "st", "area", "zone", "resist", "react", "capac",
                                                         "rate_1", "rate_2", "rate_3", "rate_4", "len", "aloss", "date_in",
                                                         "date_out", "PID", "N", "rate_5", "rate_6", "rate_7", "rate_8",
                                                         "owner_1", "part_1", "owner_2", "part_2", "owner_3", "part_3",
                                                         "owner_4", "part_4", "owner_5", "part_5", "owner_6", "part_6",
                                                         "owner_7", "part_7", "owner_8", "part_8"};
   
   public static final String[] DC_CONV_ATTR_NAMES_SA = {FROM_NAME, "from_name", "from_kv", TO_NAME, "to_name", "to_kv",
                                                         "id", "long_id", "st", "ty", "md", "nb", "fg", "attr_13", 
                                                         "no", "reg", "area", "zone", "date_in", "date_out",
                                                         "idc", "vdc", "pac", "qac", "p_schd", "i_schd", "v_schd", "i_marg",
                                                         "r_comp", "vmin_p", "vmin_c", "vac_bs", "vdc_bs",
                                                         "alpha", "al_min", "al_max", "gamma", "ga_min", "ga_max", "vdiode",
                                                         "xcomm", "r_tran", "x_tran",
                                                         "tbase", "tapfac", "tapfdc", "tap_ac", "tap_dc", "tmin", "tmax",
                                                         "tstep", "vtmax", "vtmin", "loss", "i_rate", "x_smoot", "pid", "N",
                                                         "owner_1", "part_1", "owner_2", "part_2", "owner_3", "part_3",
                                                         "owner_4", "part_4", "owner_5", "part_5", "owner_6", "part_6",
                                                         "owner_7", "part_7", "owner_8", "part_8"};
   
   public static final String[] ZTABLE_ATTR_NAMES_SA  = {"no", "ta", "t0", "f0", "t1", "f1", "t2", "f2", "t3", "f3", 
                                                         "t4", "f4", "t5", "f5", "t6", "f6", "t7", "f7", "t8", "f8",
                                                         "t9", "f9", "t10", "f10", "t11", "f11"};
   
   public static final String[] GCD_ATTR_NAMES_SA     = {};
   
   public static final String[] TRANSAC_ATTR_NAMES_SA = {"st", "sch_mw", "sch_mvar", "flag", "stn", "pid", "transaction", "name"};
   
   public static final String[] OWNER_ATTR_NAMES_SA   = {"owner", "owner_name", "s_name", "net_mw", "net_mvar", "sch_mw",
                                                         "sch_mvar",  "area"};
   
   public static final String[] INDUCT_ATTR_NAMES_SA  = {"ID", "long_id", "s", "area", "zone", "owner", "flag", "type", 
                                                         "mbase", "pelec", "qelec", "pf", "ls", "tp0", "lp", "tpp_0", "lpp",
                                                         "ra", "h", "rt", "lt", "bcap", "zppr", "zppx", "alt0", "alt1", "blt",
                                                         "alt2", "blt2", "date_in", "date_out", "pid", "N"};

   public static final String[] LINE_ATTR_NAMES_SA    = {FROM_NAME, "from_name", "from_kv", TO_NAME, "to_name", "to_kv", 
                                                         "ck", "sec", "long_id", "st", "pole_name", "length", "ws1","cond1", "ws2",
                                                         "cond2", "ws3", "cond3", "ws4", "cond4", "ws5", "cond5", "area", "zone",
                                                         "ncb", "rating", "date_in", "date_out", "proj_id", "nst", "o1", "p1", "o2",
                                                         "p2", "o3", "p3", "o4", "p4", "o5", "p5", "o6", "p6", "o7", "p7", "o8",
                                                         "p8", "r", "x", "char", "r0", "x0", "char0", "ampc0", "ampc1", "ampc2",
                                                         "ampc3", "ampc4", "ampc5", "loss"};
   
   public static final String[] GTABLE_ATTR_NAMES_SA  = {"id", "p[0]", "gmx[0]", "gmn[0]", "p[1]", "gmx[1]", "gmn[1]",
                                                               "p[2]", "gmx[2]", "gmn[2]", "p[3]", "gmx[3]", "gmn[3]",
                                                               "p[4]", "gmx[4]", "gmn[4]", "p[5]", "gmx[5]", "gmn[5]"};
 
   public static final String[] BAREA_ATTR_NAMES_SA  = {"b_area", "area_name", "swing", "pnet_desised", "pnet_tol", "pnet", 
                                                        "qnet"}; 

   //..... Sectors separator ":" position for version 15 ......
   // Number of attributes before separator ":"
   
   public static final Integer[] HEAD_ATTR_NUM_A = {null,null,null,null, 3, 9, 8, 5, 5, 10, 5, null, null, null, 7, 3,
                                                    8, 8, null, null, 0, 3, null, 9, null, null};  
   
   //----------------------------------- Aggregate arrays -----------------------------------------
   
   public static final String[][] ATTR_NAMES_SAA = {TITLE_ATTR_NAMES_SA, COMMENTS_ATTR_NAMES_SA, SOL_ATTR_NAMES_SA,
                                                    SUB_ATTR_NAMES_SA,
                                                    BUS_ATTR_NAMES_SA, BRANCH_ATTR_NAMES_SA, TRANS_ATTR_NAMES_SA, 
                                                    GEN_ATTR_NAMES_SA, LOAD_ATTR_NAMES_SA, SHUNT_ATTR_NAMES_SA, 
                                                    SVD_ATTR_NAMES_SA, AREA_ATTR_NAMES_SA, ZONE_ATTR_NAMES_SA, 
                                                    INTERFACE_ATTR_NAMES_SA, INF_BRANCH_ATTR_NAMES_SA,
                                                    DC_BUS_ATTR_NAMES_SA, DC_LINE_ATTR_NAMES_SA, DC_CONV_ATTR_NAMES_SA,
                                                    ZTABLE_ATTR_NAMES_SA, GCD_ATTR_NAMES_SA, TRANSAC_ATTR_NAMES_SA,
                                                    OWNER_ATTR_NAMES_SA, INDUCT_ATTR_NAMES_SA, LINE_ATTR_NAMES_SA,
                                                    GTABLE_ATTR_NAMES_SA, BAREA_ATTR_NAMES_SA};
}
//====================================== End of Interface =========================================
   