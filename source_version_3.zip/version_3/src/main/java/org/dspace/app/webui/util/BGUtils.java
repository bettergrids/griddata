package org.dspace.app.webui.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;


public class BGUtils {

   private static final Logger log = Logger.getLogger(BGUtils.class);
   
   private static final String _dateFormat   = "MM/dd/yyyy HH:mm";
   
   //----------------------------------------------------------------------------------------------
   // Convert String to UUID
   //----------------------------------------------------------------------------------------------
   
   public static UUID getUUID (String val_s)
   {
      try {
         return UUID.fromString(val_s);
      }
      catch (Exception e) {         
         if (val_s != null) {
            log.error("BGUtils.getUUID. Cannot convert string " + val_s + "to UUID");
         }
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   
   public static String ArrayListToString(ArrayList<String>alist)
   {
      if (alist == null) return "";
      
      StringBuilder sb = new StringBuilder();
      for (String s : alist) {
         sb.append(s);
      }
      return sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   
   public static String ArrayToString(String[] arr_sa, String delim_s)
   {
      if (arr_sa  == null) return "";
      if (delim_s == null) delim_s = " ";
      
      return String.join(delim_s, arr_sa);
   }
   //----------------------------------------------------------------------------------------------
   
   public static List<String> StringToArrayList(String text_s,
                                                String delim_s)
   {
      if (text_s == null || text_s.isEmpty()) {
         return new ArrayList<String>();
      }
      return Arrays.asList(text_s.split(delim_s));
   }
   //----------------------------------------------------------------------------------------------
   
   public static String[] ArrayListToArray(ArrayList<String> arr_al)
   {
      if (arr_al == null) return null;
      return arr_al.stream().toArray(String[]::new);
   }
   //----------------------------------------------------------------------------------------------
   // Two-dimensional array to ArrayList
   //----------------------------------------------------------------------------------------------

   public static <T> List<T> twoDArrayToList(T[][] twoDArray) 
   {
      List<T> list = new ArrayList<T>();
      for (T[] array : twoDArray) {
          list.addAll(Arrays.asList(array));
      }
      return list;
   }
   //----------------------------------------------------------------------------------------------
   // Two-dimensional array to ArrayList
   //----------------------------------------------------------------------------------------------

   public static List<String> collectionOfArraysToList(Collection<String[]> value_cl) 
   {
      List<String> value_al = new ArrayList<String>();
      Iterator<String[]> it = value_cl.iterator();
      
      while (it.hasNext()) {
         String[] val_sa = it.next();
         value_al.addAll(Arrays.asList(val_sa));
      }
      return value_al;
   }
   //----------------------------------------------------------------------------------------------
   // Array list of Strings to lower case
   //----------------------------------------------------------------------------------------------
   
   public static void toLowerCase(List<String> str_al)
   {
      if (str_al == null) return;
      
      for (int i = 0; i < str_al.size(); i++) {
         if (str_al.get(i) == null) continue;
         str_al.set(i, str_al.get(i).toLowerCase());
      }
   }
   //----------------------------------------------------------------------------------------------
   // Date functions
   //----------------------------------------------------------------------------------------------
   
   public static String getFormattedDate(Date date)
   {      
      if (date == null) {
         return "Not specified";
      }
      else {
         return new SimpleDateFormat(_dateFormat).format(date);
      }
   }   
   //----------------------------------------------------------------------------------------------
   
   public static String getDate_yyyy_MM_dd(LocalDate date)
   {      
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
      return date.format(formatter);
   }
   //----------------------------------------------------------------------------------------------
   
   public static String getNow_yyyy_MM_dd()
   {      
      return getDate_yyyy_MM_dd(LocalDate.now());
   }
   //----------------------------------------------------------------------------------------------
   
   public static Date getDateOpt(String date_s)
   {
      //..... Try to recognize format ......
      
      String format_s = null;
      
      try {
         String[] date_sa = date_s.split("[.-/]");
         if (date_sa.length != 3) return null;
      
         if (Integer.parseInt(date_sa[0]) <= 12 && Integer.parseInt(date_sa[1]) > 12) {
            format_s = "MM/dd/yy";
         }
         else {
            format_s = "dd/MM/yy";
         }
         DateFormat format = new SimpleDateFormat(format_s);
         return format.parse(date_s.trim());
      }
      catch (Exception e) {
         log.error("BGUtils.getDateOpt. String: " + date_s + " cannot be parsed to Date");
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static Double extractDoubleFromString(String str_s)
   {
      Matcher m = Pattern.compile("[^0-9\\.]*([0-9\\.]+).*").matcher(str_s);
      if (m.matches()) {
         return BGUtils.stringToDouble(m.group(1), 1);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   
   public static Integer extractIntFromString(String str_s)
   {
      Matcher m = Pattern.compile("[^0-9]*([0-9]+).*").matcher(str_s);
      if (m.matches()) {
         return BGUtils.stringToInteger(m.group(1));
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   // Check if match a number with optional '-' and decimal.
   //----------------------------------------------------------------------------------------------
   
   public static boolean isNumeric(String str)
   {
     return str != null && str.trim().matches("-?\\d+(\\.\\d+)?");       
     //return str.matches("[+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)");
     //return str != null && str.matches("[-+]?\\d*\\.?\\d+");  
   }
   //----------------------------------------------------------------------------------------------
   // Check if all string characters are letters
   //----------------------------------------------------------------------------------------------
   
   public static boolean isAlpha(String str_s) 
   {
      if (str_s == null || str_s.length() == 0) {
         return false;
      }
      if(Pattern.matches(".*[a-zA-Z]+.*[a-zA-Z]", str_s)) {
         return true;
      }
      return false;
      //return str_s.chars().allMatch(Character::isLetter);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static boolean isLetterOrDigit(String str_s) 
   {
      for (char c : str_s.toCharArray()) {
         if (!Character.isLetterOrDigit(c) && c != '/' && c != '-') {
            return false;
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Split words (and words with number at the end) and leading/trailing symbols
   //----------------------------------------------------------------------------------------------
   
   public static List<String> splitSymbols (String str_s) 
   {
      List<String> word_al = new ArrayList<String>();
      String  word_s = "";
      boolean inLetters_b = true; 
      
      char[] chars = str_s.trim().toCharArray();
      for (char c : chars) {
         if (Character.isAlphabetic(c) || c == '/' || c == '-' || 
             (word_s.length() > 0 && Character.isDigit(c))) {
            if (inLetters_b) {
               word_s += c;
            }
            else {
               if (word_s.length() > 0) {
                  word_al.add(word_s);
               }
               word_s = Character.toString(c);
               inLetters_b = true;
            }
         }
         else {
            if (inLetters_b) {
               if (word_s.length() > 0) {
                  word_al.add(word_s);
               }
               word_s = Character.toString(c);
               inLetters_b = false;
            }
            else {
               word_s += c;
            }            
         }
      }
      if (word_s.length() > 0) {
         word_al.add(word_s);
      }
      return word_al;
   }
   //----------------------------------------------------------------------------------------------
   
   public static Object stringToNumeric(String value_s)
   {
      if (value_s == null) return null;
      
      Object valueObj;
      try {
         valueObj = Double.parseDouble(value_s);    // if its numeric
         if ((Double)valueObj % 1 == 0) {
            try {
               Integer valueInt = Integer.parseInt(value_s);
               return valueInt;
            }
            catch (Exception e1) {
               return valueObj;                    // return Double
            }
         }
         return valueObj;
      }
      catch (Exception e0) { 
      }
      return value_s.trim();
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static List<Object> extendArrayList (int num, List<Object> attr_al)
   {
      Object tmp_arr = new Object[num];
      attr_al.addAll(Arrays.asList(tmp_arr));
      return attr_al;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static Double stringToDouble(String val_s)
   {
      return stringToDouble(val_s, null);
   }
   //----------------------------------------------------------------------------------------------
   
   public static Double stringToDouble(String  val_s, 
                                       Integer decimalNum)  // number of decimal points to round
   {
      try {
         Double val_d = Double.parseDouble(val_s);
         if (decimalNum != null && decimalNum > 0) {
            BigDecimal val_bd = new BigDecimal(val_d);
            val_bd = val_bd.setScale(decimalNum, RoundingMode.HALF_UP);
            return val_bd.doubleValue();
         }
         return val_d;
      }
      catch(Exception e) {
         //log.error("BGUtils.stringToDouble. Cannot convert string " + val_s + "to Double");
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   
   public static Integer stringToInteger(String val_s)
   {
      try {
         return Integer.parseInt(val_s.trim());
      }
      catch(Exception e) {
         //log.error("BGUtils.stringToInteger. Cannot convert string " + val_s + "to Integer");
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   
   public static String removeLastString(String str_s, 
                                         String suffix_s)
   {
      if (str_s    == null) return null;
      if (suffix_s == null) return str_s;
      
      int suffLen = suffix_s.length();
      if (str_s.endsWith(suffix_s)) {
         str_s = str_s.substring(0, str_s.length() - suffLen);
      }
      return str_s;
   }
   //----------------------------------------------------------------------------------------------
   // Delete the rest of string from the 1st occurrence of text_s
   //----------------------------------------------------------------------------------------------
   
   public static String deleteFrom(String str_s,      // input string
                                   String text_s)     // text to find
   {
      if (str_s != null && text_s != null && text_s.isEmpty() == false) {
         int pos = str_s.indexOf(text_s);
         if (pos >= 0) {
            return trimRight(str_s.substring(0, pos));
         }
      }
      return str_s;
   }
   //----------------------------------------------------------------------------------------------
   // Trim left and right white spaces
   //----------------------------------------------------------------------------------------------
   
   public static String trimLeft(String str_s)
   {
      return str_s.replaceAll("^\\s+","");
   }
   //----------------------------------------------------------------------------------------------
   
   public static String trimRight(String str_s)
   {
      return str_s.replaceAll("\\s+$","");
   }
   //----------------------------------------------------------------------------------------------
   // Remove (trim) specific leading and trailing characters
   //----------------------------------------------------------------------------------------------
   
   public static String trim(String string, 
                             char   leadingChar, 
                             char   trailingChar)
   {
      return string.replaceAll("^["+leadingChar+"]+|["+trailingChar+"]+$", "");
   }
   //----------------------------------------------------------------------------------------------
   
   public static String trim(String string, char ch)
   {
      return trim(string, ch, ch);
   }
   //----------------------------------------------------------------------------------------------
   // Remove (trim) specific leading and trailing set of characters (regex)
   //----------------------------------------------------------------------------------------------
   
   public static String trim(String string, 
                             String leadingRegex, 
                             String trailingRegex)
   {
      return string.replaceAll("^("+leadingRegex+")+|("+trailingRegex+")+$", "");
   }
   //----------------------------------------------------------------------------------------------

   public static String trim(String string, String regex)
   {
      return trim(string, regex, regex);
   }
   //----------------------------------------------------------------------------------------------
   
   public static String getNameFromFile(String path_s)
   {   
      //log.info("BGUtils.getNameFromFile. File path " + path_s);
      
      if (path_s == null) return null;
      
      int idx = path_s.lastIndexOf(File.separator);
      String fileName = path_s.substring(idx + 1);
      
      int pos = fileName.lastIndexOf(".");
      if (pos > 0) {
         fileName = fileName.substring(0, pos);
      }
      return fileName;
   }
   //----------------------------------------------------------------------------------------------
   
   public static String getFileNameFromPath(String path_s,
                                            String separator_s)
   {   
      //log.info("BGUtils.getNameFromFile. File path " + path_s);
      
      if (separator_s == null) {
         separator_s = File.separator;
      }
      int idx = path_s.lastIndexOf(separator_s);
      return path_s.substring(idx + 1).trim();
   }
   //----------------------------------------------------------------------------------------------
   
   public static String getFileNameFromPath(String path_s)

   {   
      return getFileNameFromPath(path_s, null);
   }
   //----------------------------------------------------------------------------------------------

   public static String getNameFromFile(String path_s,
                                        String separator_s)
   {   
      //log.info("BGUtils.getNameFromFile. File path " + path_s);
      
      int idx = path_s.lastIndexOf(separator_s);
      String fileName = path_s.substring(idx + 1);
      
      int pos = fileName.lastIndexOf(".");
      if (pos > 0) {
         fileName = fileName.substring(0, pos);
      }
      return fileName;
   }
   //----------------------------------------------------------------------------------------------
   
   public static String getFileExtension(String path_s)
   {   
      int idx = path_s.lastIndexOf(".");
      if (idx > 0) {
         return path_s.substring(idx + 1);
      }
      return "";
   }
   //----------------------------------------------------------------------------------------------
   // Find index of String[] element, which equal to 'find_s' string
   //----------------------------------------------------------------------------------------------
   
   public static Integer getStringIdx(String   find_s,
                                      String[] source_sa)
   {
      if (source_sa == null) return -1;
      return Arrays.asList(source_sa).indexOf(find_s);
   }
   //----------------------------------------------------------------------------------------------
   
   public static Integer getStringIdxIgnoreCase(String   find_s,
                                                String[] source_sa)
   {
      if (source_sa == null || find_s == null) return -1;
      for (int i = 0; i < source_sa.length; i++) {
         if (find_s.equalsIgnoreCase(source_sa[i])) {
            return i;
         }
      }
      return -1;
   }
   //----------------------------------------------------------------------------------------------
   
   public static Integer getStringIdx(String       find_s,
                                      List<String> source_al,
                                      Integer      startIdx,      // if null - 0
                                      Integer      endIdx)        // if null - source_al.size()
   { 
      if (startIdx == null) startIdx = 0;
      if (endIdx   == null) endIdx   = source_al.size();
      
      for (int i = startIdx; i < endIdx; i++) {
         if (find_s.equalsIgnoreCase(source_al.get(i))) {
            return i;
         }
      }
      return -1;
   }
   //----------------------------------------------------------------------------------------------
   // Find index of source element, which equal to one of the 'find_sa' string array
   //----------------------------------------------------------------------------------------------
   
   public static Integer getStringIdx(String[]     find_sa,
                                      List<String> source_al,
                                      Integer      startIdx,      // if null - 0
                                      Integer      endIdx)        // if null - source_al.size()
   { 
      if (startIdx == null) startIdx = 0;
      if (endIdx   == null) endIdx   = source_al.size();

      List<String> find_al = Arrays.asList(find_sa);
      
      for (int i = startIdx; i < endIdx; i++) {
         if (find_al.contains(source_al.get(i))) {
            return i;
         }
      }
      return -1;
   }
   //----------------------------------------------------------------------------------------------
   // Find index of first string from source_sa array which find_s string starts with 
   //----------------------------------------------------------------------------------------------
   
   public static Integer getStringStartIdx(String   find_s,
                                           String[] source_sa)
   {
      if (find_s == null || source_sa == null) return -1;
      
      int len = 0;
      int idx = -1;
      for (int i = 0; i < source_sa.length; i++) {
         if (find_s.startsWith(source_sa[i])) {
            if (source_sa[i].length() > len) {
               len = source_sa[i].length();
               idx = i;
            }
         }
      }
      return idx;
   }
   //----------------------------------------------------------------------------------------------
   // Find index of first string from "options_sa" array which exists in the string "line_s" 
   //----------------------------------------------------------------------------------------------
   
   public static Integer getOptionContainStringIdx(String   line_s,
                                                   String[] options_sa)
   {
      if (line_s == null || options_sa == null) return -1;
      
      for (int i = 0; i < options_sa.length; i++) {
         if (line_s.contains(options_sa[i])) {
            return i;
         }
      }
      return -1;
   }
   //----------------------------------------------------------------------------------------------
   // Find index of the first occurrence of any character from "seekAny_s" in the line_s
   //----------------------------------------------------------------------------------------------
   
   public static int getIndexOfAny(String line_s, 
                                   String seekAny_s) 
   {
      if (line_s == null || line_s.length() == 0 || seekAny_s == null || seekAny_s.length() == 0) {
          return -1;
      }
      for (int i = 0; i < seekAny_s.length(); i++) {
         int idx = line_s.indexOf(seekAny_s.charAt(i));
         if (idx != -1) return idx;
      }
      return -1;
   }
   //----------------------------------------------------------------------------------------------
   // Find index of first string from "options_sa" array which exists in the string "line_s" 
   //----------------------------------------------------------------------------------------------
   
   public static List<String> getElementsStartsWith(String   line_s,
                                                    String[] source_sa)
   {
      List<String> elem_al = new ArrayList<String>();      
      if (line_s == null || source_sa == null) return elem_al;
      
      for (int i = 0; i < source_sa.length; i++) {
         if (source_sa[i].toLowerCase().startsWith(line_s.toLowerCase())) {
            elem_al.add(source_sa[i]);
         }
      }
      return elem_al;
   }
   //----------------------------------------------------------------------------------------------
   // Find index of first string from "options_sa" array which starts with the string "line_s" 
   //----------------------------------------------------------------------------------------------
   
   public static Integer getOptionStartStringIdx(String   line_s,
                                                 String[] options_sa)
   {
      if (line_s == null || options_sa == null) return -1;
      
      for (int i = 0; i < options_sa.length; i++) {
         if (line_s.trim().startsWith(options_sa[i])) {
            return i;
         }
      }
      return -1;
   }
   //----------------------------------------------------------------------------------------------
   // Find the first word from the string separated by any of delimiter symbols
   //----------------------------------------------------------------------------------------------
   
   public static String getFirstWord(String line_s,
                                     String delim_s) 
   {
      int idx = BGUtils.getIndexOfAny(line_s, delim_s);
      if (idx > -1) {                                    // Check if there is more than one word.
         return line_s.substring(0, idx).trim();         // Extract first word.
      } 
      else {
         return line_s.trim();                           // Text is the first word itself.
      }
   }
   //----------------------------------------------------------------------------------------------
   // Find first index of "find_sa" array element, which found in the "text" string
   //----------------------------------------------------------------------------------------------
   
   public static Integer getIndexOf(String   text_s,
                                    String[] find_sa)
   {
      Integer idx = -1;
      for (int i = 0; i < find_sa.length; i++) {
         idx = text_s.indexOf(find_sa[i]);
         if (idx != -1) return i;
      }
      return idx;
   }
   //----------------------------------------------------------------------------------------------
   // Find first position of any of 'find_sa' strings in the 'text'
   //----------------------------------------------------------------------------------------------
   
   public static Integer getStringPos(String   text_s,
                                      String[] find_sa)
   {
      Integer idxMin = Integer.MAX_VALUE;
      for (int i = 0; i < find_sa.length; i++) {
         int idx = text_s.indexOf(find_sa[i]);
         if (idx != -1 && idx < idxMin) {
            idxMin = idx;
         }
      }
      return (idxMin == Integer.MAX_VALUE) ? -1 : idxMin;
   }
   //----------------------------------------------------------------------------------------------
   // Get map key is searching word in array of map values
   //----------------------------------------------------------------------------------------------
   
   public static String getKeyFromArrayValue(String               find_s,
                                             Map<String,String[]> data_hm)
   {
      for (Entry<String,String[]> mapEntry : data_hm.entrySet()) {
         String   key_s    = mapEntry.getKey();
         String[] value_sa = mapEntry.getValue();
         
         int idx = getStringIdx(find_s, value_sa);
         if (idx >= 0) return key_s;
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   // Get map keys as a String array
   //----------------------------------------------------------------------------------------------
   
   public static String[] getMapKeys(Map<String,?> map_hm)
   {
      if (map_hm == null) return null;
      return (String[])map_hm.keySet().toArray(new String[map_hm.keySet().size()]);
   }
   //----------------------------------------------------------------------------------------------
   // Find position of sub-array in the parent array 
   //----------------------------------------------------------------------------------------------

   public static int findArray(Integer[] parentArray, 
                               Integer[] subArray) 
   {
      if (subArray.length == 0) return -1;
      
      int limit = parentArray.length - subArray.length;
      next:
      for (int i = 0; i <= limit; i++) {
         for (int j = 0; j < subArray.length; j++) {
            if (subArray[j] != parentArray[i + j]) {
               continue next;
            }
         }
         // Sub array found - return its index
         return i;
      }
      // Return default value
      return -1;
   }   
   //----------------------------------------------------------------------------------------------
   // Add only unique elements
   //----------------------------------------------------------------------------------------------

   public static <GenericType> void addAllUnique (List<GenericType> mainList,
                                                  List<GenericType> addList)
   {
      if (addList == null || addList.isEmpty()) return; 
      for (GenericType val_s : addList) {
         if (mainList.contains(val_s)) continue;
         mainList.add(val_s);
      }
   }
   //----------------------------------------------------------------------------------------------
   // Split with whitespace, but not inside the quoted strings, like 'abc xyz'
   //----------------------------------------------------------------------------------------------
   
   public static String[] splitQuoted(String text_s)
   {
      String text_sa[] = text_s.split("\"|\'");      
      ArrayList<String> text_al = new ArrayList<String>(); 
      
      for (int i = 0; i < text_sa.length; i++) {         
         if ((i % 2) == 0) {                          // even
           String[] part_sa = text_sa[i].split(" ");
           for (String part_s : part_sa) {
              if (part_s.isEmpty() == false) {
                 text_al.add(part_s.trim());
              }
           }
         } 
         else {                                       // odd
           if (text_sa[i].isEmpty() == false) {
              text_al.add(text_sa[i].trim());
           }
         }
      }
      return text_al.toArray(new String[text_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   // Split with whitespace, but not inside the quoted strings, like 'abc xyz'
   //----------------------------------------------------------------------------------------------
   
   public static String[] splitQuoted(String text_s, 
                                      String delim_s)    // separator characters
   {
      text_s = text_s.trim();
      int[] quoteCnt = {0,0,0,0,0};    // ()[]{}"' 
      String quotes_s = "()[]{}\"'";     
      
      StringBuffer sb = new StringBuffer();
      List<String> text_al = new ArrayList<String>();
      int sum = 0;
      for (int i = 0; i <  text_s.length(); i++) {
         char c = text_s.charAt(i);

         //..... Update quotes if found ......
         
         switch(quotes_s.indexOf(c)) {
         case 0: quoteCnt[0]++; sum++;  break;              // "("
         case 1: quoteCnt[0]--; sum--;  break;              // ")"
         case 2: quoteCnt[1]++; sum++;  break;              // "["
         case 3: quoteCnt[1]--; sum--;  break;              // "]"
         case 4: quoteCnt[2]++; sum++;  break;              // "{"
         case 5: quoteCnt[2]--; sum--;  break;              // "}"
         case 6: 
            quoteCnt[3] = Math.abs(quoteCnt[3] - 1);        // "\""
            if (quoteCnt[3] == 0) sum--;
            else                  sum++;
            break;                                                          
         case 7: 
            quoteCnt[4] = Math.abs(quoteCnt[4] - 1);        // "'"
            if (quoteCnt[4] == 0) sum--;
            else                  sum++;
            break;     
         }
         //..... Find delimiter ......
            
         if (sum == 0 && (delim_s.indexOf(c) >= 0 || i == text_s.length() - 1)) {
            if (sb.length() > 0) {
               if (i == text_s.length() - 1) {
                  sb.append(c);                                      // add last character
               }
               text_al.add(trim(sb.toString().trim(), '"', '"'));    // add new token
               sb = new StringBuffer();
            }
            continue;
         }
         //..... Add character to the string buffer ......
         
         sb.append(c);
      }
      if (sum != 0) {
         log.error("splitQuoted. Error in the text quotation (quote pairing)");
      }
      return text_al.toArray(new String[text_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   // Replace only words or text separated from other with whitespaces
   //----------------------------------------------------------------------------------------------

   public static String replaceWords(String text_s,
                                     String exist_s,
                                     String new_s)
   {
      String regex = "\\b" + exist_s + "\\b";
      text_s = text_s.replaceAll(regex, new_s);
      return text_s;
   }
   //----------------------------------------------------------------------------------------------
   
   public static boolean stringToFile(String text_s,
                                      String filePath_s)
   {
      BufferedWriter buffWriter = null;
      FileWriter     fileWriter = null;
      
      try {
         fileWriter = new FileWriter(filePath_s, false);
         buffWriter = new BufferedWriter(fileWriter);
         buffWriter.write(text_s);
      }
      catch (IOException e0) {
         log.error("BGUtils.stringToFile. Error in saving file: " + filePath_s + ". Message: " + e0.getMessage());
         return false;
      } 
      finally {
         try {
            if (buffWriter != null) {
               buffWriter.close();
            }
            if (fileWriter != null) {
               fileWriter.close();
            }
         } 
         catch (IOException e1) {
            log.error("BGUtils.stringToFile. Cannot close BufferedWriter or FileWriter. Message: " + e1.getMessage());
            return false;
         }
      }
      log.info("BGUtils.stringToFile. File: " + filePath_s + " written successfully!");
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Read file to string
   //----------------------------------------------------------------------------------------------
   
   public static String readFile(String filePath_s)
   {
      String  text_s  = null;
      Scanner scanner = null;
      try {
         File file = new File(filePath_s);
         StringBuilder fileContents = new StringBuilder((int)file.length());
         scanner = new Scanner(file);
    
         while(scanner.hasNextLine()) {
            fileContents.append(scanner.nextLine() + "\n");
         }
         text_s = fileContents.toString();
      } 
      catch(Exception e) {
         log.error("BGUtils.readFile. Error in parsing file: " + filePath_s + 
                   "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
      }
      finally {
         if (scanner != null) {
            scanner.close();
         }
      }
      return text_s;
   }
   //----------------------------------------------------------------------------------------------
   // Get file size
   //----------------------------------------------------------------------------------------------
   
   public Long getFileSize(String filePath_s)
   {
      try {
         File file = new File(filePath_s);
         return file.length();
      } 
      catch (Exception e) {
         log.error("getFileSize. Cannot get file size for " + filePath_s);
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   // Parse voltage complex number (e.g. 318.750-335.973j or -8.75+335.9d)
   //----------------------------------------------------------------------------------------------
   
   public static Object[] parseComplexNum(String val_s)
   {
      val_s = val_s.replaceAll("\\s","");
            
      int pos = Math.max(val_s.lastIndexOf("+"), val_s.lastIndexOf("-"));
      if (pos < 1) {
         return null;
      }
      //..... Real part ......
      
      try {
         int len = val_s.length();
         Object[] val_arr = new Object[3];
      
         val_arr[0]  = Double.valueOf(val_s.substring(0, pos));
         val_arr[1]  = Double.valueOf(val_s.substring(0, len - 1).substring(pos));
         String form = val_s.substring(len - 1);
         
         if (form.equalsIgnoreCase("j")) {
            val_arr[2] = "rectangular";
         }
         else if (form.equalsIgnoreCase("d")) {
            val_arr[2] = "polar";
         }
         else {
            return null;
         }         
         return val_arr;
      }
      catch (Exception e) {
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   // Delete file
   //----------------------------------------------------------------------------------------------
   
   public static boolean deleteFile(String filePath_s)
   {
      try {
         File file = new File(filePath_s);
         boolean res_b = Files.deleteIfExists(file.toPath());
         if (res_b == false) {
            String message = file.exists() ? "is in use by another app" : "does not exist";
            log.error("deleteFile. Cannot delete file, because file " + message + ".");
         }
         return res_b;
      } 
      catch (Exception e) {
         log.error("deleteFile. Cannot delete file: " + filePath_s + 
                   "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
         return false;
      }
   }
   //----------------------------------------------------------------------------------------------
   // Return number of CPUs (cores, including hyper-threading)
   //----------------------------------------------------------------------------------------------
   
   public static int getSystemCoreNum()
   {
      int coreNum = Runtime.getRuntime().availableProcessors();     // number of system CPU
      if (coreNum < 1) coreNum = 1;
      return coreNum;
   }
   //----------------------------------------------------------------------------------------------
   // Convert JSON object (string) to XML (string) with using org.json
   //----------------------------------------------------------------------------------------------
   
   public static String jsonToXml(String  json_s,
                                  String  root_s,        // root element, like "model"
                                  Boolean format_b)      // fancy formatting with indents
   {
      if (root_s   == null) root_s = "objects";
      if (format_b == null) format_b = false;
      
      try {
         JSONObject json_o = new JSONObject(json_s);
         String xml_s = XML.toString(json_o, root_s);
         
         if (format_b) {
            StreamSource source = new StreamSource(new StringReader(xml_s));
            StringWriter writer = new StringWriter();
            StreamResult result = new StreamResult(writer);
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);
            xml_s = writer.toString();
         }
         return xml_s;
      }
      catch (Exception e) {
         log.error("jsonToXml. Cannot convert JSON string to XML" +
                   "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
         return null;
      }     
   }
   //----------------------------------------------------------------------------------------------
   // Check if this file a zip-archive
   //----------------------------------------------------------------------------------------------
   
   public static boolean isArchive(String filePath_s) 
   {
      int fileSignature = 0;
      RandomAccessFile raf = null;

      try {
         File file = new File(filePath_s);
         raf = new RandomAccessFile(file, "r");
         fileSignature = raf.readInt();
      } 
      catch (IOException e) {
         log.error("isArchive. Cannot find/open file " + filePath_s +
               "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
      } 
      finally {
          IOUtils.closeQuietly(raf);
      }
      return fileSignature == 0x504B0304 || fileSignature == 0x504B0506 || fileSignature == 0x504B0708;
   }
   //----------------------------------------------------------------------------------------------
   // Heap memory usage
   //----------------------------------------------------------------------------------------------
   
   public static boolean heapMemoryUsageLog()
   {
      // Get current size of heap in MB
      long heapSize = Runtime.getRuntime().totalMemory() / 1048576; 

      // Get maximum size of heap in MB. The heap cannot grow beyond this size.
      // Any attempt will result in an OutOfMemoryException.
      long heapMaxSize = Runtime.getRuntime().maxMemory() / 1048576;

      // Get amount of free memory within the heap in MB. This size will increase 
      // after garbage collection and decrease as new objects are created.
      long heapFreeSize = Runtime.getRuntime().freeMemory() / 1048576;
      
      log.info("heapMemoryUsageLog. Heap sizes, MB. Max.('out-of-memory' if exceeds): " + heapMaxSize + 
               "; Current: " + heapSize + "; Free: " + heapFreeSize);
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Force to run GC. This method guarantees that garbage collection is done unlike: System.gc()
   //----------------------------------------------------------------------------------------------

   public static void runGC() 
   {
      log.info("runGC. Force to run GC.");
      Object obj = new Object();
      WeakReference<Object> ref = new WeakReference<Object>(obj);
      obj = null;
      while(ref.get() != null) {
         System.gc();
      }
      System.runFinalization();
      log.info("runGC. Finish GC finalization.");
   }
   //----------------------------------------------------------------------------------------------
   // REFLECTION. get private class member names
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("rawtypes")
   public static String[] getPrivateMemberNames(Class clazz)
   {
      List<String> memberName_al = new ArrayList<String>();
      
      Field[] fields = clazz.getDeclaredFields();
      for (Field field : fields) {
         if (Modifier.isPrivate(field.getModifiers())) {
            memberName_al.add(field.getName());
         }
      }
      return memberName_al.toArray(new String[memberName_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("rawtypes")
   public static String[] getPrivateMemberTypes(Class clazz)
   {
      List<String> memberName_al = new ArrayList<String>();
      
      Field[] fields = clazz.getDeclaredFields();
      for (Field field : fields) {
         if (Modifier.isPrivate(field.getModifiers())) {
            memberName_al.add(field.getType().getName());
         }
      }
      return memberName_al.toArray(new String[memberName_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("rawtypes")
   public static Class[] getPrivateMemberClasses(Class clazz)
   {
      List<Class> memberName_al = new ArrayList<Class>();
      
      Field[] fields = clazz.getDeclaredFields();
      for (Field field : fields) {
         if (Modifier.isPrivate(field.getModifiers())) {
            memberName_al.add(field.getType());
         }
      }
      return memberName_al.toArray(new Class[memberName_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("rawtypes")
   public static boolean setClassMember(Object obj,            // the object to set the field value on
                                        String fieldName,      // name of the field (class member)
                                        Object fieldValue)     // value to set on the field
   {
      Field field;
      try {
         field = obj.getClass().getDeclaredField(fieldName);
      } 
      catch (NoSuchFieldException e) {
         field = null;
      }
      //..... Try to find the field (member) in the superclass ......
      
      Class superClass = obj.getClass().getSuperclass();
      while (field == null && superClass != null) {
         try {
            field = superClass.getDeclaredField(fieldName);
         } 
         catch (NoSuchFieldException e) {
            superClass = superClass.getSuperclass();
         }
      }
      if (field == null) {
         log.error("setClassMember. No member '" + fieldName + 
                   "' of class '" + obj.getClass().getName() + "' found.");
         return false;
      }
      //..... Set value to the class member ......
      
      field.setAccessible(true);
      try {
         field.set(obj, fieldValue);
         return true;
      } 
      catch (IllegalAccessException e) {
         log.error("setClassMember. Member '" + fieldName + 
               "' of class '" + obj.getClass().getName() + "' is not accessable.");
         return false;
      }
   }
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("rawtypes")
   public static Class getFieldClass(Class  clazz,
                              String fieldName_s)
   {
      Field field;
      try {
         field = clazz.getDeclaredField(fieldName_s);
         return field.getType();
      } 
      catch (NoSuchFieldException e) {
         log.error("getMemberClass. Cannot find field '" + fieldName_s + 
               "' in the class '" + clazz.getName() + "'");
         return null;
      }
   }
}
//======================================= End of Class ============================================
