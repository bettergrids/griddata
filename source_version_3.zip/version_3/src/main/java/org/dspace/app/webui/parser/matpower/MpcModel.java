package org.dspace.app.webui.parser.matpower;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBTypes;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGUtils;

public class MpcModel extends BGModel implements MpcTypes {
   
   private static final Logger log = Logger.getLogger(MpcModel.class);

   private String  version_s;
   private Integer baseMVA;
   
   @SuppressWarnings("unchecked")
   private Map<String, MpcObject>[] object_ahm    = (LinkedHashMap<String, MpcObject>[])new LinkedHashMap[OBJECT_TYPE_NAMES_SA.length];
   @SuppressWarnings("unchecked")
   private List<String>[]           attrNames_aal = (ArrayList<String>[])new ArrayList[OBJECT_TYPE_NAMES_SA.length];
   @SuppressWarnings("unchecked")
   private List<Integer>[]          attrTypes_aal = (ArrayList<Integer>[])new ArrayList[TYPE_IDS_AA.length];

   //..... Getters/Setters ......
   
   public String getVersion() {
      return version_s;
   }
   public void setVersion(String version_s) {
      this.version_s = version_s;
   }
   public Integer getBaseMVA() {
      return baseMVA;
   }
   public void setBaseMVA(Integer baseMVA) {
      this.baseMVA = baseMVA;
   }   
   //----------------------------------------------------------------------------------------------
   // Get/Set attribute names and types for specific type 
   //----------------------------------------------------------------------------------------------

   public void setAttrNames(int typeIdx) 
   {
      if (typeIdx < 0 || typeIdx >= OBJECT_TYPES_SAA.length) {
         log.error("MpcModel.setAttrNames. Cannot return attribute names for type index: " + typeIdx);
         return;
      }
      if (object_ahm[typeIdx] != null && object_ahm[typeIdx].isEmpty() == false) {
     
         String typeName = OBJECT_TYPE_SHOW_SA[typeIdx];
         
         MpcObject obj = (MpcObject)object_ahm[typeIdx].values().toArray()[0];
         int attrNum = obj.getAttrNum();
         
         attrNames_aal[typeIdx] = new ArrayList<String>(Arrays.asList(Arrays.copyOfRange(OBJECT_NAMES_SAA[typeIdx], 0, attrNum)));
         attrTypes_aal[typeIdx] = new ArrayList<Integer>(Arrays.asList(Arrays.copyOfRange(TYPE_IDS_AA[typeIdx], 0, attrNum)));
         
         //..... Gen.Cost - special case ......
         
         if (typeIdx == TYPE_COST_IDX) {
            
            Integer coefNum = Integer.parseInt(obj.getAttr(TYPE_COST_COEF_NUM_IDX).toString());
            Integer costNum = GEN_COST_SA.length + coefNum;
            
            for (int i = GEN_COST_SA.length; i < costNum; i++) {   // coefficient columns
               Integer idx     = costNum - i - 1;
               String attrName = "c" + idx;
               attrNames_aal[typeIdx].set(i, attrName);
               attrTypes_aal[typeIdx].set(i, DBTypes.typeDouble);
            }
            // if any additional unknown attributes exist
            
            for (int i = costNum; i < attrNum; i++) {
               String attrNew = typeName + "_attr_" + i;
               attrNames_aal[typeIdx].add(attrNew);
               attrTypes_aal[typeIdx].add(DBTypes.typeVarchar);
            }
         }
         //..... All other types ......
 
         else {           
            for (int i = OBJECT_TYPES_SAA[typeIdx].length; i < attrNum; i++) {
               String attrNew = typeName + "_attr_" + i;
               attrNames_aal[typeIdx].set(i, attrNew);
               attrTypes_aal[typeIdx].set(i, DBTypes.typeVarchar);
            }
         }
      }
      //..... No object for this type ......
      
      else {
         attrNames_aal[typeIdx] = new ArrayList<String>(Arrays.asList(OBJECT_NAMES_SAA[typeIdx]));
         attrTypes_aal[typeIdx] = new ArrayList<Integer>(Arrays.asList(TYPE_IDS_AA[typeIdx]));
      }
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public List<String> getAttrNames(int typeIdx) 
   {
      if (typeIdx < 0 || typeIdx >= OBJECT_TYPES_SAA.length) {
         log.error("MpcModel.getAttrNames. Cannot return attribute names for type index: " + typeIdx);
         return null;
      }
      if (attrNames_aal[typeIdx] == null) {
         setAttrNames(typeIdx);
      }
      return attrNames_aal[typeIdx];
   } 
   //----------------------------------------------------------------------------------------------

   @Override
   public List<Integer> getAttrTypes(int typeIdx) 
   {
      if (typeIdx < 0 || typeIdx >= TYPE_IDS_AA.length) {
         log.error("MpcModel.getAttrTypes. Cannot return attribute types for type index: " + typeIdx);
         return null;
      }
      if (attrTypes_aal[typeIdx] == null) {
         setAttrNames(typeIdx);
      }
      return attrTypes_aal[typeIdx];
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String getObjTypeName(int typeIdx) 
   {
      if (typeIdx < 0 || typeIdx >= OBJECT_TYPE_SHOW_SA.length) return null;
      return OBJECT_TYPE_SHOW_SA[typeIdx];
   }
   //----------------------------------------------------------------------------------------------   
   
   @Override
   public Integer getAttrIdx(int sectIdx, String attrName) 
   {
      try {
         return getAttrNames(sectIdx).indexOf(attrName);
      }
      catch(Exception e) {
         log.error("MpcModel.getAttrIdx. Cannot find attribute for section index: " + sectIdx + 
                   " and attribute name: " + attrName);
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   // Get some model statistics
   //----------------------------------------------------------------------------------------------
   
   public int getObjectNum()
   {
      int objNum = 0;
      for (Map<String, MpcObject> obj_hm : object_ahm) {
         if (obj_hm != null) {
            objNum += obj_hm.size();
         }
      }
      return objNum;
   }
   //----------------------------------------------------------------------------------------------
   
   public Integer getObjectNum(Integer objTypeIdx)
   {
      if (objTypeIdx != null && objTypeIdx >= 0 && object_ahm.length > objTypeIdx) {
         if (object_ahm[objTypeIdx] != null) {
            return object_ahm[objTypeIdx].size();
         }
      }
      return 0;
   }
 //----------------------------------------------------------------------------------------------
   
   public void addObject(Integer   typeIdx, 
                         String    objName_s, 
                         MpcObject obj)
   {
      if (object_ahm[typeIdx] == null) {
         object_ahm[typeIdx] = new LinkedHashMap<String, MpcObject>();
      }
      object_ahm[typeIdx].put(objName_s, obj);
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Integer getTypesNum()
   {
      return object_ahm.length;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public boolean calcTypeCounts() 
   {
      //..... Calculate counts of all types ......
   
      for (int j = 0; j < object_ahm.length; j++) {
         if (object_ahm[j] == null) continue;
         typeCounts.put(OBJECT_TYPE_SHOW_SA[j], object_ahm[j].size());
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();
      json_sb.append("{\n\""  + BGObject.OBJECT_CONST + "\": [\n");
      
      //..... For each object ......
      
      for (int j = 0; j < object_ahm.length; j++) {
         if (object_ahm[j] != null) {
            for (MpcObject obj : object_ahm[j].values()) {
               json_sb.append(obj.toJson());
            }
         }
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n]\n}");
      
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private Integer getObjIdxFromName (String objName_s)
   {
      if (objName_s == null) return null;
         
      int pos = objName_s.lastIndexOf("_");
      if (pos != -1 && pos < objName_s.length()) {
         try {
            Integer objIdx = Integer.valueOf(objName_s.substring(pos + 1));
            return objIdx;
         }
         catch (Exception e) {
            return null;
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private Integer getTypeIdxFromName (String objName_s)
   {
      if (objName_s == null) return null;
         
      int pos = objName_s.lastIndexOf("_");
      if (pos != -1 && pos < objName_s.length()) {
         String typeName_s = objName_s.substring(0, pos);
         Integer objTypeIdx = BGUtils.getStringIdx(typeName_s, OBJECT_TYPE_SHOW_SA);
         if (objTypeIdx != -1) {
            return objTypeIdx;
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private Integer getTypeIdxFromType (String objType_s)
   {
      if (objType_s == null) return null;
      
      Integer typeIdx = BGUtils.getStringIdx(objType_s, OBJECT_TYPE_SHOW_SA);
      if (typeIdx < 0) {
         log.error("MpcModel.getEntry. Cannot find index for objType_s = " + objType_s);
         return null;
      }
      return typeIdx;
   }   
   //----------------------------------------------------------------------------------------------
   // Find object based on object name
   //----------------------------------------------------------------------------------------------
   
   @Override
   public MpcObject getObject(String name_s) 
   {
      if (name_s == null) return null;
      
      Integer objTypeIdx = getTypeIdxFromName(name_s);
      if (objTypeIdx == null) return null;
      
      Integer objId = getObjIdxFromName(name_s);
      if (objId == null) return null;

      //..... Find object ......
      
      return object_ahm[objTypeIdx].get(name_s);
   }
   //----------------------------------------------------------------------------------------------
   // Return all type names
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getObjTypeNames() 
   {
      return OBJECT_TYPE_SHOW_SA;      
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getStaticObjTypeNames() 
   {
      return OBJECT_TYPE_SHOW_SA;      
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getNodeObjTypeNames() 
   {
      return new String[] {OBJECT_TYPE_SHOW_SA[TYPE_BUS_IDX]};  
   }
   //----------------------------------------------------------------------------------------------
   // Return all model objects of certain type
   //----------------------------------------------------------------------------------------------

   @Override
   public MpcObject[] getObjects(int typeIdx) 
   {
      try {
         return object_ahm[typeIdx].values().toArray(new MpcObject[0]);
      }
      catch (Exception e) {
         return new MpcObject[0];
      }
   }
   //----------------------------------------------------------------------------------------------
   // Return all model objects 
   //----------------------------------------------------------------------------------------------

   @Override
   public MpcObject[] getObjects() 
   {
      List<MpcObject> objs = new ArrayList<MpcObject>();
      
      for (int typeIdx = 0; typeIdx < object_ahm.length; typeIdx++) {
         if (object_ahm[typeIdx] != null) {
            objs.addAll(object_ahm[typeIdx].values());
         }
      }
      return objs.toArray(new MpcObject[objs.size()]);
   }
   //----------------------------------------------------------------------------------------------
   // Return array of specific type objects
   //----------------------------------------------------------------------------------------------
   
   @Override
   public MpcObject[] getObjects(String typeName_s) 
   {
      try {
         Integer objTypeIdx = getTypeIdxFromType(typeName_s);
         return object_ahm[objTypeIdx].values().toArray(new MpcObject[0]);
      }
      catch (Exception e) {
         log.info("MpcModel.getObjects. No objects for type: " + typeName_s);
         return new MpcObject[0];
      }
   }
   //----------------------------------------------------------------------------------------------
   // Return array of specific types objects
   //----------------------------------------------------------------------------------------------
   
   @Override
   public MpcObject[] getLinkObjects() 
   {
      List<MpcObject> objs_al = new ArrayList<MpcObject>(); 
      
      for (int sectIdx = 0; sectIdx < getTypesNum(); sectIdx++) {    
         List<String> attrNames = getAttrNames(sectIdx);
     
         if (attrNames.contains(MpcTypes.FROM_NAME) && attrNames.contains(MpcTypes.TO_NAME)) {
            MpcObject[] objs = getObjects(sectIdx);
            objs_al.addAll(Arrays.asList(objs));           
         }
      }
      return objs_al.toArray(new MpcObject[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getLinkObjTypeNames() 
   {
      List<String> objs_al = new ArrayList<String>(); 
         
      for (int sectIdx = 0; sectIdx < getTypesNum(); sectIdx++) {    
         List<String> attrNames = getAttrNames(sectIdx);
        
         if (attrNames.contains(MpcTypes.FROM_NAME) && attrNames.contains(MpcTypes.TO_NAME)) {
            String objType_s = getObjTypeName(sectIdx);
            objs_al.add(objType_s);           
         }
      }
      return objs_al.toArray(new String[objs_al.size()]);
   }
}
//======================================= End of Class ============================================
