package org.dspace.app.webui.parser.cyme;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;

public class CymObject extends BGObject 
{
   //..... Members ......
   
   private CymModel model;
   
   private List<Object> attr_al = new ArrayList<Object>();
   
   //..... Constructor ......
   
   public CymObject(CymModel model) 
   {
      this.model = model;
   }
   //..... Methods ......
   
   @Override
   public BGModel getModel() {
      return model;
   }
   @Override
   public void setModel(BGModel model) 
   {
      this.model = (CymModel)model;   
   }
   public void setModel(CymModel model) {
      this.model = model;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean addAttr(String name_s,
                          String value_s)
   {
      if (name_s != null && type != null) {
         attr_al.add(value_s);
         model.addAttrName(type, name_s);
         return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public void setAttrs(List<String> attr_sal)
   {
      attr_al = new ArrayList<Object>(attr_sal);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Object getAttr(String attrName) 
   {
      Integer attrIdx = model.getAttrNames(type).indexOf(attrName);
      if (attrIdx != -1) {
         return getAttr(attrIdx);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Object getAttr(int attrIdx) 
   {
      return attr_al.get(attrIdx);
   }
   //----------------------------------------------------------------------------------------------
   // Get attribute nanes
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getAttrNames()
   {
      if (type != null) {
         return model.getAttrNames(type).toArray(new String[0]);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   // Add attributes
   //----------------------------------------------------------------------------------------------
   
   public void setAttrs(String[] attr_sa)
   {
      attr_al = new ArrayList<Object>(Arrays.asList(attr_sa));
   }

   @Override
   public DBTable getTable() {
      // TODO Auto-generated method stub
      return null;
   }


   @Override
   public List<Object> getAttrs() {
      // TODO Auto-generated method stub
      return null;
   }

 
}
