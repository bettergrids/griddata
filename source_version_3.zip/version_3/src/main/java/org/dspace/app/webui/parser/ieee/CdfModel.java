package org.dspace.app.webui.parser.ieee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGUtils;

public class CdfModel extends BGModel implements CdfTypes {

   private static final Logger log = Logger.getLogger(CdfModel.class);
   
   @SuppressWarnings("unchecked")
   private Map<String, CdfObject>[] object_ahm = (LinkedHashMap<String, CdfObject>[])new LinkedHashMap[TITLES_SA.length];

   //..... Methods ......
   
   //----------------------------------------------------------------------------------------------
   // Get attribute names and types for specific type 
   //----------------------------------------------------------------------------------------------
   
   @Override
   public List<String> getAttrNames(int typeIdx) 
   {
      if (typeIdx < 0 || typeIdx >= ATTR_NAMES_SAA.length) {
         log.error("CdfModel.getAttrNames. Cannot return attribute names for type index: " + typeIdx);
         return null;
      }
      return new ArrayList<String>(Arrays.asList(ATTR_NAMES_SAA[typeIdx]));
   }
   //----------------------------------------------------------------------------------------------

   @Override
   public List<Integer> getAttrTypes(int typeIdx) 
   {
      if (typeIdx < 0 || typeIdx >= ATTR_TYPES_AA.length) {
         log.error("CdfModel.getAttrTypes. Cannot return attribute types for type index: " + typeIdx);
         return null;
      }
      return new ArrayList<Integer>(Arrays.asList(ATTR_TYPES_AA[typeIdx]));
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String getObjTypeName(int sectIdx) 
   {
      if (sectIdx < 0 || sectIdx >= TYPES_SA.length) return null;
      return TYPES_SA[sectIdx];
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Integer getAttrIdx(int sectIdx, String attrName) 
   {
      try {
         return getAttrNames(sectIdx).indexOf(attrName);
      }
      catch(Exception e) {
         log.error("MpcModel.getAttrIdx. Cannot find attribute for section index: " + sectIdx + 
                   " and attribute name: " + attrName);
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   // Get some model statistics
   //----------------------------------------------------------------------------------------------
   
   public int getObjectNum()
   {
      int objNum = 0;
      for (Map<String, CdfObject> obj_hm : object_ahm) {
         if (obj_hm != null) {
            objNum += obj_hm.size();
         }
      }
      return objNum;
   }
   //----------------------------------------------------------------------------------------------
   // Add object of certain type
   //----------------------------------------------------------------------------------------------

   public void addObject(Integer   typeIdx, 
                         String    objName_s, 
                         CdfObject obj)
   {
      if (object_ahm[typeIdx] == null) {
         object_ahm[typeIdx] = new LinkedHashMap<String, CdfObject>();
      }
      object_ahm[typeIdx].put(objName_s, obj);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public boolean calcTypeCounts() 
   {
      //..... Calculate counts of all types ......
   
      for (int j = 0; j < object_ahm.length; j++) {
         if (object_ahm[j] == null) continue;
         typeCounts.put(TYPES_SA[j], object_ahm[j].size());
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private Integer getObjIdxFromName (String objName_s)
   {
      if (objName_s == null) return null;
         
      int pos = objName_s.lastIndexOf("_");
      if (pos != -1 && pos < objName_s.length()) {
         try {
            Integer objIdx = Integer.valueOf(objName_s.substring(pos + 1));
            return objIdx;
         }
         catch (Exception e) {
            return null;
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private Integer getTypeIdxFromName (String objName_s)
   {
      if (objName_s == null) return null;
         
      int pos = objName_s.lastIndexOf("_");
      if (pos != -1 && pos < objName_s.length()) {
         String typeName_s = objName_s.substring(0, pos);
         Integer objTypeIdx = BGUtils.getStringIdx(typeName_s, TYPES_SA);
         if (objTypeIdx != -1) {
            return objTypeIdx;
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private Integer getTypeIdxFromType (String objType_s)
   {
      if (objType_s == null) return null;
      
      Integer typeIdx = BGUtils.getStringIdx(objType_s, TYPES_SA);
      if (typeIdx < 0) {
         log.error("MpcModel.getEntry. Cannot find index for objType_s = " + objType_s);
         return null;
      }
      return typeIdx;
   }   

   //----------------------------------------------------------------------------------------------
   // Find object based on object name
   //----------------------------------------------------------------------------------------------
   
   @Override
   public CdfObject getObject(String name_s) 
   {
      if (name_s == null) return null;
      
      Integer objTypeIdx = getTypeIdxFromName(name_s);
      if (objTypeIdx == null) return null;
      
      Integer objId = getObjIdxFromName(name_s);
      if (objId == null) return null;

      //..... Find object ......
      
      return object_ahm[objTypeIdx].get(name_s);
   }
   
   @Override
   public Integer getTypesNum()
   {
      return object_ahm.length;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();
      json_sb.append("{\n\""  + BGObject.OBJECT_CONST + "\": [\n");
      
      //..... For each object ......
      
      for (int j = 0; j < object_ahm.length; j++) {
         if (object_ahm[j] != null) {
            for (CdfObject obj : object_ahm[j].values()) {
               json_sb.append(obj.toJson());
            }
         }
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n]\n}");
      
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   // To graph JSON
   //----------------------------------------------------------------------------------------------
   
   public String toGraphJson() 
   {
      StringBuffer json_sb = new StringBuffer();
      json_sb.append("{\n   \"nodes\": [\n");

      //..... For each bus ......
      
      for (CdfObject obj : object_ahm[1].values()) {
         String loss_zone = ((Integer)obj.getAttr(3)).toString();
         json_sb.append("      {\"id\": \"" + obj.getName() + "\", \"group\": " + loss_zone + "},\n");
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n],\n");
      json_sb.append("   \"links\": [\n");
      
      
      for (CdfObject obj : object_ahm[2].values()) {
         String source = (String)obj.getAttr(0);
         String target = (String)obj.getAttr(1);
         
         if (source != null && target != null) {
            json_sb.append("      {\"source\": \"" + source + "\", \"target\": \"" + target + "\", \"value\": 1},\n");            
         }
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n]\n}");
      
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   // Return all type names
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getObjTypeNames() 
   {
      return TYPES_SA;     
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getStaticObjTypeNames() 
   {
      return TYPES_SA;     
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getNodeObjTypeNames() 
   {
      return new String[] {TYPES_SA[SECT_BUS_IDX]};
   }
   //----------------------------------------------------------------------------------------------
   // Return all model objects of sertain type
   //----------------------------------------------------------------------------------------------

   @Override
   public CdfObject[] getObjects(int typeIdx) 
   {
      try {
         return object_ahm[typeIdx].values().toArray(new CdfObject[0]);
      }
      catch (Exception e) {
         return new CdfObject[0];
      }
   }
   //----------------------------------------------------------------------------------------------
   // Return array of specific type objects
   //----------------------------------------------------------------------------------------------
   
   @Override
   public CdfObject[] getObjects(String typeName_s) 
   {
      try {
         Integer objTypeIdx = getTypeIdxFromType(typeName_s);
         return object_ahm[objTypeIdx].values().toArray(new CdfObject[0]);
      }
      catch (Exception e) {
         return new CdfObject[0];
      }
   }
   //----------------------------------------------------------------------------------------------
   // Return array of specific types objects
   //----------------------------------------------------------------------------------------------
   
   @Override
   public CdfObject[] getLinkObjects() 
   {
      List<CdfObject> objs_al = new ArrayList<CdfObject>(); 
      
      for (int sectIdx = 0; sectIdx < getTypesNum(); sectIdx++) {    
         List<String> attrNames = getAttrNames(sectIdx);
     
         if (attrNames.contains(CdfTypes.FROM_NAME) && attrNames.contains(CdfTypes.TO_NAME)) {
            CdfObject[] objs = getObjects(sectIdx);
            objs_al.addAll(Arrays.asList(objs));           
         }
      }
      return objs_al.toArray(new CdfObject[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getLinkObjTypeNames() 
   {
      List<String> objs_al = new ArrayList<String>(); 
         
      for (int sectIdx = 0; sectIdx < getTypesNum(); sectIdx++) {    
         List<String> attrNames = getAttrNames(sectIdx);
        
         if (attrNames.contains(CdfTypes.FROM_NAME) && attrNames.contains(CdfTypes.TO_NAME)) {
            String objType_s = getObjTypeName(sectIdx);
            objs_al.add(objType_s);           
         }
      }
      return objs_al.toArray(new String[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   // Return all model objects 
   //----------------------------------------------------------------------------------------------

   @Override
   public CdfObject[] getObjects() 
   {
      List<CdfObject> objs = new ArrayList<CdfObject>();
      
      for (int typeIdx = 0; typeIdx < object_ahm.length; typeIdx++) {
         if (object_ahm[typeIdx] != null) {
            objs.addAll(object_ahm[typeIdx].values());
         }
      }
      return objs.toArray(new CdfObject[objs.size()]);
   }
}
//======================================= End of class ============================================
