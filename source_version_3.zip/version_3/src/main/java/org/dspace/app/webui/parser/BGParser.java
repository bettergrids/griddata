package org.dspace.app.webui.parser;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.dspace.app.webui.parser.grg.GrgParser;
import org.dspace.app.webui.parser.gridlab.GlmParser;
import org.dspace.app.webui.parser.ieee.CdfParser;
import org.dspace.app.webui.parser.matpower.MpcParser;
import org.dspace.app.webui.parser.opendss.DssArchive;
import org.dspace.app.webui.parser.opendss.DssModel;
import org.dspace.app.webui.parser.opendss.DssParser;
import org.dspace.app.webui.parser.powerworld.PowParser;
import org.dspace.app.webui.parser.pslf.PlfParser;
import org.dspace.app.webui.parser.psse.PssParser;
import org.dspace.app.webui.parser.reds.RedParser;
import org.dspace.app.webui.util.BGUtils;

public class BGParser {

   private static final Logger log = Logger.getLogger(BGParser.class);
   
   //..... Constants ......
   
   public static final String BUS_NAME         = "bus";
   public static final String GENERATOR_NAME   = "generator";
   public static final String FIXED_SHUNT_NAME = "fixed_shunt";
   public static final String LOAD_NAME        = "load";
   
   //..... Members ......
   
   private BufferedReader buffReader;        // file buffer reader
   private String         comments;          // string indicates it's a comment, like "//"
   
   private boolean doNormalize = false;      // replace all duplicate white spaces and LFs
   private boolean skipEmpty   = false;      // should parser return skip empty strings and return 
                                             // first not empty one
   //..... Constructor ......
   
   public BGParser (String file_s) throws FileNotFoundException 
   {
      buffReader = new BufferedReader(new FileReader(file_s));    // throws FileNotFoundException
   }
   //..... Getters/Setters ......

   public String getComments() {
      return comments;
   }
   public void setComments(String comments) {
      this.comments = comments;
   }
   public boolean isDoNormalize() {
      return doNormalize;
   }
   public void setDoNormalize(boolean doNormalize) {
      this.doNormalize = doNormalize;
   }
   public boolean isSkipEmpty() {
      return skipEmpty;
   }
   public void setSkipEmpty(boolean skipEmpty) {
      this.skipEmpty = skipEmpty;
   }
   public void closeParser()
   {
      try {
         buffReader.close();
      } 
      catch (IOException e) {
         log.error("BGParser.closeParser(). Cannot close BufferedReader");
      }
   }
   //----------------------------------------------------------------------------------------------
   // Get one line from of the text file
   //----------------------------------------------------------------------------------------------
   
   public String getLine() throws IOException 
   {
      String line_s = buffReader.readLine();

      if (line_s == null) return line_s;
      
      if (comments != null) {                      // Remove comments
         int idx1 = line_s.indexOf(comments);
         if (idx1 >= 0) {
            line_s = line_s.substring(0, idx1);
         }
      }
      if (skipEmpty && line_s.isEmpty()) {
         return getLine();
      }
      if (doNormalize) {
         line_s = line_s.replaceAll("\\s+"," ").trim();
      }
      return line_s;
   }
   //----------------------------------------------------------------------------------------------
   // Get num lines from of the text file
   //----------------------------------------------------------------------------------------------

   public String[] getLines(int num) throws IOException  
   {
      String[] line_sa = new String[num];
      
      int i = 0;
      while (i < num) {
         line_sa[i] = getLine();
         if (line_sa[i] == null) break;
      }
      return line_sa;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static BGModel parseFile(BGModel model)
   {
      return parseFile(model.getFormat(), model.getPath());
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static BGModel parseFile(String fileFormat_s,
                                   String filePath_s)
   {
      BGModel model = null;
      
      //..... 1. GridLab-D file ......
      
      if (fileFormat_s.equalsIgnoreCase(BGModel.MODEL_FORMAT_GRIDLAB)) {      
         model = GlmParser.parseFile(filePath_s);
         //model.calculateLinks();
      }
      //..... 2. MATPOWER file ......
      
      else if (fileFormat_s.equalsIgnoreCase(BGModel.MODEL_FORMAT_MATPOWER)) {
         model =  MpcParser.parseFile(filePath_s);      
      }
      //..... 3. IEEE CDF file ......
      
      else if (fileFormat_s.equalsIgnoreCase(BGModel.MODEL_FORMAT_IEEE_COM)) {
         model =  CdfParser.parseFile(filePath_s);      
      }
      //..... 4. PSS-E raw file ......
      
      else if (fileFormat_s.equalsIgnoreCase(BGModel.MODEL_FORMAT_PSSE)) {
         model =  PssParser.parseFile(filePath_s);
         //model.calculateLinks();
      }
      //..... 5. PSLF EPC file ......
      
      else if (fileFormat_s.equalsIgnoreCase(BGModel.MODEL_FORMAT_PSLF)) {
         model =  PlfParser.parseFile(filePath_s);
         //model.calculateLinks();
      }
      //..... 6. OpenDSS archive ......
      
      else if (fileFormat_s.equalsIgnoreCase(BGModel.MODEL_FORMAT_OPENDSS)) {
         DssArchive archive =  DssParser.parseFile(filePath_s);
         for (DssModel dssModel : archive.getModels()) {
            if (dssModel != null) {
               model = dssModel;
               break;
            }
         }
         //model.calculateLinks();
      }
      //..... 7. PSLF EPC file ......
      
      else if (fileFormat_s.equalsIgnoreCase(BGModel.MODEL_FORMAT_GRG)) {
         model =  GrgParser.parseFile(filePath_s);
         //model.calculateLinks();
      }
      //..... 8. REDS POS file ......
      
      else if (fileFormat_s.equalsIgnoreCase(BGModel.MODEL_FORMAT_REDS)) {
         model =  RedParser.parseFile(filePath_s);
         //model.calculateLinks();
      }
      //..... 9. POWERWORLD file ......
      
      else if (fileFormat_s.equalsIgnoreCase(BGModel.MODEL_FORMAT_POWERWORLD)) {
         model =  PowParser.parseFile(filePath_s);
         //model.calculateLinks();
      }
      //..... For the next model format .....
      
      else {
         log.error("BGParser.parseFile. Format unknown. Cannot parse file: " + filePath_s + 
                   "; Model format: " + fileFormat_s);
         return null;
      }
      return model;
   }
   //----------------------------------------------------------------------------------------------
   // Main function
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {
      org.apache.log4j.BasicConfigurator.configure();
            
      String folderPath = "C:\\tmp_share\\";

      //..... GLM model ......
      
      String json_s;
      String xml_s;
      BGModel model1 = parseFile(BGModel.MODEL_FORMAT_PSSE, "D:\\tmp_share\\PSSE\\ACTIVSg2000_revOpalRT.raw");
      json_s = model1.toJson();
      //xml_s = BGUtils.jsonToXml(json_s, "model", true);
      xml_s = BGUtils.jsonToXml(json_s, "model", false);

      BGUtils.stringToFile(xml_s, "D:\\tmp_share\\R1-25.00-1.xml");
      int b = 2;      
      
      //BGModel model2 = parseFile(BGModel.MODEL_FORMAT_PSLF, "C:\\tmp_share\\ACTIVSg200.EPC");
      //json_s = model2.toJson();    
      //BGUtils.stringToFile(json_s, "C:\\tmp_share\\R4-25.00-1.json");
      
      //BGItem item = new BGItem();
      //item.setDspaceUID(UUID.fromString("0f2eff25-0d7e-4a84-826b-3a706edc1d94"));
      
      //item.addModel(model1);
      //item.addModel(model2);
      
      //item.populateMetadata();
      
      //DBEntry entry = model.getInfoEntry();
      //DBEntry entry = model1.getEntry(null, null);
      //DBEntry entry = model1.getEntry(null, "transformer_configuration:42");
      //entry.printContent();
      
      

      System.exit(0);
   }
}
