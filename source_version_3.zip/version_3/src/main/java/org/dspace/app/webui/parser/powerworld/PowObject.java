package org.dspace.app.webui.parser.powerworld;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.dspace.app.webui.model.DBColumn;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.model.DBTypes;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGUtils;

public class PowObject extends BGObject
{
   //..... Members ......
   
   private PowModel model;
   
   private List<Object> attr_al = new ArrayList<Object>();
   
   //..... Constructor ......
   
   public PowObject(PowModel model) 
   {
      this.model = model;
   }
   //..... Methods ......
   
   @Override
   public BGModel getModel() {
      return model;
   }
   @Override
   public void setModel(BGModel model) 
   {
      this.model = (PowModel)model;   
   }
   public void setModel(PowModel model) {
      this.model = model;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean addAttr(String name_s,
                          String value_s)
   {
      if (name_s != null && type != null) {
         attr_al.add(value_s);
         model.addAttrName(type, name_s);
         return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Object getAttr(String attrName) 
   {
      Integer attrIdx = model.getAttrNames(type).indexOf(attrName);
      if (attrIdx != -1) {
         return getAttr(attrIdx);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Object getAttr(int attrIdx) 
   {
      return attr_al.get(attrIdx);
   }
   //----------------------------------------------------------------------------------------------
   // Get attribute nanes
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getAttrNames()
   {
      if (type != null) {
         return model.getAttrNames(type).toArray(new String[0]);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   // Add attributes
   //----------------------------------------------------------------------------------------------
   
   public void setAttrs(String[] attr_sa)
   {
      attr_al = new ArrayList<Object>(Arrays.asList(attr_sa));
   }
   //----------------------------------------------------------------------------------------------
   
   public void setNameAndAttrs(String   objType_s,    // return object name 
                               String[] attr_sa)
   {
      attr_al = new ArrayList<Object>(Arrays.asList(attr_sa));
      
      for (int i = 0; i < attr_sa.length; i++) {
         String attrName_s = model.getAttrNames(objType_s).get(i);
         
         if (attrName_s.startsWith("_") && ((String)attr_al.get(i)).isEmpty() == false) {
            if (attrName_s.equals(PowModel.FROM_NAME) || attrName_s.equals(PowModel.TO_NAME)) {
               attr_al.set(i, PowModel.TYPE_NAME_BUS + "_" + attr_al.get(i));
            }
            else {
               attrName_s = attrName_s.substring(1);                       // remove "_"
               int idx = attrName_s.indexOf("_");
               if (idx > 0) {
                  attrName_s = attrName_s.substring(0, idx);
               }
               attr_al.set(i, attrName_s + "_" + attr_al.get(i));
            }
         }
      } 
      //..... Build and set object name ......
      
      int idx = BGUtils.getStringIdx("_" + objType_s, model.getAttrNames(objType_s), null, null);
      if (idx >= 0) {
         setName(attr_al.get(idx).toString());
      }
      else {
         setName(objType_s + "_" + model.getNewObjNameidx(objType_s));
      }
   }
   //----------------------------------------------------------------------------------------------
   // 
   //----------------------------------------------------------------------------------------------

   public Integer getAttrNum() 
   {
      if (attr_al != null) {
         return attr_al.size();
      }
      return 0;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();

      //String objTypeId = type + ((id == null) ? "" : "_" + id.toString());
      
      //..... Start with object type and id (if any) as attributes ......
      
      json_sb.append("{\t\"type\" : \"" + type + "\",\n" );
      if (id != null) {
         json_sb.append("\t\"id\" : " + id.toString() + ",\n");
      }
      if (name != null) {
         json_sb.append("\t\"name\" : \"" + name + "\",\n");
      }
      //..... For each attribute ......
      
      int num = getAttrNum();
      for (int i = 0; i < num; i++) {
         if (getAttr(i) == null) continue;
         String attrJson_s = BGObject.attrToJson(getAttrNames()[i], this.valueOfType(getAttr(i).toString()), null);
         json_sb.append(attrJson_s);
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n},\n");
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   // Get table with column declarations
   //----------------------------------------------------------------------------------------------
   
   @Override
   public DBTable getTable() 
   {
      //..... Setup table ......

      String objType_s = getType();
      if (objType_s == null) return null;
      
      DBTable table = new DBTable();
      table.setName(objType_s);

      int attrLen = getAttrNames().length;      
      
      for (int i = 0; i < attrLen; i++) {         
         String  colName_s = model.getAttrNames(type).get(i);
         Integer colType   = DBTypes.typeVarchar;              // model.getAttrTypes(type).get(i);

         DBColumn col = new DBColumn(colName_s, null, colType, i);
         table.addColumn(i, col);
      }
      return table;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public List<Object> getAttrs() 
   {
      return attr_al;
   }
}
//======================================= End of Class ============================================

