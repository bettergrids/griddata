package org.dspace.app.webui.parser.graph;

import java.util.PriorityQueue;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.nlidb.NLMapper;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGUtils;
   
//----------------------------------------------------------------------------------------------
//                                    BGObjVertex class
//----------------------------------------------------------------------------------------------
   
class BGObjVertex implements Comparable<BGObjVertex> 
{
   //..... Members ......
   
   public final BGObject  object;
   
   public List<BGObjEdge> links;                          // links over the shortest path
   public Integer         hops     = Integer.MAX_VALUE;   // smallest number of hops (as a result of calculation)
   public BGObjVertex     previous;
   
   //..... Constructor ......
   
   public BGObjVertex(BGObject object)
   { 
      this.object = object;
   }
   //..... Methods ......
   
   public int compareTo(BGObjVertex other) 
   {
      return Integer.compare(hops, other.hops);
   }
}
//----------------------------------------------------------------------------------------------
//                                     BGObjEdge class
//----------------------------------------------------------------------------------------------

class BGObjEdge
{
   //..... Members ......
   
   public final BGObjVertex target;
   
   //..... Constructor ......
   
   public BGObjEdge(BGObjVertex target) { 
      this.target   = target; 
   }
}
//----------------------------------------------------------------------------------------------
//                                  BGGraph public class
//----------------------------------------------------------------------------------------------
   
public class BGObjGraph  implements NLMapper {
      
   private static final Logger log = Logger.getLogger(BGObjGraph.class);
      
   //..... Members ......
   
   private HashMap<BGObject, BGObjVertex> vert_hm = null;
   
   private List<Integer[]>      paths_la  = new ArrayList<Integer[]>();       // output list
   private Map<String, Integer> typeId_hm = new HashMap<String, Integer>();

   //..... Methods ......
   
   public List<Integer[]> getPaths() {
      return paths_la;
   }
   //-------------------------------------------------------------------------------------------
   //
   //-------------------------------------------------------------------------------------------

   private boolean addLink(BGObject fromObject,
                           BGObject toObject)
   {
      //..... Find source or create a new one if not exists ......
      
      BGObjVertex source_v = vert_hm.get(fromObject);
      if (source_v == null) {
         source_v = new BGObjVertex(fromObject);
         vert_hm.put(fromObject, source_v);
      }
      //..... Find target or create a new one if not exists ......
         
      BGObjVertex target_v = vert_hm.get(toObject);
      if (target_v == null) {
         target_v = new BGObjVertex(toObject);
         vert_hm.put(toObject, target_v);
      }
      BGObjEdge target_e = new BGObjEdge(target_v);
         
      //..... Find edge by source object or create a new one if not exists ...... 
      
      if (source_v.links == null) {
         source_v.links = new ArrayList<BGObjEdge>();
      }
      source_v.links.add(target_e);
      return true;
   }
   //-------------------------------------------------------------------------------------------
   // Setup graph as HashMap of vertices with links to neighbors
   //-------------------------------------------------------------------------------------------

   public boolean setupGraph(BGModel model)       
   {
      //..... Initialize hash maps (vertices and edges) ......
      
      vert_hm = new HashMap<BGObject, BGObjVertex>(); 
      
      for (BGObject obj : model.getObjects()) {
         if (obj == null) continue;

         String objType = obj.getType();
         String from_s  = (String)obj.getAttr(model.getAttrName_from());
         String to_s    = (String)obj.getAttr(model.getAttrName_to());
         
         // "bus" only, because GRIDLAB does not have attribute with name = "node";         
         String bus_s   = (String)obj.getAttr(model.getAttrName_bus());  
         
         //----------------- Process link objects -----------------------
            
         if (from_s != null && to_s != null) {
            
            // Create two rows: 1) objFrom --> this object; 2) this object --> objTo
            // Populate row: FROM from attr. TO current object
            
            BGObject fromObj = model.getObject(from_s);
            BGObject toObj   = model.getObject(to_s);
               
            if (fromObj != null) addLink(fromObj, obj);     // from FROM to object
            if (toObj   != null) addLink(obj,     toObj);   // from object to TO
         }
         //----------------- Process bus-end objects -----------------------
            
         else if (bus_s != null && objType.equalsIgnoreCase(_BUS) == false) {      
            BGObject busObj = model.getObject(bus_s);
            
            if (busObj != null) {              
               if (BGUtils.getStringIdx(obj.getType().toLowerCase(), _LOAD_NODES) >= 0) {
                  addLink(busObj, obj);     // from BUS to LOAD
               }
               else {
                  addLink(obj, busObj);     // from GEN to BUS
               }
            }
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Compute paths for all model branches
   //----------------------------------------------------------------------------------------------
   
   public boolean computeShortestPaths(BGModel model)
   {
      //..... Initialize Graph structure ......
      
      setTypeIdMap(model.getFormat());
      setupGraph(model);

      //..... For each model node (bus) ......
      
      int j = 0; 
      for (BGObjVertex source_v : vert_hm.values()) {      
         if (source_v == null) continue;
         
         //..... Delay to allow Tomcat to switch to another servlet thread ......
         
         if (++j % 500 == 0) {
            try {
               TimeUnit.MILLISECONDS.sleep(10);
            }
            catch (InterruptedException e) {
               log.error("computeShortestPaths. Model: " + model.getName() + 
                         ". Timeout.Stack Trace: " + ExceptionUtils.getStackTrace(e));
            }
         }
         //......................................................................
         
         cleanupPaths();
         computeShortestPaths(source_v);        // compute min hops (or distances) to all vertices
         
         //..... Get shortest paths to all nodes ......
         
         for (BGObjVertex target_v : vert_hm.values()) {
            
            if (target_v == null || source_v == target_v) continue;             
            if (target_v.hops == Integer.MAX_VALUE || target_v.hops == 0) continue;
            
            //..... Set link parameters for source to the target ......
                        
            List<Integer> paths = getShortestPathTo(target_v);
            paths_la.add(paths.toArray(new Integer[paths.size()]));            
         }
      }
      //..... Shrink paths ......
      
      log.info("computeShortestPaths. Model: " + model.getName() + 
               ". Start shrinking " + paths_la.size() + " paths....");
      
      shrinkPaths();
      
      log.info("computeShortestPaths. Model: " + model.getName() + 
               ". Result of shrinking: " + paths_la.size() + " paths");
      return true;
   }   
   //----------------------------------------------------------------------------------------------
   // Find the shortest path from source to all neighbor nodes recursively
   //----------------------------------------------------------------------------------------------
      
   public void computeShortestPaths(BGObjVertex source)
   {
      source.hops = 0;
      
      PriorityQueue<BGObjVertex> vertexQueue = new PriorityQueue<BGObjVertex>();  // queue keeps order      
      vertexQueue.add(source);
      
      while (!vertexQueue.isEmpty()) {
         
         // Poll: Retrieves and removes the head of this queue, 
         // or returns null if this queue is empty
         
         BGObjVertex nodeSource = vertexQueue.poll();
         if (nodeSource.links == null) continue;
         
         //..... Visit each edge exiting node ......
         
         for (BGObjEdge link : nodeSource.links) {
            BGObjVertex nodeTarget = link.target;
            int hops = nodeSource.hops + 1;
           
            if (hops < nodeTarget.hops) {
               vertexQueue.remove(nodeTarget);
               nodeTarget.hops     = hops;
               nodeTarget.previous = nodeSource;
               vertexQueue.add(nodeTarget);
            }
         }
      }
   }
   //----------------------------------------------------------------------------------------------
   // Cleanup vertex links
   //----------------------------------------------------------------------------------------------
   
   private void cleanupPaths()
   {
      for (BGObjVertex vert : vert_hm.values()) {
         vert.hops     = Integer.MAX_VALUE;
         vert.previous = null;
      }
   }   
   //----------------------------------------------------------------------------------------------
   // Get shortest path (all nodes from source to target) 
   //----------------------------------------------------------------------------------------------
   
   private List<Integer> getShortestPathTo(BGObjVertex target_v)
   {
      List<Integer> path = new ArrayList<Integer>();      
      BGObjVertex vertex = target_v;
      int hops           = target_v.hops;
      
      if (hops > 0 && hops < Integer.MAX_VALUE) {
         while (vertex != null && hops >= 0) {
            Integer typeId = typeId_hm.get(vertex.object.getType());
            path.add(typeId);
            vertex = vertex.previous;
            hops--;
         }
         Collections.reverse(path);
      }
      return path;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private void shrinkPaths()
   {
      Integer[][] path_aa = paths_la.toArray(new Integer[0][0]);
      
      //Arrays.sort(path_aa, (a, b)->Integer.compare(a.length, b.length));
            
      for (int j = 0; j < path_aa.length; j++) {      // sub-array
         
         //..... Delay to allow Tomcat to switch to another servlet thread ......
         
         if (j % 1000 == 0) {
            try {
               TimeUnit.MILLISECONDS.sleep(20);
            }
            catch (InterruptedException e) {
               log.error("shrinkPaths. Timeout.Stack Trace: " + ExceptionUtils.getStackTrace(e));
            }
         }
         //..............................................................
         
         for (int i = 0; i < path_aa.length; i++) {   // parent-array
            
            if (path_aa[i] != null && i != j && path_aa[i].length >= path_aa[j].length) {
               if (BGUtils.findArray(path_aa[i], path_aa[j]) >= 0) {
                  path_aa[j] = null;                                     // mark to delete;
                  break;
               }
            }
         }
      }
      paths_la = new ArrayList<Integer[]>();
      for (int j = 0; j < path_aa.length; j++) {
         if (path_aa[j] != null) {
            paths_la.add(path_aa[j]);
         }
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private void shrinkPaths2()
   {
      Integer[][] path_aa = paths_la.toArray(new Integer[0][0]);
      
      Arrays.sort(path_aa, (a, b)->Integer.compare(a.length, b.length));
            
      paths_la = new ArrayList<Integer[]>(Arrays.asList(path_aa));
      
      int step = 0;
      for (Integer[] parentPath : paths_la) {
              
         if (step++ % 10000 == 0) {
            System.out.println("Pass: " + step++);         
         }
         
         for (Integer[] subPath : paths_la) {
            if (subPath != parentPath) {
               int idx = BGUtils.findArray(parentPath, subPath);
               if (idx >= 0) {
                  paths_la.remove(subPath);
               }
            }
         }
      }
      paths_la = new ArrayList<Integer[]>();
      for (int j = 0; j < path_aa.length; j++) {
         if (path_aa[j] != null) {
            paths_la.add(path_aa[j]);
         }
      }
   }

   //----------------------------------------------------------------------------------------------
   // Prepare typeId map for specific model format
   //----------------------------------------------------------------------------------------------
   
   private void setTypeIdMap(String format_s)
   {
      if (typeId_hm.isEmpty()) {
         for (String type_s : BGModel.getStaticObjTypeNames(format_s)) {
            Integer typeId = BGObject.getObjTypeId(format_s, type_s);
            if (typeId != null) {
               typeId_hm.put(type_s, typeId);
            }
         }
      }
   }
}
//======================================= End of Class ============================================