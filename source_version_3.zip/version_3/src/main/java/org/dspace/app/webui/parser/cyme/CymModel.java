package org.dspace.app.webui.parser.cyme;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;

public class CymModel  extends BGModel 
{
   private static final Logger log = Logger.getLogger(CymModel.class);
   
   //..... Members ......
   
   //          objType        objName object
   private Map<String, HashMap<String,CymObject>> object_mhm = new LinkedHashMap<String, HashMap<String,CymObject>>();

   private List<String> objTypeNames_al = new ArrayList<String>();
   
   //          objType
   private Map<String, ArrayList<String>>  attrNames_hml = new LinkedHashMap<String, ArrayList<String>>();
   private Map<String, ArrayList<Object>>  attrDefs_hml  = new LinkedHashMap<String, ArrayList<Object>>();
   
   //..... These map is needed only at the parsing stage ......
   
   private Map<String, Integer> objNameidx = new HashMap<String, Integer>();

   //---------------------------------------------------------------------------------------------
   // Get attribute names hash map
   //---------------------------------------------------------------------------------------------
   
   public Map<String, ArrayList<String>> getAttrNamesHm()
   {
      return attrNames_hml;
   }
   //----------------------------------------------------------------------------------------------
   // Get object hashmap
   //----------------------------------------------------------------------------------------------
   
   public Map<String, HashMap<String,CymObject>> getObjectsHm()
   {
      return object_mhm;
   }
   //----------------------------------------------------------------------------------------------
   // Generate indices for object name
   //----------------------------------------------------------------------------------------------

   public Integer getNewObjNameidx(String objType_s) 
   {
      Integer idx = objNameidx.get(objType_s);
      if (idx == null) {
         idx = 0;
      }
      else {
         idx += 1;
      }
      objNameidx.put(objType_s, idx);
      return idx;
   }
   //----------------------------------------------------------------------------------------------
   // Get/Add object to specific section
   //----------------------------------------------------------------------------------------------
      
   public List<String> getAttrNames(String objType_s) 
   {      
      if (attrNames_hml != null) {
         return attrNames_hml.get(objType_s);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   // Add new object type name
   //----------------------------------------------------------------------------------------------
   
   public void addObjTypeName(String objType_s)
   {
      if (objTypeNames_al.contains(objType_s) == false) {
         objTypeNames_al.add(objType_s);
      }
   }
   //----------------------------------------------------------------------------------------------
   // Set attribute names of type specified
   //----------------------------------------------------------------------------------------------
   
   public void setAttrNames(String            objType_s,
                            ArrayList<String> attrNames_al)
   {  
      if (objTypeNames_al.indexOf(objType_s) == -1) {
         objTypeNames_al.add(objType_s);
      }
      attrNames_hml.put(objType_s, attrNames_al);
   }
   //----------------------------------------------------------------------------------------------
   // Set attribute default values for type specified
   //----------------------------------------------------------------------------------------------
   
   public void setAttrDefs(String            objType_s,
                           ArrayList<Object> attrDefs_al)
   {  
      if (attrDefs_hml.get(objType_s) != null) {
         log.warn("setAttrDefs. Attribute defaults for " + objType_s + " are already exist." +
                  " Old values will be overwritten."); 
      }
      attrDefs_hml.put(objType_s, attrDefs_al);
   }
   //----------------------------------------------------------------------------------------------
   // Add attribute name for object of type specified
   //----------------------------------------------------------------------------------------------
   
   public void addAttrName(String objType_s,
                           String attrName_s)
   {  
      if (objTypeNames_al.indexOf(objType_s) == -1) {
         objTypeNames_al.add(objType_s);
      }
      if (attrNames_hml.get(objType_s) == null) {
         attrNames_hml.put(objType_s, new ArrayList<String>());
      }
      attrNames_hml.get(objType_s).add(attrName_s);
   }
   //----------------------------------------------------------------------------------------------
   // Get all object types
   //----------------------------------------------------------------------------------------------

   @Override
   public String[] getObjTypeNames() 
   {
      return objTypeNames_al.toArray(new String[objTypeNames_al.size()]);
      //return ArrayUtils.addAll(NODE_TYPE_NAMES, LINK_TYPE_NAMES);
   }

   @Override
   public BGObject getObject(String name_s) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public BGObject[] getObjects(int typeIdx) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public BGObject[] getObjects() {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public BGObject[] getObjects(String typeName_s) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public BGObject[] getLinkObjects() {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public Integer getTypesNum() {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public String toJson() {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public String[] getStaticObjTypeNames() {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public String[] getNodeObjTypeNames() {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public String[] getLinkObjTypeNames() {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public String getObjTypeName(int sectIdx) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public List<String> getAttrNames(int typeIdx) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public List<Integer> getAttrTypes(int typeIdx) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public Integer getAttrIdx(int sectIdx, String attrName) {
      // TODO Auto-generated method stub
      return null;
   }


}
