package org.dspace.app.webui.model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.dspace.app.webui.nlidb.NLIPAddress;
import org.dspace.app.webui.nlidb.NLNumConverter;
import org.dspace.app.webui.nlidb.NLTranslator;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.parser.BGParser;
import org.dspace.app.webui.parser.graph.BGGraphMap;
import org.dspace.app.webui.parser.psse.PssTypes;
import org.dspace.app.webui.spellcheck.SpellChecker;
import org.dspace.app.webui.submit.step.JSPUploadStep;
import org.dspace.app.webui.util.BGUtils;

public class DBModelTest implements DBTypes {

   private static final Logger log = Logger.getLogger(BGParser.class);
   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static boolean testModels(String   folderPath,
                                     String   fileName[],
                                     String   fileFormat,
                                     boolean  printEntry_b,
                                     boolean  saveDB_b)
   {
      DBConnection dbConn = new DBConnection(DBProvider.GraphDB);
      Connection conn     = dbConn.getConnection();
      DBExecute  exec     = new DBExecute();
      boolean res_b       = true;

      //****** NOT IN USE *******
      DBModelProcess proc = new DBModelProcess(null, null); // null, null, just for compilation!!!
      
      for (int j = 0; j < fileName.length; j++) {
         String filePath = folderPath + fileName[j];
         log.info("ModelProcess.processBitstream. Processing of file: " + filePath +
                  "; Model format: " + fileFormat);
      
         BGModel model = BGParser.parseFile(fileFormat, filePath);
         if (model == null) {
            log.error("ModelProcess.processBitstream. Cannot parse file: " + filePath + 
                      "; Model format: " + fileFormat);
            return false;
         }
         UUID userUid = UUID.fromString("aaaaaaaa-529b-4231-aefc-601df75f890d");
         model.setUuid(userUid);
         
         //..... Print entry data ......
         
         if (printEntry_b) {
            
            System.out.println("=== " + fileFormat + " ========================= " + fileName[j] + " ==========================");                 
         
            String json_s = model.toJson();
            
            DBEntry entry;
            entry = model.getInfoEntry();
            entry.printContent();
      
            for (int i = 0; i < model.getTypesNum(); i++) {
               String sectName = model.getObjTypeNames()[i];
               
              System.out.println("---------------- Section: " + sectName + " ---------------------");
               
               entry = model.getEntry(sectName, null); 
               if (entry != null) {
                  entry.printContent();
               }
            }
         }
         //..... Save model in the Graph DB ......
      
         if (saveDB_b) {      
            res_b = proc.saveParsedModel (conn, exec, model, false);
        
            res_b = proc.checkModelExist(conn, exec, model.getUuid());
         }
      }
      dbConn.close();
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   
   private static void readFromInputStream(String file_s) throws IOException 
   {
      int idx0, idx1;
      List<String> lines   = new ArrayList<String>();
      List<String> results = new ArrayList<String>();
      try (BufferedReader br = new BufferedReader(new FileReader(file_s))) {
         while (true) {
            String line_s = br.readLine();
            if (line_s == null) break;
            lines.add(line_s);
         }
      }
      String line_s;
      for (int i = 0; i < lines.size(); i++) {
         line_s = lines.get(i);

         idx0 = line_s.indexOf("ip_addr=");
         if (idx0 < 0) continue;
         
         idx0 += 8;
         
         if (idx0 >= 0) {
            idx1 = line_s.indexOf(":", idx0);
            line_s = line_s.substring(idx0, idx1);
            results.add(line_s);
         }
      }
      lines = new ArrayList<String>();
      HashMap<String, Integer> counts = new HashMap<String, Integer>();
      for (int i = 0; i < results.size(); i++) {
         line_s = results.get(i);
         
         Integer count = counts.get(line_s);
         counts.put(line_s, ((count == null) ? 1 : count + 1));
      }
      Integer idx    = 0;
      Integer total  = 0; 
      Integer google = 0;
      for (Map.Entry<String, Integer> entry : counts.entrySet()) {
         String  key   = entry.getKey();
         Integer value = entry.getValue();
         total += value;
         
         if (key.startsWith("66.249")) {
            google += value;
         }
      
         System.out.println(padRight(idx.toString(), 8) + " " + padRight(key, 20) + " : " + value);
         idx++;
     }
      System.out.println("Total  : " + total);
      System.out.println("Google : " + google);
   }
   public static String padRight(String s, int n) {
      return String.format("%1$-" + n + "s", s);  
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static boolean testDBAccess()
   {
      DBConnection dbConn = new DBConnection(DBProvider.GraphDB);
      Connection conn     = dbConn.getConnection();
      DBExecute  exec     = new DBExecute();
      boolean res_b       = true;
   
      // SELECT * FROM _cdf WHERE modeluid='85652679-9b52-4cb5-b1bf-affa9914ff91' AND nodetype='title' AND 1=1
      
      DBEntry entry = DBFunctions.getNodes("85652679-9b52-4cb5-b1bf-affa9914ff91", 
                                           "title", 
                                           null, 
                                           null, 
                                           "_cdf");     
      if (entry != null) {
         entry.printContent();
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("unused")
   private static void testModelParsers()
   {
      String folderPath;

      //..... POWERWORLD models ......
      
      folderPath = "D:\\tmp_share\\powerworld\\";
      
      String[] powModels = { "ACTIVSg200.aux" };
      
      testModels(folderPath, powModels, BGModel.MODEL_FORMAT_POWERWORLD, true, true);

      //..... Matpower models ......
      
      folderPath = "D:\\tmp_share\\matpower\\";
      
      String[] matModels = { "Spring13Tight.m",
                             "nmwc5.m",
                             "nmwc3acyclic_connected_feasible_space.m",
                             "pglib_opf_case1888_rte__api.m",
                             "case2736sp.m", 
                             "case2737sop.m",
                             "case2746wop.m",
                             "case2746wp.m",
                             "case2869pegase.m",
                             "case9241pegase.m",
                             };
      
      testModels(folderPath, matModels, BGModel.MODEL_FORMAT_MATPOWER, true, true);

      //..... PSS/E models ......
      
      folderPath = "D:\\tmp_share\\PSSE\\";
      
      String[] psseModels = { "WECC_191.raw",
                              "ACTIVSg2000.RAW",
                              "ACTIVSg2000_revOpalRT.raw",
                              "Texas_2000_Bus.raw",
                              "IEEE300Bus.raw",
                              "SDET 500bus case.raw",
                              "IEEE 118 Bus.RAW",
                              "Brazilian_7_bus_Equiv_Model.RAW",
                              "IEEE RTS 96 bus.RAW",
                              "NETS-NYPS 68 Bus System.RAW",
                              "Benchmark_4ger_33_2015.RAW",
                              "IEEE_300_bus_test.raw",};
      
      testModels(folderPath, psseModels, BGModel.MODEL_FORMAT_PSSE, true, true);
      
      //..... GridLab models ......
      
      folderPath = "D:\\tmp_share\\GridLab\\";
      
      String[] gldModels = { "R4-12.47-1.glm",
                             "load_schedule_OFP.glm",
                             "TMP0009_glmfile_ts.glm",
                             "R3-12.47-1.glm",
                             "GC-12.47-1.glm",
                             "R1-25.00-1.glm",
                             "AL0001_glmfile_loads.glm",
                             "R4-25.00-1.glm",
                             "R4-12.47-2.glm"};

      testModels(folderPath, gldModels, BGModel.MODEL_FORMAT_GRIDLAB, false, true);
      
      //..... OpenDSS models ......
      
      String[] dssModels = { "OpenDSS\\feeder_j1_opendss_model.zip" };
      
      testModels(folderPath, dssModels, BGModel.MODEL_FORMAT_OPENDSS, true, true);
            
      //..... REDS models ......
      
      String[] redModels = { "bus_13_3.pos" };
      
      testModels(folderPath, redModels, BGModel.MODEL_FORMAT_REDS, true, true);
            
      //..... GRG models ......
      
      String[] grgModels = { "grg_test_1.grg" };
      
      testModels(folderPath, grgModels, BGModel.MODEL_FORMAT_GRG, true, true);

      
      //..... PSLF models ......
      
      String[] pslfModels = { "AU14GenModel.EPC",
                              "ACTIVSg200.EPC",
                              "ThreeMIB_Benchmark_System.EPC",
                              "WSCC 9 bus.epc",
                              "IEEE 118 Bus.EPC",
                              "Benchmark_4ger_33_2015.EPC",
                              "IEEE 30 bus.EPC",
                              "IEEE300Bus.epc"};
      
      testModels(folderPath, pslfModels, BGModel.MODEL_FORMAT_PSLF, true, true);
      
      //..... CDF models ......

      String[] cdfModels = { "14BusPF.cdf",
                             "300BusPF.cdf",
                             "17GenDynamicSolvedPowerFlow.cdf",
                             "118BusPF.cdf",
                             "145BusSolvedPFCommoData.cdf"};

      testModels(folderPath, cdfModels, BGModel.MODEL_FORMAT_IEEE_COM, true, true);
   }
   //----------------------------------------------------------------------------------------------
   // Test NLIDB service
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("unused")
   private static void testNLIDB(boolean save_b)
   {
      String query_s = "show all repository models with more than ten nodes";
      
      DBEntry entry0 = DBSearchFunctions.getModelsBySearch(query_s);
      if (entry0 == null) return;     
      entry0.printContent();
      
      if (save_b) {
         boolean res_b = true;
         
         String dbFilePath_s = "C:\\Archive\\Java\\IPAddress\\GeoLite2\\GeoLite2-City_20180102\\GeoLite2-City.mmdb";
         String ipAddr_s     = "47.35.23.30"; 
         ipAddr_s            = "24.242.230.253"; 
         ipAddr_s            = "185.38.14.171"; 
         ipAddr_s            = "47.35.23.30"; 
         
         res_b = DBSearchFunctions.saveIPAddressInfo(ipAddr_s);
         
         UUID userUid = UUID.fromString("3a84eb35-529b-4231-aefc-601df75f890d");
         
         res_b = DBSearchFunctions.saveQuery(userUid, ipAddr_s, query_s, 0);
      }
   }
   //----------------------------------------------------------------------------------------------
   // Test graph
   //----------------------------------------------------------------------------------------------
   
   public static boolean testGraph(Connection conn, DBExecute exec)
   {
      //String filePath   = "C:\\tmp_share\\IEEE 118 Bus.RAW";
      //String fileFormat = BGModel.MODEL_FORMAT_PSSE;
      
      //String filePath   = "D:\\tmp_share\\powerworld\\ACTIVSg10k.aux";
      //String filePath   = "C:\\tmp_share\\ACTIVSg10k.RAW";
      //String fileFormat = BGModel.MODEL_FORMAT_POWERWORLD;
            
      //String filePath   = "C:\\tmp_share\\IEEE 24 Bus.RAW";
      //String fileFormat = BGModel.MODEL_FORMAT_PSSE;

      //String filePath   = "C:\\tmp_share\\GC-12.47-1.glm";
      //String filePath   = "C:\\tmp_share\\R1-12.47-3.glm";
      //String filePath   = "C:\\tmp_share\\R3-12.47-3.glm";
      //String filePath   = "C:\\tmp_share\\R4-25.00-1.glm";
      //String filePath   = "C:\\tmp_share\\R2-35.00-1.glm";
      //String fileFormat = BGModel.MODEL_FORMAT_GRIDLAB;

      //String filePath   = "C:\\tmp_share\\Texas_2000_Bus.raw";
      //String fileFormat = BGModel.MODEL_FORMAT_PSSE;

      //String filePath   = "C:\\tmp_share\\118BusPF.cdf";
      //String fileFormat = BGModel.MODEL_FORMAT_IEEE_COM;
      
      //String filePath   = "C:\\tmp_share\\IEEE 118 Bus.EPC";
      //String filePath   = "C:\\tmp_share\\ACTIVSg200.EPC";
      //String fileFormat = BGModel.MODEL_FORMAT_PSLF;
      
      //String filePath   = "C:\\tmp_share\\pglib_opf_case1888_rte__api.m";
      //String filePath   = "C:\\tmp_share\\case9241pegase.m";
      //String fileFormat = BGModel.MODEL_FORMAT_MATPOWER;
      
      //String filePath   = "C:\\tmp_share\\Brazilian_7_bus_Equiv_Model.RAW";
      //String fileFormat = BGModel.MODEL_FORMAT_PSSE;    
      
      //String filePath   = "D:\\tmp_share\\OpenDSS\\GSO_Base_Network-1.zip";
      //String fileFormat = BGModel.MODEL_FORMAT_OPENDSS;    

      //String filePath   = "D:\\tmp_share\\REDS\\bus_13_3.pos";
      //String fileFormat = BGModel.MODEL_FORMAT_REDS;    

      //String filePath = "D:\\tmp_share\\powerworld\\ACTIVSg200.aux";
      //String fileFormat = BGModel.MODEL_FORMAT_POWERWORLD;     
      
      String filePath   = "D:\\tmp_share\\OpenDSS\\feeder_j1_opendss_model.zip";
      String fileFormat = BGModel.MODEL_FORMAT_OPENDSS;    

      
      boolean res_b = true;   
      
      BGModel model = BGParser.parseFile(fileFormat, filePath);
      if (model == null) {
         log.error("ModelProcess.processBitstream. Cannot parse file: " + filePath + 
                   "; Model format: " + fileFormat);
         return false;
      }
      model.setUuid(UUID.fromString("aaaaaaaa-bbbb-cccc-dddd-9e1e0d0811ee"));
      model.setName("TEST");
      model.setDescription("Test Description");
      model.setVisible(true);
      
      DBModelProcess process = new DBModelProcess(null, null);
      res_b = process.saveParsedModel(conn, exec, model, true);
      
      //..... Graph ......
      
      res_b = process.processModelLinks (conn, exec, model);
      
      //..... Analyze model to find paths inside ......
     /* 
      String what_s   = "fuse";
      String where_s  = "overhead_line";
      int    what_min = 1;
      int    what_num = 0;
      
      
      BGGraphMap graphMap = new BGGraphMap();
      graphMap.createMap(model, "_from", "_to", true);
      
      for (BGObject obj : model.getObjects()) {
         System.out.println("object: " + obj.getName());
         what_num = obj.findNodesInside(model, graphMap, what_s, where_s, what_min, 0);
         if (what_num > 0) break;
      }      
      //.....
      */
      
      
     /* 
      
      DBModelProcess process = new DBModelProcess(null, null);
      res_b = process.saveParsedModel(conn, exec, model, true);
      
      //..... Graph ......
      
      res_b = process.processModelLinks (conn, exec, model);
      
      //..... Print results ......
            
      for (BGObject obj : model.getObjects(PssTypes.SECT_BUS_IDX)) {
         List<BGLinkAttr> links = obj.getLinksUp();
         
         System.out.println("\n------ Object Name: " + obj.getName() + " --------");
         for(BGLinkAttr link : links) {        
            System.out.println("Name: " + link.getTargetName() + "; Hops: " + link.getHops() +
                               "; Path: " + link.getPath());
         }
      }
      */
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {            
      org.apache.log4j.BasicConfigurator.configure();
      
    //  String[] res_as = DBFunctions.getModelNameType(UUID.fromString("72b690bd-fca8-47b9-a392-f83414984c5c"));
      
//      DBFunctions.isBitstreamInMultBundles(UUID.fromString("5536651a-5c89-4e9a-adaa-4d41684e5821"));
      
      //DBFunctions.getNodes("ae7d5e05-cc46-4b00-8784-81514ef538ed", 
      //                     "branch", "node_18", null, "_reds", null, null);
          
      //DBFunctions.getNodes("c4d22413-de64-4b0a-a0f3-9604c4fa84f2", 
      //      "switch", null, null, "_reds", null, null);


      
      //String test_s = DBSearchFunctions.mapCommonNodeType("transformer");
      
     //testModelParsers();           
      
      //DBEntry dataEntry = DBFunctions.getNodeStatistics("fa7dbd20-071a-429d-9baf-d4807076897b", 
     //                                                   "R4-25-00-1_node_217",
     //                                                   "name",
     //                                                   "_gridlab");
   //   dataEntry.printContent();
            
      DBConnection dbConn = new DBConnection(DBProvider.GraphDB);
      Connection conn     = dbConn.getConnection();                  // get DB connection
      DBExecute exec      = new DBExecute(); 
      
      
   //   testGraph(conn, exec);
   //   dbConn.close();
   //   System.exit(0);
     /* 
      testNLIDB(true);
      
      DBEntry entry7 = DBFunctions.getNodeStatistics("a2a3e826-d786-4f39-9976-ad58de23e18a", "bus_7", "bus", "_psse");      
      entry7.printContent();

      DBEntry entry0 = exec.execQuery(conn, "SELECT * FROM _ipaddr", null);
      entry0.printContent();
*/
      //DBEntry entry1 = DBFunctions.getModelsByType(BGModel.MODEL_FORMAT_PSSE); 
      //entry1.printContent();

      
      /*
      try {
         readFromInputStream("C:\\Archive\\backup\\AWS\\PROD\\logs\\log-2018-01-16\\view_bitstream-5.txt");
      } 
      catch (IOException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
      */
      
      //DBConnection dbConn = new DBConnection(DBProvider.GraphDB);
      //Connection conn     = dbConn.getConnection();                  // get DB connection
      //DBExecute exec      = new DBExecute(); 

      String query_s = null;
      query_s = " Could you show all GRIDLAB models with more than twenty five nodes and also 75 fuses ";
      
      query_s = "Please find all XYZ models with more than a four hundred nodes";
      query_s = "wyceofycnqopwieufc";
      query_s = "Please return grid item files where the number of transformers is more than nine";
      query_s = "Could you find all GRIDLAB models which have switches, more than twenty five nodes and also 79 fuses";
      query_s = "return all GRIDLAB, grg, powerworld and PSS/E models with loads, where number of lines is more than eight hundred";
      query_s = "Show me all grid models with at least 10000 transformers";
      
      query_s = "Give me matlab, Siemens psse and ge models where >= 250 generators or less than 10 branches";     
      query_s = "Show me all grid models";     
            
      query_s = "Return all models with more than three overhead line conductors";
      query_s = "find models with transformers between meters";
      query_s = "find models with at least one meter, where exist 3 switches between two fuses";
      query_s = "find models with at least one meter and with more than 3 switches within fuses";
      //query_s = "find models with at least one transformer between nodes";
      //query_s = "find models with transformers between nodes";
      query_s = "search models with more than 10000 transformers";      
      query_s = "Please return powerworld models where the number of transformers is more than 1000";
      query_s = "Return all models with more than three overhead line conductors";
      query_s = "find all models with more than twelve conductors";
      query_s = "geta alle modls with more4 10 no5des";
      query_s = "return all models with greater than ten overhead line conductors";      
      query_s = "find models with more than two thousand lines with length > 15000 ft";
           
      query_s = "find gridlabd models with overhead lines with length > 1000 ft";
      query_s = "find gridlabd models which have overhead lines with length > 1000 ft";
      query_s = "find gridlabd models with overhead lines where length value > 1000 ft";

      query_s = "find models with more than two lines with length between 1000 ft and 10000 ft";
      query_s = "find models with more than two lines with length > 15000 ft and more than two hundred buses with voltage > 15 kvolt";
      query_s = "find gridlabd models with overhead lines length > 304.8 m";
      query_s = "find reds models with buses where x coord > 100";
      query_s = "find models with solar with efficiency > 0.100";
      query_s = "find gridlabd models with solar with battery capacity > 10 Kwh";
      query_s = "Return all models with more than three overhead line conductors and > 2 triplex lines";
      query_s = "Show me all grid models with at least 10000 transformers";
      query_s = "find gridlabd models with capacitor";
      query_s = "find gridlabd models with overhead lines where length > 1000 ft";
      query_s = "find models with more than two hundred buses with voltage > 15 kvolt";
      
      query_s = "find models with more than two capacitors with voltage > 5 kvolt";
      query_s = "show gridlab and opendss models which have three phase capacitors";
      query_s = "Please return grid models with more than five thousand buses with voltage > 10 kvolt";
      query_s = "Please return grid models with more than five buses with voltage > 10 kvolt";
      query_s = "Please return models xyz, psse format";
      query_s = "find gridlabd models with overhead lines where length > 1000 ft";

      query_s = "files with > 2 capacitors and with nodes";
      query_s = "psse files";
      query_s = "models which > 10 three phase capacitors";
      query_s = "pv models";
      query_s = "all reds models.!";
      
      //NLTranslator trans = new NLTranslator(conn, exec);
      //trans.parseQuery(query_s);
      //String sql_s = DBSearchFunctions.buildSQL(trans, null);
      
      //DBEntry entry = exec.execQuery(conn, sql_s, null);
      
      query_s = SpellChecker.correctPhrase(query_s);
      DBEntry entry = DBSearchFunctions.getModelsBySearch(query_s);
      if (entry == null) {
         System.out.println("Query cannot be executed: " + query_s);
      }
      else {
         entry.printContent();
      }
      
      //testNLIDB();
      
      //***** TMP STUFF *****
      
      //String query_s = "show all repository models with more than ten nodes and two thousand fifty seven fuses";
      //query_s = NLNumConverter.translateNumbers(query_s);

      //DBEntry entryInfo = DBFunctions.getModelsByType("PTI PSS");
      //entryInfo.printContent();
     
      // testModelParsers();
      // testDBAccess();
      
      dbConn.close();
      System.exit(0);
   }

}
