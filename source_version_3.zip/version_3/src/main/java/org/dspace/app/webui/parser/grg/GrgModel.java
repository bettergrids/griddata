package org.dspace.app.webui.parser.grg;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBColumn;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.parser.gridlab.GlmObject;
import org.dspace.app.webui.util.BGSetList;

public class GrgModel extends BGModel {

   private static final Logger log = Logger.getLogger(GrgModel.class);
   
   //..... Constants ......
   
   public static final String FROM_NAME     = "_from";
   public static final String TO_NAME       = "_to";
   public static final String LENGTH_NAME   = "length";
   
   //..... Members ......
   
   private Map<String, GrgObject> objects_hm = new LinkedHashMap<String, GrgObject>();
   
   // Key - object type name; Value - number of object of this type
   private Map<String, Integer> objTypeNum_hm = new HashMap<String, Integer>();
   
   private List<String> objTypeNames_al = new ArrayList<String>();
   private String[] attrNames_sa        = null;
   
   //..... Methods ......
   
   //----------------------------------------------------------------------------------------------
   // Create object name from object type
   //----------------------------------------------------------------------------------------------
   
   public String getNextObjectName(String type_s)
   {
      Integer nameIdx = objTypeNum_hm.get(type_s);
      if (nameIdx == null) {
         objTypeNum_hm.put(type_s, 1);
         return type_s + "_0";
      }
      objTypeNum_hm.put(type_s, nameIdx + 1);
      return type_s + "_" + nameIdx;
   }
   //----------------------------------------------------------------------------------------------
   // Parse DBEntry to GrgObject[]
   //----------------------------------------------------------------------------------------------
   
   public List<GrgObject> entryToBGObjects(DBEntry entry)
   {
      if (entry == null || entry.getTable() == null || entry.getRows().isEmpty()) {
         log.error("entryToBGObjects. DBEntry or/and entry table is/are null or row list is empty");
         return null;
      }
      //..... Create objects from entry rows ......
      
      DBTable table = entry.getTable();
      if (table.getName() == null) {
         log.error("entryToBGObjects. DBEntry table name is null");
         return null;
      }
      String objType = table.getName();
      DBColumn nameCol = table.getColumnByName(nodeName);
      List<String> columnNames = table.getColumnNames();
      if (columnNames == null || columnNames.isEmpty()) {
         log.error("entryToBGObjects. List of column names of DBEntry table is null or empty");
         return null;        
      }
      Integer[] columnIdx_a = new Integer[columnNames.size()];
      for (int i = 0; i < columnNames.size(); i++) {
         columnIdx_a[i] = table.findColumnIdx(columnNames.get(i));
      }
      //..... Create GrgObjects from DBEntry ......
      
      List<GrgObject> objs = new ArrayList<GrgObject>();
      for (Map<Integer,Object> row : entry.getRows()) {         
         
         //..... Set object name ......
         
         String objName = null;
         if (nameCol != null) {
            objName = nameCol.getName();
         }
         else {
            objName = getNextObjectName(objType);
         }
         //..... Find or create object ......
         
         GrgObject obj = this.getObject(objName);
         if (obj == null) {
            obj = new GrgObject();
            obj.setType(objType);
            obj.setName(objName);
            obj.setModel(this);
         }
         //..... Add attributes ......
         
         for (int i = 0; i < columnNames.size(); i++) {
            obj.addAttr(columnNames.get(i), row.get(columnIdx_a[i]).toString());
         }
         objs.add(obj);
      }            
      return objs;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean addObject(GrgObject obj)
   {
      objects_hm.put(obj.getName(), obj);
      return true;
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public GrgObject getObject(String name_s)
   {
      return objects_hm.get(name_s);
   }
   //----------------------------------------------------------------------------------------------
   // Calculate counts of different types (node, fuse, etc.)
   //----------------------------------------------------------------------------------------------
   
   @Override
   public boolean calcTypeCounts() 
   {
      //..... Calculate counts of all types ......
      
      for (GrgObject obj : objects_hm.values()) {  
         String type_s = obj.getType();
         if (typeCounts.containsKey(type_s) == false) { 
            typeCounts.put(type_s, 1);
         }
         else {
            typeCounts.merge(type_s, 1, Integer::sum);
         }
      }   
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Return all objects
   //----------------------------------------------------------------------------------------------
   
   @Override
   public BGObject[] getObjects() 
   {
      return objects_hm.values().toArray(new GrgObject[objects_hm.size()]);   
   }
   //----------------------------------------------------------------------------------------------
   // Return all objects of certain type
   //----------------------------------------------------------------------------------------------
   
   @Override
   public BGObject[] getObjects(String typeName_s) 
   {
      List<GrgObject> objs = new ArrayList<GrgObject>();
      for (GrgObject obj : objects_hm.values()) {
         if (obj.getType().equalsIgnoreCase(typeName_s)) {
            objs.add(obj);
         }
      }
      return objs.toArray(new GrgObject[objs.size()]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public BGObject[] getObjects(int typeIdx) 
   {
      return getObjects(getObjTypeNames()[typeIdx]);
   }
   //----------------------------------------------------------------------------------------------
   // Convert model to entry
   //----------------------------------------------------------------------------------------------

   @Override
   public DBEntry getEntry(String  nodeType_s,
                           String  nodeName_s)
                          
   {
      return getEntry(nodeType_s, nodeName_s, true);
   }
   //----------------------------------------------------------------------------------------------

   public DBEntry getEntry(String  nodeType_s,
                           String  nodeName_s,
                           boolean setNumeric_b)
   {
      DBEntry entry       = new DBEntry();
      boolean haveTypes_b = false;
      
      //..... Setup table ......

      DBTable table = new DBTable();
      table.setName(getName());
      
      for (int i = 0; i < getAttrNames().length; i++) {
         String colName = getAttrNames()[i].replaceAll("\\s+"," ").trim();
         colName = colName.replaceAll("[ .-]", "_");
         
         DBColumn col = new DBColumn(colName, null, Types.VARCHAR, i);
         table.addColumn(i, col);
      }
      entry.setTable(table);
      
      if (objTypeNames_al.isEmpty() == false) {
         haveTypes_b = true;
      }
      //..... Populate row values ......
      
      for (GrgObject obj : objects_hm.values()) {
         if ((nodeName_s == null && nodeType_s == null) ||
             (nodeName_s != null && nodeName_s.equalsIgnoreCase(obj.getName())) ||
             (nodeName_s == null && nodeType_s != null && nodeType_s.equalsIgnoreCase(obj.getType()))) {
             
            Map<Integer, Object> row = entry.newRow();
            for (GrgAttr attr : obj.getAttrsHM().values()) {
               int columnIdx = table.findColumnIdx(attr.getName());
               entry.setRowValue(row, columnIdx, attr.getValue());
            }
            entry.addRow(row);
            
            //..... Populate object type names ......
            
            if (haveTypes_b == false) {
               String type_s = obj.getType();
               if (objTypeNames_al.contains(type_s) == false) { 
                  objTypeNames_al.add(type_s);
               }
            }
         }
      }
      entry.setCompactTable();         // remove columns with all null values
      if (setNumeric_b) {
         entry.setNumericColumns();    // set column types numeric/integer, based on data
      }
      return entry;
   }
   //----------------------------------------------------------------------------------------------
/*
   public DBEntry getEntry(String  parentName_s,
                           String  nodeType_s,
                           String  nodeName_s,
                           boolean setNumeric_b)
   {
      DBEntry entry       = new DBEntry();
      boolean haveTypes_b = false;
      
      //..... Get object(s) type ......
      
      String type_s     = null;
      GrgObject[] obj_a = null;
      
      GrgObject obj = this.getObject(nodeName_s);
      if (obj == null) {
         obj_a = (GrgObject[])getObjects(nodeType_s);
         if (obj_a != null && obj_a.length > 0) {
            type_s = obj_a[0].getType();
         }
      }
      else {
         type_s = obj.getType();
      }
      if (type_s == null) return entry;
      
      //..... Create table using object types as a column names ......      

      DBTable table = new DBTable();
      table.setName(getName());
      
      for (int i = 0; i < getAttrNames().length; i++) {
         String colName = getAttrNames()[i].replaceAll("\\s+"," ").trim();
         colName = colName.replaceAll("[ .-]", "_");
         
         DBColumn col = new DBColumn(colName, null, Types.VARCHAR, i);
         table.addColumn(i, col);
      }
      entry.setTable(table);
      
      if (objTypeNames_al.isEmpty() == false) {
         haveTypes_b = true;
      }
      //..... Get all objects of specified type for parent object ......
      
      if (parent_s != null)
      
      
      
      //..... Populate row values ......
      
      for (GrgObject obj : objects_hm.values()) {
         if ((nodeName_s == null && nodeType_s == null) ||
             (nodeName_s != null && nodeName_s.equalsIgnoreCase(obj.getName())) ||
             (nodeName_s == null && nodeType_s != null && nodeType_s.equalsIgnoreCase(obj.getType()))) {
             
            Map<Integer, Object> row = entry.newRow();
            for (GrgAttr attr : obj.getAttrsHM().values()) {
               int columnIdx = table.findColumnIdx(attr.getName());
               entry.setRowValue(row, columnIdx, attr.getValue());
            }
            entry.addRow(row);
            
            //..... Populate object type names ......
            
            if (haveTypes_b == false) {
               String type_s = obj.getType();
               if (objTypeNames_al.contains(type_s) == false) { 
                  objTypeNames_al.add(type_s);
               }
            }
         }
      }
      entry.setCompactTable();         // remove columns with all null values
      if (setNumeric_b) {
         entry.setNumericColumns();    // set column types numeric/integer, based on data
      }
      return entry;
   }
   */
   //----------------------------------------------------------------------------------------------
   // Get model info (return number of objects of each type)
   //----------------------------------------------------------------------------------------------
   
   public DBEntry getInfoEntry()
   {
      DBEntry entry = new DBEntry();
      Map<String, Integer> info_hm = new LinkedHashMap<String, Integer>();
      
      //..... Setup table ......

      DBTable table = new DBTable();
      table.setName(getName());
      
      table.addColumn(0, new DBColumn(TYPE_CONST,  null, Types.VARCHAR, 0));   // column index: 0
      table.addColumn(1, new DBColumn(COUNT_CONST, null, Types.INTEGER, 1));   // column index: 1
      
      entry.setTable(table);
      
      //..... Calculate counts of all types ......
      
      for (GrgObject obj : objects_hm.values()) {  
         String type_s = obj.getType();
         if (info_hm.containsKey(type_s) == false) { 
            info_hm.put(type_s, 1);
         }
         else {
            info_hm.merge(type_s, 1, Integer::sum);
         }
      }   
      //..... Sort by value ...... 
      
      Set<Entry<String, Integer>>  info_set  = info_hm.entrySet();
      List<Entry<String, Integer>> info_list = new ArrayList<Entry<String, Integer>>(info_set);
      
      Collections.sort(info_list, new Comparator<Map.Entry<String, Integer>>()
      {
          public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
              return (o2.getValue()).compareTo( o1.getValue() );//Descending order
          }
      });
      //..... Populate row values ......
      
      for (Map.Entry<String, Integer> info_pair : info_list){
         Map<Integer, Object> row = entry.newRow();        
         entry.setRowValue(row, 0, info_pair.getKey());        // column index: 0
         entry.setRowValue(row, 1, info_pair.getValue());      // column index: 1
         entry.addRow(row);
      }
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   // Get all model attributes (BGSetList keeps only unique values)
   //----------------------------------------------------------------------------------------------
   
   private void setAttrNames()
   {
      BGSetList<String> attrSet = new BGSetList<String>();
      
      //..... A few columns to display first ......
      
      attrSet.add(GrgParser.NAME_CONST);
     // attrSet.add(GrgParser.OBJ_INDEX_CONST);
     // attrSet.add(GrgParser.FROM_CONST);
     // attrSet.add(GrgParser.TO_CONST);
      
      //..... All other attributes ......
      
      for (GrgObject obj : objects_hm.values()) {         
         attrSet.addAll(new ArrayList<String>(Arrays.asList(obj.getAttrNames())));
      }
      attrNames_sa = attrSet.toArray(new String[attrSet.size()]);
   }   
   //----------------------------------------------------------------------------------------------
   
   private String[] getAttrNames()
   {
      if (attrNames_sa == null) {
         setAttrNames();
      }
      return attrNames_sa;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public String[] getObjTypeNames() 
   {
      if (objTypeNames_al.isEmpty()) {
         for (GrgObject obj : objects_hm.values()) {
            String type_s = obj.getType();
            if (objTypeNames_al.contains(type_s) == false) { 
               objTypeNames_al.add(type_s);
            }
         }
      }
      return objTypeNames_al.toArray(new String[objTypeNames_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public Integer getTypesNum() 
   {
      if (objTypeNames_al.isEmpty()) {
         getObjTypeNames();
      }
      return objTypeNames_al.size();
   }
   //----------------------------------------------------------------------------------------------
   // Convert GrgModel to JSON format
   //----------------------------------------------------------------------------------------------

   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();
      //json_sb.append("{\"" + GlmParser.OBJECT_CONST + "s\": {\n");
      json_sb.append("{\n\""  + GrgParser.OBJECT_CONST + "\": [\n");
      
      //..... For each object ......
      
      for(GrgObject obj : objects_hm.values()) {
         json_sb.append(obj.toJson());
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n]\n}");
      
      return json_sb.toString();
   }

   //----------------------------------------------------------------------------------------------

   @Override
   public BGObject[] getLinkObjects() {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public String[] getNodeObjTypeNames() {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public String[] getLinkObjTypeNames() {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public String getObjTypeName(int sectIdx) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public List<String> getAttrNames(int typeIdx) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public List<Integer> getAttrTypes(int typeIdx) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public Integer getAttrIdx(int sectIdx, String attrName) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public String[] getStaticObjTypeNames() 
   {
      return getObjTypeNames();  // *** TEMPORARY ***
   }

}
