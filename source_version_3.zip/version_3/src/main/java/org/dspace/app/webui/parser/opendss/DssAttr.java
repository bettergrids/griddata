package org.dspace.app.webui.parser.opendss;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.dspace.app.webui.util.BGUtils;

public class DssAttr {

   //..... Attribute types ......
   
   public static final String TYPE_COORD_X  = "x_coord";
   public static final String TYPE_COORD_Y  = "y_coord";
   
   //..... Constructors ......
   
   public DssAttr() {};
   
   public DssAttr(DssObject obj,
                  String name_s,
                  String value_s)
   {
      this.name     = name_s;
      this.value    = value_s;
      this.valueObj = BGUtils.stringToNumeric(value_s);
   }
   //..... Members ......

   private String  name;
   private String  value;
   private Object  valueObj;
   private String  units = null;
   private Integer type;
   
   //..... Getters and Setters ......
   
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getValue() {
      return value;
   }
   public void setValue(String value) {
      this.value = value;
   }
   public Object getObjValue() {
      return valueObj;
   }
   public void setUnits(String units) {
      this.units = units;
   }
   public String getUnits() {
      return units;
   }
   //----------------------------------------------------------------------------------------------
   // Convert to the JSON string/object
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("unchecked")
   String toJson()
   {
      StringBuffer json_sb = new StringBuffer();
      json_sb.append("\t\"" + name + "\" : ");
         
      //..... String array ......
         
      if (valueObj instanceof String[]) {
         String[] val_sa = (String[])valueObj;
         json_sb.append("[");  
            
         for (int i = 0; i < val_sa.length; i++) {
            if (i < val_sa.length - 1) {
               json_sb.append("\"" + val_sa[i] + "\",");
            }
            else {
               json_sb.append("\"" + val_sa[i] + "\"]");
            }
         }
         json_sb.append(",\n");
      }
      //..... Numeric array ......
         
      else if (valueObj instanceof Double[]) {
         Double[] val_da = (Double[])valueObj;
         json_sb.append("[");  
            
         for (int i = 0; i < val_da.length; i++) {
            if (i < val_da.length - 1) {
               json_sb.append(val_da[i] + ",");
            }
            else {
               json_sb.append(val_da[i] + "]");
            }
         }
         json_sb.append(",\n");
      }
      //..... Property type ......

      else if (valueObj instanceof HashMap) {
         json_sb.append("{\n");
            
         HashMap<String,ArrayList<Object>> val_hm = (HashMap<String,ArrayList<Object>>)valueObj;
         for (Map.Entry<String,ArrayList<Object>> entry : val_hm.entrySet()) {
            String elemName           = entry.getKey();
            ArrayList<Object> elemVal = entry.getValue(); 
            json_sb.append("\t\"" + elemName + "\" : ");
             
            if (elemVal.size() > 1) {              // it's an array
               json_sb.append("[");
            }
            for (Object val : elemVal) {
               if (val instanceof Double) {
                  json_sb.append(val.toString() + ",");
               }
               else {
                  json_sb.append("\"" + val.toString() + "\",");
               }
            }
            json_sb.deleteCharAt(json_sb.length() - 1);     // delete last ","
            json_sb.append("],\n");
         }
         json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
         json_sb.deleteCharAt(json_sb.length() - 1);     // delete last ","
         json_sb.append("\n\t},\n");
      }
      //..... Numeric data ......
         
      else if (valueObj instanceof Double || valueObj instanceof Integer) {
            
         if (units != null) {    // create sub-object
            json_sb.append("{\"value\" : " + valueObj.toString());
            json_sb.append(", \"units\" : \"" + units + "\"}");
         }
         else {
            json_sb.append(valueObj.toString());
         }
         json_sb.append(",\n");
      }
      //..... Complex number ......
      
      else if (valueObj instanceof Object[]) {
         json_sb.append("{\"real\" : " + ((Object[])valueObj)[0] + ", \"imag\" : " + ((Object[])valueObj)[1]);        
         json_sb.append(", \"form\" : \"" + ((Object[])valueObj)[2] + "\"},\n");        
      }
      //..... Just string ......
         
      else {
         value = value.replaceAll(":", "_");
         if (value.startsWith("\"")) {
            json_sb.append(value + ",\n");
         }
         else {
            json_sb.append("\"" + value + "\",\n");
         }
      }      
      return json_sb.toString();
   }
}
