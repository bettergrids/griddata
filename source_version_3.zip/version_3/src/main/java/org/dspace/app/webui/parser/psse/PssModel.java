package org.dspace.app.webui.parser.psse;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGUtils;

public class PssModel extends BGModel implements PssTypes {

   private static final Logger log = Logger.getLogger(PssModel.class);
   
   //..... Constants ......
   
   public static final Double VERSION_26   = 26.0;
   public static final Double VERSION_29   = 29.0;
   public static final Double VERSION_30   = 30.0;
   public static final Double VERSION_31   = 31.0;
   public static final Double VERSION_32   = 32.0;
   public static final Double VERSION_33   = 33.0;
   public static final Double VERSION_33_7 = 33.7;
   
   public static final Double VERSION_DEFAULT = VERSION_33;
   
   public static final int MAX_SECT_LINE_NUM = 5;
   //..... Members ......

   @SuppressWarnings("unchecked")
   private Map<String, PssObject>[] object_ahm = (LinkedHashMap<String, PssObject>[])new LinkedHashMap[ATTR_NAMES_SAA.length];
   
   @SuppressWarnings("unchecked")
   private List<String>[][] attrNames_aal  = (ArrayList<String>[][])new ArrayList[SECT_NAMES_SA.length][MAX_SECT_LINE_NUM];
   @SuppressWarnings("unchecked")
   private List<Object>[][] attrDefs_aal   = (ArrayList<Object>[][])new ArrayList[SECT_NAMES_SA.length][MAX_SECT_LINE_NUM];
   @SuppressWarnings("unchecked")
   private List<Integer>[][] attrTypes_aal = (ArrayList<Integer>[][])new ArrayList[SECT_NAMES_SA.length][MAX_SECT_LINE_NUM];
  
   //..... Constructors ......
   
   public PssModel() {
      formatVersion = VERSION_DEFAULT;   // default version
   }
   //----------------------------------------------------------------------------------------------
   //                               Get/Set attribute names
   //----------------------------------------------------------------------------------------------
   
   public List<String> getAttrNames(int sectIdx)   
   {
      if (sectIdx < 0 || sectIdx >= SECT_NAMES_SA.length) return null;
      
      List<String> linkToNames = getAttrNames(sectIdx, 0);
      if (linkToNames == null) return null;
      
      List<String> names_al = new ArrayList<String>(linkToNames);
      Integer      lineNum  = 1;
      switch (sectIdx) {
      case SECT_TRANS3_IDX:
         lineNum = 5;
         break;
      case SECT_TRANS2_IDX:
      case SECT_MTDC_IDX:
         lineNum = 4;
         break;
      case SECT_DC2_IDX:
      case SECT_VSC_IDX:
         lineNum = 3;
         break;
      }
      //..... Multiline sections ......
      
      for (int i = 1; i < lineNum; i++) {
         names_al.addAll(new ArrayList<String>(getAttrNames(sectIdx, i)));
      }
      return names_al;
   }   
   //----------------------------------------------------------------------------------------------
   
   public List<String> getAttrNames(int sectIdx, 
                                    int lineIdx)      // index of line for multiline sections   
   {
      if (attrNames_aal[sectIdx][lineIdx] == null) {
         setAttrSpec(sectIdx);
      }
      //attrNames_aal[sectIdx] = attrNames_aal[sectIdx].stream().map(s -> s.toLowerCase()).collect(Collectors.toList());
      
      BGUtils.toLowerCase(attrNames_aal[sectIdx][lineIdx]);
      return attrNames_aal[sectIdx][lineIdx];
   }
   //----------------------------------------------------------------------------------------------
   
   public void setAttrNames(int sectIdx, 
                            int lineIdx,
                            List<String> attrNames_al) 
   {
      this.attrNames_aal[sectIdx][lineIdx] = attrNames_al;
   }
   //----------------------------------------------------------------------------------------------
   //                            Get/Set attribute default values
   //----------------------------------------------------------------------------------------------
  
   public List<Object> getAttrDefs(int sectIdx,
                                   int lineIdx) 
   {
      if (attrDefs_aal[sectIdx][lineIdx] == null) {
         setAttrSpec(sectIdx);
      }
      return attrDefs_aal[sectIdx][lineIdx];
   }
   //----------------------------------------------------------------------------------------------
   
   public Object getAttrDefault(int sectIdx, 
                                int lineIdx,
                                int attrIdx)
   {
      if (sectIdx < 0 || sectIdx >= SECT_NAMES_SA.length || 
          attrIdx < 0 || attrIdx >= attrDefs_aal[sectIdx][lineIdx].size()) {
         return "";
      }
      if (attrDefs_aal[sectIdx][lineIdx] == null || attrDefs_aal[sectIdx][lineIdx].isEmpty()) {
         setAttrSpec(sectIdx);
      }
      if (attrDefs_aal[sectIdx] == null) {
         return "";
      }
      return attrDefs_aal[sectIdx][lineIdx].get(attrIdx);
   }

   //----------------------------------------------------------------------------------------------
  
   public void setAttrDefs(int sectIdx, 
                           int lineIdx,
                           List<Object> attrDefs_al)
   {
      this.attrDefs_aal[sectIdx][lineIdx] = attrDefs_al;
   }
   //----------------------------------------------------------------------------------------------
   //                                Get/Set attribute types
   //----------------------------------------------------------------------------------------------
   
   public List<Integer> getAttrTypes(int sectIdx, 
                                     int lineIdx) 
   {
      if (attrTypes_aal[sectIdx] == null) {
         setAttrSpec(sectIdx);
      }
      return attrTypes_aal[sectIdx][lineIdx];
   }
   //----------------------------------------------------------------------------------------------

   @Override
   public List<Integer> getAttrTypes(int sectIdx)     // section (or type) index
   {
      if (sectIdx < 0 || sectIdx >= SECT_NAMES_SA.length) return null;
      
      List<Integer> linkToTypes = getAttrTypes(sectIdx, 0);
      if (linkToTypes == null) return null;
      
      List<Integer> types_al = new ArrayList<Integer>(linkToTypes);
      Integer       lineNum  = 1;
      switch (sectIdx) {
      case SECT_TRANS3_IDX:
         lineNum = 5;
         break;
      case SECT_TRANS2_IDX:
      case SECT_MTDC_IDX:
         lineNum = 4;
         break;
      case SECT_DC2_IDX:
      case SECT_VSC_IDX:
         lineNum = 3;
         break;
      }
      //..... Multiline sections ......
      
      for (int i = 1; i < lineNum; i++) {
         types_al.addAll(new ArrayList<Integer>(getAttrTypes(sectIdx, i)));
      }
      return types_al;
   }
   //---------------------------------------------------------------------------------------------   
   
   public void setAttrTypes(int           sectIdx,
                            int           lineIdx,
                            List<Integer> attrTypes_al) 
   {
      this.attrTypes_aal[sectIdx][lineIdx] = attrTypes_al;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
/*   
   public void addSectSpec (int       sectIdx,
                            int       lineIdx,
                            int       lastAttrIdx,        // add all spec attrs up to this (included)
                            String[]  attrNames_sa,
                            Object[]  attrDefs_oa,
                            Integer[] attrTypes_a)
   {
      attrNames_aal[sectIdx][lineIdx].addAll(Arrays.asList(Arrays.copyOfRange(attrNames_sa, 0, lastAttrIdx + 1)));
      attrDefs_aal[sectIdx][lineIdx].addAll(Arrays.asList(Arrays.copyOfRange(attrDefs_oa,   0, lastAttrIdx + 1)));
      attrTypes_aal[sectIdx][lineIdx].addAll(Arrays.asList(Arrays.copyOfRange(attrTypes_a,  0, lastAttrIdx + 1)));
   }
   //----------------------------------------------------------------------------------------------
   
   public void addSectSpec (int       sectIdx,
                            int       lineIdx,
                            String[]  attrNames_sa,
                            Object[]  attrDefs_oa,
                            Integer[] attrTypes_a)
   {
      attrNames_aal[sectIdx][lineIdx].addAll(Arrays.asList(attrNames_sa));
      attrDefs_aal[sectIdx][lineIdx].addAll(Arrays.asList(attrDefs_oa));
      attrTypes_aal[sectIdx][lineIdx].addAll(Arrays.asList(attrTypes_a));
   }
   */
   //----------------------------------------------------------------------------------------------
   // Add object to specific section
   //----------------------------------------------------------------------------------------------
   
   public void addObject(Integer   sectIdx, 
                         String    objName_s, 
                         PssObject obj)
   {
      if (object_ahm[sectIdx] == null) {
         object_ahm[sectIdx] = new LinkedHashMap<String, PssObject>();
      }
      object_ahm[sectIdx].put(objName_s, obj);
   }
   //----------------------------------------------------------------------------------------------
   // Add object to specific section
   //----------------------------------------------------------------------------------------------
   
   public void addObject(PssObject obj)
   {
      int sectIdx = obj.getSectIdx();
      
      if (object_ahm[sectIdx] == null) {
         object_ahm[sectIdx] = new LinkedHashMap<String, PssObject>();
      }
      object_ahm[sectIdx].put(obj.getName(), obj);
   }
   //----------------------------------------------------------------------------------------------
   // Add attribute specification: name, default value, type from the lists
   //----------------------------------------------------------------------------------------------
   
   public void addAttrSpec(int     sectIdx, 
                           int     lineIdx,
                           String  attrName,
                           Object  defaultVal,
                           Integer attrType)
   {
      attrNames_aal[sectIdx][lineIdx].add(attrName);
      attrDefs_aal[sectIdx][lineIdx].add(defaultVal);
      attrTypes_aal[sectIdx][lineIdx].add(attrType);
   }
   //----------------------------------------------------------------------------------------------
   
   public void addAttrSpec(int     sectIdx, 
                           String  attrName,
                           Object  defaultVal,
                           Integer attrType)
   {
      addAttrSpec(sectIdx, 0, attrName, defaultVal, attrType);
      return;
   }
   //----------------------------------------------------------------------------------------------
   // Remove attribute specification: name, default value, type from the lists
   //----------------------------------------------------------------------------------------------
   
   public int removeAttrSpec(int    sectIdx, 
                             int    lineIdx,
                             String attrName)     // returns index of attribute
   {
      int idx = attrNames_aal[sectIdx][lineIdx].indexOf(attrName);
      if (idx >= 0) {
         attrNames_aal[sectIdx][lineIdx].remove(idx);
         attrDefs_aal[sectIdx][lineIdx].remove(idx);
         attrTypes_aal[sectIdx][lineIdx].remove(idx);
      }
      return idx;
   }
   //----------------------------------------------------------------------------------------------
   
   public int removeAttrSpec(int    sectIdx,
                             String attrName)
   {
      return removeAttrSpec(sectIdx, 0, attrName);
   }
   //----------------------------------------------------------------------------------------------
   // Rename attribute 
   //----------------------------------------------------------------------------------------------

   public boolean renameAttr(int    sectIdx, 
                             int    lineIdx,
                             String oldAttrName,
                             String newAttrName)
   {
      int idx = attrNames_aal[sectIdx][lineIdx].indexOf(oldAttrName);
      if (idx >= 0) {
         attrNames_aal[sectIdx][lineIdx].set(idx, newAttrName);
         return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------

   public boolean renameAttr(int    sectIdx, 
                             String oldAttrName,
                             String newAttrName)
   {
      return renameAttr(sectIdx, 0, oldAttrName, newAttrName);
   }
   //----------------------------------------------------------------------------------------------
   // Remove 
   //----------------------------------------------------------------------------------------------
   
   public int removeAttrRest(int sectIdx,     // section index
                             int lineIdx,     // line index               
                             int attrIdx)     // returns index of attribute in the line
   {
      int idx = 0;
      if (idx >= 0) {
         attrNames_aal[sectIdx][lineIdx].remove(idx);
         attrDefs_aal[sectIdx][lineIdx].remove(idx);
         attrTypes_aal[sectIdx][lineIdx].remove(idx);
      }
      return idx;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public void setAttrSpec(int sectIdx)
   {
      if (attrNames_aal[sectIdx][0] != null && attrNames_aal[sectIdx][0].isEmpty() == false) {
         return;
      }
      //..... Common for 1-line sections ......
      
      if (ATTR_NAMES_SAA[sectIdx] != null) {
         attrNames_aal[sectIdx][0] = new ArrayList<String>(Arrays.asList(ATTR_NAMES_SAA[sectIdx]));
      }
      if (ATTR_DEFS_OAA[sectIdx] != null) {
         attrDefs_aal[sectIdx][0]  = new ArrayList<Object>(Arrays.asList(ATTR_DEFS_OAA[sectIdx]));
      }
      if (ATTR_TYPES_AA[sectIdx] != null) {
         attrTypes_aal[sectIdx][0] = new ArrayList<Integer>(Arrays.asList(ATTR_TYPES_AA[sectIdx]));
      }
      //..... Section processing ......
      
      switch(sectIdx) {
      case SECT_HEADER_IDX:
      case SECT_COMMENTS_IDX:
      case SECT_FIX_SHUNT_IDX:
      case SECT_AREA_IDX:
      case SECT_TICT_IDX:
      case SECT_ZONE_IDX:
      case SECT_IATD_IDX:
      case SECT_OWNER_IDX:
      case SECT_FACTS_IDX:
      case SECT_GNE_IDX:
      case SECT_INDUCT_IDX: 
         break;

      case SECT_BRANCH_IDX:
         if (formatVersion > VERSION_26) {
            removeAttrSpec(sectIdx, ANGLE_NAME);
            removeAttrSpec(sectIdx, RATIO_NAME);
         }
         if (formatVersion < VERSION_31) {
            removeAttrSpec(sectIdx, MET_NAME);
         }
         break;

      case SECT_BUS_IDX:
         if (formatVersion < VERSION_33) {
            removeAttrSpec(sectIdx, NVHI_NAME);
            removeAttrSpec(sectIdx, NVLO_NAME);
            removeAttrSpec(sectIdx, EVHI_NAME);
            removeAttrSpec(sectIdx, EVLO_NAME);
         }
         if (formatVersion >= VERSION_31) {
            removeAttrSpec(sectIdx, GL_NAME);
            removeAttrSpec(sectIdx, BL_NAME);
         }
         if (formatVersion <= VERSION_30) {
            removeAttrSpec(sectIdx, OWNER_NAME);
            addAttrSpec(sectIdx, OWNER_NAME, 1, Types.INTEGER);
         }            
         break;         

      case SECT_LOAD_IDX:
         if (formatVersion < VERSION_33) {
            removeAttrSpec(sectIdx, INTRPT_NAME);
         }
         if (formatVersion < VERSION_32) {
            removeAttrSpec(sectIdx, SCALE_NAME);
         }
         break;
         
      case SECT_GEN_IDX:
         if (formatVersion < PssModel.VERSION_32) {
            removeAttrSpec(sectIdx, WPF_NAME);
            removeAttrSpec(sectIdx, WMOD_NAME);
         }
         break;
         
      case SECT_TRANS3_IDX:         
         int last45Idx = (formatVersion < VERSION_30) ? 6 : 16;   // last attr index from lines 4 and 5 
         
         for (int i = 0; i < TR3_ATTR_NAMES_SAA.length; i++) {
            if (i < 3) {
               attrNames_aal[sectIdx][i] = new ArrayList<String>(Arrays.asList(TR3_ATTR_NAMES_SAA[i]));
               attrDefs_aal[sectIdx][i]  = new ArrayList<Object>(Arrays.asList(TR3_ATTR_DEFS_OAA[i]));
               attrTypes_aal[sectIdx][i] = new ArrayList<Integer>(Arrays.asList(TR3_ATTR_TYPES_AA[i]));
            }
            else {
               attrNames_aal[sectIdx][i] = new ArrayList<String>(Arrays.asList(Arrays.copyOfRange(TR3_ATTR_NAMES_SAA[i], 0, last45Idx)));
               attrDefs_aal[sectIdx][i]  = new ArrayList<Object>(Arrays.asList(Arrays.copyOfRange(TR3_ATTR_DEFS_OAA[i],  0, last45Idx)));
               attrTypes_aal[sectIdx][i] = new ArrayList<Integer>(Arrays.asList(Arrays.copyOfRange(TR3_ATTR_TYPES_AA[i],  0, last45Idx)));
            }
         }
         if (formatVersion < VERSION_33) {        
            removeAttrSpec(sectIdx, 0, VECGRP_NAME);     // remove from line 1
         }
         if (formatVersion < VERSION_33_7) {
            removeAttrSpec(sectIdx, 2, ATTR_317_NAME);   // remove from line 3
            removeAttrSpec(sectIdx, 3, ATTR_417_NAME);   // remove from line 4
            removeAttrSpec(sectIdx, 4, ATTR_517_NAME);   // remove from line 5            
         }
         break;

      case SECT_TRANS2_IDX:  
         for (int i = 0; i < TR2_ATTR_NAMES_SAA.length; i++) {
            attrNames_aal[sectIdx][i] = new ArrayList<String>(Arrays.asList(TR2_ATTR_NAMES_SAA[i]));
            attrDefs_aal[sectIdx][i]  = new ArrayList<Object>(Arrays.asList(TR2_ATTR_DEFS_OAA[i]));
            attrTypes_aal[sectIdx][i] = new ArrayList<Integer>(Arrays.asList(TR2_ATTR_TYPES_AA[i]));
         }
         if (formatVersion < VERSION_33) {        
            removeAttrSpec(sectIdx, 0, VECGRP_NAME);
         }
         if (formatVersion < VERSION_33_7) {
            removeAttrSpec(sectIdx, 2, ATTR_317_NAME);
         }
         break;
                  
      case SECT_DC2_IDX:  
         for (int i = 0; i < DC2_ATTR_NAMES_SAA.length; i++) {
            attrNames_aal[sectIdx][i] = new ArrayList<String>(Arrays.asList(DC2_ATTR_NAMES_SAA[i]));
            attrDefs_aal[sectIdx][i]  = new ArrayList<Object>(Arrays.asList(DC2_ATTR_DEFS_OAA[i]));
            attrTypes_aal[sectIdx][i] = new ArrayList<Integer>(Arrays.asList(DC2_ATTR_TYPES_AA[i]));
         }
         break;
        
      case SECT_VSC_IDX:
         for (int i = 0; i < VSC_ATTR_NAMES_SAA.length; i++) {
            attrNames_aal[sectIdx][i] = new ArrayList<String>(Arrays.asList(VSC_ATTR_NAMES_SAA[i]));
            attrDefs_aal[sectIdx][i]  = new ArrayList<Object>(Arrays.asList(VSC_ATTR_DEFS_OAA[i]));
            attrTypes_aal[sectIdx][i] = new ArrayList<Integer>(Arrays.asList(VSC_ATTR_TYPES_AA[i]));
         }
         break;

      case SECT_SW_SHUNT_IDX:
         if (formatVersion < VERSION_29) {  
            removeAttrSpec(sectIdx, MIDNT_NAME);
         }
         if (formatVersion < VERSION_30) {  
            removeAttrSpec(sectIdx, RMPCT_NAME);
         }
         if (formatVersion >= VERSION_30 && formatVersion <= VERSION_31) {
            renameAttr(sectIdx, MIDNT_NAME, RMIDNT_NAME);
         }
         if (formatVersion < VERSION_32) {  
            removeAttrSpec(sectIdx, STAT_NAME);
            removeAttrSpec(sectIdx, ADJM_NAME);
         }
         break;
         
      case SECT_MTDC_IDX:
         for (int i = 0; i < MTDC_ATTR_NAMES_SAA.length; i++) {
            attrNames_aal[sectIdx][i] = new ArrayList<String>(Arrays.asList(MTDC_ATTR_NAMES_SAA[i]));
            attrDefs_aal[sectIdx][i]  = new ArrayList<Object>(Arrays.asList(MTDC_ATTR_DEFS_OAA[i]));
            attrTypes_aal[sectIdx][i] = new ArrayList<Integer>(Arrays.asList(MTDC_ATTR_TYPES_AA[i]));
         }
         break;

      case SECT_MSLD_IDX:
         if (formatVersion < PssModel.VERSION_32) {
            removeAttrSpec(sectIdx, MET_NAME);
         }
         break;
         
      default:
         log.error("PssModel.getAttrNames. Section type with index " + sectIdx + " not supported");
         return;
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   //----------------------------------------------------------------------------------------------
   // Get index of attribute
   //----------------------------------------------------------------------------------------------
   
   public Integer getAttrIdx(int    sectIdx, 
                             String attrName)
   {
      try {
         return getAttrNames(sectIdx).indexOf(attrName);
      }
      catch(Exception e) {
         log.error("PssModel.getAttrIdx. Cannot find attribute for section index: " + sectIdx + 
                   " and attribute name: " + attrName);
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   // Assign default values to the empty object attributes
   //----------------------------------------------------------------------------------------------
   
   public PssObject setDefaultValues(PssObject obj,
                                     int       lineIdx)
   {
      int attrNum    = obj.getAttrNum();                                // object values, including empties      
      int defAttrNum = getAttrDefs(obj.getSectIdx(), lineIdx).size();   // number of declared defaults (PssTypes)
      
      for (int i = 0; i < attrNum; i++) {
         if (obj.getAttr(i) == null) continue;                             // unknown attribute
         if (obj.getAttr(i).toString().isEmpty()) {            
            obj.setAttr(i, getAttrDefault(obj.getSectIdx(), lineIdx, i));  // fill all empty places with defaults
         }
      }
      if (defAttrNum > attrNum) {
         for (int i = attrNum; i < defAttrNum; i++) {
            obj.addAttr(null);                                    // fill not presented attributes
         }                                                        // to keep its position while
      }                                                           // line concatenating
      return obj;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public boolean calcTypeCounts() 
   {
      //..... Calculate counts of all types ......
   
      for (int j = 0; j < object_ahm.length; j++) {
         if (object_ahm[j] == null) continue;
         typeCounts.put(getObjTypeNames()[j], object_ahm[j].size());
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private Integer getTypeIdxFromType (String objType_s)
   {
      if (objType_s == null) return null;
      
      Integer typeIdx = BGUtils.getStringIdx(objType_s, getObjTypeNames());
      if (typeIdx < 0) {
         log.error("MpcModel.getEntry. Cannot find index for objType_s = " + objType_s);
         return null;
      }
      return typeIdx;
   }
   //----------------------------------------------------------------------------------------------
   // Return array of specific type objects
   //----------------------------------------------------------------------------------------------
   
   @Override
   public PssObject[] getObjects(String typeName_s) 
   {
      try {
         Integer objTypeIdx = getTypeIdxFromType(typeName_s);
         return object_ahm[objTypeIdx].values().toArray(new PssObject[0]);
      }
      catch (Exception e) {
         return new PssObject[0];
      }
   }
   //----------------------------------------------------------------------------------------------
   // Return array of specific types objects
   //----------------------------------------------------------------------------------------------
   
   @Override
   public PssObject[] getLinkObjects() 
   {
      List<PssObject> objs_al = new ArrayList<PssObject>(); 
      
      for (int sectIdx = 0; sectIdx < getTypesNum(); sectIdx++) {    
         List<String> attrNames = getAttrNames(sectIdx);
     
         if (attrNames.contains(PssTypes.FROM_NAME) && attrNames.contains(PssTypes.TO_NAME)) {
            PssObject[] objs = getObjects(sectIdx);
            objs_al.addAll(Arrays.asList(objs));           
         }
      }
      return objs_al.toArray(new PssObject[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   // Return all model objects of certain type
   //----------------------------------------------------------------------------------------------

   @Override
   public PssObject[] getObjects(int typeIdx) 
   {
      try {
         return object_ahm[typeIdx].values().toArray(new PssObject[0]);
      }
      catch (Exception e) {
         return new PssObject[0];
      }
   }
   //----------------------------------------------------------------------------------------------
   // Return all model objects 
   //----------------------------------------------------------------------------------------------

   @Override
   public PssObject[] getObjects() 
   {
      List<PssObject> objs = new ArrayList<PssObject>();
      
      for (int typeIdx = 0; typeIdx < object_ahm.length; typeIdx++) {
         if (object_ahm[typeIdx] != null) {
            objs.addAll(object_ahm[typeIdx].values());
         }
      }
      return objs.toArray(new PssObject[objs.size()]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private Integer getTypeIdxFromName (String objName_s)
   {
      if (objName_s == null) return null;
         
      int pos = objName_s.lastIndexOf("_");
      if (pos != -1 && pos < objName_s.length()) {
         String typeName_s = objName_s.substring(0, pos);
         Integer objTypeIdx = BGUtils.getStringIdx(typeName_s, SECT_NAMES_SA);
         if (objTypeIdx != -1) {
            return objTypeIdx;
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private Integer getObjIdxFromName (String objName_s)
   {
      if (objName_s == null) return null;
         
      int pos = objName_s.lastIndexOf("_");
      if (pos != -1 && pos < objName_s.length()) {
         try {
            Integer objIdx = Integer.valueOf(objName_s.substring(pos + 1));
            return objIdx;
         }
         catch (Exception e) {
            return null;
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Integer getTypesNum()
   {
      return object_ahm.length;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();
      json_sb.append("{\n\""  + BGObject.OBJECT_CONST + "\": [\n");
      
      //..... For each object ......
      
      for (int j = 0; j < object_ahm.length; j++) {
         if (object_ahm[j] != null) {
            for (PssObject obj : object_ahm[j].values()) {
               json_sb.append(obj.toJson());
            }
         }
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n]\n}");
      
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   // Return all type names
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getObjTypeNames() 
   {
      return SECT_NAMES_SA;      
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getStaticObjTypeNames() 
   {
      return SECT_NAMES_SA;      
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getNodeObjTypeNames() 
   {
      String[] linkTypes_sa = new String[] {SECT_NAMES_SA[SECT_BUS_IDX]};
      return linkTypes_sa;      
   }
   //----------------------------------------------------------------------------------------------

   @Override
   public String getObjTypeName(int sectIdx) 
   {
      if (sectIdx < 0 || sectIdx >= SECT_NAMES_SA.length) return null;
      return SECT_NAMES_SA[sectIdx];
   }
   //----------------------------------------------------------------------------------------------
   // Return all model objects of certain type
   //----------------------------------------------------------------------------------------------
   
   @Override
   public PssObject getObject(String name_s) 
   {
      if (name_s == null) return null;
      
      Integer objTypeIdx = getTypeIdxFromName(name_s);
      if (objTypeIdx == null) return null;
      
      Integer objId = getObjIdxFromName(name_s);
      if (objId == null) return null;

      //..... Find object ......
      
      if (objTypeIdx < object_ahm.length && object_ahm[objTypeIdx] != null) {
         return object_ahm[objTypeIdx].get(name_s);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getLinkObjTypeNames() 
   {
      List<String> objs_al = new ArrayList<String>(); 
         
      for (int sectIdx = 0; sectIdx < getTypesNum(); sectIdx++) {    
         List<String> attrNames = getAttrNames(sectIdx);
        
         if (attrNames.contains(PssTypes.FROM_NAME) && attrNames.contains(PssTypes.TO_NAME)) {
            String objType_s = getObjTypeName(sectIdx);
            objs_al.add(objType_s);           
         }
      }
      return objs_al.toArray(new String[objs_al.size()]);
   }
}
//======================================= End of Class ============================================

