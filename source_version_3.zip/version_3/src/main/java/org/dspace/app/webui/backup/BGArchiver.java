package org.dspace.app.webui.backup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.log4j.Logger;

public class BGArchiver 
{
   private static final Logger log = Logger.getLogger(BGArchiver.class);
   
   public static void main(String[] a) throws Exception 
   {
      BGArchiver ba = new BGArchiver();
      ba.zipFolder("D:\\reports\\january", "D:\\reports\\january.zip");
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean zipFolder(String srcFolder, 
                            String destZipFile)
   {
      ZipOutputStream  zip        = null;
      FileOutputStream fileWriter = null;
      
      try {
         fileWriter = new FileOutputStream(destZipFile);
         zip        = new ZipOutputStream(fileWriter);
         addFolderToZip("", srcFolder, zip);
         zip.flush();
         zip.close();
      }
      catch(Exception e) {
         log.error("Packing " + srcFolder + " file; Exception: " + e.getMessage());
         return false;
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------   
   
   private boolean addFileToZip(String          path, 
                                String          srcFile, 
                                ZipOutputStream zip)
   {
      File folder = new File(srcFile);
      if (folder.isDirectory()) {
         addFolderToZip(path, srcFile, zip);
      } 
      else {
         byte[] buf = new byte[1024];
         int len;
         FileInputStream in = null;
         try {
            in = new FileInputStream(srcFile);
            zip.putNextEntry(new ZipEntry(path + "/" + folder.getName()));
            while ((len = in.read(buf)) > 0) {
               zip.write(buf, 0, len);
            }
            closeQuietly(in);
         }
         catch (Exception e) {
            log.error("Packing " + folder.getName() + "; Exception: " + e.getMessage());
            if (in != null) closeQuietly(in);
            return false;
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   
   public void closeQuietly(InputStream s) 
   {
      if (null == s) {
         return;
      }
      try {
         s.close();
      } 
      catch (IOException ioe) {
         //ignore exception
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------   

   private void addFolderToZip(String          path, 
                                      String          srcFolder, 
                                      ZipOutputStream zip)
   {
      File folder = new File(srcFolder);

      for (String fileName : folder.list()) {
         if (path.equals("")) {
            addFileToZip(folder.getName(), srcFolder + "/" + fileName, zip);
         } 
         else {
            addFileToZip(path + "/" + folder.getName(), srcFolder + "/" +   fileName, zip);
         }
      }
   }
   //----------------------------------------------------------------------------------------------
   // Another option to pack folder (fro Java 8+ only)
   //----------------------------------------------------------------------------------------------
   
   public static boolean pack (String sourceDirPath, 
                               String zipFilePath) throws IOException 
   {
      Path p = Files.createFile(Paths.get(zipFilePath));
      
      try (ZipOutputStream zs = new ZipOutputStream(Files.newOutputStream(p))) {
         Path pp = Paths.get(sourceDirPath);
         Files.walk(pp)
            .filter(path  -> !Files.isDirectory(path))
            .forEach(path -> {ZipEntry zipEntry = new ZipEntry(pp.relativize(path).toString());
                                 try {
                                    zs.putNextEntry(zipEntry);
                                    zs.write(Files.readAllBytes(path));
                                    zs.closeEntry();
                                 }
                                 catch (Exception e) {
                                    log.error("Packing " + sourceDirPath + " file; Exception: " + e.getMessage());
                                 }
                              }
                    );
      }
      return true;
   }
}
//======================================= End of File =============================================