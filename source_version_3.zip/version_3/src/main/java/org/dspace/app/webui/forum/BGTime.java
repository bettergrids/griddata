package org.dspace.app.webui.forum;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class BGTime {

   public static final List<Long> times = Arrays.asList(TimeUnit.DAYS.toMillis(365),
                                                        TimeUnit.DAYS.toMillis(30),
                                                        TimeUnit.DAYS.toMillis(1),
                                                        TimeUnit.HOURS.toMillis(1),
                                                        TimeUnit.MINUTES.toMillis(1),
                                                        TimeUnit.SECONDS.toMillis(1));
   
   public static final List<String> timesString = Arrays.asList("year","month","day","hour","minute","second");

   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String getTimeAgo(Date dateTime) 
   {
      
      long duration = (new Date()).getTime() - dateTime.getTime();
      if (duration < 0) {
         return "It's in a future";
      }
      StringBuffer res = new StringBuffer();
      
      for(int i = 0; i < BGTime.times.size(); i++) {
         Long current = BGTime.times.get(i);
         long temp    = duration / current;
         if(temp > 0) {
            res.append(temp).append(" ").append(BGTime.timesString.get(i)).append(temp != 1 ? "s" : "").append(" ago");
            break;
         }
      }
      if ("".equals(res.toString())) {
        return "0 seconds ago";
      }
      else {
        return res.toString();
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public static String formatDate(Date   dateTime,
                                   String format_s)
   {
      SimpleDateFormat formatter = new SimpleDateFormat(format_s);
      return formatter.format(dateTime);     
   }
   //----------------------------------------------------------------------------------------------
   
   public static String formatDate(Date dateTime)                                 
   {
      String format_s = "MMMM dd, yyyy HH:mm";
      SimpleDateFormat formatter = new SimpleDateFormat(format_s);
      return formatter.format(dateTime);     
   }
   //----------------------------------------------------------------------------------------------   

}