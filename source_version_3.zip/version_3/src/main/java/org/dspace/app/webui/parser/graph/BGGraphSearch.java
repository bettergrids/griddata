package org.dspace.app.webui.parser.graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

public class BGGraphSearch {

   private static final Logger log = Logger.getLogger(BGGraphSearch.class);
   
   //..... Members ......
   
   private String nodeTo;     // for recursive use
   
   private List<LinkedList<String>> paths_lls = null;
   
   //..... Methods ......
    
   public List<LinkedList<String>> getPaths()
   {
      return paths_lls;
   }
   //---------------------------------------------------------------------------------------------
   // Return all paths as an two dimensional array
   //---------------------------------------------------------------------------------------------
   
   public boolean calculateAllPaths(String     nodeFrom,
                                    String     nodeTo,
                                    BGGraphMap graph)
   {
      paths_lls = new ArrayList<LinkedList<String>>();
      
      LinkedList<String> visited = new LinkedList<String>();
      visited.add(nodeFrom);
      this.nodeTo = nodeTo;
      depthFirst(graph, visited);

      return true;
   }
   //---------------------------------------------------------------------------------------------
   // Recursive "depth-first" search all non-cyclical paths between two nodes
   //---------------------------------------------------------------------------------------------
       
   private void depthFirst(BGGraphMap         graph, 
                           LinkedList<String> visited) 
   {
      LinkedList<String> nodes = graph.adjacentNodes(visited.getLast());
      
      //..... Examine adjacent nodes ......
      
      for (String node : nodes) {
         if (visited.contains(node)) continue;
          
         if (node.equals(nodeTo)) {
            visited.add(node);
            paths_lls.add(new LinkedList<String>(visited));
            visited.removeLast();
            break;
         }
      }
      for (String node : nodes) {
         if (visited.contains(node) || node.equals(nodeTo)) continue;
            
         visited.addLast(node);
         depthFirst(graph, visited);
         visited.removeLast();
      }
   }
   //---------------------------------------------------------------------------------------------
   // Return all paths as an two dimensional array
   //---------------------------------------------------------------------------------------------
   
   public int findNodesInside(String     nodeFrom,
                              String     nodeTo,
                              BGGraphMap graph,
                              String     what_s,
                              String     where_s,
                              int        what_min,
                              int        hops) 

   {
      LinkedList<String> visited = new LinkedList<String>();
      visited.add(nodeFrom);
      this.nodeTo = nodeTo;

      return searchInside(graph, visited, what_s, where_s, what_min, hops);
   }
   //---------------------------------------------------------------------------------------------
   // Recursive "depth-first" search all non-cyclical paths between two nodes
   //---------------------------------------------------------------------------------------------
       
   private int searchInside(BGGraphMap         graph,
                            LinkedList<String> visited,
                            String             what_s,
                            String             where_s,
                            int                what_min,
                            int                hops) 
   {
      LinkedList<String> nodes = graph.adjacentNodes(visited.getLast());
      int what_num = 0;
      
      //..... Examine adjacent nodes ......
      
      for (String node : nodes) {
         if (visited.contains(node)) continue;
          
         if (node.equals(nodeTo)) {
            visited.add(node);
            
            //..... Check if the goal achieved ......
            
            int pos_where_1 = visited.indexOf(where_s);
            if (pos_where_1 >= 0) {
               int pos_where_2 = visited.lastIndexOf(where_s);
               if (pos_where_2 >= 2) {
                  what_num = Collections.frequency(visited.subList(pos_where_1 + 1, pos_where_2), what_s);
                  if (what_num >= what_min) {
                     return what_num;
                  }
               }
            }
            visited.removeLast();
            break;
         }
      }
      for (String node : nodes) {
         if (visited.contains(node) || node.equals(nodeTo)) continue;
            
         visited.addLast(node);
         what_num = searchInside(graph, visited, what_s, where_s, what_min, hops);
         if (what_num > 0) {
            return what_num;
         }
         visited.removeLast();
      }
      return 0;
   }
   //---------------------------------------------------------------------------------------------
   // Main function for testing
   //---------------------------------------------------------------------------------------------
    
   public static void main(String[] args) 
   {
      // this graph is directional
      BGGraphMap graph = new BGGraphMap();
      
      graph.addEdge("A", "B");
      graph.addEdge("A", "C");
      graph.addEdge("B", "A");
      graph.addEdge("B", "D");
      graph.addEdge("B", "E"); // this is the only one-way connection
      graph.addEdge("B", "F");
      graph.addEdge("C", "A");
      graph.addEdge("C", "E");
      graph.addEdge("C", "F");
      graph.addEdge("D", "B");
      graph.addEdge("E", "C");
      graph.addEdge("E", "F");
      graph.addEdge("F", "B");
      graph.addEdge("F", "C");
      graph.addEdge("F", "E");
      graph.addEdge("D", "E");
      
      BGGraphSearch bgSearch = new BGGraphSearch();
      bgSearch.calculateAllPaths("B", "E", graph);
       
      for (LinkedList<String> path : bgSearch.getPaths()) {
         for(String node : path) {
            System.out.print(node + ", ");
         }
         System.out.println("");
      }
   }
}
//======================================= End of Class ============================================