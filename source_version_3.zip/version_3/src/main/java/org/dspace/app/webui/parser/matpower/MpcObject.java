package org.dspace.app.webui.parser.matpower;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBColumn;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGUtils;

public class MpcObject extends BGObject implements MpcTypes {
   
   private static final Logger log = Logger.getLogger(MpcObject.class);
   
   //..... Members ......
   
   private Integer  typeIdx      = null;    // 0 - version, 1 - baseMVA, 2 - bus, 3 - gen, 4 - branch, 5 - gencost
   private Object[] attr_oa      = null;
   private MpcModel model;
   
   //..... Getters/Setters ......
   
   public Integer getAttrNum() 
   {
      if (attr_oa != null) {
         return attr_oa.length;
      }
      return 0;
   }   
   public Integer getTypeIdx() {
      return typeIdx;
   }
   public void setTypeIdx(Integer typeIdx) {
      this.typeIdx = typeIdx;
   }
   public String getType()
   {
      if (typeIdx != null && typeIdx >= 0 && typeIdx < OBJECT_TYPE_SHOW_SA.length) {
         return OBJECT_TYPE_SHOW_SA[typeIdx];
      }
      return null;
   }
   
   @Override
   public MpcModel getModel() {
      return model;
   }
   public void setModel(MpcModel model) {
      this.model = model;
   }
   @Override
   public void setModel(BGModel model) {
      this.model = (MpcModel)model;
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getAttrNames()
   {
      return model.getAttrNames(typeIdx).toArray(new String[0]);
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean setAttr(int idx, String attr_s)
   {
      try {
         attr_oa[idx] = attr_s;
         return true;
      }
      catch (Exception e) {
         return false;
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean setAttrs(String attrs_s)
   {
      if (attrs_s == null || typeIdx == null) return false;
      if (attrs_s.endsWith("]")) {
         attrs_s = attrs_s.substring(0, attrs_s.length() - 1).trim();
      }      
      String[] tmp_sa = BGUtils.splitQuoted(attrs_s);
      
      // String[] tmp_sa = attrs_s.split("\\s+");
      
      if (typeIdx != 5 && tmp_sa.length != OBJECT_TYPES_SAA[typeIdx].length && typeIdx != 4) {
         if (tmp_sa.length > OBJECT_TYPES_SAA[typeIdx].length) {
            
            //log.info("MpcObject.setAttrs. Number of attributes: " + tmp_sa.length + 
            //      " > " + OBJECT_TYPES_SAA[typeIdx].length + ", declared for type: " + OBJECT_TYPE_NAMES_SA[typeIdx]);

            // attr_oa = new Object[OBJECT_TYPES_SAA[typeIdx].length];
            // System.arraycopy(tmp_sa, 0, attr_oa, 0, attr_oa.length);
            
            attr_oa = tmp_sa;
            return true;
         }
         else {
            log.error("MpcObject.setAttrs. Number of attributes: " + tmp_sa.length + 
                      " is less than " + OBJECT_TYPES_SAA[typeIdx].length + 
                       ", required for type: " + OBJECT_TYPE_NAMES_SA[typeIdx]);
            return false;
         }
      }
      //..... Allow to copy only known part of attributes ......
      
      attr_oa = tmp_sa;
      
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public List<Object> getAttrs() 
   {
      return new ArrayList<Object>(Arrays.asList(attr_oa));
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public Object getAttr(int idx)
   {
      Object value = null;
      try {
         value = valueOfType((String)attr_oa[idx]);
         
         if (value instanceof Double || value instanceof Integer) {
            return value;
         }
         else {
            return value;         // all mpc attributes are numbers
         }
      }
      catch (Exception e) {
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Object getAttr(String attrName_s)
   {
      int idx = Arrays.asList(getAttrNames()).indexOf(attrName_s);
      if (idx == -1) return null;
      return getAttr(idx);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   /*
   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();

      //String objTypeId = type + ((id == null) ? "" : "_" + id.toString());
      
      //..... Start with object type, id and name (if any) as attributes ......
      
      json_sb.append("{\t\"object_type\" : \"" + type + "\",\n" );
      if (id != null) {
         json_sb.append("\t\"object_id\" : " + id.toString() + ",\n");
      }
      if (name != null) {
         json_sb.append("\t\"object_name\" : \"" + name + "\",\n");
      }
      //..... For each attribute ......
      
      for (int i = 0; i < getAttrNum(); i++) {
         String attrJson_s = BGObject.attrToJson(getAttrNames()[i], getAttr(i), null);
         json_sb.append(attrJson_s);
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n},\n");
      return json_sb.toString();
   }
   */
   //----------------------------------------------------------------------------------------------
   // Get table with column declarations
   //----------------------------------------------------------------------------------------------
   
   @Override
   public DBTable getTable() 
   {
      //..... Setup table ......

      String objType_s = getType();
      if (objType_s == null) return null;
      
      DBTable table = new DBTable();
      table.setName(objType_s);

      int attrLen = Math.max(getAttrNames().length, this.getAttrNum()) ;      
      
      for (int i = 0; i < attrLen; i++) {         
         String  colName_s = null;
         Integer colType   = null;
         
         if (this.typeIdx == TYPE_COST_IDX && OBJECT_NAMES_SAA[typeIdx].length <= i) {
            Integer idx = attrLen - i - 1;
            colName_s = "c" + idx;
            colType   = Types.DOUBLE;
         }
         else {
            colName_s = model.getAttrNames(typeIdx).get(i);
            colType   = model.getAttrTypes(typeIdx).get(i);
         }               
         DBColumn col = new DBColumn(colName_s, null, colType, i);
         table.addColumn(i, col);
      }
      return table;
   }
}
//======================================= End of Class ============================================
