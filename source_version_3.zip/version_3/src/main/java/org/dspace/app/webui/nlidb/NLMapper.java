package org.dspace.app.webui.nlidb;

public interface NLMapper {
   
   //..... Keywords ......
   
   final static String _BUS            = "bus";
   final static String _LOAD           = "load";
   final static String _GENERATOR      = "generator";
   final static String _FIXED_SHUNT    = "fixed_shunt";
   final static String _SWITCHED_SHUNT = "switched_shunt";
   
   final static String[] _LOAD_NODES = {_LOAD, _FIXED_SHUNT, _SWITCHED_SHUNT};
   final static String[] _GEN_NODES  = {_GENERATOR};
   
   //..... Node type synonyms ......
   
   final static String[]   _NODETYPE_KEY_SA   = {"configuration", "conductor","bus", "line", 
                                                 "transformer", "meter"};
   final static String[][] _NODETYPE_SYNS_SAA = {{"overhead line configuration", "triples line configuration",
                                                  "underground line configuration",
                                                  "line configuration", "regulator configuration", 
                                                  "transformer configuration"},
                                                 {"overhead line conductor", "triples line conductor",
                                                  "underground line conductor"},
                                                 {"triplex node", "dc bus", "bus", "node"},
                                                 {"overhead line", "triplex line", "underground line", 
                                                  "multi section line", "dc line", "ac line", "line branch",
                                                  "multisectionline", "line"},  
                                                 {"transformer 2 wind", "transformer 3 wind", 
                                                  "two winding transformer", "three winding transformer", 
                                                  "transformer branch", "transformerwinding branch", 
                                                  "gicxformer", "transformer"},
                                                 {"meter", "triplex meter"}
                                                 };  
      
   //-------------------------------------- Attributes --------------------------------------------
   
   // names per model format by order: 
   // 1.GridLab-D; 2.Matpower; 3.IEEE CDF; 4.PSS/E; 5.PSLF; 6.OpenDSS; 7.GRG; 8.REDS; 9.PowerWorld
   
   final static String[]  _BUS_KEY_SA               = {"bus", "node"};
   final static String[]  _BUS_COLNAME_SA           = {"node", "bus", "bus", "bus", "bus", "name", "name", "name", "bus"}; 
   final static String    _BUS_COLNAME_DEFAULT      = "bus";
   
   final static String[]  _LINE_KEY_SA              = {"line"};
   final static String[]  _LINE_COLNAME_SA          = {"line", "line", "line", "line", "line", "line","line", "line", "line"}; 
   final static String    _LINE_COLNAME_DEFAULT     = "line";

   final static String[]  _CAP_KEY_SA                = {"capacitor"};
   final static String[]  _CAP_COLNAME_SA            = {"capacitor", null,null,null,null,"capacitor", null,null,null}; 
   final static String    _CAP_COLNAME_DEFAULT       = "capacitor";
   
   final static String[][]  _ATTR_KEY_SA            = {_BUS_KEY_SA, _LINE_KEY_SA, _CAP_KEY_SA};
   final static String[][]  _ATTR_COLNAME_SA        = {_BUS_COLNAME_SA, _LINE_COLNAME_SA, _CAP_COLNAME_SA};
   
   //..... Node attributes ......
   
   final static String[]    _TAB_ATTR_KEY_SA        = {"bus.voltage", 
                                                       "line.length",
                                                       "solar.efficiency",
                                                       "battery.capacity",
                                                       "capacitor.voltage",
                                                       "capacitor.phase"};
   
   final static String[][]  _TAB_ATTR_SYNS_SAA      = {{"bus nominal voltage", "bus voltage", "nominal voltage", "voltage"},
                                                       {"length", "len", "distance"},
                                                       {"efficiency", "effectiveness"},
                                                       {"battery capacity", "capacity"},
                                                       {"capacitor nominal voltage", "capacitor voltage", "nominal voltage", "voltage"},
                                                       {"phase"}
                                                      };
   final static String[][]  _TAB_ATTR_NAME_SAA      = {{"nominal_voltage", "base_kv", "base_kv", "bus_kv", "kv",
                                                        null, null, null, "busnomvolt"},
                                                       {"length", null, null,"length","length","length",
                                                        null, "length","linelength"},
                                                       {"efficiency"},
                                                       {"battery_capacity"},
                                                       {"nominal_voltage", null,null,null,null,"kv", null,null,null},
                                                       {"(length(phases) - 1)",null,null,null,null,"phases", null,null,null}
                                                      };   
   final static String[][]  _TAB_ATTR_COEFF_SAA     = {{"1", "1000", "1000", "1000", "1000", null,null,null, "1000"},
                                                       {"1", null, null, "1", "1", "1", null, "1", "1"},
                                                       {"1", "1", "1", "1", "1", "1", "1", "1", "1"},
                                                       {"1", "1", "1", "1", "1", "1", "1", "1", "1"},
                                                       {"1",  null,null,null,null,"1000", null,null,null},
                                                       {"1", null,null,null,null,"1", null,null,null}
                                                      };   
   
   final static String     _TAB_ATTR_COEFF_DEFAULT  = "1";
   
   //..... Units ......
   
   final static String[]   _UNIT_KEY_SA             = {"v", "kv", "ft", "mi", "km", "m", "Wh", "KWh", "MWh"};
   final static String[][] _UNIT_SYNS_SAA           = {{"volt", "v"},
                                                      {"kvolt", "kv", "kilovolt"},
                                                      {"foot", "feet", "ft"},
                                                      {"mile", "mi"},
                                                      {"kilometer", "km"},
                                                      {"meter", "m"},
                                                      {"watt/hour", "wh"},
                                                      {"kilowatt/hour","KW/hour","KW/h", "KWh"},
                                                      {"megawatt/hour","MW/hour","MW/h", "MWh"}
                                                      };
   final static String[]   _UNIT_COEFF_SA           = {"1", "1000", "1", "5280", "3280.84", "3.28084", "1", "1000", "1000000"};
   final static String     _UNIT_COEFF_DEFAULT      = "1";
   
   //..... Attribute: Length ......
   
   final static String      _TAB_ATTR_NAME_DEFAULT  = "voltage";
   
   
   
   
   
   //--------------------------------------- GRIDLAB-D --------------------------------------------
   
   //..... Units ......
   
   final static String _VOLTAGE_UNIT_KEY_S = " V";  
   
   //..... Transformer ......
   
   final static String   ___KEY_S     = "model";  
   final static String[] ___MODEL_SYNS_SA   = {"object", "item", "file", "attachment", "bitstream"};  


}
