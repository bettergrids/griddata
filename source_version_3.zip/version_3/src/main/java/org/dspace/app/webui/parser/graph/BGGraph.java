package org.dspace.app.webui.parser.graph;

import java.util.PriorityQueue;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.parser.BGModel;

//----------------------------------------------------------------------------------------------
//                                    BGVertex class
//----------------------------------------------------------------------------------------------
   
class BGVertex implements Comparable<BGVertex> 
{
   //..... Members ......
   
   public final String  name;
   
   public BGEdge[] links;                           // links to neighbors 
   public Double   distance = Double.MAX_VALUE;
   public Integer  hops     = Integer.MAX_VALUE;
   public BGVertex previous;
      
   private boolean hops_b;          // true: compare by hops; false: compare by distance
   
   //..... Constructor ......
   
   public BGVertex(String  name, 
                   boolean hops_b)       // true: compare by hops; false: compare by distance 
   { 
      this.name   = name;
      this.hops_b = hops_b;
   }
   //..... Methods ......
   
   public int compareTo(BGVertex other) 
   {
      if (hops_b) {
         return Integer.compare(hops, other.hops);
      }
      return Double.compare(distance, other.distance);
   }
}
//----------------------------------------------------------------------------------------------
//                                     BGEdge class
//----------------------------------------------------------------------------------------------

class BGEdge
{
   //..... Members ......
   
   public final String   linkType;  // type of link object, like: "branch", "transformer", etc.
   public final BGVertex target;
   public final Double   length;      // length (or weight) of the edge
   
   //..... Methods ......
   
   public BGEdge(String   linkType, 
                 BGVertex target, 
                 Double length) 
   { 
      this.linkType = linkType;
      this.target   = target; 
      this.length   = length; 
   }
}
//----------------------------------------------------------------------------------------------
//                                  BGGraph public class
//----------------------------------------------------------------------------------------------
   
public class BGGraph {
      
   private static final Logger log = Logger.getLogger(BGGraph.class);
      
   //..... Members ......
   
   private boolean hops_b = true;       // true: compare by hops; false: compare by distance
   
   private HashMap<String, List<BGEdge>> edge_hm = null;
   private HashMap<String, BGVertex>     vert_hm = null;

   //..... Methods ......
   
   public void setHopsCompare(boolean hops_b)
   {
      this.hops_b = hops_b;
   }
   //-------------------------------------------------------------------------------------------
   //
   //-------------------------------------------------------------------------------------------

   private boolean addEdge(BGObject linkObj,
                           String   fromName,
                           String   toName,
                           String   lengthName)    // name of length (or weight) of the edge
   {
      try {
         if (linkObj.getAttr(fromName) == null || linkObj.getAttr(toName) == null) {
            return true;
         }
         String fromValue_s = linkObj.getAttr(fromName).toString();
         String toValue_s   = linkObj.getAttr(toName).toString();
         
         Double lenValue;
         try {
            lenValue = Double.valueOf(linkObj.getAttr(lengthName).toString());
         }
         catch (Exception e) {
            lenValue = 0.0;
         }
         //..... Find target or create a new one if not exists ......
         
         BGVertex target_v = vert_hm.get(toValue_s);
         if (target_v == null) {
            target_v = new BGVertex(toValue_s, hops_b);
            vert_hm.put(toValue_s, target_v);
         }
         BGEdge target_e = new BGEdge(linkObj.getType(), target_v, lenValue);
         
         //..... Find edge or create a new one if not exists ...... 
         
         List<BGEdge> targets_al;
         if (edge_hm.containsKey(fromValue_s) == false) {            
            targets_al = new ArrayList<BGEdge>();                        
         }
         else {
            targets_al = edge_hm.get(fromValue_s);
         }
         targets_al.add(target_e);
         edge_hm.put(fromValue_s, targets_al);
      }
      catch (Exception e) {
         log.error("addEdge. Cannot get attribute value for: " + fromName + 
                   " and/or " + toName + ". " + ExceptionUtils.getStackTrace(e));
         return false;
      }
      return true;
   }
   //-------------------------------------------------------------------------------------------
   // Setup graph as HashMap of vertices with links to neighbors
   //-------------------------------------------------------------------------------------------
   

   public boolean setupGraph(BGObject[] branches,
                             String     fromName,
                             String     toName,
                             String     lengthName)    // can be distance or weight
   {
      boolean res_b;
      
      //..... Initialize hash maps (vertices and edges) ......
      
      edge_hm = new HashMap<String, List<BGEdge>>();
      vert_hm = new HashMap<String, BGVertex>(); 
      
      //..... Create links ......
      
      for (int i = 0; i < branches.length; i++) {
         res_b = addEdge(branches[i], fromName, toName, lengthName);
         if (res_b == false) {
            return false;
         }
      }
      //..... Attach neighbor links to vertices ......
      
      for (Entry<String, List<BGEdge>> entry : edge_hm.entrySet()) {
         String     source_s  = entry.getKey();
         List<BGEdge> links_ea = entry.getValue();
         
         BGVertex source_v = vert_hm.get(source_s);
         if (source_v == null) {
            source_v = new BGVertex(source_s, hops_b);
         }
         source_v.links = links_ea.toArray(new BGEdge[links_ea.size()]);
         vert_hm.put(source_s, source_v);
      }      
      return true;   
   }
   //----------------------------------------------------------------------------------------------
   // Compute paths for all model branches
   //----------------------------------------------------------------------------------------------
   
   public boolean computeShortestPaths(BGModel model,
                                       String  fromName,
                                       String  toName,
                                       String  lenName,        // name of branch length attribute
                                       boolean linksDown_b)    // true: DOWN; false: UP
   {
      BGObject[] links = model.getLinkObjects(); 
      BGObject[] buses = model.getObjects();                // for all objects
      
      if (links == null || buses == null) return false;
      
      //..... Links Up/Down ......
      
      if (linksDown_b == false) {         // change FROM to TO and vice versa
         String tmp = fromName;
         fromName   = toName;
         toName     = tmp;
      }
      //..... Initialize Graph structure ......
      
      setupGraph(links, fromName, toName, lenName);
   
      //..... For each model node (bus) ......
      
      for (int j = 0; j < buses.length; j++) {
         BGVertex source_v = vert_hm.get(buses[j].getName());         
         if (source_v == null) continue;
         
         //..... Delay to allow Tomcat to switch to another servlet thread ......
         
         if (j % 100 == 0) {
            try {
               TimeUnit.MILLISECONDS.sleep(10);
            }
            catch (InterruptedException e) {
               log.error("computeShortestPaths. Timeout.Stack Trace: " + ExceptionUtils.getStackTrace(e));
            }
         }
         //......................................................................
         
         cleanupPaths();
         computeShortestPaths(source_v);        // compute min hops (or distances) to all vertices
         
         BGObject source_o = model.getObject(source_v.name);
         
         source_o.initLinks();      // create links if not exist

         //..... Get shortest paths to all nodes ......
         
         for (int i = 0; i < buses.length; i++) {
            BGVertex target_v = vert_hm.get(buses[i].getName());
            
            if (target_v == null || source_v == target_v) continue;             
            if (target_v.hops == Integer.MAX_VALUE || target_v.hops == 0) continue;
            
            //..... Set link parameters for source to the target ......
                        
            BGLinkAttr linkAttr = new BGLinkAttr();
            
            linkAttr.setTargetName(target_v.name);
            linkAttr.setHops((target_v.hops < Integer.MAX_VALUE) ? target_v.hops : 0);
            linkAttr.setDistance((target_v.distance < Double.MAX_VALUE - 1.) ? target_v.distance : 0.0);
            linkAttr.setPath(getShortestPathTo(target_v.name));
            
            source_o.addLink(linksDown_b, linkAttr, null);
         }
      }
      return true;
   }   
   //----------------------------------------------------------------------------------------------
   // Find the shortest path from source to all neighbor nodes recursively
   //----------------------------------------------------------------------------------------------
      
   public void computeShortestPaths(BGVertex source)
   {
      source.distance = 0.0;
      source.hops     = 0;
      
      PriorityQueue<BGVertex> vertexQueue = new PriorityQueue<BGVertex>();  // queue keeps order      
      vertexQueue.add(source);
      
      while (!vertexQueue.isEmpty()) {
         
         // Poll: Retrieves and removes the head of this queue, 
         // or returns null if this queue is empty
         
         BGVertex nodeSource = vertexQueue.poll();
         if (nodeSource.links == null) continue;
         
         //..... Visit each edge exiting node ......
         
         for (BGEdge link : nodeSource.links) {
            BGVertex nodeTarget = link.target;
            double   weight     = link.length;
            double   distance   = nodeSource.distance + weight;
            int      hops       = nodeSource.hops + 1;
           
            if ((hops_b && hops < nodeTarget.hops) || (!hops_b && distance < nodeTarget.distance)) {
               vertexQueue.remove(nodeTarget);
               nodeTarget.distance = distance;
               nodeTarget.hops     = hops;
               nodeTarget.previous = nodeSource;
               vertexQueue.add(nodeTarget);
            }
         }
      }
   }
   //----------------------------------------------------------------------------------------------
   // Cleanup vertex links
   //----------------------------------------------------------------------------------------------
   
   private void cleanupPaths()
   {
      for (BGVertex vert : vert_hm.values()) {
         vert.hops     = Integer.MAX_VALUE;
         vert.distance = Double.MAX_VALUE;
         vert.previous = null;
      }
   }   
   //----------------------------------------------------------------------------------------------
   // Get shortest path (all nodes from source to target) 
   //----------------------------------------------------------------------------------------------
   
   public List<String> getShortestPathTo(String target_s)
   {
      List<String> path = new ArrayList<String>();
      BGVertex target_v = vert_hm.get(target_s);
      if (target_v == null) {
         log.error("getShortestPathTo. Cannot find vertex: '" + target_s + "'" );
         return null;
      }
      BGVertex vertex = target_v;
      int hops      = target_v.hops;
      
      if (hops > 0 && hops < Integer.MAX_VALUE) {
         while (vertex != null && hops >= 0) {
            path.add(vertex.name);
            vertex = vertex.previous;
            hops--;
         }
         Collections.reverse(path);
      }
      return path;
   }
}
//======================================= End of Class ============================================