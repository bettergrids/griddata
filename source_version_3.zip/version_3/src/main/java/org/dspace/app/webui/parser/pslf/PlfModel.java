package org.dspace.app.webui.parser.pslf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGUtils;

public class PlfModel extends BGModel implements PlfTypes {

   private static final Logger log = Logger.getLogger(PlfModel.class);
      
   //..... Constants ......
      
   public static final Double VERSION_15 = 15.0;
   public static final Double VERSION_17 = 17.0;
   public static final Double VERSION_20 = 20.0;

   //..... Members ......

   @SuppressWarnings("unchecked")
   private Map<String, PlfObject>[] object_ahm = (LinkedHashMap<String, PlfObject>[])new LinkedHashMap[ATTR_NAMES_SAA.length];
      
   @SuppressWarnings("unchecked")
   private List<String>[] attrNames_aal  = (ArrayList<String>[])new ArrayList[SECT_NAMES_SA.length];
      
   @SuppressWarnings("unchecked")
   private List<Integer>[] attrTypes_aal  = (ArrayList<Integer>[])new ArrayList[SECT_NAMES_SA.length];
     
   //----------------------------------------------------------------------------------------------
   // Add object to specific section
   //----------------------------------------------------------------------------------------------
      
   public List<String> getAttrNames(int sectIdx) 
   {
      if (sectIdx < 0 || sectIdx >= attrNames_aal.length) return null;
      
      if (attrNames_aal[sectIdx] == null) {
         attrNames_aal[sectIdx] = new ArrayList<String>(Arrays.asList(ATTR_NAMES_SAA[sectIdx]));
      }
      return attrNames_aal[sectIdx];
   }

   public List<Integer> getAttrTypes(int sectIdx) 
   {
      if (sectIdx < 0 || sectIdx >= attrTypes_aal.length) return null;
      return attrTypes_aal[sectIdx];
   }
   
   public void setAttrTypes(int sectIdx, List<Integer> attrTypes_a) 
   {
      attrTypes_aal[sectIdx] = attrTypes_a;
   }

   public Integer getAttrType(int sectIdx, int attrIdx) 
   {
      if (sectIdx < 0 || sectIdx >= attrTypes_aal.length) return null;
      if (attrIdx < 0 || attrIdx >= attrTypes_aal[sectIdx].size()) return null;
         
      return attrTypes_aal[sectIdx].get(attrIdx);
   }

   @Override
   public String getObjTypeName(int sectIdx) 
   {
      if (sectIdx < 0 || sectIdx >= SECT_NAMES_SA.length) return null;
      return SECT_NAMES_SA[sectIdx];
   }
   //----------------------------------------------------------------------------------------------
   // Get index of attribute
   //----------------------------------------------------------------------------------------------
   
   public Integer getAttrIdx(int sectIdx, String attrName)
   {
      return attrNames_aal[sectIdx].indexOf(attrName);
   }
   //-------------------------------------------------------------------------------------------
   //
   //-------------------------------------------------------------------------------------------
      
   public boolean setAttrType(int sectIdx, 
                              int attrIdx, 
                              int type) 
   {
      attrTypes_aal[sectIdx].set(attrIdx, type);
      return true;
   }
   //-------------------------------------------------------------------------------------------
   //
   //-------------------------------------------------------------------------------------------

   public void addObject(Integer   sectIdx, 
                         PlfObject obj)
   {
      if (object_ahm[sectIdx] == null) {
         object_ahm[sectIdx] = new LinkedHashMap<String, PlfObject>();
      }
      object_ahm[sectIdx].put(obj.getName(), obj);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public boolean calcTypeCounts() 
   {
      //..... Calculate counts of all types ......
   
      for (int j = 0; j < object_ahm.length; j++) {
         if (object_ahm[j] == null) continue;
         typeCounts.put(getObjTypeNames()[j], object_ahm[j].size());
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private Integer getTypeIdxFromType (String objType_s)
   {
      if (objType_s == null) return null;
      
      Integer typeIdx = BGUtils.getStringIdx(objType_s, getObjTypeNames());
      if (typeIdx < 0) {
         log.error("MpcModel.getEntry. Cannot find index for objType_s = " + objType_s);
         return null;
      }
      return typeIdx;
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private Integer getTypeIdxFromName (String objName_s)
   {
      if (objName_s == null) return null;
         
      int pos = objName_s.lastIndexOf("_");
      if (pos != -1 && pos < objName_s.length()) {
         String typeName_s = objName_s.substring(0, pos);
         Integer objTypeIdx = BGUtils.getStringIdx(typeName_s, SECT_NAMES_SA);
         if (objTypeIdx != -1) {
            return objTypeIdx;
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private Integer getObjIdxFromName (String objName_s)
   {
      if (objName_s == null) return null;
         
      int pos = objName_s.lastIndexOf("_");
      if (pos != -1 && pos < objName_s.length()) {
         try {
            Integer objIdx = Integer.valueOf(objName_s.substring(pos + 1));
            return objIdx;
         }
         catch (Exception e) {
            return null;
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Integer getTypesNum()
   {
      return object_ahm.length;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();
      json_sb.append("{\n\""  + BGObject.OBJECT_CONST + "\": [\n");
      
      //..... For each object ......
      
      for (int j = 0; j < object_ahm.length; j++) {
         if (object_ahm[j] != null) {
            for (PlfObject obj : object_ahm[j].values()) {
               json_sb.append(obj.toJson());
            }
         }
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n]\n}");
      
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   // Return all type names
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getObjTypeNames() 
   {
      return SECT_NAMES_SA;      
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getStaticObjTypeNames() 
   {
      return SECT_NAMES_SA;      
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getNodeObjTypeNames() 
   {
      String[] linkTypes_sa = new String[] {SECT_NAMES_SA[SECT_BUS_IDX]};
      return linkTypes_sa;      
   }
   //----------------------------------------------------------------------------------------------
   // Return all model objects of certain type
   //----------------------------------------------------------------------------------------------

   @Override
   public PlfObject[] getObjects(int typeIdx) 
   {
      try {
         return object_ahm[typeIdx].values().toArray(new PlfObject[0]);
      }
      catch (Exception e) {
         return new PlfObject[0];
      }
   }
   //----------------------------------------------------------------------------------------------
   // Return array of specific type objects
   //----------------------------------------------------------------------------------------------
   
   @Override
   public PlfObject[] getObjects(String typeName_s) 
   {
      try {
         Integer objTypeIdx = getTypeIdxFromType(typeName_s);
         return object_ahm[objTypeIdx].values().toArray(new PlfObject[0]);
      }
      catch (Exception e) {
         return new PlfObject[0];
      }
   }
   //----------------------------------------------------------------------------------------------
   // Return array of specific types objects
   //----------------------------------------------------------------------------------------------
   
   @Override
   public PlfObject[] getLinkObjects() 
   {
      List<PlfObject> objs_al = new ArrayList<PlfObject>(); 
      
      for (int sectIdx = 0; sectIdx < getTypesNum(); sectIdx++) {    
         List<String> attrNames = getAttrNames(sectIdx);
     
         if (attrNames.contains(PlfTypes.FROM_NAME) && attrNames.contains(PlfTypes.TO_NAME)) {
            PlfObject[] objs = getObjects(sectIdx);
            objs_al.addAll(Arrays.asList(objs));           
         }
      }
      return objs_al.toArray(new PlfObject[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getLinkObjTypeNames() 
   {
      List<String> objs_al = new ArrayList<String>(); 
         
      for (int sectIdx = 0; sectIdx < getTypesNum(); sectIdx++) {    
         List<String> attrNames = getAttrNames(sectIdx);
        
         if (attrNames.contains(PlfTypes.FROM_NAME) && attrNames.contains(PlfTypes.TO_NAME)) {
            String objType_s = getObjTypeName(sectIdx);
            objs_al.add(objType_s);           
         }
      }
      return objs_al.toArray(new String[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   // Return all model objects 
   //----------------------------------------------------------------------------------------------

   @Override
   public PlfObject[] getObjects() 
   {
      List<PlfObject> objs = new ArrayList<PlfObject>();
      
      for (int typeIdx = 0; typeIdx < object_ahm.length; typeIdx++) {
         if (object_ahm[typeIdx] != null) {
            objs.addAll(object_ahm[typeIdx].values());
         }
      }
      return objs.toArray(new PlfObject[objs.size()]);
   }
   //----------------------------------------------------------------------------------------------
   // Return all model objects of certain type
   //----------------------------------------------------------------------------------------------

   @Override
   public PlfObject getObject(String name_s) 
   {
      if (name_s == null) return null;
      
      Integer objTypeIdx = getTypeIdxFromName(name_s);
      if (objTypeIdx == null) return null;
      
      Integer objId = getObjIdxFromName(name_s);
      if (objId == null) return null;

      //..... Find object ......
      
      if (objTypeIdx < object_ahm.length && object_ahm[objTypeIdx] != null) {
         return object_ahm[objTypeIdx].get(name_s);
      }
      return null;
   }
}
//======================================= End of Class ============================================
