package org.dspace.app.webui.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.dspace.app.webui.util.BGUtils;

public class DBTable
{
   private static final Logger log = Logger.getLogger(DBTable.class);

   private String   name;
   private DBTable  parentTable;
   
   private DBColumn primaryKey;
   private ArrayList<DBColumn>fkeys = new ArrayList<DBColumn>();

   private Map<Integer, DBColumn> columns = new LinkedHashMap<Integer,DBColumn>();
      
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public DBColumn getPrimaryKey() {
      return primaryKey;
   }
   public void setPrimaryKey(DBColumn primaryKey) {
      this.primaryKey = primaryKey;
   }   
   public ArrayList<DBColumn>getFkeys() {
      return fkeys;
   }
   public void addFkey(String columnName) {
      fkeys.add(getColumnByName(columnName));
   }
   public Map<Integer, DBColumn> getColumns() {
      return columns;
   }
   public void setColumns(Map<Integer, DBColumn> columns) {
      this.columns = columns;
   }
   public DBTable getParentTable() {
      return parentTable;
   }
   public void setParentTable(DBTable parentTable) {
      this.parentTable = parentTable;
   }
   
   public boolean setColumns(String[]  colName_sa,
                             Integer[] colTypes_a)
   {
      if (colName_sa == null || colName_sa.length == 0) {
         log.error("setColumns. 'Column Names' is null or empty");
         return false;
      }
      for (int i = 0; i < colName_sa.length; i++) {
         Integer typeIdx = DBTypes.typeText;
         if (colTypes_a != null && colTypes_a[i] != null) {
            typeIdx = colTypes_a[i];
         }
         DBColumn col = new DBColumn(colName_sa[i], null, typeIdx, i);
         this.addColumn(i, col);        
      }
      return true;
   }
   
   protected DBTable copy()
   {
      final DBTable newTable = new DBTable();
      for (Map.Entry<Integer, DBColumn> entry : this.columns.entrySet()) {
         newTable.columns.put(entry.getKey(), entry.getValue().copy());
      }
      return newTable;
   }
   
   public List<String> getColumnNames()
   {
      List<String> columnNames = new ArrayList<String>();
      for (DBColumn column : columns.values()) {
         columnNames.add(column.getName());
      }
      return columnNames;
   }
      
   public List<Integer> getColumnTypes()
   {
      List<Integer>columnTypes = new ArrayList<Integer>();
      for (DBColumn column : columns.values()) {
         columnTypes.add(column.getTypeIdx());
      }
      return columnTypes;
   }
   
   public void addColumn (int idx, DBColumn column)
   {
      columns.put(idx, column);
   }
   
   public int findColumnIdx(String name_s)
   {
      for (Map.Entry<Integer, DBColumn> entry : columns.entrySet()) {
         int idx = entry.getKey();
         if (columns.get(idx).getName().equalsIgnoreCase(name_s)) {
            return idx;
         }
      }
      return -1;
   }
   
   public boolean deleteColumn(int colIdx)
   {
      if (columns == null) return false;    
      try {
         columns.remove(colIdx);
         return true;
      }
      catch (Exception e) {
         log.error("ERROR.deleteColumn: Column with internal index " + colIdx + "does not exists.");
      }
      return false;
   }
   
   public boolean deleteColumn(String columnName)
   {
      int colIdx = findColumnIdx(columnName);
      if (colIdx >= 0) {
         return deleteColumn(colIdx);
      }
      return false;
   }
   
   public DBColumn getColumn(int idx) 
   {
      return columns.get(idx);
   }
   
   public DBColumn getColumnByName(String columnName) 
   {
      return columns.get(findColumnIdx(columnName));
   }
   
   public DBColumn getColumnByModifiedName(String columnName)     // modified name starts with "_", like "_from" 
   {
      if (columnName.startsWith("_")) {
         columnName = columnName.substring(1);
      }
      return getColumnByName(columnName);
   }

   public int getColumnNum()
   {
      return columns.size();
   }
   
   public int getMaxColumnIndex()
   {
      return Collections.max(columns.keySet());
   }
   
   public boolean isIdenticalTable(DBTable tab) 
   {
      if (tab.getColumnNum() != this.getColumnNum()) return false;

      for (Map.Entry<Integer, DBColumn> entry : this.columns.entrySet()) {
         Integer colIdx = entry.getKey();
         DBColumn col   = entry.getValue();
         
         if (col.isIdenticalColumn(tab.getColumn(colIdx)) == false) return false;
      }
      return true;
   }
}
//======================================= End of Class ============================================
