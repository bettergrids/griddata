package org.dspace.app.webui.model;

import java.sql.*;
import java.util.Properties;
import org.apache.log4j.Logger;

public class DBConnection extends DBProvider  
{
   private static final Logger log = Logger.getLogger(DBConnection.class);
   
   Connection conn = null;
   
   public DBConnection (String db_s)
   {
      super(db_s);
   }
   
   public Connection getConnection() 
   {
      try {
         //Class.forName(getClassName());
         
         Properties props = new Properties();
         props.setProperty("user",     getUser());
         props.setProperty("password", getPwd());
         
         //props.setProperty("ssl","true");
         conn = DriverManager.getConnection(getConnURL(), props);
      }
      catch (SQLException e) {
         log.error("DBConnection.getConnection. Cannot get connection for: URL: " + getConnURL() + 
               "; User: " + getUser() + "; Pass: " + getPwd() + "; " + e.getMessage());
        return null;
      }      
      return conn;  
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean close()
   {
      if (conn != null) {
         try {
            conn.close(); 
            log.info("Close. Connection closed.");
         } 
         catch (SQLException e) {
            log.error("DBConnection.close. Cannot close connection: " + e.getMessage());
            return false;
         }
      }
      return true;
   }
}
//======================================== End of Class ===========================================
