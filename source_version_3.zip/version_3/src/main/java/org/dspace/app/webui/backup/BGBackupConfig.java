package org.dspace.app.webui.backup;

import java.io.File;

import org.apache.log4j.Logger;

public class BGBackupConfig extends BGConfig
{
   private static final Logger log = Logger.getLogger(BGBackupConfig.class);
   
   private static String archiveFolder              = null; //"/home/dspace/backup";  // "C:\\tmp_share";
   private static String dspaceHome                 = null; //"/home/dspace/dspace";  // "C:\\dspace";
   private static String repPrefix                  = null;
   
   protected static final String solrNameConst      = "solr";
   protected static final String statNameConst      = "statistics";
   protected static final String statCSVNameConst   = "statCSV";
   protected static final String assetNameConst     = "assetstore";
   protected static final String configNameConst    = "config";
   protected static final String dspaceAipNameConst = "dspaceAIP";
      
   protected static String dspaceConfigArchive      = "configArchive.zip";
   protected static String dspaceSolrArchive        = "solrStatArchive.zip";
   protected static String dspaceAssetArchive       = "assetArchive.zip";
   protected static String dspaceMetadataArchive    = "metadataArchive.csv";
   
   protected static String aipArchive               = "dspace_full.zip";
   protected static String userEmail                = "admin@bettergrids.org";
   
   private static String dbName                     = null;
   private static String dbUser                     = null;
   private static String dbPass                     = null;
   private static String dbArchive                  = null;
   
   protected static final BGBackupConfig INSTANCE = new BGBackupConfig();

   public static final BGBackupConfig getInstance() 
   {
      getArchiveFolder();
      getDspaceHome();
      getRepPrefix();
      return INSTANCE;
   }
   
   //----------------------------- Commands -------------------------------------------------------
   
   public static String getFullAIPCmd(String email,
                                      String prefix,
                                      String archiveFolder,
                                      String archiveName) 
   {
      return getDspaceBin() + "dspace packager -u -d -a -t AIP -e " + email + " -i " +
             prefix + "/0 " + archiveFolder + File.separator + archiveName;

   }
   //----------------------------------------------------------------------------------------------

   public static String getMetadataExportCmd(String archiveFolder,
                                             String archiveName) 
   {
      return getDspaceBin() + "dspace metadata-export -a -f " + archiveFolder + File.separator + archiveName;
   }
   //----------------------------------------------------------------------------------------------

   public static String getSolrStatExportCmd(String archiveFolder) 
   {
      return getDspaceBin() + "dspace solr-export-statistics -a export -d " + archiveFolder + 
             File.separator + statNameConst + " -i statistics -l 7";
   }
   //----------------------------------------------------------------------------------------------
   
   public static String getFullDBExportCmd(String userName,
                                           String userPass,
                                           String dbName,
                                           String archiveFolder,
                                           String archiveName) 
   {
      return "pg_dump --dbname=postgresql://" + userName + ":" + userPass + 
             "@127.0.0.1:5432/" + dbName + " -v -c --if-exists -f " + archiveFolder + 
             File.separator + archiveName; 
   }
   //----------------------------------------------------------------------------------------------
   
   public static void setArchiveFolder(String archiveFolder) {
      BGBackupConfig.archiveFolder = archiveFolder;
   }
   //----------------------------------------------------------------------------------------------
   
   public static void setDspaceHome(String dspaceHome) {
      BGBackupConfig.dspaceHome = dspaceHome;
   }

   public static String getDspaceConfigFolder() {
      return dspaceHome + File.separator + configNameConst;
   }

   public static String getDspaceSolrFolder() {
      return dspaceHome + File.separator + solrNameConst + File.separator + statNameConst;
   }

   public static String getDspaceAssetFolder() {
      return dspaceHome + File.separator + assetNameConst;
   }

   public static String getDspaceConfigArchive() {
      return dspaceConfigArchive;
   }

   public static void setDspaceConfigArchive(String dspaceConfigArchive) {
      BGBackupConfig.dspaceConfigArchive = dspaceConfigArchive;
   }

   public static String getDspaceSolrArchive() {
      return dspaceSolrArchive;
   }

   public static void setDspaceSolrArchive(String dspaceSolrArchive) {
      BGBackupConfig.dspaceSolrArchive = dspaceSolrArchive;
   }

   public static String getDspaceAssetArchive() {
      return dspaceAssetArchive;
   }

   public static void setDspaceAssetArchive(String dspaceAssetArchive) {
      BGBackupConfig.dspaceAssetArchive = dspaceAssetArchive;
   }

   public static String getDspaceMetadataArchive() {
      return dspaceMetadataArchive;
   }

   public static void setDspaceMetadataArchive(String dspaceMetadataArchive) {
      BGBackupConfig.dspaceMetadataArchive = dspaceMetadataArchive;
   }

   public static void setRepPrefix(String repPrefix) {
      BGBackupConfig.repPrefix = repPrefix;
   }

   public static String getAipArchive() {
      return aipArchive;
   }

   public static void setAipArchive(String aipArchive) {
      BGBackupConfig.aipArchive = aipArchive;
   }

   public static String getUserEmail() {
      return userEmail;
   }

   public static void setUserEmail(String userEmail) {
      BGBackupConfig.userEmail = userEmail;
   }
   //----------------------------------------------------------------------------------------------
   //   Get from bettergrids.cfg configuration file
   //----------------------------------------------------------------------------------------------
   
   public static String getArchiveFolder() 
   {
      if (archiveFolder != null) return archiveFolder;
   
      if (BGSystem._WINDOWS.equalsIgnoreCase(BGSystem.getOSType())) {
         archiveFolder = getBgProperty("bgBackupFolderWindows");
      }
      else if (BGSystem._LINUX.equalsIgnoreCase(BGSystem.getOSType())) {
         archiveFolder = getBgProperty("bgBackupFolderLinux");
      }
      else {
         log.error("Operating system : " + BGSystem.getOSType() + " is not supported");
         return null;
      }
      return archiveFolder;
   }
   //----------------------------------------------------------------------------------------------
   
   public static String getDspaceHome() 
   {
      if (dspaceHome != null) return dspaceHome;
      
      if (BGSystem._WINDOWS.equalsIgnoreCase(BGSystem.getOSType())) {
         dspaceHome = getBgProperty("dspaceHomeWindows");
      }
      else if (BGSystem._LINUX.equalsIgnoreCase(BGSystem.getOSType())) {
         dspaceHome = getBgProperty("dspaceHomeLinux");
      }
      else {
         log.error("Operating system : " + BGSystem.getOSType() + " is not supported");
         return null;
      }
      return dspaceHome;
   }
   //----------------------------------------------------------------------------------------------
   
   private static String getDspaceBin() 
   {
      return getDspaceHome() + File.separator + "bin" + File.separator;
   }
   //----------------------------------------------------------------------------------------------

   public static String getRepPrefix() 
   {
      if (repPrefix != null) return repPrefix;
      repPrefix = getBgProperty("repPrefix");
      return repPrefix;
   }
   //----------------------------------------------------------------------------------------------

   public static String getDbName() 
   {
      if (dbName != null) return dbName;
      dbName = getBgProperty("db.name");
      return dbName;
   }
   //----------------------------------------------------------------------------------------------
   
   public static String getDbUser() 
   {
      if (dbUser != null) return dbUser;
      dbUser = getBgProperty("db.user");
      return dbUser;

   }
   //----------------------------------------------------------------------------------------------

   public static String getDbPass() 
   {
      if (dbPass != null) return dbPass;
      dbPass = getBgProperty("db.password");
      return dbPass;
   }
   //----------------------------------------------------------------------------------------------

   public static String getDbArchive() 
   {
      if (dbArchive != null) return dbArchive;
      dbArchive = getBgProperty("db.archive");
      return dbArchive;
   }
}
//====================================== End of File ==============================================