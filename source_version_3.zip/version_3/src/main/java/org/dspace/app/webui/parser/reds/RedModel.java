package org.dspace.app.webui.parser.reds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBTypes;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;

public class RedModel extends BGModel
{
   private static final Logger log = Logger.getLogger(RedModel.class);
   
   //..... Constants ......
   
   public static final String SRC_BUS_NAME  = "src_bus";
   public static final String REC_BUS_NAME  = "rec_bus";
   public static final String SWITCH_NAME   = "switch";
   
   public static final String FROM_NAME     = "_from";
   public static final String TO_NAME       = "_to";
   public static final String LENGTH_NAME   = "length";
   public static final String NAME_NAME     = "name";
   
   public static final String TYPE_NAME_HEADER       = "header";
   public static final String TYPE_NAME_NODE         = "node";
   public static final String TYPE_NAME_BRANCH       = "branch";
   public static final String TYPE_NAME_TIE_SWITCHES = "tie_switches";
   public static final String TYPE_NAME_GRID_SIZE    = "grid_size";
   
   public static final String[] NODE_TYPE_NAMES = {TYPE_NAME_NODE};                       // 800

   public static final String[] LINK_TYPE_NAMES = {TYPE_NAME_BRANCH,                      // 801
                                                   TYPE_NAME_TIE_SWITCHES};               // 802
   //..... Members ......
   
   //          objType        objName object
   private Map<String, HashMap<String,RedObject>> object_mhm = new LinkedHashMap<String, HashMap<String,RedObject>>();

   private List<String> objTypeNames_al = new ArrayList<String>();
      
   //          objType
   private Map<String, ArrayList<String>>  attrNames_hml = new LinkedHashMap<String, ArrayList<String>>();
   private Map<String, ArrayList<Integer>> attrTypes_hml = new LinkedHashMap<String, ArrayList<Integer>>();

   //..... Methods ......
   
   //----------------------------------------------------------------------------------------------
   // Get object hashmap
   //----------------------------------------------------------------------------------------------
   
   public Map<String, HashMap<String,RedObject>> getObjectsHm()
   {
      return object_mhm;
   }
   //----------------------------------------------------------------------------------------------
   // Get/Add object to specific section
   //----------------------------------------------------------------------------------------------
      
   public List<String> getAttrNames(String objType_s) 
   {      
      if (attrNames_hml != null) {
         return attrNames_hml.get(objType_s);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public List<String> getAttrNames(int typeIdx) 
   {
      try {
         String attrName_s = (String)attrNames_hml.keySet().toArray()[typeIdx];
         return getAttrNames(attrName_s);
      }
      catch (Exception e) {
         log.error("getAttrNames. Cannot find attr.names for type index " + typeIdx);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   // Set attribute names of type specified
   //----------------------------------------------------------------------------------------------
   
   public void setAttrNames(String            objType_s,
                            ArrayList<String> attrNames_al)
   {  
      if (objTypeNames_al.indexOf(objType_s) == -1) {
         objTypeNames_al.add(objType_s);
      }
      attrNames_hml.put(objType_s, attrNames_al);
   }
   //----------------------------------------------------------------------------------------------
   // Add attribute name for object of type specified
   //----------------------------------------------------------------------------------------------
   
   public void addAttrName(String objType_s,
                           String attrName_s)
   {  
      if (objTypeNames_al.indexOf(objType_s) == -1) {
         objTypeNames_al.add(objType_s);
      }
      if (attrNames_hml.get(objType_s) == null) {
         attrNames_hml.put(objType_s, new ArrayList<String>());
      }
      attrNames_hml.get(objType_s).add(attrName_s);
   }
   //----------------------------------------------------------------------------------------------
   // Get index of attribute
   //----------------------------------------------------------------------------------------------
   
   public Integer getAttrIdx(int    typeIdx, 
                             String attrName)
   {
      try {
         return getAttrNames(typeIdx).indexOf(attrName);
      }
      catch(Exception e) {
         log.error("RedModel.getAttrIdx. Cannot find attribute for type index: " + typeIdx + 
                   " and attribute name: " + attrName);
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean addObject(RedObject obj)
   {
      if (obj == null || obj.getName() == null || obj.getType() == null) return false;
   
      String type_s = obj.getType();
      String name_s = obj.getName();
      if (object_mhm.get(type_s) == null) {
         object_mhm.put(type_s, new HashMap<String,RedObject>());
      }
      object_mhm.get(type_s).put(name_s, obj);
      return true;
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public RedObject getObject(String name_s)
   {
      for (HashMap<String,RedObject> obj_hm : object_mhm.values()) {
         if (obj_hm.get(name_s) != null) {
            return obj_hm.get(name_s);
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public RedObject[] getObjects(String objType_s) 
   {
      List<BGObject> values =  new ArrayList<BGObject>(object_mhm.get(objType_s).values());
      return values.toArray(new RedObject[values.size()]);
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public RedObject[] getObjects() 
   {
      List<RedObject>objs_al = new ArrayList<RedObject>();
      for (HashMap<String,RedObject> objs_hm : object_mhm.values()) {
         objs_al.addAll(objs_hm.values());         
      }
      return objs_al.toArray(new RedObject[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public RedObject[] getObjects(int typeIdx) 
   {
      try {
         String objType_s = (String)object_mhm.keySet().toArray()[typeIdx];
         return getObjects(objType_s);
      }
      catch (Exception e) {
         log.error("getObjects. Cannot find objects with type index " + typeIdx);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getObjTypeNames() 
   {
      return objTypeNames_al.toArray(new String[objTypeNames_al.size()]);
   }
   //----------------------------------------------------------------------------------------------

   @Override
   public String[] getStaticObjTypeNames() 
   {
      return ArrayUtils.addAll(NODE_TYPE_NAMES, LINK_TYPE_NAMES);
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String getObjTypeName(int typeIdx) 
   {
      return objTypeNames_al.get(typeIdx);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public Integer getTypesNum() 
   {
      return object_mhm.size();
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean setAttrTypes() 
   {
      boolean res_b = true;
      if (attrTypes_hml.isEmpty()) {
         for (String objType_s : object_mhm.keySet()) {
            res_b &= setAttrTypes(objType_s);
         }
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public List<Integer> getAttrTypes(String objType_s) 
   {
      if (attrTypes_hml.get(objType_s) == null) {
         setAttrTypes(objType_s);
      }
      return attrTypes_hml.get(objType_s);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean setAttrTypes(String objType_s) 
   {
      if (attrTypes_hml.get(objType_s) == null) {
         try {
            HashMap<String,RedObject> objs_hm = object_mhm.get(objType_s);
            for (int i = 0; i < attrNames_hml.get(objType_s).size(); i++) {
            
               if (attrTypes_hml.get(objType_s) == null) {
                  attrTypes_hml.put(objType_s, new ArrayList<Integer>());
               }           
               int typeIdx = DBTypes.typeLong;
               for (RedObject obj : objs_hm.values()) {
                  Object attrValue = obj.valueOfType((String)obj.getAttr(i));
                  if (attrValue == null) continue;
               
                  if (attrValue instanceof Double) {
                     typeIdx = DBTypes.typeDouble;
                     continue;
                  }
                  else if (attrValue instanceof Integer) {
                     continue;
                  }
                  else {
                     typeIdx = DBTypes.typeVarchar;
                     break;
                  }
               }
               attrTypes_hml.get(objType_s).add(typeIdx);
            }
         }
         catch (Exception e) {
            log.error("setAttrTypes. Error in setting of attribute type" + 
                      "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------   

   @Override
   public List<Integer> getAttrTypes(int typeIdx) 
   {
      try {
         if (attrTypes_hml.isEmpty()) {
            setAttrTypes();
         }
         String attrName_s = (String)attrTypes_hml.keySet().toArray()[typeIdx];
         return getAttrTypes(attrName_s);
      }
      catch (Exception e) {
         log.error("getAttrTypes. Cannot find attr.names for type index " + typeIdx);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public String[] getNodeObjTypeNames() 
   {
      return NODE_TYPE_NAMES;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public String[] getLinkObjTypeNames() 
   {
      List<String> objs_al = new ArrayList<String>(); 
      
      for (int sectIdx = 0; sectIdx < getTypesNum(); sectIdx++) {    
         List<String> attrNames = getAttrNames(sectIdx);
        
         if (attrNames.contains(RedModel.FROM_NAME) && attrNames.contains(RedModel.TO_NAME)) {
            String objType_s = getObjTypeName(sectIdx);
            objs_al.add(objType_s);           
         }
      }
      return objs_al.toArray(new String[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public boolean calcTypeCounts() 
   {
      //..... Calculate counts of all types ......
   
      if (typeCounts.isEmpty()) {
         for (Map.Entry <String, HashMap<String,RedObject>> entry : object_mhm.entrySet()) {            
            String  objType_s  = entry.getKey();
            Integer objTypeCnt = entry.getValue().size();
            
            typeCounts.put(objType_s, objTypeCnt);
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();
      json_sb.append("{\n\""  + BGObject.OBJECT_CONST + "\": [\n");
      
      //..... For each object ......
      
      for (HashMap<String,RedObject> objs : object_mhm.values()) {
         if (objs == null) continue; 
      
         for (RedObject obj : objs.values()) {
            json_sb.append(obj.toJson());
         }
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n]\n}");
      
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public BGObject[] getLinkObjects() 
   {
      List<RedObject> objs_al = new ArrayList<RedObject>(); 
      
      for (int sectIdx = 0; sectIdx < getTypesNum(); sectIdx++) {    
         List<String> attrNames = getAttrNames(sectIdx);
     
         if (attrNames.contains(RedModel.FROM_NAME) && attrNames.contains(RedModel.TO_NAME)) {
            RedObject[] objs = getObjects(sectIdx);
            objs_al.addAll(Arrays.asList(objs));           
         }
      }
      return objs_al.toArray(new RedObject[objs_al.size()]);
   }
}
//======================================= End of Class ============================================

