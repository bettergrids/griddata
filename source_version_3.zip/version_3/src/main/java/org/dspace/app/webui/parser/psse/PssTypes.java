package org.dspace.app.webui.parser.psse;

import java.sql.Types;

public interface PssTypes {

   //------------------------------------- List of sections ---------------------------------------
   
   //  0. Header
   //  1. Comments (2 lines)
   //  2. Bus
   //  3. Load
   //  4. Fixed Shunt
   //  5. Generator
   //  6. Branch
   //  7. Transformer 3-winding
   //  8. Transformer 2-winding
   //  9. Area interchange                       PSSEInterAreaTransfer
   // 10. Two-terminal DC transmission line
   // 11. Voltage source converter               PSSEVSCHVDC2T
   // 12. Switched Shunt
   // 13. Impedance correction                   PSSEXfrZTable
   // 14. Multi-terminal DC
   // 15. Multi-section line
   // 16. Zone
   // 17. Inter-area transfer data
   // 18. Owner
   // 19. Facts Control Device
   // 20. GNE Device
   // 21. Ind Motor
   
   //----------------------------------------- Sections -------------------------------------------
   
   public static final int SECT_HEADER_IDX    = 0;
   public static final int SECT_COMMENTS_IDX  = 1;
   public static final int SECT_BUS_IDX       = 2;
   public static final int SECT_LOAD_IDX      = 3;
   public static final int SECT_FIX_SHUNT_IDX = 4;
   public static final int SECT_GEN_IDX       = 5;
   public static final int SECT_BRANCH_IDX    = 6;
   public static final int SECT_TRANS3_IDX    = 7;
   public static final int SECT_TRANS2_IDX    = 8;
   public static final int SECT_AREA_IDX      = 9;
   public static final int SECT_DC2_IDX       = 10;
   public static final int SECT_VSC_IDX       = 11;
   public static final int SECT_SW_SHUNT_IDX  = 12;
   public static final int SECT_TICT_IDX      = 13;
   public static final int SECT_MTDC_IDX      = 14;
   public static final int SECT_MSLD_IDX      = 15;
   public static final int SECT_ZONE_IDX      = 16;
   public static final int SECT_IATD_IDX      = 17;
   public static final int SECT_OWNER_IDX     = 18;
   public static final int SECT_FACTS_IDX     = 19;
   public static final int SECT_GNE_IDX       = 20;
   public static final int SECT_INDUCT_IDX    = 21;
   
   // We mention "transformer" here and below twice, because of having
   // two variants of this section: 2-winding transformers and 
   // 3-winding transformers
   
   public static final String[] SECT_NAMES_SA = {"header", "comments", "bus", "load", "fixed_shunt",
                                                 "generator", "branch", "transformer_3_wind", "transformer_2_wind", 
                                                 "area", "two_term_DC", "voltage_src_converter", "switch_shunt", "imp_correction", 
                                                 "multi_term_DC", "multi_section_line", "zone", "inter_area", 
                                                 "owner", "facts", "gne_device", "induction"}; 
 
   //..... Section information from comments ......

   public static final String[] BUS_COMMENT_SA       = {"BUS"};
   public static final String[] LOAD_COMMENT_SA      = {"LOAD"};
   public static final String[] FIX_SHUNT_COMMENT_SA = {"FIXED SHUNT"};
   public static final String[] GEN_COMMENT_SA       = {"GENERATOR"};
   public static final String[] BRANCH_COMMENT_SA    = {"BRANCH"};
   public static final String[] TRANS_COMMENT_SA     = {"TRANSFORMER"};
   public static final String[] AREA_COMMENT_SA      = {"AREA"};
   public static final String[] DC2_COMMENT_SA       = {"TWO-TERMINAL"};
   public static final String[] VSC_COMMENT_SA       = {"VOLTAGE SOURCE CONVERTER", "VSC DC LINE"};
   public static final String[] SW_SHUNT_COMMENT_SA  = {"SWITCHED SHUNT"};
   public static final String[] TICT_COMMENT_SA      = {"IMPEDANCE CORRECTION", "CORR"};
   public static final String[] MTDC_COMMENT_SA      = {"MULTI-TERMINAL"};
   public static final String[] MSLD_COMMENT_SA      = {"MULTI-SECTION LINE"};
   public static final String[] ZONE_COMMENT_SA      = {"ZONE"};
   public static final String[] IATD_COMMENT_SA      = {"INTER-AREA", "INTERAREA"};
   public static final String[] OWNER_COMMENT_SA     = {"OWNER"};
   public static final String[] FACTS_COMMENT_SA     = {"FACTS CONTROL DEVICE"};
   public static final String[] GNE_COMMENT_SA       = {"GNE DEVICE"};
   public static final String[] INDUCT_COMMENT_SA    = {"INDUCTION MACHINE"};
   
   
   public static final String[][] SECT_COMMENTS_SAA  = {null, null, BUS_COMMENT_SA, LOAD_COMMENT_SA, 
                                                        FIX_SHUNT_COMMENT_SA, GEN_COMMENT_SA, BRANCH_COMMENT_SA,
                                                        TRANS_COMMENT_SA, TRANS_COMMENT_SA, AREA_COMMENT_SA, 
                                                        DC2_COMMENT_SA, VSC_COMMENT_SA, SW_SHUNT_COMMENT_SA, 
                                                        TICT_COMMENT_SA, MTDC_COMMENT_SA, MSLD_COMMENT_SA, 
                                                        ZONE_COMMENT_SA, IATD_COMMENT_SA, OWNER_COMMENT_SA, 
                                                        FACTS_COMMENT_SA, GNE_COMMENT_SA, INDUCT_COMMENT_SA};

   public static final String BEGIN_NAME = "BEGIN";
   
   //..... 0. Case Identification (up to three lines) .............................................
   //
   // Line 1:
   //  0.1. Indicator IC Change code: 
   //          0 - base case (default) (i.e., clear the working case before adding data to it)
   //          1 - add data to the working case
   //
   //  0.2. SBASE System base MVA. SBASE = 100.0 by default. 
   //       In some files, SBASE is followed by a comment with the 
   //       REV number such as: "/ PSS/E-29.0" or "/ PSS(tm)E-30 RAW"
   //  0.3. Version of the format
   //  0.4. "XFRRAT" 
   //  0.5. "NXFRAT"
   //  0.6. "BASFRQ"  - base frequency.
   //   
   // Line 2:
   // 0.7. "Comment1"
   // Line 3:
   // 0.6. "Comment2" 
   
   public static final int HEADER_ATTR_VERSION_IDX    = 2;
   public static final String[] HEADER_ATTR_NAMES_SA  = {"IC", "SBASE", "Version", "XFRRAT", 
                                                         "NXFRAT", "BASFRQ"};
   
   public static final Object[] HEADER_ATTR_DEFS_OA   = {null, null, null, null, null, null};
   
   public static final Integer[] HEADER_ATTR_TYPES_A  = {Types.INTEGER, Types.DOUBLE, Types.VARCHAR, 
                                                         Types.INTEGER, Types.INTEGER,Types.DOUBLE};
   
   //..... 1. Comments (2 lines) ..................................................................
   
   public static final String[] COMMENT_ATTR_NAMES_SA  = {"comment_1", "comment_2"};
   public static final Object[] COMMENT_ATTR_DEFS_OA   = {null, null};
   public static final Integer[] COMMENT_ATTR_TYPES_A  = {Types.VARCHAR, Types.VARCHAR};

   
   //..... 2. Bus section .........................................................................
   
   // Format V29, V30:
   // Idx,  'Name',  BASKV, IDE,  GL, BL, AREA, ZONE,         VM, VA,  OWNER 
   //
   // Format V31, V32:  
   // Idx,  'Name',  BASKV, IDE,          AREA, ZONE, OWNER,  VM, VA 
   // 
   // Format V33: 
   // Idx,  'Name',  BASKV, IDE,          AREA, ZONE, OWNER,  VM, VA, NVHI, NVLO, EVHI, EVLO 
     
   // IDE Bus type code:
   // 1 - load bus or other bus without any generator boundary condition.
   // 2 - generator or plant bus either regulating voltage or with a fixed reactive power
   //     (Mvar). A generator that reaches its reactive power limit will no longer control voltage
   //      but rather hold reactive power at its limit.
   // 3 - swing bus or slack bus. It has no power or reactive limits and regulates voltage
   //     at a fixed reference angle.
   // 4 - disconnected or isolated bus.
   //     IDE = 1 by default.

   //   NVHI Normal voltage magnitude high limit; entered in pu.     NVHI=1.1 by default  
   //   NVLO Normal voltage magnitude low limit, entered in pu.      NVLO=0.9 by default  
   //   EVHI Emergency voltage magnitude high limit; entered in pu.  EVHI=1.1 by default  
   //   EVLO Emergency voltage magnitude low limit; entered in pu.   EVLO=0.9 by default 
   
   public static final String OWNER_NAME = "owner";
   public static final String GL_NAME    = "GL";
   public static final String BL_NAME    = "BL";
   public static final String NVHI_NAME  = "NVHI";
   public static final String NVLO_NAME  = "NVLO";
   public static final String EVHI_NAME  = "EVHI";
   public static final String EVLO_NAME  = "EVLO";
   public static final String BUS_NAME   = "bus";
   
   public static final String[] BUS_ATTR_NAMES_SA = {BUS_NAME, "bus_name", "bus_Kv", "IDE", 
                                                     GL_NAME, BL_NAME, 
                                                     "area", "zone", OWNER_NAME, "VM", "VA",
                                                     NVHI_NAME, NVLO_NAME, EVHI_NAME, EVLO_NAME};
   public static final Object[] BUS_ATTR_DEFS_OA  = {null, "            ", 0.0, 1, 0.0, 0.0,
                                                     1, 1, 1, 1.0, 0.0, 1.1, 0.9, 1.1, 0.9};
   
   public static final Integer[] BUS_ATTR_TYPES_A = {Types.VARCHAR, Types.VARCHAR, Types.DOUBLE,
                                                     Types.INTEGER, Types.DOUBLE,  Types.DOUBLE,
                                                     Types.VARCHAR, Types.VARCHAR, 
                                                     Types.VARCHAR, Types.DOUBLE,  Types.DOUBLE,  
                                                     Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE};
   public static final int BUS_MIN_NUMBER = 1;
   public static final int BUS_MAX_NUMBER = 999997;
   
   //..... 3. Load section .........................................................................
   
   // Format V29, V30
   // I, ID, STATUS, AREA, ZONE, PL, QL, IP, IQ, YP, YQ, OWNER 
   //
   // Format V32 
   // I, ID, STATUS, AREA, ZONE, PL, QL, IP, IQ, YP, YQ, OWNER, SCALE 
   // 
   // Format V33 
   // I, ID, STATUS, AREA, ZONE, PL, QL, IP, IQ, YP, YQ, OWNER, SCALE, INTRPT 
   
   public static final String SCALE_NAME  = "scale";
   public static final String INTRPT_NAME = "intrpt";
   
   public static final String[] LOAD_ATTR_NAMES_SA = {BUS_NAME, "ID", "status", "area", "zone", "PL",
                                                      "QL", "IP", "IQ", "YP", "YQ",
                                                      OWNER_NAME, SCALE_NAME, INTRPT_NAME};
         
   public static final Object[] LOAD_ATTR_DEFS_OA  = {null, "1", 1, null, null, 0.0, 0.0, 0.0, 
                                                      0.0, 0.0, 0.0, 1, 1, 0};

   public static final Integer[] LOAD_ATTR_TYPES_A = {Types.VARCHAR, Types.VARCHAR, Types.INTEGER, 
                                                      Types.VARCHAR, Types.VARCHAR, Types.DOUBLE,  
                                                      Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  
                                                      Types.DOUBLE,  Types.DOUBLE,  
                                                      Types.VARCHAR, Types.INTEGER, Types.INTEGER};
   
   //..... 4. Fixed shunt data ..........................................................................
   
   // Format V32, V33
   // I, ID, STATUS, GL, BL
   //
   // sample : 1089, '1 ', 0, 0.000, 36.000 
   // STATUS : 1 in service, 0 out of service 
   
   public static final String[]  FIX_SHUNT_ATTR_NAMES_SA = {BUS_NAME, "ID", "status", "GL", "BL"};

   public static final Object[]  FIX_SHUNT_ATTR_DEFS_OA  = {null, "1", 1, 0.0, 0.0}; 

   public static final Integer[] FIX_SHUNT_ATTR_TYPES_A  = {Types.VARCHAR, Types.VARCHAR, Types.INTEGER, 
                                                            Types.DOUBLE,  Types.DOUBLE}; 

   //..... 5. Generator section ...................................................................

   // Format V29, V30
   //  I, ID, PG, QG, QT, QB, VS, IREG,MBASE, ZR,ZX,RT,XT, GTAP, STAT,RMPCT, PT,PB, O1,F1,...,O4,F4 
   //
   // Format V32, V33 
   //  I, ID, PG, QG, QT, QB, VS, IREG,MBASE, ZR,ZX,RT,XT, GTAP, STAT,RMPCT, PT,PB, O1,F1,...,O4,F4, 
   //  WMOD, WPF 
  
   // WMOD Wind machine control mode; WMOD is used to indicate whether a machine is a wind machine, 
   // and, if it is, the type of reactive power limits to be imposed. 
   // 0 for a machine that is not a wind machine. 
   // 1 for a wind machine for which reactive power limits are specified  by QT and QB. 
   // 2 for a wind machine for which reactive power limits are determined from  the machines active power 
   //   output and WPF; limits are of equal  magnitude and opposite sign 
   // 3 for a wind machine with a fixed reactive power setting determined from  the machines active power 
   //   output and WPF; when WPF is positive,the machines reactive power has the same sign as its active power;  
   //   when WPF is negative, the machines reactive power has the opposite sign of its active power. 
   //   WMOD = 0 by default.  
     
   // WPF Power factor used in calculating reactive power limits or output when WMOD is 2 or 3. 
   // WPF = 1.0 by default.    
  
   // Oi, Fi - Owner number, fraction of total ownership (up to 4 pairs).
   //          Default: O1 = bus owner; others = 0; all Fi = 1.0
   // MBASE = system BASE (SBASE) by default
   // RT, XT - Step-up transformer impedance; complex number: RT + jXT
   
   public static final String WMOD_NAME = "WMOD";
   public static final String WPF_NAME  = "WPF";
   
   public static final String[] GEN_ATTR_NAMES_SA = {BUS_NAME, "ID", "PG", "QG", "QT", "QB", "VS", 
                                                     "IREG", "MBASE", "ZR", "ZX", "RT", "XT", 
                                                     "GTAP", "STAT", "RMPCT", "PT", "PB", 
                                                     "O1","F1", "O2","F2", "O3","F3", "O4","F4",
                                                     WMOD_NAME, WPF_NAME};
         
   public static final Object[] GEN_ATTR_DEFS_OA  = {null, "1", 0.0, 0.0, 9999.0, -9999.0, 1.0,
                                                     0, null, 0.0, 1.0, 0.0, 0.0, 
                                                     1.0, 1, 100.0, 9999.0, -9999.0, 
                                                     null, 1.0, 0, 1.0, 0, 1.0, 0, 1.0,
                                                     0, 1.0};
         
   public static final Integer[] GEN_ATTR_TYPES_A = {Types.VARCHAR, Types.VARCHAR, Types.DOUBLE,  Types.DOUBLE,
                                                     Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.INTEGER, 
                                                     Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  
                                                     Types.DOUBLE,  Types.DOUBLE,  Types.INTEGER, Types.DOUBLE,
                                                     Types.DOUBLE,  Types.DOUBLE,
                                                     Types.VARCHAR, Types.DOUBLE,  Types.VARCHAR, Types.DOUBLE,
                                                     Types.VARCHAR, Types.DOUBLE,  Types.VARCHAR, Types.DOUBLE, 
                                                     Types.INTEGER, Types.DOUBLE};

   //..... 6. Branch section ......................................................................
   
   // Format V26
   // I, J, CKT, R,X,B, RATEA,RATEB,RATEC, RATIO,ANGLE, GI,BI,GJ,BJ,ST,     LEN,O1,F1,...,O4,F4 
   //
   // Format V29, V30 
   //  I, J, CKT, R,X,B, RATEA,RATEB,RATEC,             GI,BI,GJ,BJ,ST,      LEN,O1,F1,...,O4,F4 
   //   
   // Format V31, V32, V33 
   //  I, J, CKT, R,X,B, RATEA,RATEB,RATEC,             GI,BI,GJ,BJ,ST, MET, LEN,O1,F1,...,O4,F4  
   //   
   // MET Metered end flag; 
   //     <=1 to designate bus I as the metered end 
   //     >=2 to designate bus J as the metered end. 
   //  MET = 1 by default. 
   
   public static final String RATIO_NAME  = "RATIO";
   public static final String ANGLE_NAME  = "ANGLE";
   public static final String MET_NAME    = "MET";
   public static final String FROM_NAME   = "_from";
   public static final String TO_NAME     = "_to";
   public static final String LENGTH_NAME = "length";
   
   public static final String[] BRANCH_ATTR_NAMES_SA = {FROM_NAME, TO_NAME, "CKT", "R","X","B", "RATEA","RATEB","RATEC", 
                                                        RATIO_NAME, ANGLE_NAME, 
                                                        "GI","BI","GJ","BJ","ST", MET_NAME, LENGTH_NAME,
                                                        "O1","F1", "O2","F2", "O3","F3", "O4","F4"}; 
   
   public static final Object[] BRANCH_ATTR_DEFS_OA  = {null, null, "1", null, null, 0.0, 0.0, 0.0, 0.0, 
                                                        0.0,  0.0,  0.0, 0.0, 0.0, 0.0, 1, 1, 0.0, 
                                                        null, 1.0, 0, 1.0, 0, 1.0, 0, 1.0};
         
   public static final Integer[] BRANCH_ATTR_TYPES_A = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DOUBLE,  
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE, 
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE, 
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.INTEGER, 
                                                        Types.INTEGER, Types.DOUBLE,
                                                        Types.VARCHAR, Types.DOUBLE,  Types.VARCHAR, Types.DOUBLE,
                                                        Types.VARCHAR, Types.DOUBLE,  Types.VARCHAR, Types.DOUBLE};
      
   //..... 7. Transformer section (3-winding) .....................................................
    
   // Format V29: 
   //
   // 3-winding transformer: 
   // Line-1:  I, J, K, CKT, CW,CZ,CM, MAG1, MAG2, NMETR, NAME, STAT,O1,F1,...,O4,F4 
   // Line-2:  R1-2, X1-2, SBASE1-2, R2-3,X2-3, SBASE2-3, R3-1,X3-1, SBASE3-1, VMSTAR, ANSTAR 
   // Line-3:  WINDV1, NOMV1, ANG1, RATA1,RATB1,RATC1, COD, CONT,RMA, RMI, VMA, VMI, NTP,TAB,CR,CX 
   // Line-4:  WINDV2, NOMV2, ANG2, RATA2,RATB2,RATC2  
   // Line-5   WINDV3, NOMV3, ANG3, RATA3,RATB3,RATC3   
   
   // Format V30: 
   // 
   // 3-winding transformer:
   // Line-1:  I, J, K, CKT, CW,CZ,CM, MAG1, MAG2, NMETR, NAME, STAT,O1,F1,...,O4,F4 
   // Line-2:  R1-2, X1-2, SBASE1-2, R2-3,X2-3, SBASE2-3, R3-1,X3-1, SBASE3-1, VMSTAR, ANSTAR 
   // Line-3:  WINDV1, NOMV1, ANG1, RATA1,RATB1,RATC1, COD,  CONT, RMA, RMI, VMA, VMI,  NTP, TAB, CR, CX 
   // Line-4:  WINDV2, NOMV2, ANG2, RATA2,RATB2,RATC2, COD2, CONT2,RMA2,RMI2,VMA2,VMI2, NTP2,TAB2,CR2,CX2 
   // Line-5:  WINDV3, NOMV3, ANG3, RATA3,RATB3,RATC3, COD3, CONT3,RMA3,RMI3,VMA3,VMI3, NTP3,TAB3,CR3,CX3 
   //
  
   // Format V32:
   //
   // 3-winding transformer:
   // Line-1:  I, J, K, CKT, CW,CZ,CM, MAG1, MAG2, NMETR, NAME, STAT,O1,F1,...,O4,F4 
   // Line-2:  R1-2, X1-2, SBASE1-2, R2-3,X2-3, SBASE2-3, R3-1,X3-1, SBASE3-1, VMSTAR, ANSTAR 
   // Line-3:  WINDV1, NOMV1, ANG1, RATA1,RATB1,RATC1, COD1, CONT1,RMA1,RMI1,VMA1,VMI1, NTP1,TAB1,CR1,CX1 
   // Line-4:  WINDV2, NOMV2, ANG2, RATA2,RATB2,RATC2, COD2, CONT2,RMA2,RMI2,VMA2,VMI2, NTP2,TAB2,CR2,CX2 
   // Line-5:  WINDV3, NOMV3, ANG3, RATA3,RATB3,RATC3, COD3, CONT3,RMA3,RMI3,VMA3,VMI3, NTP3,TAB3,CR3,CX3 
   
   // Format V30 and V32, data structure is the same, only renamed some of the fields, 
   // for example COD -> COD1 
         
   // Format V33 
   //
   // 3-winding transformer:
   // Line-1:  I, J, K, CKT, CW,CZ,CM, MAG1, MAG2, NMETR, NAME, STAT,O1,F1,...,O4,F4, VECGRP 
   // Line-2:  R1-2, X1-2, SBASE1-2, R2-3,X2-3, SBASE2-3, R3-1,X3-1, SBASE3-1, VMSTAR, ANSTAR 
   // Line-3:  WINDV1,  NOMV1,  ANG1, RATA1,RATB1,RATC1,  COD1, CONT1,RMA1,RMI1,VMA1,VMI1, NTP1,TAB1,CR1,CX1 
   // Line-4:  WINDV2,  NOMV2,  ANG2, RATA2,RATB2,RATC2,  COD2, CONT2,RMA2,RMI2,VMA2,VMI2, NTP2,TAB2,CR2,CX2 
   // Line-5:  WINDV3,  NOMV3,  ANG3, RATA3,RATB3,RATC3,  COD3, CONT3,RMA3,RMI3,VMA3,VMI3, NTP3,TAB3,CR3,CX3 
       
   // Format V33.7
   //
   // 3-winding transformer:
   // Line-1:  I, J, K, CKT, CW,CZ,CM, MAG1, MAG2, NMETR, NAME, STAT,O1,F1,...,O4,F4, VECGRP 
   // Line-2:  R1-2, X1-2, SBASE1-2, R2-3,X2-3, SBASE2-3, R3-1,X3-1, SBASE3-1, VMSTAR, ANSTAR 
   // Line-3:  WINDV1,  NOMV1,  ANG1, RATA1,RATB1,RATC1,  COD1, CONT1,RMA1,RMI1,VMA1,VMI1, NTP1,TAB1,CR1,CX1, attr_3_17, 
   // Line-4:  WINDV2,  NOMV2,  ANG2, RATA2,RATB2,RATC2,  COD2, CONT2,RMA2,RMI2,VMA2,VMI2, NTP2,TAB2,CR2,CX2, attr_4_17,
   // Line-5:  WINDV3,  NOMV3,  ANG3, RATA3,RATB3,RATC3,  COD3, CONT3,RMA3,RMI3,VMA3,VMI3, NTP3,TAB3,CR3,CX3, attr_5_17, 
   
   // VECGRP Alphanumeric identifier specifying vector group based on transformer 
   // winding connections and phase angles.  
   // VECGRP value is used for information purpose only.  VECGRP is 12 blanks by default. 

   //..... Transformer Line 1 ......
   
   public static final String K_BUS_NAME  = "K_Bus";
   public static final int    K_BUS_IDX   = 2; 
   public static final String VECGRP_NAME = "VECGRP";
   
   public static final String ATTR_317_NAME = "attr_3_17";
   public static final String ATTR_417_NAME = "attr_4_17";
   public static final String ATTR_517_NAME = "attr_5_17";
   
   public static final int W3_33_START_IDX = 24;   // for v.33
   public static final int W3_START_IDX    = 31;   // for < v.33
   
   public static final int W3_33_LAST_IDX = 24;    // for v.33
   public static final int W3_LAST_IDX    = 30;    // for < v.33
   
   public static final String[] TR3_L1_ATTR_NAMES_SA = {FROM_NAME, TO_NAME, K_BUS_NAME, "CKT", "CW", "CZ", "CM", 
                                                        "MAG1", "MAG2", "NMETR", "NAME", "STAT",
                                                        "O1","F1", "O2","F2", "O3","F3", "O4","F4",
                                                        VECGRP_NAME};
   
   public static final Object[] TR3_L1_ATTR_DEFS_OA  = {null, null, 0, "1", 1, 1, 1, 0.0, 0.0, 2, "            ",
                                                        1, null, 1.0, 0, 1.0, 0, 1.0, 0, 1.0,
                                                        "            "}; 

   public static final Integer[] TR3_L1_ATTR_TYPES_A = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                                                        Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.DOUBLE,  
                                                        Types.DOUBLE,  Types.INTEGER, Types.VARCHAR, Types.INTEGER, 
                                                        Types.VARCHAR, Types.DOUBLE,  Types.VARCHAR, Types.DOUBLE,
                                                        Types.VARCHAR, Types.DOUBLE,  Types.VARCHAR, Types.DOUBLE,
                                                        Types.VARCHAR};   
   //..... Transformer Line 2 ......
  
   public static final String[] TR3_L2_ATTR_NAMES_SA = {"R1_2", "X1_2", "SBASE1_2", "R2_3", "X2_3",
                                                        "SBASE2_3", "R3_1", "X3_1", "SBASE3_1", "VMSTAR",
                                                        "ANSTAR"};   
         
   public static final Object[] TR3_L2_ATTR_DEFS_OA  = {0.0, null, null, 0.0, null, null, 0.0, null, null,
                                                        1.0, 0.0}; 

   
   public static final Integer[] TR3_L2_ATTR_TYPES_A = {Types.DOUBLE,Types.DOUBLE,Types.DOUBLE,Types.DOUBLE,
                                                        Types.DOUBLE,Types.DOUBLE,Types.DOUBLE,Types.DOUBLE,
                                                        Types.DOUBLE,Types.DOUBLE,Types.DOUBLE};
   //..... Transformer Line 3 ......  
  
   public static final String[] TR3_L3_ATTR_NAMES_SA = {"WINDV1", "NOMV1", "ANG1", "RATA1", "RATB1", 
                                                        "RATC1", "COD", "CONT", "RMA", "RMI", "VMA", "VMI",
                                                        "NTP", "TAB1", "CR", "CX", ATTR_317_NAME};           

   public static final Object[] TR3_L3_ATTR_DEFS_OA  = {null, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0, 
                                                        1.1, 0.9, 1.1, 0.9, 33, 0, 0.0, 0.0, 0.0};
         
   public static final Integer[] TR3_L3_ATTR_TYPES_A = {Types.DOUBLE,  Types.DOUBLE, Types.DOUBLE,
                                                        Types.DOUBLE,  Types.DOUBLE, Types.DOUBLE,
                                                        Types.INTEGER, Types.VARCHAR,
                                                        Types.DOUBLE,  Types.DOUBLE, Types.DOUBLE, Types.DOUBLE,
                                                        Types.INTEGER, Types.INTEGER, Types.DOUBLE, Types.DOUBLE,
                                                        Types.DOUBLE};
   //..... Transformer Line 4 ......  
   
   public static final String[] TR3_L4_ATTR_NAMES_SA = {"WINDV2", "NOMV2", "ANG2", "RATA2", "RATB2", "RATC2",    
                                                        "COD2", "CONT2", "RMA2", "RMI2", "VMA2", "VMI2", "NTP2",
                                                        "TAB2", "CR2", "CX2", ATTR_417_NAME};
   
   public static final Object[] TR3_L4_ATTR_DEFS_OA  = {null, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0, 
                                                        1.1, 0.9, 1.1, 0.9, 33, 0, 0.0, 0.0, 0.0};
   
   
   public static final Integer[] TR3_L4_ATTR_TYPES_A = {Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.INTEGER, Types.VARCHAR,
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,
                                                        Types.INTEGER, Types.INTEGER, Types.DOUBLE,  Types.DOUBLE, 
                                                        Types.DOUBLE};   
   //..... Transformer Line 5 ......  
   
   public static final String[] TR3_L5_ATTR_NAMES_SA = {"WINDV3", "NOMV3", "ANG3", "RATA3", "RATB3", "RATC3",    
                                                        "COD3", "CONT3", "RMA3", "RMI3", "VMA3", "VMI3", "NTP3",
                                                        "TAB3", "CR3", "CX3", ATTR_517_NAME};

   public static final Object[] TR3_L5_ATTR_DEFS_OA  = {null, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0,
                                                        1.1, 0.9, 1.1, 0.9, 33, 0, 0.0, 0.0, 0.0};

   public static final Integer[] TR3_L5_ATTR_TYPES_A = {Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE, 
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.INTEGER, Types.VARCHAR,
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,
                                                        Types.INTEGER, Types.INTEGER, Types.DOUBLE,  Types.DOUBLE,
                                                        Types.DOUBLE};
 
   //..... Common arrays for 3-winding transformers ......   
   
   public static final String[][] TR3_ATTR_NAMES_SAA = {TR3_L1_ATTR_NAMES_SA, TR3_L2_ATTR_NAMES_SA, TR3_L3_ATTR_NAMES_SA,
                                                        TR3_L4_ATTR_NAMES_SA, TR3_L5_ATTR_NAMES_SA};

   public static final Object[][] TR3_ATTR_DEFS_OAA  = {TR3_L1_ATTR_DEFS_OA, TR3_L2_ATTR_DEFS_OA, TR3_L3_ATTR_DEFS_OA,
                                                        TR3_L4_ATTR_DEFS_OA, TR3_L5_ATTR_DEFS_OA};

   public static final Integer[][] TR3_ATTR_TYPES_AA = {TR3_L1_ATTR_TYPES_A, TR3_L2_ATTR_TYPES_A, TR3_L3_ATTR_TYPES_A,
                                                        TR3_L4_ATTR_TYPES_A, TR3_L5_ATTR_TYPES_A};

   //..... 8. Transformer section (2-winding) .....................................................
   
   // Format V29:
   //
   // 2-winding transformer:
   // Line-1:  I, J, K, CKT, CW,CZ,CM, MAG1, MAG2, NMETR, NAME, STAT,O1,F1,...,O4,F4 
   // Line-2:  R1-2, X1-2, SBASE1-2 
   // Line-3:  WINDV1, NOMV1, ANG1, RATA1,RATB1,RATC1, COD,  CONT,RMA, RMI, VMA, VMI, NTP,TAB,CR,CX 
   // Line-4:  WINDV2, NOMV2 
   
   // Format V30:
   //
   // 2-winding transformer:
   // Line-1:  I, J, K, CKT, CW,CZ,CM, MAG1, MAG2, NMETR, NAME, STAT,O1,F1,...,O4,F4 
   // Line-2:  R1-2, X1-2, SBASE1-2 
   // Line-3:  WINDV1, NOMV1, ANG1, RATA1,RATB1,RATC1, COD, CONT,RMA, RMI, VMA, VMI, NTP,TAB,CR,CX 
   // Line-4:  WINDV2, NOMV2 
  
   // Format V32:
   //
   // 2-winding transformer:
   // Line-1:  I, J, K, CKT, CW,CZ,CM, MAG1, MAG2, NMETR, NAME, STAT,O1,F1,...,O4,F4 
   // Line-2:  R1-2, X1-2, SBASE1-2 
   // Line-3:  WINDV1, NOMV1, ANG1, RATA1,RATB1,RATC1, COD1, CONT1,RMA1,RMI1,VMA1, VMI1, NTP1,TAB1,CR1,CX1 
   // Line-4:  WINDV2, NOMV2 
   
   // Format V30 and V32, data structure is the same, only renamed some of the fields, 
   // for example COD -> COD1 
         
   // Format V33
   //
   // 2-winding transformer:
   // Line-1:  I, J, K, CKT, CW,CZ,CM, MAG1, MAG2, NMETR, NAME, STAT,O1,F1,...,O4,F4, VECGRP 
   // Line-2:  R1-2, X1-2, SBASE1-2 
   // Line-3:  WINDV1,  NOMV1,  ANG1, RATA1,RATB1,RATC1,  COD1, CONT1,RMA1,RMI1,VMA1, VMI1,  NTP1,TAB1,CR1,CX1 
   // Line-4:  WINDV2,  NOMV2 
         
   // Format V33.7
   //
   // 2-winding transformer:
   // Line-1:  I, J, K, CKT, CW,CZ,CM, MAG1, MAG2, NMETR, NAME, STAT,O1,F1,...,O4,F4, VECGRP 
   // Line-2:  R1-2, X1-2, SBASE1-2 
   // Line-3:  WINDV1,  NOMV1,  ANG1, RATA1,RATB1,RATC1,  COD1, CONT1,RMA1,RMI1,VMA1, VMI1,  NTP1,TAB1,CR1,CX1, attr_3_17 
   // Line-4:  WINDV2,  NOMV2
   
   // VECGRP Alphanumeric identifier specifying vector group based on transformer 
   // winding connections and phase angles.  
   // VECGRP value is used for information purpose only.  VECGRP is 12 blanks by default. 

   //..... Transformer Line 1 ......
      
   public static final String[] TR2_L1_ATTR_NAMES_SA = {FROM_NAME, TO_NAME, K_BUS_NAME, "CKT", "CW", "CZ", "CM", 
                                                        "MAG1", "MAG2", "NMETR", "NAME", "STAT",
                                                        "O1","F1", "O2","F2", "O3","F3", "O4","F4",
                                                        VECGRP_NAME};
   
   public static final Object[] TR2_L1_ATTR_DEFS_OA  = {null, null, 0, "1", 1, 1, 1, 0.0, 0.0, 2, "            ",
                                                        1, null, 1.0, 0, 1.0, 0, 1.0, 0, 1.0,
                                                        "            "}; 

   public static final Integer[] TR2_L1_ATTR_TYPES_A = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                                                        Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.DOUBLE,  
                                                        Types.DOUBLE,  Types.INTEGER, Types.VARCHAR, Types.INTEGER, 
                                                        Types.VARCHAR, Types.DOUBLE,  Types.VARCHAR, Types.DOUBLE,
                                                        Types.VARCHAR, Types.DOUBLE,  Types.VARCHAR, Types.DOUBLE,
                                                        Types.VARCHAR};   
   //..... Transformer Line 2 ......
  
   public static final String[] TR2_L2_ATTR_NAMES_SA = {"R1_2", "X1_2", "SBASE1_2"};   
         
   public static final Object[] TR2_L2_ATTR_DEFS_OA  = {0.0, null, null}; 

   public static final Integer[] TR2_L2_ATTR_TYPES_A = {Types.DOUBLE,Types.DOUBLE,Types.DOUBLE};
   
   //..... Transformer Line 3 ......  
  
   public static final String[] TR2_L3_ATTR_NAMES_SA = {"WINDV1", "NOMV1", "ANG1", "RATA1", "RATB1", 
                                                       "RATC1", "COD", "CONT", "RMA", "RMI", "VMA", "VMI",
                                                       "NTP", "TAB1", "CR", "CX", ATTR_317_NAME};           

   public static final Object[] TR2_L3_ATTR_DEFS_OA  = {null, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0, 
                                                       1.1, 0.9, 1.1, 0.9, 33, 0, 0.0, 0.0, 0.0};
         
   public static final Integer[] TR2_L3_ATTR_TYPES_A = {Types.DOUBLE,  Types.DOUBLE, Types.DOUBLE,
                                                       Types.DOUBLE,  Types.DOUBLE, Types.DOUBLE,
                                                       Types.INTEGER, Types.VARCHAR,
                                                       Types.DOUBLE,  Types.DOUBLE, Types.DOUBLE, Types.DOUBLE,
                                                       Types.INTEGER, Types.INTEGER, Types.DOUBLE,  Types.DOUBLE,
                                                       Types.DOUBLE};
   //..... Transformer Line 4 ......  
   
   public static final String[] TR2_L4_ATTR_NAMES_SA = {"WINDV2", "NOMV2"};
   
   public static final Object[] TR2_L4_ATTR_DEFS_OA  = {null, 0.0};   
   
   public static final Integer[] TR2_L4_ATTR_TYPES_A = {Types.DOUBLE,  Types.DOUBLE};   
 
   //..... Common arrays for 2-winding transformers ......
   
   public static final String[][] TR2_ATTR_NAMES_SAA = {TR2_L1_ATTR_NAMES_SA, TR2_L2_ATTR_NAMES_SA, TR2_L3_ATTR_NAMES_SA,
                                                        TR2_L4_ATTR_NAMES_SA};

   public static final Object[][] TR2_ATTR_DEFS_OAA  = {TR2_L1_ATTR_DEFS_OA, TR2_L2_ATTR_DEFS_OA, TR2_L3_ATTR_DEFS_OA,
                                                        TR2_L4_ATTR_DEFS_OA};

   public static final Integer[][] TR2_ATTR_TYPES_AA = {TR2_L1_ATTR_TYPES_A, TR2_L2_ATTR_TYPES_A, TR2_L3_ATTR_TYPES_A,
                                                        TR2_L4_ATTR_TYPES_A};

   //..... 9. Area interchange section ............................................................
   
   // Format V29, V30, V32, V33:
   // I,  ISW,     PDES,      PTOL, 'ARNAM' 
   
   public static final String[] AREA_ATTR_NAMES_SA = {"area", "ISW", "PDES", "PTOL", "ARNAM"}; 
   
   public static final Object[] AREA_ATTR_DEFS_OA = {null, 0, 0.0, 10.0, "            " };
   
   public static final Integer[] AREA_ATTR_TYPES_A = {Types.VARCHAR, Types.VARCHAR, Types.DOUBLE, Types.DOUBLE,
                                                      Types.VARCHAR,};
         
   //..... 10. Two-terminal DC transmission line section (DC2) ....................................
   
   // Format V30: 
   //
   // Line-1: I, MDC, RDC, SETVL, VSCHD, VCMOD, RCOMP, DELTI, METER, DCVMIN, CCCITMX, CCCACC 
   // Line-2: IPR,NBR,ALFMX,ALFMN,RCR,XCR,EBASR,TRR,TAPR,TMXR,TMNR,STPR,ICR,IFR,ITR,IDR,XCAPR 
   // Line-3: IPI,NBI,GAMMX,GAMMN,RCI,XCI,EBASI,TRI,TAPI,TMXI,TMNI,STPI,ICI,IFI,ITI,IDI,XCAPI
   
   //..... Line 1 ......
   
   public static final String[] DC2_L1_ATTR_NAMES_SA = {"I", "MDC", "RDC", "SETVL", "VSCHD", "VCMOD",
                                                        "RCOMP", "DELTI", "METER", "DCVMIN", "CCCITMX", "CCCACC"};
   
   public static final Object[] DC2_L1_ATTR_DEFS_OA = {null, 0, null, null, null, 0.0, 0.0, 0.0, 'I',
                                                           0.0, 20, 1.0};

   public static final Integer[] DC2_L1_ATTR_TYPES_A = {Types.VARCHAR, Types.INTEGER, Types.DOUBLE,  Types.DOUBLE, 
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE, 
                                                        Types.VARCHAR, Types.DOUBLE,  Types.INTEGER, Types.DOUBLE};
   //..... Line 2 ......
   
   public static final String[] DC2_L2_ATTR_NAMES_SA = {"IPR", "NBR", "ALFMX", "ALFMN", "RCR", "XCR", "EBASR", "TRR",
                                                        "TAPR", "TMXR", "TMNR", "STPR", "ICR", "IFR", "ITR", "IDR", 
                                                        "XCAPR"};

   public static final Object[] DC2_L2_ATTR_DEFS_OA = {null, null, null, null, null, null, null,
                                                           1.0, 1.0, 1.5, 0.51, 0.00625, 0, 0, 0, '1', 0.0};

   public static final Integer[] DC2_L2_ATTR_TYPES_A = {Types.VARCHAR, Types.INTEGER, Types.DOUBLE,  Types.DOUBLE,
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,
                                                        Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR,
                                                        Types.DOUBLE};
   //..... Line 3 ......
   
   public static final String[] DC2_L3_ATTR_NAMES_SA = {"IPI", "NBI", "GAMMX", "GAMMN", "RCI", "XCI", "EBASI", "TRI",
                                                        "TAPI", "TMXI", "TMNI", "STPI", "ICI", "IFI", "ITI", "IDI", 
                                                        "XCAPI"};

   public static final Object[] DC2_L3_ATTR_DEFS_OA  = {null, null, null, null, null, null, null,
                                                        1.0, 1.0, 1.5, 0.51, 0.00625, 0, 0, 0, '1', 0.0};

   public static final Integer[] DC2_L3_ATTR_TYPES_A = {Types.VARCHAR, Types.INTEGER, Types.DOUBLE,  Types.DOUBLE,
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,
                                                        Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR,
                                                        Types.DOUBLE};
   
   public static final String[][] DC2_ATTR_NAMES_SAA = {DC2_L1_ATTR_NAMES_SA, DC2_L2_ATTR_NAMES_SA, DC2_L3_ATTR_NAMES_SA};
   public static final Object[][] DC2_ATTR_DEFS_OAA  = {DC2_L1_ATTR_DEFS_OA,  DC2_L2_ATTR_DEFS_OA,  DC2_L3_ATTR_DEFS_OA};
   public static final Integer[][] DC2_ATTR_TYPES_AA = {DC2_L1_ATTR_TYPES_A,  DC2_L2_ATTR_TYPES_A,  DC2_L3_ATTR_TYPES_A};
   
   //..... 11. Voltage source converter data (VSC) ................................................
  
   // Line-1: 'NAME', MDC, RDC, O1, F1, ... O4, F4 
   // Line-2: IBUS,TYPE,MODE,DCSET,ACSET,ALOSS,BLOSS,MINLOSS,SMAX,IMAX,PWF,MAXQ,MINQ,REMOT,RMPCT 
   // Line-3: JBUS,TYPE,MODE,DCSET,ACSET,ALOSS,BLOSS,MINLOSS,SMAX,IMAX,PWF,MAXQ,MINQ,REMOT,RMPCT 
   
   //..... Line 1 ......
   
   public static final String[] VSC_L1_ATTR_NAMES_SA = {"NAME", "MDC", "RDC", "O1","F1", "O2","F2", "O3","F3", "O4","F4"}; 
   
   public static final Object[] VSC_L1_ATTR_DEFS_OA  = {null, 1, null, null, 1.0, 0, 1.0, 0, 1.0, 0, 1.0};        
   
   public static final Integer[] VSC_L1_ATTR_TYPES_A = {Types.VARCHAR, Types.INTEGER, Types.DOUBLE,
                                                        Types.VARCHAR, Types.DOUBLE,  Types.VARCHAR, Types.DOUBLE,
                                                        Types.VARCHAR, Types.DOUBLE,  Types.VARCHAR, Types.DOUBLE};
   //..... Line 2 ......
   
   public static final String[] VSC_L2_ATTR_NAMES_SA = {"IBUS", "TYPE1", "MODE1", "DCSET1", "ACSET1", "ALOSS1", "BLOSS1",
                                                        "MINLOSS1", "SMAX1", "IMAX1", "PWF1", "MAXQ1", "MINQ1", "REMOT1", 
                                                        "RMPCT1"};
   
   public static final Object[] VSC_L2_ATTR_DEFS_OA  = {null, null, 1, null, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 
                                                        9999.0, -9999.0, 0, 100.0};
         
   public static final Integer[] VSC_L2_ATTR_TYPES_A = {Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.DOUBLE, 
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,
                                                        Types.DOUBLE,  Types.INTEGER,  Types.DOUBLE};
   //..... Line 3 ......
   
   public static final String[] VSC_L3_ATTR_NAMES_SA = {"JBUS", "TYPE2", "MODE2", "DCSET2", "ACSET2", "ALOSS2", "BLOSS2",
                                                        "MINLOSS2", "SMAX2", "IMAX2", "PWF2", "MAXQ2", "MINQ2", "REMOT2", 
                                                        "RMPCT2"}; 
                      
   public static final Object[] VSC_L3_ATTR_DEFS_OA  = {null, null, 1, null, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 
                                                        9999.0, -9999.0, 0, 100.0};

   public static final Integer[] VSC_L3_ATTR_TYPES_A = {Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.DOUBLE, 
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,
                                                        Types.DOUBLE,  Types.INTEGER,  Types.DOUBLE};
   
   public static final String[][] VSC_ATTR_NAMES_SAA = {VSC_L1_ATTR_NAMES_SA, VSC_L2_ATTR_NAMES_SA, VSC_L3_ATTR_NAMES_SA};
   public static final Object[][] VSC_ATTR_DEFS_OAA  = {VSC_L1_ATTR_DEFS_OA,  VSC_L2_ATTR_DEFS_OA,  VSC_L3_ATTR_DEFS_OA};
   public static final Integer[][] VSC_ATTR_TYPES_AA = {VSC_L1_ATTR_TYPES_A,  VSC_L2_ATTR_TYPES_A,  VSC_L3_ATTR_TYPES_A};
   
   //..... 12. Switched Shunt ...............................................................                                                      

   // Format V26:     I, MODSW, VSWHI, VSWLO, SWREM, BINIT, N1, B1, N2, B2...N8,B8 
   // Sample Data:    34606, 0, 1.1000, 0.9000, 0, -190.800, 1, -47.700, 1, -47.700, 1, -47.700, 1, -47.700,.. 
    
   // Format V29:     I, MODSW, VSWHI, VSWLO, SWREM, 'MIDNT', BINIT, N1, B1, N2, B2, ... N8, B8                                                              
   
   // Format V30, 31: I, MODSW, VSWHI, VSWLO, SWREM, RMPCT, 'RMIDNT', BINIT, N1, B1, N2, B2, ... N8, B8 
   // Sample Data:    8441, 1, 1.03869, 0.99869, 0,100.0,'        ', 334.80, 3, 50.40, 1, 37.80, 2, 36.00, 1,
   //                 37.80, 1,  36.00 
   
   // Description:
   // I      - Bus number.
   // MODSW  - Mode: 0 - fixed 1 - discrete 2 - continuous 
   // VSWHI  - Desired voltage upper limit, per unit 
   // VSWLO  - Desired voltage lower limit, per unit 
   // SWREM  - Number of remote bus to control. 0 to control own bus. 
   // RMPCT  - Percent of the total Mvar required to hold the voltage at the bus controlled 
   //          by bus I that are to be contributed by this switched shunt; RMPCT must be positive. 
   //          RMPCT is needed only if SWREM specifies a valid remote bus and there is more 
   //          than one local or remote voltage controlling device (plant, switched shunt, FACTS 
   //          device shunt element, or VSC dc line converter) controlling the voltage at bus 
   //          SWREM to a setpoint, or SWREM is zero but bus I is the controlled bus, local or 
   //          remote, of one or more other setpoint mode voltage controlling devices. Only used 
   //          if MODSW = 1 or 2. RMPCT = 100.0 by default. 
   // RMIDNT - When MODSW is 4, the name of the VSC dc line whose converter bus is specified 
   //          in SWREM. RMIDNT is not used for other values of MODSW. 
   //          RMIDNT is a blank name by default. 
   // BINIT  - Initial switched shunt admittance, MVAR at 1.0 per unit volts 
   //          N1 - Number of steps for block 1, first 0 is end of blocks 
   //          B1 - Admittance increment of block 1 in MVAR at 1.0 per unit volts. 
   //          N2, B2, etc, as N1, B1 
  
   // Format V32, V33: I, MODSW, ADJM, STAT, VSWHI, VSWLO, SWREM,  RMPCT, 'MIDNT', BINIT, N1, B1, 
   //                  N2, B2, ... N8, B8 
 
   // ADJM - Adjustment method: 0 - steps and blocks are switched on in input order, and off in 
   //                               reverse input order; this adjustment method was the only method 
   //                               available prior to PSS/E-32.0. 
   //                           1 - steps and blocks are switched on and off such that the next 
   //                               highest (or lowest, as appropriate) total admittance is achieved. 
   //                               ADJM = O by default. 
   // STAT - Initial switched shunt status of one for in-service and zero for out-of-service; 
   //        STAT = 1 by default.   
     
   public static final String ADJM_NAME   = "ADJM";
   public static final String STAT_NAME   = "STAT";
   public static final String MIDNT_NAME  = "MIDNT";
   public static final String RMIDNT_NAME = "RMIDNT";
   public static final String RMPCT_NAME  = "RMPCT";
   
   public static final String[] SW_SHUNT_ATTR_NAMES_SA = {"bus", "MODSW", ADJM_NAME, STAT_NAME, 
                                                          "VSWHI","VSWLO", "SWREM", "RMPCT", "MIDNT", "BINIT",
                                                          "N1", "B1", "N2", "B2", "N3", "B3", "N4", "B4",
                                                          "N5", "B5", "N6", "B6", "N7", "B7", "N8", "B8"}; 
   
   public static final Object[] SW_SHUNT_ATTR_DEFS_OA = {null, null, 0, 1, null, null, null, 100.0, 
                                                             "            ", null,
                                                             null, null,null, null,null, null,null, null,
                                                             null, null,null, null,null, null,null, null};
   
   public static final Integer[] SW_SHUNT_ATTR_TYPES_A = {Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, 
                                                          Types.DOUBLE,  Types.DOUBLE,  Types.INTEGER, Types.DOUBLE,  
                                                          Types.VARCHAR, Types.DOUBLE,
                                                          Types.INTEGER, Types.DOUBLE,Types.INTEGER, Types.DOUBLE,
                                                          Types.INTEGER, Types.DOUBLE,Types.INTEGER, Types.DOUBLE,
                                                          Types.INTEGER, Types.DOUBLE,Types.INTEGER, Types.DOUBLE,
                                                          Types.INTEGER, Types.DOUBLE,Types.INTEGER, Types.DOUBLE};
      
   //..... 13. Transformer Impedance Correction Tables ............................................
   
   // Format V29, V30, V32, V33: 
   // I, T1, F1, T2, F2, T3, F3, ... T11, F11 
    
   public static final String[] TICT_ATTR_NAMES_SA = {"number",  "T1", "F1", "T2", "F2", "T3", "F3", "T4", "F4", 
                                                      "T5", "F5", "T6", "F6", "T7", "F8", "T9", "F9", "T10",
                                                      "F10", "T11", "F11"};            
   
   public static final Object[] TICT_ATTR_DEFS_OA  = {null, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                                      0.0,  0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  
   public static final Integer[] TICT_ATTR_TYPES_A = {Types.INTEGER, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, 
                                                      Types.DOUBLE,  Types.DOUBLE, Types.DOUBLE, Types.DOUBLE,  
                                                      Types.DOUBLE,  Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, 
                                                      Types.DOUBLE,  Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, 
                                                      Types.DOUBLE,  Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, 
                                                      Types.DOUBLE};
   
   //..... 14. Multi-Terminal DC Line Data (MTDC) .................................................
   
   // Format V30:  (only that info was found)
   // Line 1: I, NCONV, NDCBS, NDCLN, MDC, VCONV, VCMOD, VCONVN
   // Line 2: IB,N,ANGMX,ANGMN,RC,XC,EBAS,TR,TAP,TPMX,TPMN,TSTP,SETVL,DCPF,MARG,CNVCOD
   // Line 3: IDC, IB, IA, ZONE, 'NAME', IDC2, RGRND, OWNER
   // Line 4: IDC, JDC, DCCKT, RDC, LDC
   
   //..... Line 1 ......
   
   public static final String[] MTDC_L1_ATTR_NAMES_SA = {"number", "NCONV", "NDCBS", "NDCLN", "MDC", "VCONV", "VCMOD", "VCONVN"};
   
   public static final Object[] MTDC_L1_ATTR_DEFS_OA = {null, null, null, null, 0, null, 0.0, 0};
   
   public static final Integer[] MTDC_L1_ATTR_TYPES_A = {Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                                                        Types.INTEGER, Types.VARCHAR, Types.DOUBLE, Types.INTEGER};
   //..... Line 2 ......
   
   public static final String[] MTDC_L2_ATTR_NAMES_SA = {"IB", "N", "ANGMX", "ANGMN", "RC", "XC", "EBAS", "TR", "TAP",
                                                         "TPMX", "TPMN", "TSTP", "SETVL", "DCPF", "MARG", "CNVCOD"};
   
   public static final Object[] MTDC_L2_ATTR_DEFS_OA = {null, null, null, null, null, null, null, 1.0, 1.0, 1.5,
                                                            0.51, 0.00625, null, 1.0, 0.0, 1};  
   
   public static final Integer[] MTDC_L2_ATTR_TYPES_A = {Types.VARCHAR, Types.INTEGER, Types.DOUBLE, Types.DOUBLE,
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE, Types.DOUBLE,
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE, Types.DOUBLE,
                                                        Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE, Types.INTEGER};
   //..... Line 3 ......
   
   public static final String[] MTDC_L3_ATTR_NAMES_SA = {"IDC", "IB", "IA", "ZONE", "NAME", "IDC2", "RGRND", "OWNER"};
   
   public static final Object[] MTDC_L3_ATTR_DEFS_OA = {null, 0, 1, 1, "            ", 0, 0.0, 1};
   
   public static final Integer[] MTDC_L3_ATTR_TYPES_A = {Types.INTEGER, Types.VARCHAR, Types.INTEGER, Types.VARCHAR,
                                                        Types.VARCHAR, Types.VARCHAR, Types.DOUBLE, Types.VARCHAR}; 
   //..... Line 4 ......
   
   public static final String[] MTDC_L4_ATTR_NAMES_SA = {"IDC", "JDC", "DCCKT", "RDC", "LDC"};
   
   public static final Object[] MTDC_L4_ATTR_DEFS_OA = {null, null, "1", null, 0.0};
   
   public static final Integer[] MTDC_L4_ATTR_TYPES_A = {Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.DOUBLE,
                                                        Types.DOUBLE};
   
   //..... Common array for MTDC section ......
   
   public static final String[][] MTDC_ATTR_NAMES_SAA = {MTDC_L1_ATTR_NAMES_SA, MTDC_L2_ATTR_NAMES_SA, 
                                                         MTDC_L3_ATTR_NAMES_SA, MTDC_L4_ATTR_NAMES_SA};

   public static final Object[][] MTDC_ATTR_DEFS_OAA  = {MTDC_L1_ATTR_DEFS_OA, MTDC_L2_ATTR_DEFS_OA, 
                                                         MTDC_L3_ATTR_DEFS_OA, MTDC_L4_ATTR_DEFS_OA};

   public static final Integer[][] MTDC_ATTR_TYPES_AA = {MTDC_L1_ATTR_TYPES_A, MTDC_L2_ATTR_TYPES_A, 
                                                         MTDC_L3_ATTR_TYPES_A, MTDC_L4_ATTR_TYPES_A};

   //..... 15. Multi-Section Line Grouping Data ............................................................
   
   // Format V29, V30: I, J, ID,      DUM1, DUM2, ... DUM9 
   // Format V32, V33: I, J, ID, MET, DUM1, DUM2, ... DUM9 
    
   // MET Metered end flag:  <=1 to designate bus I as the metered end  
   //                        >=2 to designate bus J as the metered end. 
   //                        MET = 1 by default. 
   
   public static final String[] MSLD_ATTR_NAMES_SA = {FROM_NAME, TO_NAME, "ID", "DUM1", MET_NAME, "DUM2", "DUM3",
                                                      "DUM4", "DUM5", "DUM6", "DUM7", "DUM8", "DUM9"}; 

   public static final Object[] MSLD_ATTR_DEFS_OA = {null, null, "&1", null, 1, null, null, null, 
                                                         null, null, null, null, null};
   
   public static final Integer[] MSLD_ATTR_TYPES_A = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                                                     Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, 
                                                     Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, 
                                                     Types.VARCHAR};
   
   //..... 16. Zone Data ..........................................................................
   
   // Format V29, V30, V32, V33:  I, ZONAME
   
   public static final String[] ZONE_ATTR_NAMES_SA = {"zone", "ZONAME"};
   
   public static final Object[] ZONE_ATTR_DEFS_OA = {null, "            "};
   
   public static final Integer[] ZONE_ATTR_TYPES_A = {Types.VARCHAR, Types.VARCHAR};
         
   //..... 17. Inter-area transfer data ...........................................................
   
   // Format V29, V30, V32, V33: ARFROM, ARTO, TRID, PTRAN 

   public static final String[] IATD_ATTR_NAMES_SA = {"area_from", "area_to", "TRID", "PTRAN"};              
 
   public static final Object[] IATD_ATTR_DEFS_OA = {null, null, "1", 0.0};
   
   public static final Integer[] IATD_ATTR_TYPES_A = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DOUBLE};
   
   //..... 18. Owner data .........................................................................
   
   // Format V29, V30, V32, V33: I, OWNAME 
   
   public static final String[] OWNER_ATTR_NAMES_SA = {"owner", "OWNAME"};
   
   public static final Object[] OWNER_ATTR_DEFS_OA = {null, "            "};
   
   public static final Integer[] OWNER_ATTR_TYPES_A = {Types.VARCHAR, Types.VARCHAR};
   
   //..... 19. Facts Control Device ...............................................................
   
   // Format V30: N,I,J,MODE,PDES,QDES,VSET,SHMX,TRMX,VTMN,VTMX,VSMX,IMX,LINX,RMPCT,OWNER,SET1,SET2,VSREF 
   
   public static final String[] FACTS_ATTR_NAMES_SA = {"N", "I", "J", "MODE", "PDES", "QDES", "VSET", "SHMX",
                                                       "TRMX", "VTMN", "VTMX", "VSMX", "IMX", "LINX", "RMPCT", 
                                                       "OWNER", "SET1", "SET2", "VSREF"};
   
   public static final Object[] FACTS_ATTR_DEFS_OA  = {null, null, 0, 1, 0.0, 0.0, 1.0, 9999.0, 9999.0,
                                                       0.9, 1.1, 1.0, 0.0, 0.05, 100.0, 1, 0.0, 0.0, 0};
   
   public static final Integer[] FACTS_ATTR_TYPES_A = {Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.INTEGER,
                                                       Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE, 
                                                       Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE, 
                                                       Types.DOUBLE,  Types.DOUBLE,  Types.DOUBLE,  Types.VARCHAR,
                                                       Types.DOUBLE,  Types.DOUBLE,  Types.INTEGER};
                                                      
   //..... 20. GNE Device .........................................................................
   
   public static final int NTERN_IDX         = 2;
   public static final int GNE_MIN_ATTR_NUM  = 9;        // if zero buses
   public static final String BUS_1_NAME     = "BUS_1";
   public static final String BUS_NTERM_NAME = "BUS_NTERM";
   
   // Format 32 (maybe), 33: 'NAME','MODEL', NTERM,BUS1, ...,BUSNTERM, NREAL,NINTG,NCHAR, STATUS,OWNER,NMETR
   //    REAL1, ..., REALmin(10,NREAL)
   //    INTG1, ..., INTGmin(10,NINTG)
   //    CHAR1, ..., CHARmin(10,NCHAR)
   
   public static final String[] GNE_ATTR_NAMES_SA = {"NAME","MODEL", 
                                                     "NTERM", "BUS_1", "BUS_NTERM",   // Buses from 1 to nterm
                                                     "NREAL","NINTG", "NCHAR", "STATUS","OWNER","NMETR"};
   
   //..... 21. Induction Machine data .........................................................................
   
   // Format 33: I,ID,STAT,SCODE,DCODE,AREA,ZONE,OWNER,TCODE,BCODE,MBASE,RATEKV, PCODE,PSET,
   //            H,A,B,D,E,RA,XA,XM,R1,X1,R2,X2,X3,E1,SE1,E2,SE2,IA1,IA2, XAMULT

   public static final String[] INDUCT_ATTR_NAMES_SA = {"I","ID","STAT","SCODE","DCODE","AREA","ZONE","OWNER",
                                                        "TCODE","BCODE","MBASE","RATEKV","PCODE","PSET",
                                                        "H","A","B","D","E","RA","XA","XM","R1","X1","R2","X2",
                                                        "X3","E1","SE1","E2","SE2","IA1","IA2", "XAMULT"};
   
   //----------------------------------- Aggregate arrays -----------------------------------------
   
   public static final String[][] ATTR_NAMES_SAA = {HEADER_ATTR_NAMES_SA, COMMENT_ATTR_NAMES_SA, 
                                                    BUS_ATTR_NAMES_SA, LOAD_ATTR_NAMES_SA, FIX_SHUNT_ATTR_NAMES_SA,
                                                    GEN_ATTR_NAMES_SA, BRANCH_ATTR_NAMES_SA, null, null, 
                                                    AREA_ATTR_NAMES_SA, null, null, SW_SHUNT_ATTR_NAMES_SA, 
                                                    TICT_ATTR_NAMES_SA, null, MSLD_ATTR_NAMES_SA, ZONE_ATTR_NAMES_SA, 
                                                    IATD_ATTR_NAMES_SA, OWNER_ATTR_NAMES_SA, FACTS_ATTR_NAMES_SA, 
                                                    GNE_ATTR_NAMES_SA, INDUCT_ATTR_NAMES_SA};

   public static final Object[][] ATTR_DEFS_OAA = {HEADER_ATTR_DEFS_OA, COMMENT_ATTR_DEFS_OA, 
                                                   BUS_ATTR_DEFS_OA, LOAD_ATTR_DEFS_OA, FIX_SHUNT_ATTR_DEFS_OA,
                                                   GEN_ATTR_DEFS_OA, BRANCH_ATTR_DEFS_OA, null, null, AREA_ATTR_DEFS_OA,
                                                   null, null, SW_SHUNT_ATTR_DEFS_OA, TICT_ATTR_DEFS_OA, null, 
                                                   MSLD_ATTR_DEFS_OA, ZONE_ATTR_DEFS_OA, IATD_ATTR_DEFS_OA, 
                                                   OWNER_ATTR_DEFS_OA, FACTS_ATTR_DEFS_OA,  null, null};

   public static final Integer[][] ATTR_TYPES_AA = {HEADER_ATTR_TYPES_A, COMMENT_ATTR_TYPES_A, BUS_ATTR_TYPES_A,
                                                    LOAD_ATTR_TYPES_A, FIX_SHUNT_ATTR_TYPES_A, GEN_ATTR_TYPES_A, 
                                                    BRANCH_ATTR_TYPES_A, null, null, AREA_ATTR_TYPES_A,
                                                    null, null, SW_SHUNT_ATTR_TYPES_A, TICT_ATTR_TYPES_A, null, 
                                                    MSLD_ATTR_TYPES_A, ZONE_ATTR_TYPES_A, IATD_ATTR_TYPES_A, 
                                                    OWNER_ATTR_TYPES_A, FACTS_ATTR_TYPES_A,  null, null};
   }
