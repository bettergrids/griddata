package org.dspace.app.webui.sitemap;

import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

public class BGSitemapForm 
{
   private static final Logger log = Logger.getLogger(BGSitemapForm.class);
   
   private static String    serviceStatus = null;
   private static Boolean[] options_ba    = new Boolean[BGSitemap.getOptionNames().length];
   private static int       numOfDays;
   private static int       startHour;
   private static int       startMin;
   private static String    staticLinks;
   private static Double    priority;  
   
   protected static final BGSitemapForm INSTANCE = new BGSitemapForm();

   public static final BGSitemapForm getInstance() {
      if (options_ba == null) {
         BGSitemap.getInstance();
         options_ba = BGSitemap.getOptionsBoolean();
      }
      return INSTANCE;
   }

   public static String getServiceStatus() {
      return serviceStatus;
   }
   public static void setServiceStatus(String serviceStatus) {
      BGSitemapForm.serviceStatus = serviceStatus;
   }
   public static Boolean[] getOptions() {
      return options_ba;
   }
   
   public static void setOption(int idx, Boolean options_b) 
   {
      BGSitemapForm.options_ba[idx] = options_b;
   }
   public static void setOptions(Boolean options_b) 
   {
      for (int i = 0; i < options_ba.length; i++) {
         BGSitemapForm.options_ba[i] = options_b;
      }
   }   
   public static void setOptions(Boolean[] options_ba) 
   {
      for (int i = 0; i < options_ba.length; i++) {
         BGSitemapForm.options_ba[i] = options_ba[i];
      }
   }
   
   public static void setOptionsFromForm(String[] option_sa) 
   {
      setOptions(false);
      
      if (option_sa != null) {
         List<String> options_l = Arrays.asList(BGSitemap.getOptionNames());     
      
         // Array options_sa - values from checkbox controls. 
         // Returns names only those are checked
      
         for (int i = 0; i < option_sa.length; i++) {
            int idx = options_l.indexOf(option_sa[i]);
            if (idx >= 0) setOption(idx, true); 
         }
      }
   }

   public static int getNumOfDays() {
      return numOfDays;
   }
   public static void setNumOfDays(int numOfDays) {
      BGSitemapForm.numOfDays = numOfDays;
   }
   public static int getStartHour() {
      return startHour;
   }
   public static void setStartHour(int startHour) {
      BGSitemapForm.startHour = startHour;
   }
   public static int getStartMin() {
      return startMin;
   }
   public static void setStartMin(int startMin) {
      BGSitemapForm.startMin = startMin;
   }
   public static String getStaticLinks() {
      return staticLinks;
   }
   public static void setStaticLinks(String staticLinks) {
      BGSitemapForm.staticLinks = staticLinks;
   }
   public static Double getPriority() {
      return priority;
   }
   public static void setPriority(Double priority) {
      BGSitemapForm.priority = priority;
   }
}
