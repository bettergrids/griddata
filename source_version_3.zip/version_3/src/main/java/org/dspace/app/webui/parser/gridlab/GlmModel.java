package org.dspace.app.webui.parser.gridlab;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBColumn;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGSetList;


public class GlmModel extends BGModel {

   private static final Logger log = Logger.getLogger(GlmModel.class);
   
   //..... Constants ......
      
   public static final String MODEL_TYPE_CONST = "GRIDLAB D";
   
   //..... Link node type names ......
   
   public static final String TYPE_NAME_OVERHEAD_LINE    = "overhead_line";
   public static final String TYPE_NAME_SWITCH           = "switch";
   public static final String TYPE_NAME_TRANSFORMER      = "transformer";
   public static final String TYPE_NAME_UNDERGROUND_LINE = "underground_line";
   public static final String TYPE_NAME_FUSE             = "fuse";
   public static final String TYPE_NAME_TRIPLEX_LINE     = "triplex_line";
   public static final String TYPE_NAME_REGULATOR        = "regulator";
   public static final String TYPE_NAME_PARENT           = "parent";
   public static final String TYPE_NAME_RECLOSER         = "recloser";
   
   public static final String TYPE_NAME_NODE             = "node";
   public static final String TYPE_NAME_CAPACITOR        = "capacitor";
   public static final String TYPE_NAME_METER            = "meter";
   public static final String TYPE_NAME_LOAD             = "load";
   public static final String TYPE_NAME_TRIPLEX_NODE     = "triplex_node";
   public static final String TYPE_NAME_TRIPLEX_METER    = "triplex_meter";
   public static final String TYPE_NAME_RECORDER         = "recorder";
   
   public static final String TYPE_NAME_OVERHEAD_LINE_CONDUCTOR    = "overhead_line_conductor";
   public static final String TYPE_NAME_UNDERGROUND_LINE_CONDUCTOR = "underground_line_conductor";
   public static final String TYPE_NAME_TRIPLEX_LINE_CONDUCTOR     = "triplex_line_conductor";
   
   public static final String FROM_NAME                  = "_from";
   public static final String TO_NAME                    = "_to";
   public static final String LENGTH_NAME                = "length";
     
   public static final String[] NODE_TYPE_NAMES = {TYPE_NAME_NODE,                           // 100
                                                   TYPE_NAME_METER,                          // 101
                                                   TYPE_NAME_TRIPLEX_NODE,                   // 102
                                                   TYPE_NAME_LOAD,                           // 103
                                                   TYPE_NAME_CAPACITOR,                      // 104
                                                   TYPE_NAME_TRIPLEX_METER,
                                                   TYPE_NAME_RECORDER,
                                                   TYPE_NAME_OVERHEAD_LINE_CONDUCTOR,
                                                   TYPE_NAME_UNDERGROUND_LINE_CONDUCTOR,
                                                   TYPE_NAME_TRIPLEX_LINE_CONDUCTOR};
   
   public static final String[] LINK_TYPE_NAMES = {TYPE_NAME_OVERHEAD_LINE,                  // 110
                                                   TYPE_NAME_SWITCH,                         // 111
                                                   TYPE_NAME_TRANSFORMER,                    // 112
                                                   TYPE_NAME_UNDERGROUND_LINE,               // 113
                                                   TYPE_NAME_FUSE,                           // 114
                                                   TYPE_NAME_TRIPLEX_LINE,                   // 115
                                                   TYPE_NAME_REGULATOR,                      // 116
                                                   TYPE_NAME_PARENT,                         // 117
                                                   TYPE_NAME_RECLOSER};                      // 118
   //..... Members ......
   
   private Map<String, GlmObject> objects_hm = new LinkedHashMap<String, GlmObject>();
   
   // Top Map - for object types by type name
   // Map     - for Object by name
   
   //private Map<String, Map<String,GlmObject>> object_hmm = new LinkedHashMap<String, Map<String,GlmObject>>();
   //private Map<String, List<String>> attrNames_hml       = new LinkedHashMap<String, List<String>>();
   
   //private Map<String, GlmModule> modules_hm = new LinkedHashMap<String, GlmModule>();
   
   private List<String> objTypeNames_al  = new ArrayList<String>();
   private String[]     attrNames_sa     = null;
   
   //..... Overwritten functions ......
   
   public String getType ()
   {
      return MODEL_TYPE_CONST;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean addObject(GlmObject obj)
   {
      if (obj.getFullId() != null) {
         objects_hm.put(obj.getName(), obj);
         return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   
   public GlmObject getObject(String name_s)
   {
      return objects_hm.get(name_s);
   }
   //----------------------------------------------------------------------------------------------
   
   public int getObjectCnt()
   {
      return objects_hm.size();
   }

   //----------------------------------------------------------------------------------------------
   // Convert model to entry
   //----------------------------------------------------------------------------------------------

   @Override
   public DBEntry getEntry(String  nodeType_s,
                           String  nodeName_s)
                          
   {
      return getEntry(nodeType_s, nodeName_s, true);
   }
   //----------------------------------------------------------------------------------------------

   public DBEntry getEntry(String  nodeType_s,
                           String  nodeName_s,
                           boolean setNumeric_b)
   {
      DBEntry entry       = new DBEntry();
      boolean haveTypes_b = false;
      
      //..... Setup table ......

      DBTable table = new DBTable();
      table.setName(getName());
      
      for (int i = 0; i < getAttrNames().length; i++) {
         String colName = getAttrNames()[i].replaceAll("\\s+"," ").trim();
         colName = colName.replaceAll("[ .-]", "_");
         
         DBColumn col = new DBColumn(colName, null, Types.VARCHAR, i);
         table.addColumn(i, col);
      }
      entry.setTable(table);
      
      if (objTypeNames_al.isEmpty() == false) {
         haveTypes_b = true;
      }
      //..... Populate row values ......
      
      for (GlmObject obj : objects_hm.values()) {
         if ((nodeName_s == null && nodeType_s == null) ||
             (nodeName_s != null && nodeName_s.equalsIgnoreCase(obj.getName())) ||
             (nodeName_s == null && nodeType_s != null && nodeType_s.equalsIgnoreCase(obj.getType()))) {
             
            Map<Integer, Object> row = entry.newRow();
            for (GlmAttr attr : obj.getAttrsHM().values()) {
               int columnIdx = table.findColumnIdx(attr.getName());
               entry.setRowValue(row, columnIdx, attr.getValue());
            }
            entry.addRow(row);
            
            //..... Populate object type names ......
            
            if (haveTypes_b == false) {
               String type_s = obj.getType();
               if (objTypeNames_al.contains(type_s) == false) { 
                  objTypeNames_al.add(type_s);
               }
            }
         }
      }
      entry.setCompactTable();         // remove columns with all null values
      if (setNumeric_b) {
         entry.setNumericColumns();    // set column types numeric/integer, based on data
      }
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   // Get model info (return number of objects of each type)
   //----------------------------------------------------------------------------------------------
   
   public DBEntry getInfoEntry()
   {
      DBEntry entry = new DBEntry();
      Map<String, Integer> info_hm = new LinkedHashMap<String, Integer>();
      
      //..... Setup table ......

      DBTable table = new DBTable();
      table.setName(getName());
      
      table.addColumn(0, new DBColumn(TYPE_CONST,  null, Types.VARCHAR, 0));   // column index: 0
      table.addColumn(1, new DBColumn(COUNT_CONST, null, Types.INTEGER, 1));   // column index: 1
      
      entry.setTable(table);
      
      //..... Calculate counts of all types ......
      
      for (GlmObject obj : objects_hm.values()) {  
         String type_s = obj.getType();
         if (info_hm.containsKey(type_s) == false) { 
            info_hm.put(type_s, 1);
         }
         else {
            info_hm.merge(type_s, 1, Integer::sum);
         }
      }   
      //..... Sort by value ...... 
      
      Set<Entry<String, Integer>>  info_set  = info_hm.entrySet();
      List<Entry<String, Integer>> info_list = new ArrayList<Entry<String, Integer>>(info_set);
      
      Collections.sort(info_list, new Comparator<Map.Entry<String, Integer>>()
      {
          public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
              return (o2.getValue()).compareTo( o1.getValue() );//Descending order
          }
      });
      //..... Populate row values ......
      
      for (Map.Entry<String, Integer> info_pair : info_list){
         Map<Integer, Object> row = entry.newRow();        
         entry.setRowValue(row, 0, info_pair.getKey());        // column index: 0
         entry.setRowValue(row, 1, info_pair.getValue());      // column index: 1
         entry.addRow(row);
      }
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   // Get all model attributes (BGSetList keeps only unique values)
   //----------------------------------------------------------------------------------------------
   
   private void setAttrNames()
   {
      BGSetList<String> attrSet = new BGSetList<String>();
      
      //..... A few columns to display first ......
      
      attrSet.add(GlmParser.NAME_CONST);
      attrSet.add(GlmParser.OBJ_INDEX_CONST);
      attrSet.add(GlmParser.FROM_CONST);
      attrSet.add(GlmParser.TO_CONST);
      
      //..... All other attributes ......
      
      for (GlmObject obj : objects_hm.values()) {         
         attrSet.addAll(new ArrayList<String>(Arrays.asList(obj.getAttrNames())));
      }
      attrNames_sa = attrSet.toArray(new String[attrSet.size()]);
   }   
   //----------------------------------------------------------------------------------------------
   
   private String[] getAttrNames()
   {
      if (attrNames_sa == null) {
         setAttrNames();
      }
      return attrNames_sa;
   }
   //----------------------------------------------------------------------------------------------
   
   private ArrayList<DBColumn> getAttrAsColumns()
   {
      ArrayList<DBColumn> cols = new ArrayList<DBColumn>();
      
      for (int i = 0; i < getAttrNames().length; i++) {
         DBColumn col = new DBColumn(attrNames_sa[i], null, Types.VARCHAR, i);
         cols.add(col);
      }
      return cols;
   }
   //----------------------------------------------------------------------------------------------
   // Calculate counts of different types (node, fuse, etc.)
   //----------------------------------------------------------------------------------------------
   
   @Override
   public boolean calcTypeCounts() 
   {
      //..... Calculate counts of all types ......
      
      for (GlmObject obj : objects_hm.values()) {  
         String type_s = obj.getType();
         if (typeCounts.containsKey(type_s) == false) { 
            typeCounts.put(type_s, 1);
         }
         else {
            typeCounts.merge(type_s, 1, Integer::sum);
         }
      }   
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Convert GmlModel to JSON format
   //----------------------------------------------------------------------------------------------

   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();
      //json_sb.append("{\"" + GlmParser.OBJECT_CONST + "s\": {\n");
      json_sb.append("{\n\""  + GlmParser.OBJECT_CONST + "\": [\n");
      
      //..... For each object ......
      
      for(GlmObject obj : objects_hm.values()) {
         json_sb.append(obj.toJson());
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n]\n}");
      
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   // Return all objects of certain type
   //----------------------------------------------------------------------------------------------
   
   @Override
   public BGObject[] getObjects(String typeName_s) 
   {
      List<GlmObject> objs = new ArrayList<GlmObject>();
      for (GlmObject obj : objects_hm.values()) {
         if (obj.getType().equalsIgnoreCase(typeName_s)) {
            objs.add(obj);
         }
      }
      return objs.toArray(new GlmObject[objs.size()]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public BGObject[] getObjects(int typeIdx) 
   {
      return getObjects(getObjTypeNames()[typeIdx]);
   }
   //----------------------------------------------------------------------------------------------
   // Return all objects
   //----------------------------------------------------------------------------------------------
   
   @Override
   public BGObject[] getObjects() 
   {
      return objects_hm.values().toArray(new GlmObject[objects_hm.size()]);   
   }
   //----------------------------------------------------------------------------------------------
   // Return all objects of certain type
   //----------------------------------------------------------------------------------------------

   @Override
   public Integer getTypesNum() 
   {      
      return NODE_TYPE_NAMES.length + LINK_TYPE_NAMES.length;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getObjTypeNames() 
   {
      if (objTypeNames_al.isEmpty()) {        
         objTypeNames_al = new ArrayList<String>(Arrays.asList(ArrayUtils.addAll(NODE_TYPE_NAMES, LINK_TYPE_NAMES)));
         
         for (GlmObject obj : objects_hm.values()) {
            String type_s = obj.getType();
            if (objTypeNames_al.contains(type_s) == false) { 
               objTypeNames_al.add(type_s);
            }
         }
      }
      return objTypeNames_al.toArray(new String[objTypeNames_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getStaticObjTypeNames() 
   {
      return ArrayUtils.addAll(NODE_TYPE_NAMES, LINK_TYPE_NAMES);
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getNodeObjTypeNames() 
   {
      return NODE_TYPE_NAMES;      
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String getObjTypeName(int sectIdx) 
   {
      int len = getObjTypeNames().length;
      if (sectIdx < 0 || sectIdx >= len) {
         log.error("GlmModel.getObjTypeName. Model: " + getName() + 
                   ". Type with index: " + sectIdx + " does not exist");
         return null;
      }
      return getObjTypeNames()[sectIdx];
   }
   //----------------------------------------------------------------------------------------------
   // Return array of specific types objects
   //----------------------------------------------------------------------------------------------   
 
   public BGObject[] getLinkObjects() 
   {
      List<BGObject> objs_al = new ArrayList<BGObject>(); 
      
      for (String objType_s : getObjTypeNames()) {    
         List<String> attrNames = getAttrNames(objType_s);
     
         if (attrNames.contains(GlmModel.FROM_NAME) && attrNames.contains(GlmModel.TO_NAME)) {
            BGObject[] objs = getObjects(objType_s);
            objs_al.addAll(Arrays.asList(objs));           
         }
      }
      return objs_al.toArray(new GlmObject[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getLinkObjTypeNames() 
   {
      /*
      List<String> objs_al = new ArrayList<String>(); 
         
      for (int sectIdx = 0; sectIdx < getTypesNum(); sectIdx++) {    
         List<String> attrNames = getAttrNames(sectIdx);
        
         if (attrNames.contains(GlmModel.FROM_NAME) && attrNames.contains(GlmModel.TO_NAME)) {
            String objType_s = getObjTypeName(sectIdx);
            objs_al.add(objType_s);           
         }
      }
      return objs_al.toArray(new String[objs_al.size()]);
      */
      return LINK_TYPE_NAMES;

   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public List<String> getAttrNames(int typeIdx) 
   {
      Set<String> attrNames_hs = new LinkedHashSet<String>();
      
      for (GlmObject obj : objects_hm.values()) {
         if (obj.getType().equalsIgnoreCase(getObjTypeNames()[typeIdx])) {
            attrNames_hs.addAll(Arrays.asList(obj.getAttrNames()));
         }         
      }
      return new ArrayList<String>(attrNames_hs);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public List<String> getAttrNames(String objType_s) 
   {
      Set<String> attrNames_hs = new LinkedHashSet<String>();
      
      for (GlmObject obj : objects_hm.values()) {
         if (obj.getType().equalsIgnoreCase(objType_s)) {
            attrNames_hs.addAll(Arrays.asList(obj.getAttrNames()));
         }         
      }
      return new ArrayList<String>(attrNames_hs);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public List<Integer> getAttrTypes(int typeIdx) 
   {
      
      //List<Integer> list = new ArrayList<Integer>(Collections.nCopies(60, 0));
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public Integer getAttrIdx(int sectIdx, String attrName) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public String getAttrTypeName(int sectIdx, int attrIdx) {
      // TODO Auto-generated method stub
      return null;
   }      
}
//======================================= End of Class ============================================
