package org.dspace.app.webui.parser.pslf;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBColumn;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGUtils;

public class PlfObject extends BGObject implements PlfTypes {

   private static final Logger log = Logger.getLogger(PlfObject.class);
   
   //..... Constants ......
   
   public static final String UNKNOWN_ATTR_NAME = "attr_";
   
   //..... Members ......
   
   private Integer  sectIdx;
   private PlfModel model;
   private Integer  nextSectIdx;
   
   private List<Object> attr_al = new ArrayList<Object>();
   
   //..... Constructors ......
   
   //public PslObject() {};
   
   public PlfObject(PlfModel model, Integer sectIdx)
   {
      this.model   = model;
      this.sectIdx = sectIdx;
   }
   //..... Methods ......
   
   public Integer getSectIdx() {
      return sectIdx;
   }
   public void setSectIdx(Integer sectIdx) {
      this.sectIdx = sectIdx;
   }
   public PlfModel getModel() {
      return model;
   }
   public void setModel(PlfModel model) {
      this.model = model;
   }
   @Override
   public void setModel(BGModel model) {
      this.model = (PlfModel)model;
   }
   public Integer getNextSectIdx() {
      return nextSectIdx;
   }
   public void setNextSectIdx(Integer nextSectIdx) {
      this.nextSectIdx = nextSectIdx;
   }
   //----------------------------------------------------------------------------------------------
   // Initialize array to be able to set arbitrary attribute
   //----------------------------------------------------------------------------------------------
   
   public void addAttrs(String[] attr_sa, 
                        int      sectIdx)
   {
      if (model.getAttrTypes(sectIdx) == null) {
         Integer[] types_a = new Integer[model.getAttrNames(sectIdx).size()];
         Arrays.fill(types_a, Types.VARCHAR);                                          // defaut setting        
         model.setAttrTypes(sectIdx, new ArrayList<Integer>(Arrays.asList(types_a)));
      }
      int attrNum = attr_sa.length;
      int lastIdx = model.getAttrNames(sectIdx).size();
      while (attrNum > lastIdx) {
         model.getAttrNames(sectIdx).add("attr_" + lastIdx);
         model.getAttrTypes(sectIdx).add(Types.VARCHAR);
         lastIdx++;
      }
      attr_al.addAll(Arrays.asList(attr_sa));
   }
   //----------------------------------------------------------------------------------------------
   // Long version of Initialize array to be able to set arbitrary attribute
   // (detect value type, which is not necessary for display table)
   //----------------------------------------------------------------------------------------------
   
   public void addAttrsLong(String[] attr_sa, 
                            int      sectIdx)
   {
      Object[] attr_oa = new Object[attr_sa.length];
      
      if (model.getAttrTypes(sectIdx) == null) {
         Integer[] types_a = new Integer[model.getAttrNames(sectIdx).size()];
         Arrays.fill(types_a, Types.DOUBLE);                                          // preliminary setting        
         model.setAttrTypes(sectIdx, new ArrayList<Integer>(Arrays.asList(types_a)));
      }
      for (int i = 0; i < attr_sa.length; i++) {
         attr_oa[i] = valueOfType(attr_sa[i]); 
         int type    = getAttrType(attr_oa[i]);    

         if (i >= model.getAttrNames(sectIdx).size()) {
            model.getAttrNames(sectIdx).add("attr_" + i);
            model.getAttrTypes(sectIdx).add(type);
         }
         else {
            int curType = model.getAttrType(sectIdx, i);
            if (curType != Types.VARCHAR && type == Types.VARCHAR ||
                curType == Types.DOUBLE  && type == Types.INTEGER) {
               model.setAttrType(sectIdx, i, type);
            }
         }
      }
      attr_al.addAll(Arrays.asList(attr_oa));
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public String[] getAttrsAsArray()
   {
      return (String[])attr_al.toArray();
   }
   //----------------------------------------------------------------------------------------------
   
   public List<Object> getAttrs()
   {
      return attr_al;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public void addAttr(int idx, Object attr) 
   {
      attr_al.add(idx, attr);
   }
   //----------------------------------------------------------------------------------------------
   
   public void addAttr(Object attr) 
   {
      attr_al.add(attr);
   }
   //----------------------------------------------------------------------------------------------
   // Set arbitrary attribute
   //----------------------------------------------------------------------------------------------
   
   public boolean setAttr(int idx, String attr_s)
   {
      try {
         attr_al.set(idx, attr_s);
         return true;
      }
      catch (Exception e) {
         return false;
      }
   }
   //----------------------------------------------------------------------------------------------
   // Modify attribute value from just a number, like "2" to attribute name + value, like "bus_2" 
   //----------------------------------------------------------------------------------------------
   
   public boolean setAttrExtendedValue(String attrName)     // like "bus", "load", etc
   {
      try {
         Integer idx = getAttrIdx(attrName);
         String value = getAttr(idx).toString();
         if (idx != null && BGUtils.stringToInteger(value) != null) {
            attr_al.set(idx, attrName + "_" + value);
            return true;
         }
         return false;
      }
      catch (Exception e) {
         return false;
      }
   }
   //----------------------------------------------------------------------------------------------
   
   /*
   public void setAttr(int    attrIdx,
                       String value_s)
   {
      int dataType;
      
      if (attr_al.size() == 0) {
         initAttrPlaces();
      }
      if (attr_al.size() >= attrIdx) {
         attr_al = BGUtils.extendArrayList(attrIdx - attr_al.size() + 1, attr_al);
         dataType = Types.VARCHAR;
      }
      else {
         dataType = getAttrType(attrIdx);
      }
      if (dataType == Types.VARCHAR) {
         value_s = value_s.trim().replaceAll("\\s+"," ");   // replace all duplicate white spaces and LFs
         value_s = value_s.replaceAll("^'+", "");           // remove leading "'"
         value_s = value_s.replaceAll("'+$", "");           // remove trailing "'"
         value_s = value_s.trim();
      }      
      attr_al.set(attrIdx, valueOfType(value_s, dataType, null));
   }
   */
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Object getAttr(int idx) 
   {
      if (idx < attr_al.size()) {
         return attr_al.get(idx);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   // 
   //----------------------------------------------------------------------------------------------

   public Integer getAttrNum() 
   {
      if (attr_al != null) {
         return attr_al.size();
      }
      return 0;
   }   
   //----------------------------------------------------------------------------------------------
   @Override
   public String[] getAttrNames()
   {
      return model.getAttrNames(sectIdx).toArray(new String[0]);
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   /*
   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();

      //String objTypeId = type + ((id == null) ? "" : "_" + id.toString());
      
      //..... Start with object type, id and name (if any) as attributes ......
      
      json_sb.append("{\t\"object_type\" : \"" + type + "\",\n" );
      if (id != null) {
         json_sb.append("\t\"object_id\" : " + id.toString() + ",\n");
      }
      if (name != null) {
         json_sb.append("\t\"object_name\" : \"" + name + "\",\n");
      }
      //..... For each attribute ......
      
      int num = getAttrNum();
      for (int i = 0; i < num; i++) {
         if (getAttr(i) == null) continue;
         String attrJson_s = BGObject.attrToJson(getAttrNames()[i], valueOfType(getAttr(i).toString()), null);
         json_sb.append(attrJson_s);
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n},\n");
      return json_sb.toString();
   }
   */
   //----------------------------------------------------------------------------------------------
   // Get table with column declarations
   //----------------------------------------------------------------------------------------------
   
   public DBTable getTable() 
   {
      //..... Setup table ......

      String objType_s = getType();
      if (objType_s == null) return null;
      
      DBTable table = new DBTable();
      table.setName(objType_s);

      int attrLen = getAttrNames().length;      
      
      for (int i = 0; i < attrLen; i++) {         
         String  colName_s = model.getAttrNames(sectIdx).get(i);
         Integer colType   = model.getAttrTypes(sectIdx).get(i);

         DBColumn col = new DBColumn(colName_s, null, colType, i);
         table.addColumn(i, col);
      }
      return table;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public Integer getAttrIdx(String attrName) 
   {
      List<String> attrNames_sa = model.getAttrNames(sectIdx);
      
      for (int idx = 0; idx < attrNames_sa.size(); idx++) {
         if (attrNames_sa.get(idx).equalsIgnoreCase(attrName)) {
            return idx;
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public Object getAttr(String attrName) 
   {
      Integer idx = getAttrIdx(attrName);
      if (idx != null) {
         return getAttr(idx);
      }
      return null;
   }
}
//======================================= End of Class ============================================
