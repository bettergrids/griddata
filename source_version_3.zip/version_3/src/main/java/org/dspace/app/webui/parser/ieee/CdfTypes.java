package org.dspace.app.webui.parser.ieee;

import java.sql.Types;


public interface CdfTypes {
      
   //..... Common constants ......
   
   public static final int LINE_SIZE        =  128;
   public static final String DATE_FORMAT_S = "dd/MM/yy";
   public static final String END_OF_DATA   = "END OF DATA"; 
   
   //..... Section indices ......
   
   public static final int SECT_TITLE_IDX   = 0;
   public static final int SECT_BUS_IDX     = 1;
   public static final int SECT_BRANCH_IDX  = 2;
   public static final int SECT_ZONE_IDX    = 3;
   public static final int SECT_ICHANGE_IDX = 4;
   public static final int SECT_TLINE_IDX   = 5;
   
   //................................... 0. Title Data ............................................
   
   public static final String[] SECT_TITLE_NAMES_SA  = {"date", "originators_name", "MVA_base", "year", 
                                                       "season", "case_ID"};
   
   public static final Integer[] SECT_TITLE_TYPES_A  = {Types.DATE, Types.VARCHAR, Types.DOUBLE, 
                                                        Types.INTEGER, Types.VARCHAR, Types.VARCHAR};
   
   public static final int[] SECT_TITLE_START_A      = {2, 11, 32, 39, 44, 46};
   public static final int[] SECT_TITLE_STOP_A       = {9, 30, 37, 42, 44, 73};
   
   public static final String[] SEASON_KEY_SA  = {"S", "W"};
   public static final String[] SEASON_VAL_SA  = {"Summer", "Winter"};
  
   //................................... 1. Bus data ..............................................

   public static final String SECT_BUS_TITLE_S     = "BUS DATA FOLLOWS";
   
   public static final String[] SECT_BUS_NAMES_SA  = {"bus", "bus_name", "load_flow_area", 
                                                     "loss_zone", "type", "final_voltage", "final_angle",
                                                     "load_MW", "Load_MVAR", "Generation_MW", "Generation_MVAR",
                                                     "base_KV", "desired_volts", "max_MVAR", "min_MVAR",
                                                     "shunt_cond_G", "shunt_suscep_B", "remote_controlled_bus"};
   
   public static final Integer[] SECT_BUS_TYPES_A  = {Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER,
                                                      Types.INTEGER, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, 
                                                      Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE,
                                                      Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, 
                                                      Types.DOUBLE, Types.INTEGER};
 
   public static final int[] SECT_BUS_START_A      = {1,  5, 19, 21, 25, 28, 34, 41, 50, 60, 68, 77, 85, 91,  99, 107, 115, 124};
   public static final int[] SECT_BUS_STOP_A       = {4, 17, 20, 23, 26, 33, 40, 49, 59, 67, 75, 83, 90, 98, 106, 114, 122, 127};
         
   public static final String[] SECT_BUS_TYPES_SA  = {"Unregulated (load, PQ)", 
                                                      "Hold MVAR generation within voltage limits, (PQ)",
                                                      "Hold voltage within VAR limits (gen, PV)", 
                                                      "Hold voltage and angle (swing, V-Theta)"};

   public static final String SECT_BUS_END_S      = "-999";  // characters: 1-4
   
   //................................... 2. Branch data ...........................................
   
   public static final String FROM_NAME   = "_from";
   public static final String TO_NAME     = "_to";
   public static final String LENGTH_NAME = "length";  //!!!!****** LENGTH TEMPORARY ******
   
   public static final String SECT_BRANCH_TITLE_S     = "BRANCH DATA FOLLOWS";
   
   public static final String[] SECT_BRANCH_NAMES_SA  = {FROM_NAME, TO_NAME, "load_flow_area", "loss_zone", "Circuit",
                                                         "Type", "resistance_R", "resistance_X", "Line_charg_B", "line_MVA_1",
                                                         "line_MVA_2", "line_MVA_3", "control_bus", "side", "transformer_turns_ratio",
                                                         "transformer_final_angle", "min_tap_phase_shift", "max_tap_phase_shift",
                                                         "step_size", "min_voltage", "max_voltage"};
      
   public static final Integer[] SECT_BRANCH_TYPES_A  = {Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                                                         Types.INTEGER, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, 
                                                         Types.DOUBLE,  Types.DOUBLE, Types.INTEGER, Types.INTEGER, Types.DOUBLE, 
                                                         Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, 
                                                         Types.DOUBLE};
   
   public static final int[] SECT_BRANCH_START_A      = {1, 6, 11, 13, 17, 19, 20, 30, 41, 51, 57, 63, 69, 74, 77, 84, 91, 98,
                                                         106, 113, 120};

   public static final int[] SECT_BRANCH_STOP_A       = {4, 9, 12, 15, 17, 19, 29, 40, 50, 55, 61, 67, 72, 74, 82, 90, 97, 104, 
                                                         111, 119, 126};
   
   public static final String[] SECT_BRANCH_TYPES_SA  = {"Transmission line", "Fixed tap", 
                                                         "Variable tap for voltage control (TCUL, LTC)",
                                                         "Variable tap (turns ratio) for MVAR control",
                                                         "Variable phase angle for MW control (phase shifter)"};
   
   
   public static final String[] SECT_BRANCH_SIDE_SA   = {"Controlled bus is one of the terminals",
                                                         "Controlled bus is near the tap side",
                                                         "Controlled bus is near the impedance side (Z bus)"};
   
   public static final String SECT_BRANCH_END_S      = "-999";  // characters: 1-4
   
   //............................... 3. Loss Zone Data ............................................
   
   public static final String SECT_ZONE_TITLE_S       = "LOSS ZONES FOLLOWS";
   
   public static final String[] SECT_ZONE_NAMES_SA    = {"loss_zone_number", "loss_zone_name"};
   
   public static final Integer[] SECT_ZONE_TYPES_A    = {Types.INTEGER, Types.VARCHAR};
   
   public static final int[] SECT_ZONE_START_A        = {1, 5};
   public static final int[] SECT_ZONE_STOP_A         = {3, 16};
   
   public static final String SECT_ZONE_END_S         = "-99";  // characters: 1-3
   
   //............................... 4. Interchange Data ..........................................
     
   public static final String SECT_ICHANGE_TITLE_S    = "INTERCHANGE DATA FOLLOWS";
   
   public static final String[] SECT_ICHANGE_NAMES_SA = {"area_number", "inter_slack_bus_number",
                                                         "alternate_swing_bus_name", "area_inter_export_MW",
                                                         "area_inter_toler_MW", "area_code", "area_name"};
    
   public static final Integer[] SECT_ICHANGE_TYPES_A = {Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.DOUBLE,
                                                         Types.DOUBLE, Types.VARCHAR, Types.VARCHAR};
         
   public static final int[] SECT_ICHANGE_START_A     = {1, 4,  9, 21, 30, 38, 46};
   public static final int[] SECT_ICHANGE_STOP_A      = {2, 7, 20, 28, 35, 43, 75};
   
   public static final String SECT_ICHANGE_END_S      = "-9";  // characters: 1-2

   //............................... 5. Tie Line Data .............................................
   
   public static final String SECT_TLINE_TITLE_S    = "TIE LINES FOLLOW";
   
   public static final String[] SECT_TLINE_NAMES_SA = {"metered_bus", "metered_area", "non_metered_bus", 
                                                       "non_metered_area", "circuit"};
   
   public static final Integer[] SECT_TLINE_TYPES_A = {Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                                                       Types.INTEGER};
         
   public static final int[] SECT_TLINE_START_A     = {1, 7, 11, 17, 21};
   public static final int[] SECT_TLINE_STOP_A      = {4, 8, 14, 18, 21};
   
   public static final String SECT_TLINE_END_S      = "-999";  // characters: 1-4

   //----------------------------------- Aggregated arrays ----------------------------------------
   
   public static final String[]   TYPES_SA          = {"title", "bus", "branch", "loss_zones", "interchange", "tie_lines"};
   
   public static final String[]   TITLES_SA         = {"TITLE DATA", SECT_BUS_TITLE_S, SECT_BRANCH_TITLE_S,
                                                       SECT_ZONE_TITLE_S, SECT_ICHANGE_TITLE_S, SECT_TLINE_TITLE_S};
  
   public static final String[][] ATTR_NAMES_SAA    = {SECT_TITLE_NAMES_SA, SECT_BUS_NAMES_SA, SECT_BRANCH_NAMES_SA,
                                                       SECT_ZONE_NAMES_SA, SECT_ICHANGE_NAMES_SA, SECT_TLINE_NAMES_SA};
   
   public static final Integer[][] ATTR_TYPES_AA    = {SECT_TITLE_TYPES_A, SECT_BUS_TYPES_A, SECT_BRANCH_TYPES_A,
                                                       SECT_ZONE_TYPES_A, SECT_ICHANGE_TYPES_A, SECT_TLINE_TYPES_A};
  
   public static final int[][] START_AA             = {SECT_TITLE_START_A, SECT_BUS_START_A, SECT_BRANCH_START_A,
                                                       SECT_ZONE_START_A, SECT_ICHANGE_START_A, SECT_TLINE_START_A};
   
   public static final int[][] STOP_AA              = {SECT_TITLE_STOP_A, SECT_BUS_STOP_A, SECT_BRANCH_STOP_A,
                                                       SECT_ZONE_STOP_A, SECT_ICHANGE_STOP_A, SECT_TLINE_STOP_A};
     
   public static final String[] SECT_END_SA         = {null, SECT_BUS_END_S, SECT_BRANCH_END_S, SECT_ZONE_END_S, 
                                                       SECT_ICHANGE_END_S, SECT_TLINE_END_S};
}
//======================================= End of Interface ========================================

