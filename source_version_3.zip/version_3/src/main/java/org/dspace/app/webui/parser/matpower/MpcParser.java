package org.dspace.app.webui.parser.matpower;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.util.BGUtils;

public class MpcParser implements MpcTypes {

   private static final Logger log = Logger.getLogger(MpcParser.class);
   
   //..... Constants ......
   
   public static final Integer OUTSIDE_OF_OBJECT = -99;     // line is outside of the object
   public static final String  OBJECT_END_S      = ".end";  // end of object block
   public static final String  EQUAL_S           = "=";     // equal sign
   public static final String  SECT_OPEN_S       = "[{";    // open a new section 
   public static final String  SECT_CLOSE_S      = "]}";    // close section 
   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static MpcModel parseFile(String file_s) 
   {
      int       idx1;
      int       objTypeIdx = OUTSIDE_OF_OBJECT; 
      Integer   objIdx     = 0;
      MpcModel  model      = new MpcModel();
      Integer   formatType = 0;                 // 0 -text; 1 - m-file, like mpc.version = '2';
      
      //..... Read input file ......
   
      try (BufferedReader br = new BufferedReader(new FileReader(file_s))) {
         do {         
            String line_s = br.readLine();
            if (line_s == null) break;
            line_s = line_s.trim();
            if (line_s.isEmpty()) continue;
            
            //..... Remove comments ......
         
            idx1 = BGUtils.getStringPos(line_s, COMMENT_CONST_SA);
            if (idx1 == 0) continue;
            else if (idx1 > -1) {
               line_s = line_s.substring(0, idx1).trim();
            }
            line_s = line_s.replaceAll("\\s+"," ");      // replace all duplicate white spaces and LFs
            line_s = line_s.trim();
            if (line_s.isEmpty()) continue;
            
            //..... Start parsing object block .....
            
            if (objTypeIdx == OUTSIDE_OF_OBJECT) {
               
               objTypeIdx = BGUtils.getStringIdx(BGUtils.getFirstWord(line_s, EQUAL_S), OBJECT_TYPE_NAMES_SA);
               if (objTypeIdx == -1) {
                  objTypeIdx = OUTSIDE_OF_OBJECT;
                  continue;
               }
               //..... Check if formatType == 1 ......
               
               int pos1 = line_s.indexOf(EQUAL_S);
               if (pos1 > 0) {
                  formatType = 1;
                  int pos2 = line_s.indexOf(";");
                  
                  //..... One line object ......
                  
                  if (pos2 > 0) {
                     boolean res = addObject(model, line_s.substring(pos1 + 1, pos2).trim(), objTypeIdx, 0);
                     if (res == false) {
                        return null;
                     }
                     objTypeIdx = OUTSIDE_OF_OBJECT;
                     continue;
                  }
                  //..... Start line for the formatType = 1 object ......
                  
                  else if (BGUtils.getIndexOfAny(line_s, SECT_OPEN_S) == -1) {
                     log.error("MpcParser.parseFile.2. Line: " + line_s + " cannot be recognized as a valid MPC object");
                     return null;
                  }                  
               }
               //..... formatType = 0 (text format) ......
               
               else {
                  formatType = 0;
               }
               objIdx = 0;
            }
            else {
               try {
                  //..... End of object block ......
                  
                  if (formatType == 0 && line_s.equalsIgnoreCase(OBJECT_TYPE_NAMES_SA[objTypeIdx] + OBJECT_END_S) ||
                      formatType == 1 && BGUtils.getIndexOfAny(line_s.replaceAll("\\s+",""), SECT_CLOSE_S) != -1) {
                     objTypeIdx = OUTSIDE_OF_OBJECT;
                  }
                  //..... Add object to the model ......
                  
                  else {
                     if (formatType == 1) {
                        line_s = line_s.replace(";", "");
                     }
                     MpcObject obj = new MpcObject();
                     obj.setTypeIdx(objTypeIdx);
                     obj.setType(OBJECT_TYPE_SHOW_SA[objTypeIdx]);
                     obj.setId(objIdx);
                     obj.setName(OBJECT_TYPE_SHOW_SA[objTypeIdx] + "_" + objIdx);
                     objIdx++;
                     
                     if (obj.setAttrs(line_s) == false) {
                        log.error("MpcParser.parseFile.3. Line: " + line_s + " cannot be recognized as a valid MPC object");
                        return null;
                     }
                     //..... Special object processing ......
                     
                     if (objTypeIdx == TYPE_VERSION_IDX) {                             // mpc.version
                        model.setVersion(obj.getAttr(0).toString().replaceAll("'", ""));
                     }
                     else if (objTypeIdx == TYPE_BASE_MVA_IDX) {                        // mpc.baseMVA
                        model.setBaseMVA((Integer)obj.getAttr(1));
                     }                     
                     else if (objTypeIdx == TYPE_BUS_IDX) { 
                        obj.setId((Integer)obj.getAttr(0));
                        obj.setAttr(0, OBJECT_NAMES_SAA[TYPE_BUS_IDX][0] + "_" + obj.getId());
                        obj.setName((String)obj.getAttr(0));
                     }
                     else if (objTypeIdx == TYPE_GEN_IDX) {
                        obj.setAttr(0, OBJECT_NAMES_SAA[TYPE_BUS_IDX][0] + "_" + obj.getAttr(0));
                     }
                     else if (objTypeIdx == TYPE_BRANCH_IDX) {
                        obj.setAttr(0, OBJECT_NAMES_SAA[TYPE_BUS_IDX][0] + "_" + obj.getAttr(0));
                        obj.setAttr(1, OBJECT_NAMES_SAA[TYPE_BUS_IDX][0] + "_" + obj.getAttr(1));
                     }
                     obj.setModel(model);
                     model.addObject(objTypeIdx, obj.getName(), obj);
                     
                     //..... If square bracket ends the line ......
                     
                     if (line_s.endsWith("]")) {
                        objTypeIdx = OUTSIDE_OF_OBJECT;
                     }                     
                  }
               }
               catch (Exception e) {
                  log.error("MpcParser.parseFile.4. Line: " + line_s + " cannot be recognized as a valid MPC object");
                  return null;
               }
            }
         }
         while (true);
      }
      catch (FileNotFoundException e) {
         log.error("MpcParser.parseFile. File " + file_s + " not found. " + e.getMessage());
         return null;
      } 
      catch (IOException e) {
         log.error("MpcParser.parseFile. General error in parsing file " + file_s + ". " + e.getMessage());
         return null;
      }
      //..... Model attributes ......
   
      //model.setDspaceId(BGUtils.getNameFromFile(file_s));
      model.setName(BGUtils.getNameFromFile(file_s));
      model.setPath(file_s);
      model.calcTypeCounts();
      model.setFormat(BGModel.MODEL_FORMAT_MATPOWER);
      model.setFormatVersion(null);
   
      return model;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static boolean addObject(MpcModel model,
                                    String   line_s,
                                    Integer  objTypeIdx,
                                    Integer  objIdx)
   {
      MpcObject obj = new MpcObject();
      obj.setTypeIdx(objTypeIdx);
      obj.setType(OBJECT_TYPE_SHOW_SA[objTypeIdx]);
      obj.setName(OBJECT_TYPE_SHOW_SA[objTypeIdx] + "_" + objIdx++);
      
      if (obj.setAttrs(line_s) == false) {
         log.error("MpcParser.addObject. Line: " + line_s + " cannot be recognized as a valid MPC object");
         return false;
      }
      if (objTypeIdx == 0) {                             // mpc.version
         model.setVersion(obj.getAttr(0).toString());
      }
      else if (objTypeIdx == 1) {                        // mpc.baseMVA
         model.setBaseMVA((Integer)obj.getAttr(1));
      }
      obj.setModel(model);
      model.addObject(objTypeIdx, obj.getName(), obj);
 
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {
     // String[] text_sa = BGUtils.splitQuoted("abc xyz 'abc xx' try ");
      
      org.apache.log4j.BasicConfigurator.configure();
      
      //MpcModel model0 = parseFile("C:\\tmp_share\\case4gs.txt");
      
      String fileName_s = "D:\\tmp_share\\matpower\\Spring13Tight.m";
      MpcModel model0 = parseFile(fileName_s);
      
      //MpcModel model0 = parseFile("C:\\tmp_share\\case4gs.mat");
      String json_s = model0.toJson();
      
      //BGUtils.stringToFile(json_s, "C:\\tmp_share\\AL0001_glmfile_equip_manual.json");
      
      //DBEntry entry = model0.getInfoEntry();
      DBEntry entry;
      entry = model0.getInfoEntry();
      entry.printContent();
      entry = model0.getEntry("version", null);
      entry.printContent();
      entry = model0.getEntry("base_MVA", null);
      entry.printContent();
      entry = model0.getEntry("bus", null); 
      entry.printContent();
      entry = model0.getEntry("bus", "bus_3");
      entry.printContent();
      entry = model0.getEntry("generator", null);
      entry.printContent();
      entry = model0.getEntry("branch", null);
      entry.printContent();
      entry = model0.getEntry("cost", null);
      entry.printContent();
            
      //DBEntry entry = model1.getEntry(null, "transformer_configuration:42");
      //entry.printContent();
   }

}
//======================================= End of Class ============================================