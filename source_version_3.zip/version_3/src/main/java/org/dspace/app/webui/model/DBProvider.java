package org.dspace.app.webui.model;

import org.apache.log4j.Logger;
import org.dspace.app.webui.backup.BGConfig;

public class DBProvider 
{   
   private static final Logger log = Logger.getLogger(DBProvider.class);
   
   //..... Constants ......
   
   public static final String DSpaceDB      = "dspace";
   public static final String GraphDB       = "graph";   
   public static final String TimeZoneId    = "US/Pacific";
   private static Integer     dbPortDefault =  5432; 
   
   //..... PostgreSQl settings ......
      
   static String DSpaceName = null;             // "dspace";
   static String DSpaceUser = null;             // "dspace";
   static String DSpacePwd  = null;             // "dspace";
   
   static String GraphName  = GraphDB;
   static String GraphUser  = "graph";
   static String GraphPwd   = "graph";
   
   //..... PostgreSQL connection parameters ......
   
   private String dbName = null;
   private String user   = null;
   private String pwd    = null;
    
   private static String  ipaddr  = null;              // "192.168.1.105";   // C:\Users\Nickolay>psql -U dspace -h 192.168.1.105
   private static Integer port    = null;              // 5432; 
   
   private static String className = "org.postgresql.Driver";
   
   //..... Tablespaces ......
   
   private static String tempTsName = "tempts";
   
   //...... Constructor ......
   
   public DBProvider(String db_s)
   {
      init();
      
      if (db_s.equals(DSpaceName)) {
         setUser(DSpaceUser);
         setPwd(DSpacePwd);
         setDbName(DSpaceDB);
      }
      else if (db_s.equals(GraphName)) {
         setUser(GraphUser);
         setPwd(GraphPwd);
         setDbName(GraphDB);
      }
   }
   //----------------------------------------------------------------------------------------------
   // Retrieve configuration parameters
   //----------------------------------------------------------------------------------------------
   
   private void init()
   {
      obtainDSpaceName();
      obtainDSpaceUser();
      obtainDSpacePwd();
      obtainIpaddr();
      obtainDbPort();
   }
   //----------------------------------------------------------------------------------------------
   
   public static void obtainDSpaceName() 
   {
      if (DSpaceName == null) {
         DSpaceName = BGConfig.getBgProperty("db.name");
      }
   }
   //----------------------------------------------------------------------------------------------

   public static void obtainDSpaceUser() 
   {
      if (DSpaceUser == null) {
         DSpaceUser = BGConfig.getBgProperty("db.user");
      }
   }
   //----------------------------------------------------------------------------------------------

   public static void obtainDSpacePwd() 
   {
      if (DSpacePwd == null) {
         DSpacePwd = BGConfig.getBgProperty("db.password");
      }
   }
   //----------------------------------------------------------------------------------------------

   public static void obtainIpaddr() 
   {
      if (ipaddr == null) {
         ipaddr = BGConfig.getBgProperty("db.IPaddr");
      }
   }
   //----------------------------------------------------------------------------------------------

   public static void obtainDbPort() 
   {
      if (port == null) {
         try {
            port = Integer.valueOf(BGConfig.getBgProperty("db.port"));
         }
         catch(Exception e) {
            port = dbPortDefault;
            log.error("obtainDbPort. Cannot receive port from configuration. The default value " + 
                      dbPortDefault + " will be used");
         }
      }
   }
   //----------------------------------------------------------------------------------------------
   
   public static String getClassName() {
      return className;
   }
   public static void setClassName(String _className) {
      className = _className;
   }
   public String getDbName() {
      return dbName;
   }
   public void setDbName(String dbName) {
      this.dbName = dbName;
   }
   public String getUser() {
      return user;
   }
   public void setUser(String user) {
      this.user = user;
   }
   public String getPwd() {
      return pwd;
   }
   public void setPwd(String pwd) {
      this.pwd = pwd;
   }
   public String getIpaddr() {
      return ipaddr;
   }
   public int getPort() {
      return port;
   }
   public String getConnURL() {
      return "jdbc:postgresql://" + ipaddr + ":" + port + "/" + dbName;
   }
   public static String getTempTsName() {
      return tempTsName;
   }
   public static void setTempTsName(String tempTsName) {
      DBProvider.tempTsName = tempTsName;
   }

}
