package org.dspace.app.webui.nlidb;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.backup.BGConfig;
import org.dspace.app.webui.model.DBSingleEntry;
import org.dspace.app.webui.model.DBTypes;

import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import com.maxmind.geoip2.model.CityResponse;

public class NLIPAddress extends DBSingleEntry implements DBTypes {

   private static final Logger log = Logger.getLogger(NLIPAddress.class);
   
   //..... Constants ......
   
   private static final String dbFilePathName = "IPAddress.dbFilePath";
   
   //..... Column of the _ipaddr table ......
   
   public static final String IPADDR_TABLE_NAME = "_ipaddr";

   public static final String ipAddrName        = "ipaddr";    // primary key
   public static final String countryName       = "country";
   public static final String stateName         = "state";
   public static final String cityName          = "city";
   public static final String postalName        = "postal"; 
   public static final String latitudeName      = "latitude";
   public static final String longitudeName     = "longitude";
   
   final static String[] columnNames  = {ipAddrName, countryName, stateName, cityName, postalName,
                                         latitudeName, longitudeName};
   
   final static Integer[] columnTypes = {typeInet, typeText, typeText, typeText, typeText, 
                                         typeDouble, typeDouble};   
   //..... Constructor ......
   
   public NLIPAddress() {
      init();
   }   
   //..... Members ......
   
   private Object[] values_oa = new Object[columnNames.length];  // column values
   
   private static File   dbFile       = null;      // IP Address database file
   private static String dbFilePath_s = null;
   
   //..... Methods ......
   
   @Override
   public String getTableName() {
      return IPADDR_TABLE_NAME;
   }
   @Override
   public String[] getColumnNames() {
      return columnNames;
   }
   @Override
   public Integer[] getColumnTypes() {
      return columnTypes;
   }
   @Override
   public Object[] getValues() {
      return values_oa;
   }
   @Override
   public Boolean[] getAutoIncrement() {
      return null;
   }
   public String getStringValue(int idx) 
   {
      if (idx < values_oa.length) {
         if (values_oa[idx] instanceof String) {  
            return (String)values_oa[idx];
         }
      }
      return null;
   } 
   public Double getDoubleValue(int idx) 
   {
      if (idx < values_oa.length) {
         if (values_oa[idx] instanceof Double) {  
            return (Double)values_oa[idx];
         }
      }
      return null;
   } 

   public String getCountry() {
      return getStringValue(1);
   }
   public void setCountry(String country) {
      values_oa[1] = country;
   }
   public String getState() {
      return getStringValue(2);
   }
   public void setState(String state) {
      values_oa[2] = state;
   }
   public String getCity() {
      return getStringValue(3);
   }
   public void setCity(String city) {
      values_oa[3] = city;
   }
   public String getPostal() {
      return getStringValue(4);
   }
   public void setPostal(String postal) {
      values_oa[4] = postal;
   }
   public Double getLatitude() {
      return getDoubleValue(5);
   }
   public void setLatitude(Double latitude) {
      values_oa[5] = latitude;
   }
   public Double getLongitude() {
      return getDoubleValue(6);
   }
   public void setLongitude(Double longitude) {
      values_oa[6] = longitude;
   }
   public static String getDbFilePath_s() {
      return dbFilePath_s;
   }
   public static void setDbFilePath_s(String dbFilePath_s) {
      NLIPAddress.dbFilePath_s = dbFilePath_s;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   private boolean init()
   {
      if (dbFile == null) {
         if (dbFilePath_s == null) {    
            dbFilePath_s = BGConfig.getBgProperty(dbFilePathName);      // Get DB file path
            if (dbFilePath_s == null) {
               return false;
            }
         }
         try {
            dbFile = new File(dbFilePath_s);
         }
         catch (Exception e) {
            log.error("init. Cannot find the IpAddress database file " + 
                      dbFilePath_s + "; " + ExceptionUtils.getStackTrace(e));
            return false;
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public boolean setGeoInfo(String ipAddr_s)
   {
      init();     // setup database
      
      try {
         DatabaseReader dbReader = new DatabaseReader.Builder(dbFile).build();
         InetAddress ipAddr      = InetAddress.getByName(ipAddr_s);
         CityResponse response   = dbReader.city(ipAddr);
              
         values_oa[0] = ipAddr;
         values_oa[1] = response.getCountry().getName();
         values_oa[2] = response.getLeastSpecificSubdivision().getName();
         values_oa[3] = response.getCity().getName();
         values_oa[4] = response.getPostal().getCode();         
         values_oa[5] = response.getLocation().getLatitude();
         values_oa[6] = response.getLocation().getLongitude();

         //Traits t         = response.getTraits();
      } 
      catch (IOException e) {
         log.error("getGeoInfo. Cannot read IPAddress DB file or cannot get IP address " +
                   "by its string presentation. " + ExceptionUtils.getStackTrace(e));
         return false;
      } 
      catch (GeoIp2Exception e) {
         log.warn("getGeoInfo. Cannot get IP info attributes." + e.getMessage());
         return false;
      }
      return true;
   }
}
//====================================== End of File ==============================================
