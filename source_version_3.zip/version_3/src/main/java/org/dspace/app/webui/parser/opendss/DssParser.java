package org.dspace.app.webui.parser.opendss;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGParser;
import org.dspace.app.webui.util.BGUtils;

public class DssParser extends BGParser {

   private static final Logger log = Logger.getLogger(DssParser.class);
   
   //..... Constants ......
   
   public static final String COMMENT_INSIDE_CONST    = "!";
   public static final String COMMENT_LINE_CONST      = "//";
   public static final String COMMENT_BLOCK_IN_CONST  = "/*";
   public static final String COMMENT_BLOCK_OUT_CONST = "*/";
   
   public static final String DELIM_NEW_LINE_CONST    = "\\r?\\n";
   public static final String DELIM_WHITE_CONST       = "\\s+";
   public static final String DELIM_ATTR_CONST        = "[\t, ]";          // "\\t|,| ";
   public static final String DELIM_FUNC_CONST        = "[):>-]+";
   public static final String DELIM_TYPE_NAME_CONST   = "[.]+";
   
   public static final String QUOTES_CONST         = "[\"'\\[\\](){}]";    // "\"|\'|\\[|\\]|\\(|\\)|\\{|\\}";
   public static final String VALUE_CONST          = "=";
   public static final String EXTENSION_CONST      = "~";
   public static final String FROM_TO_CONST        = "->";  
   public static final String OPEN_BRACKET_CONST   = "("; 
   public static final String CLOSE_BRACKET_CONST  = ")";
   public static final String DOT_CONST            = ".";
   public static final String COMMA_CONST          = ",";
   
   public static final String MASTER_CONST         = "master";
   public static final String REDIRECT_CONST       = "redirect";
   public static final String BUSCOORDS_CONST      = "buscoords";
   
   public static final String NEW_CONST            = "New";
   public static final String OBJECT_CONST         = "Object";
   public static final char   LN_CONST             = '\n';
   public static final char   CR_CONST             = '\r';
   
   public static final String NAME_CONST           = "name";
   public static final String FROM_CONST           = "from";
   public static final String TO_CONST             = "to";
   public static final String BUS_CONST            = "bus";
   public static final String BUS1_CONST           = "bus1";
   public static final String BUS2_CONST           = "bus2";
   
   //..... Constructor ......
   
   public DssParser(String zipFilePath_s) throws FileNotFoundException 
   {
      super(zipFilePath_s);
   }

   //----------------------------------------------------------------------------------------------
   // Parse model file
   //----------------------------------------------------------------------------------------------
   
   public static DssArchive parseFile(String zipFilePath_s) 
   {
      boolean res_b = true;
      
      //..... Parse archive file ......
      
      DssArchive archive = new DssArchive();
      res_b = archive.extractModels(zipFilePath_s);
      if (res_b = false) {
         return null;
      }
      //..... For each file (String) ......
      
      for (DssModel model : archive.getModels()) {                   // for each model
         
         res_b = parseMasterFile(model);                             // order files based on master commands 
         if (res_b == false) {
            log.warn("parseFile. Model " + model.getName() + " has no master file.");
         }
         //..... Parse model files ......
         
         for (Entry<String, String> file_e : model.getFilesMap().entrySet()) {      // for each model file (type)
            String fileName_s = file_e.getKey();
            String text_s     = file_e.getValue();

            List<String> line_al = removeComments(text_s);           // remove comments lines and blocks
            line_al = mergeLinesWithExtensions(line_al);             // merge lines with their extensions            

            String cmd_s = model.getCommand(fileName_s);

            switch (cmd_s) {
            case BUSCOORDS_CONST:
               res_b = parseBusCoords(model, line_al);
               break;
            default:
               res_b = parseObjectFile(model, line_al);
               
               // If parser could not parse file with default "redirect" 
               // command let' try to do it with "buscoords"
               
               if (model.getFilesMap().size() == 1 && model.getObjects().length == 0) {
                  res_b = parseBusCoords(model, line_al);
               }
            }           
         }
         model.setName(BGUtils.getNameFromFile(zipFilePath_s));
         model.setPath(zipFilePath_s);
         model.calcTypeCounts();
         model.setFormat(BGModel.MODEL_FORMAT_OPENDSS);
         model.setFormatVersion(null);
      }
      return archive;
   }
   //----------------------------------------------------------------------------------------------
   // Parse BusCoords file: busname, x, y.
   //----------------------------------------------------------------------------------------------

   private static boolean parseBusCoords(DssModel     model,
                                         List<String> line_al)
   {
      for (String line_s : line_al) {
         line_s = line_s.replace(COMMA_CONST, " ");             // replace commas delimiters
         String[] line_sa = line_s.split(DELIM_WHITE_CONST);
         if (line_sa.length != 3) continue;
         
         String name_s = line_sa[0];
         int idx = name_s.indexOf(".");
         if (idx >= 0) {
            name_s.substring(0, idx);
         }         
         DssObject obj = model.getObject(name_s);
         if (obj == null) {
            obj = new DssObject();
            obj.setName(name_s);
            obj.setType(BUS_CONST);
            obj.addAttr(NAME_CONST, name_s);
         }
         obj.addAttr(DssAttr.TYPE_COORD_X, line_sa[1]);
         obj.addAttr(DssAttr.TYPE_COORD_Y, line_sa[2]);
         
         obj.setModel(model);
         model.addObject(obj);
      }
      return true;      
   }
   //----------------------------------------------------------------------------------------------
   // Parse "redirect" file with New objects
   //----------------------------------------------------------------------------------------------
   
   private static boolean parseObjectFile(DssModel     model,
                                          List<String> line_al)
   {
      boolean res_b = true;
      
      for (String line_s : line_al) {
         String[] line_sa = BGUtils.splitQuoted(line_s, DELIM_ATTR_CONST);
      
         // Merge wrongly splitted attrs, like: NormAmps=580 {580 1.25 *} 
         
         for(int i = 2; i < line_sa.length; i++) {
            if (line_sa[i].contains(VALUE_CONST) == false) {
               line_sa[i - 1] += " " + line_sa[i].trim();
               line_sa[i] = null;
            }            
         }
         //..... Create object with attributes ......
         
         DssObject obj = new DssObject();
         
         if (line_sa[0].equalsIgnoreCase(NEW_CONST) && line_sa.length > 1) {
            
            //..... Get object type and name ......
            
            String type_s;
            String name_s;
            int pos = line_sa[1].indexOf(DOT_CONST);
            
            //..... Object has type and name ......
            
            if (pos >= 0) {
               type_s = line_sa[1].substring(0, pos).toLowerCase();
               obj.setType(type_s);               
               name_s = line_sa[1].substring(pos + 1).toLowerCase();
               res_b = parseObjectName(model, obj, name_s);
               if (res_b == false) {
                  log.error("parseObjectFile. Cannot parse object name: " + name_s);
                  continue;
               }
            }
            //..... Object has type ......
            
            else {
               type_s  = line_sa[1].toLowerCase().trim();
               obj.setType(type_s);               
               int idx = model.getNextObjectTypeIdx(obj.getType());
               name_s  = obj.getType() + "_" + idx;
               obj.setName(name_s);
               obj.addAttr(DssParser.NAME_CONST, obj.getName());
            }
            //..... Parse attributes ......
                             
            for (int i = 2; i < line_sa.length; i++) {
               parseAddAttr(obj, line_sa[i]);
            }
            //..... Add object to model ......
            
            obj.setModel(model);
            model.addObject(obj);
         }         
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   private static boolean parseObjectName(DssModel  model,
                                          DssObject obj,
                                          String    fullName_s)
   {
      String name_s = null;
      
      //..... Check if it's a function name ......
      
      int idx0 = fullName_s.indexOf(OPEN_BRACKET_CONST);
      int idx1 = fullName_s.lastIndexOf(CLOSE_BRACKET_CONST);
      
      if (idx0 >= 0 && idx1 > idx0) {
         String func_s = fullName_s.substring(idx0 + 1, idx1);
         
         //..... It's a function with "from bus -> to bus" ......
         
         if (func_s.contains(FROM_TO_CONST)) {
            String[] func_sa = func_s.split(DELIM_FUNC_CONST);
            if (func_sa.length >= 3) {
               DssAttr attrFrom = new DssAttr(obj, DssModel.FROM_NAME, getBusName(func_sa[1]));                        
               DssAttr attrTo   = new DssAttr(obj, DssModel.TO_NAME, getBusName(func_sa[2]));
               
               obj.addAttr(attrFrom);
               obj.addAttr(attrTo);
            }
         }
         name_s = fullName_s.substring(0, idx0);
         
         //..... No name extension after function brackets ...... 
         
         if (idx1 == fullName_s.length() - 1) {
            int idx = model.getNextObjectTypeIdx(obj.getType());
            name_s = name_s + "_" + idx;            
         }
         //..... There is a real name (extension) after function brackets ......
         
         else {
            name_s += "_" + fullName_s.substring(idx1 + 1);
         }
      }
      else {
         name_s = fullName_s;
      }
      //..... Set object name and add it as an attribute ......
      
      obj.setName(name_s);
      obj.addAttr(DssParser.NAME_CONST, obj.getName());

      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
      
   private static boolean parseAddAttr(DssObject obj,
                                       String    attr_s)
   {
      if (attr_s == null) return true;
      
      attr_s = attr_s.toLowerCase();
      String[] attr_sa = attr_s.split(VALUE_CONST);
      if (attr_sa.length >= 2) {
         
         // Check if this attribute was already added
         // while parsing function's "_FROM/_TO" attributes
         
         if (obj.isLinkObject() && obj.ifAttrExists(attr_sa[1])) return true;
         
         //..... Create attribute ......
         
         String attrName_s = attr_sa[0].trim().replace("%", "").replaceAll("\\s+"," ");
         attrName_s        = attrName_s.replaceAll("[ .-]", "_");
         
         if (obj.getType().equals(DssModel.TYPE_NAME_TRANSFORMER) ||
               obj.getType().equals(DssModel.TYPE_NAME_LINE)) {
            if (attrName_s.equals(BUS1_CONST) || attrName_s.equals(BUS2_CONST)) return true;  
         }
         DssAttr attr = new DssAttr(obj, attrName_s, attr_sa[1]);
         obj.addAttr(attr);
         return true;
      }
      log.error("parseAddAttr. Cannot parse attribute: " + attr_s);
      return false;
   }
   //----------------------------------------------------------------------------------------------
   // Merge line and it's extensions
   //----------------------------------------------------------------------------------------------
      
   private static List<String> mergeLinesWithExtensions(List<String> line_al)
   {
      for (int idx = 0; idx < line_al.size(); idx++) {
         String line_s = line_al.get(idx).trim();
         if (idx == 0) continue;
          
         if (line_s.startsWith(EXTENSION_CONST)) {
            line_al.set(idx - 1, line_al.get(idx - 1) + " " + line_s.substring(1).trim());
            line_al.remove(idx);
            idx--;
         }
      }
      return line_al;
   }
   //----------------------------------------------------------------------------------------------
   // Remove comments
   //----------------------------------------------------------------------------------------------
      
   private static List<String> removeComments(String file_s)
   {
      file_s = file_s.replace("\n\r" , "\n").replace("\r\n" , "\n");
      
      String line_sa[]      = file_s.split(DELIM_NEW_LINE_CONST);    // split file to lines      
      List<String> line_al  = new ArrayList<String>();
      boolean insideBlock_b = false;
      
      for (String line_s : line_sa) {
         line_s = line_s.trim();
         
         if (insideBlock_b == false) {
            int pos1 = line_s.indexOf(COMMENT_INSIDE_CONST);
            int pos2 = line_s.indexOf(COMMENT_LINE_CONST);
            pos1     = Math.max(pos1, pos2);

            int pos3 = line_s.indexOf(COMMENT_BLOCK_IN_CONST);
            pos1     = Math.max(pos1, pos3);
            
            if (pos1 >= 0) {
               line_s = line_s.substring(0, pos1).trim();
               if (pos1 == pos3) {                                // open block "/*"
                  insideBlock_b = true;
               }
            }
         }
         else {
            int pos3 = line_s.indexOf(COMMENT_BLOCK_OUT_CONST);
            if (pos3 >= 0) {
               line_s   = line_s.substring(pos3 + COMMENT_BLOCK_OUT_CONST.length()).trim();
               int pos1 = line_s.indexOf(COMMENT_INSIDE_CONST);
               int pos2 = line_s.indexOf(COMMENT_LINE_CONST);
               pos1     = Math.max(pos1, pos2);
               if (pos1 >= 0) {
                  line_s = line_s.substring(0, pos1).trim();
               }
            }           
         }
         //..... Add line to the list ......

         if (line_s.isEmpty() == false) {
            line_al.add(line_s);
         }
      }
      return line_al;
   }
   //----------------------------------------------------------------------------------------------
   // Parse master file
   //----------------------------------------------------------------------------------------------
   
   private static boolean parseMasterFile(DssModel model)
   {
      boolean res_b = true;
      Map<String, String>fileOrder_hm = new LinkedHashMap<String, String>();
      
      for (String file_s : model.getFileNames()) {
         if (file_s.toLowerCase().contains(MASTER_CONST) == false) continue;

         //..... Parse master file ......
         
         String context_s = model.getFile(file_s);
         
         List<String> context_al = removeComments(context_s);        // get text of the master file
         context_al = mergeLinesWithExtensions(context_al);
         
         for (String line_s : context_al) {
            String[] line_sa = line_s.split(DELIM_WHITE_CONST);
            if (line_sa.length >= 2) {
               String cmd_s = line_sa[0].toLowerCase();
               
               switch(cmd_s) {
               case REDIRECT_CONST:
               case BUSCOORDS_CONST:
                  String fileName_s = line_sa[1].toLowerCase();
                  String text_s = model.getFile(fileName_s);         // get text of the file   
                  if (text_s != null) {
                     fileOrder_hm.put(fileName_s, text_s);
                     model.setCommand(fileName_s, cmd_s);
                  }
                  break;
               }
            }
         }
      }
      //..... There is no master file for this model ......
         
      if (fileOrder_hm.isEmpty()) {
         for (String fileName_s : model.getFileNames()) {
            if (fileName_s.toLowerCase().contains(BUSCOORDS_CONST)) {
               model.setCommand(fileName_s, BUSCOORDS_CONST);
            }
            else {
               model.setCommand(fileName_s, REDIRECT_CONST);
            }
         }
         return false;
      }
      //..... Master file has been found ......
      
      else {
         model.setFilesMap(fileOrder_hm);
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   private static String getBusName(String name_s)
   {
      int pos = name_s.indexOf(DOT_CONST);
      if (pos >= 0) {
         name_s = name_s.substring(0, pos);
      }
      return name_s.trim();
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public static void main(String[] args) 
   {      
      org.apache.log4j.BasicConfigurator.configure();
      
      String fileName_s = "D:\\tmp_share\\OpenDSS\\GSO_Base_Network-1.zip";
      fileName_s = "D:\\tmp_share\\OpenDSS\\GSO_Base_Rural.zip";
      fileName_s = "D:\\tmp_share\\OpenDSS\\GSO_Base_Industrial.zip";
      fileName_s = "D:\\tmp_share\\OpenDSS\\Buscoords.dss";
      
      DssArchive archive = parseFile(fileName_s);
      
      for (DssModel model : archive.getModels()) {
         
         DBEntry entryInfo = model.getInfoEntry();
         entryInfo.printContent();
         
         //DBEntry entry0 = model.getEntry(null, "uclv33406");
         //entry0.printContent();
         
         for (String nodeType_s : model.getObjTypeNames()) {
            DBEntry entry = model.getEntry(nodeType_s, null);
            if (entry != null && entry.isEmpty() == false) {
               entry.printContent();
            }
            
         }
         
      }
   }
}
