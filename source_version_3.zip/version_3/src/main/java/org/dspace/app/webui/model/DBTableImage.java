package org.dspace.app.webui.model;

public interface DBTableImage 
{
   static String name = null;
   
   public static String receiveTableName() {
      return name;
   }
}
