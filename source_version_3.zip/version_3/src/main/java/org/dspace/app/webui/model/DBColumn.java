package org.dspace.app.webui.model;

import org.apache.log4j.Logger;

public class DBColumn implements DBTypes
{
   private static final Logger log = Logger.getLogger(DBColumn.class);
   
   private String  name;
   private String  type;
   private int     typeIdx;
   private int     idx;
   private Object  value;
   private String  tableName;
   private boolean autoIncrement_b;    // is this column automatically numbered
   private boolean fkey_b;             // is this column a foreign key

   public DBColumn (String name,
                    String type,
                    int    typeIdx,
                    int    idx)
   {
      this.name    = name;
      this.type    = type;
      this.typeIdx = typeIdx;
      this.idx     = idx;
      
      if (type == null) {
         this.type = DBUtils.getJDBCTypeName(typeIdx);
      }
   }
   
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getType() {
      return type;
   }
   public void setType(String type) {
      this.type = type;
   }
   public int getTypeIdx() {
      return typeIdx;
   }
   public void setTypeIdx(int typeIdx) {
      this.typeIdx = typeIdx;
   }
   public Object getValue() {
      return value;
   }
   public void setValue(Object value) {
      this.value = value;
   }
   public int getIdx() {
      return idx;
   }
   public void setIdx(int idx) {
      this.idx = idx;
   }
   public String getTableName() {
      return tableName;
   }
   public void setTableName(String tableName) {
      this.tableName = tableName;
   }
   public boolean isAutoIncrement() {
      return autoIncrement_b;
   }
   public void setAutoIncrement(boolean autoIncrement_b) {
      this.autoIncrement_b = autoIncrement_b;
   }
   public boolean isFkey() {
      return fkey_b;
   }
   public void setFkey(boolean fkey_b) {
      this.fkey_b = fkey_b;
   }

   protected DBColumn copy()
   {
      DBColumn newColumn = new DBColumn(getName(), getType(), getTypeIdx(), getIdx());
      newColumn.value    = this.getValue();
      return newColumn;
   }
   
   public boolean isIdenticalColumn (DBColumn col)
   {
      if (this.name.equals(col.getName())  &&
          this.type.equals(col.getType())  &&
          this.typeIdx == col.getTypeIdx() &&
          this.idx     == col.getIdx()) {
         return true;
      }
      return false;
   }
}
//======================================= End of Class ============================================
