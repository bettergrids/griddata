package org.dspace.app.webui.spellcheck;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.nlidb.Inflector;
import org.dspace.app.webui.nlidb.NLLexicon;
import org.dspace.app.webui.util.BGUtils;

public class SpellChecker implements NLLexicon
{
   private static final Logger log = Logger.getLogger(SpellChecker.class);
      
   //..... Constants ......
   
   private static final String COMPLEX_WORD_DELIM = "-"; 
   
   //..... Members ......
   
   private static Set<String> dict_hs   = null;
   
   //..... Methods ......
   
   public static Set<String> getDictionary() 
   {
      if (dict_hs == null) { 
         dict_hs = Dictionary.getDictionary();
      }
      return dict_hs;
   }
   //----------------------------------------------------------------------------------------------
   // Check/correct English word
   //----------------------------------------------------------------------------------------------
   
   public static String correctWord(String word_s)
   {
      if (BGUtils.isNumeric(word_s)) return word_s;
      
      //..... Create dictionary ......
      
      Set<String> dict_hs = getDictionary();
      
      //..... word_s is correct ......
      
      Inflector inf = new Inflector();
      
      String modified_s = word_s.toLowerCase().replaceAll("[,.-:;]", "");
      String single_s   = inf.singularize(modified_s);

      if(dict_hs.contains(single_s)) return modified_s;
         
      //..... Find the best similar word ...... 
      
      double maxCoeff = 0;
      double similarityCoeff;
      String suggestWord_s = null;
      
      for (String dictWord_s : dict_hs) {
         similarityCoeff = Similarity.getSimilarity(word_s, dictWord_s);
         if (similarityCoeff > maxCoeff) {
            maxCoeff      = similarityCoeff;
            suggestWord_s = dictWord_s;
         }
      }
      if (maxCoeff < 0.5) {
         String maxCoeff_s = String.format("%.3f", maxCoeff);  
         log.info("correctWord. Correction for " + word_s + " not found. Best choice: " + 
                  suggestWord_s + ". coeff = " + maxCoeff_s);         
         return word_s;
      }
      return suggestWord_s;
   }
   //----------------------------------------------------------------------------------------------
   // Check/correct phrase
   //----------------------------------------------------------------------------------------------
   
   public static String correctPhrase(String phrase_s)
   {
      if (phrase_s == null || phrase_s.isEmpty()) return "";
      
      String[] word_sa = phrase_s.split(" ");
      phrase_s = "";
      
      for (int i = 0; i < word_sa.length; i++) {
         
         // To be corrected all string characters 
         // should be letters 
         
         if (BGUtils.isNumeric(word_sa[i]) == false) {       
            List<String> word_al = BGUtils.splitSymbols(word_sa[i]);
            for (String word_s : word_al) {
               if (BGUtils.isLetterOrDigit(word_s)) {
                  if (word_s.contains(COMPLEX_WORD_DELIM)) {
                     word_s = checkComplexWord(word_sa[i]);
                  }
                  else {
                     word_s = correctWord(word_s);
                  }
               }
               if (word_s.equals(",") || word_s.equals(".")) {
                  phrase_s += word_s;
               }
               else {
                  phrase_s += " " + word_s;
               }
            }
         }
         else {
            phrase_s += " " + word_sa[i].trim();      // It's a number
         }
      }
      return phrase_s.trim();
   }
   //----------------------------------------------------------------------------------------------
   // Check complex words
   //----------------------------------------------------------------------------------------------
   
   public static String checkComplexWord(String word_s)
   {
      //..... Try to correct the entire word ......
      
      word_s = correctWord(word_s);
      if(dict_hs.contains(word_s)) return word_s;
      
      //..... Split complex word apart ...... 
      
      String[] word_sa = word_s.trim().split(COMPLEX_WORD_DELIM);    
      
      word_s = "";
      for (int i = 0; i < word_sa.length; i++) {
         word_sa[i] = correctWord(word_sa[i]);
         if (i < word_sa.length - 1) {
            word_sa[i] += COMPLEX_WORD_DELIM;
         }
         word_s += word_sa[i];
      }
      return word_s;
   }   
   //----------------------------------------------------------------------------------------------
   // Harness Function. Remove duplicate words from the dictionary text file  
   //----------------------------------------------------------------------------------------------
   
   public static boolean cleanDictionaryFile(String dictFilePath_s)
   {
      try {         
         //..... Get common words from file dictionary ......
         
         String dict_s =  BGUtils.readFile(dictFilePath_s);
         dict_s = dict_s.replace("\r", "\n").replace("\n\n", "\n");
         String[] dict_sa = dict_s.split("\n");
         
         dict_hs = new HashSet<String>(Arrays.asList(dict_sa));
         dict_s  = String.join("\n", dict_hs);
         
         boolean res_b = BGUtils.stringToFile(dict_s, dictFilePath_s);
         return res_b;
      }
      catch (Exception e) {
         log.error("cleanDictionaryFile. Cannot read/update/write dictionary file. Stack Trace: " + 
                   ExceptionUtils.getStackTrace(e));
         return false;
      }
   }
   //----------------------------------------------------------------------------------------------
   // Test spell checker
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args)
   {
      org.apache.log4j.BasicConfigurator.configure();
      
      //boolean res_b = cleanDictionaryFile(getDictFilePath());
      
      //String wrong_s   = "Courled your fins alle GRInDLABh mdles which have switches, more than twenty five nodes and also 75 fuses";
      String wrong_s   = "find a model with tim-segrige loads";
      String correct_s = correctPhrase(wrong_s);
      
      System.out.println("Wrong  : " + wrong_s + "\nCorrect: " + correct_s);
      System.exit(0);
   }
}
