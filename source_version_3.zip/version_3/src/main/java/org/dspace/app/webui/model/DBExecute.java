package org.dspace.app.webui.model;

import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Statement;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.util.BGUtils;

public class DBExecute implements DBTypes
{
   private static final Logger log = Logger.getLogger(DBExecute.class);
   
   //..... Constants ......
   
   final public static String SCHEMA_PUBLIC    = "public";
   final public static String COL_UNNAMED      = "?column?";
   final public static String COL_NAME_DEFAULT = "not found";
    
   //..... Static members ......
   
   private static String[] pgKeywords = null;
      
   //----------------------------------------------------------------------------------------------
   // Execute insert record
   //----------------------------------------------------------------------------------------------
   
   public boolean execInsert (Connection conn,
                              DBEntry    entry)
   {
      Map<Integer, DBColumn> columns_hm = entry.getTable().getColumns();
      
      ArrayList<String>  columnNames_al = new ArrayList<String>();
      ArrayList<Integer> columnTypes_al = new ArrayList<Integer>();
      ArrayList<Object>  values_al      = new ArrayList<Object>();
      
      for (int idx = 0; idx < columns_hm.size(); idx++) {
         DBColumn column = columns_hm.get(idx);
         if (column.isAutoIncrement()) continue;
         
         columnNames_al.add(column.getName());
         columnTypes_al.add(column.getTypeIdx());
         values_al.add(entry.getValue(0, idx));
      }
      //..... Call generic fucntion ......
      
      return execInsert(conn, entry.getTable().getName(), columnTypes_al, columnNames_al, values_al);      
   }
   //----------------------------------------------------------------------------------------------
   // Execute DML statement
   //----------------------------------------------------------------------------------------------
   
   public int execInsert(Connection conn,
                         String     sql_s)
   { 
      int num = 0;
      if (conn == null) {
         log.error("execInsert. Cannot establish connection");
         return -1;
      }
      //..... Execute ......
   
      PreparedStatement stmt = null;  
      try {
         stmt = conn.prepareStatement(sql_s);
         num  = stmt.executeUpdate();           // return number of inserted records
      }
      catch (Exception e) {
         log.error("DBExecute.execDML. DML SQL: " + sql_s + " Error: " + e.getMessage() + 
                   "; Stack trace: " + ExceptionUtils.getStackTrace(e));
         num = -1;
      }
      closeAll(null, stmt, null);
      return num;
   }
   //----------------------------------------------------------------------------------------------
   // Execute insert record
   //----------------------------------------------------------------------------------------------
   
   public boolean execInsert (Connection         conn,
                              String             tableName,
                              ArrayList<Integer> types,
                              ArrayList<String>  paramNames,
                              ArrayList<Object>  values)
   {
      if (values != null) {
         List<List<Object>> rows = new ArrayList<List<Object>>();
         rows.add(values);
         
         return execBulkInsert (conn, tableName, types, paramNames, rows);
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   // Execute insert record
   //----------------------------------------------------------------------------------------------
   
   public boolean execBulkInsert (Connection          conn,
                                  String              tableName,
                                  List<Integer>       types,
                                  List<String>        paramNames,
                                  List<List<Object>>  rows)
   {
      boolean res_b = true;

      //..... Verification ......
      
      int rawValuesNum = rows.get(0).size();    // number of values in the each row
      
      if (types.size() != paramNames.size()) {
         log.error("DBExecute.execBulkInsert. Table: " + tableName + ". Number of attr.names:" + 
                   paramNames.size() + " not equal attr.types: " + types.size());
         return false;
      }
      if (paramNames.size() < rawValuesNum) {
         log.error("DBExecute.execBulkInsert. Table: " + tableName + ". Number of attr.names:" + 
                   paramNames.size() + " less than number of row values: " + rawValuesNum);
         return false;     
      }
      //..... Chop attribute names and types to match real data ......
      
      if (paramNames.size() > rawValuesNum) {
         paramNames = paramNames.subList(0, rawValuesNum);
      }
      //..... Prepare procedure string ......
      
      String sql_s = "INSERT INTO " + tableName + "(";
      for (int i = 0; i < paramNames.size(); i++) {
         sql_s += paramNames.get(i) + ",";
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(",")) + ")";      // remove last comma and close statement
      
      sql_s += " VALUES (";
      for (int i = 0; i < rawValuesNum; i++) {
         sql_s += (types.get(i) == typeInet) ? "?::inet," : "?,";
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(",")) + ")";
      
      PreparedStatement stmt = null;      
      try {
         conn.setAutoCommit(false);
         stmt = conn.prepareStatement(sql_s);
         
         int i = 0;
         for (List<Object> values : rows) {      // for each row (line of values)
            
            res_b = setStatementData(conn, stmt, types, values);
            if (res_b == false) return false;
          
            stmt.addBatch();                          // Add statement to batch            
            if (++i % 10000 == 0){                    // Execute batch of 10000 records
               stmt.executeBatch();
               conn.commit();
            }
         }
         stmt.executeBatch();                         // Execute final batch
         conn.commit();
         conn.setAutoCommit(true);                    // return value back for other operations
      }
      catch (SQLException sqle) {
         log.error("DBExecute.execBulkInsert. Error in INSERT statement processing. SQL: " + sql_s + 
                   ". Message: " + sqle.getMessage() + "; Stack Trace: " + ExceptionUtils.getStackTrace(sqle));
         res_b = false;
      }
      catch (NullPointerException npe) {
         log.error("DBExecute.execBulkInsert. Null pointer: " + npe.getMessage() +
                   "; Stack Trace: " + ExceptionUtils.getStackTrace(npe));
         res_b = false;
      }
      catch (Exception e) {
         log.error("DBExecute.execBulkInsert. General Error. SQL: " + sql_s + 
                   ". Message: " + e.getMessage() + "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
         res_b = false;
      }
      finally {
         if (stmt != null) {
            try {
               stmt.close();
            } 
            catch (SQLException sqle) {
               log.error("DBExecute.execBulkInsert. Error in closing prepared statement: " + 
                          sqle.getMessage());
               res_b = false;
            }
         }
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // execUpsertEntry query implemented (example):
   //
   // WITH input (title, rating, value) AS 
   // (VALUES('testing1', 1, 'value20'),
   //        ('testing2', 1, 'value30'),
   //        ('testing1', 2, 'value40'),
   //        ('testing1', 1, 'value99')
   // ),
   // ---------------------------------
   // upsert AS (
   // UPDATE test1 t1
   //    SET value = t2.value
   //   FROM input t2
   //  WHERE t1.title  = t2.title
   //    AND t1.rating = t2.rating
   //  RETURNING t1.*
   // )
   // ---------------------------------
   // INSERT INTO test1 (title, rating, value)
   // SELECT title, rating, value
   //   FROM input 
   //  WHERE NOT EXISTS (SELECT 1 
   //                      FROM upsert t3
   //                     WHERE t3.title  = input.title
   //                       AND t3.rating = input.rating);
   //----------------------------------------------------------------------------------------------
   
   public boolean execUpsert(Connection   conn,
                             List<String> matchColNames,     // column names, matched for update
                             List<String> notUpdateCols,     // column names which should not be updated 
                             DBEntry      entry)
   {
      boolean res_b = true;
      
      if (entry == null || conn == null) {
         log.error("execUpsert. Connection and/or entry are nulls");
         return false;
      }
      DBTable table    = entry.getTable();
      String tableName = table.getName();

      //..... Prepare SQL ......

      String sql_s = "WITH input (" + getColumnCSV(table);
      sql_s += ") AS (VALUES";
     
      for (int j = 0; j < entry.getRowNum(); j++) {                  // for each record (row)
         sql_s += "(";
         for (int i = 0; i < table.getColumnNum(); i++) {            // for each column
            if (table.getColumn(i).isAutoIncrement() == false) {
               sql_s += (table.getColumn(i).getTypeIdx() == typeInet) ? "?::inet," : "?,";
            }
         }
         sql_s = sql_s.substring(0, sql_s.lastIndexOf(",")) + "),";
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(",")) + "),";     // remove last comma and close brackets
      
      sql_s += " upsert AS (UPDATE " + tableName + " t1 SET ";
      
      for (int i = 0; i < table.getColumnNum(); i++) {
         DBColumn col = table.getColumn(i);
         if (col.isAutoIncrement() == false && 
            (matchColNames == null || matchColNames.contains(col.getName()) == false) &&
            (notUpdateCols == null || notUpdateCols.contains(col.getName()) == false)) {
            sql_s += col.getName() + "=t2." + col.getName() + ",";
         }
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(","));            // remove last comma
      
      sql_s += " FROM input t2 WHERE 1=1 ";
      for (int i = 0; i < matchColNames.size(); i++) {
         sql_s += " AND t1." + matchColNames.get(i) + "=t2." + matchColNames.get(i);
      }
      sql_s += " RETURNING t1.*) INSERT INTO " + tableName + "(" + getColumnCSV(table);

      sql_s += ") SELECT " + getColumnCSV(table) + 
               " FROM input WHERE NOT EXISTS (SELECT 1 FROM upsert t3 WHERE 1=1 ";
      
      for (int i = 0; i < matchColNames.size(); i++) {
         sql_s += " AND t3." + matchColNames.get(i) + "=" + matchColNames.get(i);
      }
      sql_s += ")";

      //..... setup column type and values and insert record ......
      
      ArrayList<Integer> colTypes = new ArrayList<Integer>();
      ArrayList<Object>  values   = new ArrayList<Object>();
      
      for (int j = 0; j < entry.getRowNum(); j++) {                  // for each record (row)
         for (int i = 0; i < table.getColumnNum(); i++) {            // for each column
            if (table.getColumn(i).isAutoIncrement() == false) {              
               colTypes.add(table.getColumn(i).getTypeIdx());
               values.add(entry.getValue(j, i));
            }
         }
      }
      PreparedStatement stmt = null; 
      
      try {
         stmt = setPreparedStatement(conn, sql_s, colTypes, values);
         stmt.executeUpdate();
         if (conn.getAutoCommit() == false) {
            conn.commit();
         }
      }
      catch (SQLException sqle) {
         log.error("DBExecute.execUpsert. Error in UPSERT statement processing: " + sqle.getMessage());
         res_b = false;
      }
      catch (NullPointerException npe) {
         log.error("DBExecute.execUpsert. Null pointer: " + npe.getMessage());
         res_b = false;
      }
      catch (Exception e) {
         log.error("DBExecute.execUpsert. General Error: " + e.getMessage());
         res_b = false;
      }
      finally {
         closeAll(null, stmt, null);
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // execUpdate query implemented
   //----------------------------------------------------------------------------------------------
   
   public boolean execUpdate(Connection   conn,
                             List<String> matchColNames,    // column names, matched for update
                             List<String> updateColNames,   // column names which should updated 
                             DBEntry      entry)
   {
      boolean res_b = true;
      
      if (entry == null || conn == null) {
         log.error("execUpdate. Connection and/or entry are nulls");
         return false;
      }
      DBTable table    = entry.getTable();
      String tableName = table.getName();

      //..... Prepare SQL ......

      String sql_s = "UPDATE " + tableName + " SET ";
      
      for (int i = 0; i < updateColNames.size(); i++) {
         sql_s += updateColNames.get(i) + "= ?,";
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(","));            // remove last comma
      
      sql_s += " WHERE 1=1 ";
      if (matchColNames != null && matchColNames.isEmpty() == false) {
         for (int i = 0; i < matchColNames.size(); i++) {
            sql_s += " AND " + matchColNames.get(i) + "= ?";
         }
      }
      //..... setup column type and values and insert record ......
      
      ArrayList<Integer> colTypes = new ArrayList<Integer>();
      ArrayList<Object>  values   = new ArrayList<Object>();
      
      for (int j = 0; j < entry.getRowNum(); j++) {                  // for each record (row)
         for (int i = 0; i < updateColNames.size(); i++) {               // for each update column
            DBColumn col = table.getColumn(i);
            if (col.isAutoIncrement() == false && updateColNames.contains(col.getName())) {              
               colTypes.add(col.getTypeIdx());
               values.add(entry.getValue(j, i));
            }
         }
         if (matchColNames == null || matchColNames.isEmpty()) continue;
         
         for (int i = 0; i < matchColNames.size(); i++) {            // for each match column
            DBColumn col = table.getColumn(i);
            if (matchColNames.contains(col.getName())) {              
               colTypes.add(col.getTypeIdx());
               values.add(entry.getValue(j, i));
            }
         }
      }
      //..... Prepare statement and execute SQL ......
      
      PreparedStatement stmt = null;      
      try {
         stmt = setPreparedStatement(conn, sql_s, colTypes, values);
         stmt.executeUpdate();
         if (conn.getAutoCommit() == false) {
            conn.commit();
         }
      }
      catch (SQLException sqle) {
         log.error("execUpdate. Error in UPDATE statement processing: " + sqle.getMessage() +
                   "; Trace: " + ExceptionUtils.getStackTrace(sqle));
         res_b = false;
      }
      catch (NullPointerException npe) {
         log.error("execUpdate. Null pointer: " + npe.getMessage() +
                   "; Trace: " + ExceptionUtils.getStackTrace(npe));
         res_b = false;
      }
      catch (Exception e) {
         log.error("execUpdate. General Error: " + e.getMessage() +
                   "; Trace: " + ExceptionUtils.getStackTrace(e));
         res_b = false;
      }
      finally {
         closeAll(null, stmt, null);
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public boolean execUpdate (Connection         conn,
                              String             dbTableName,
                              List<String>       matchColNames,
                              List<List<Object>> matchRows,
                              List<String>       updateColNames,
                              List<List<Object>> updateRows)
   {
      boolean res_b = true;
      
      //..... Verification ......
      
      if (dbTableName == null) {
         log.error("execUpdate. No DB table specified");
         return false;
      }
      if (updateRows == null || updateRows.isEmpty() || updateColNames == null) {
         log.info("execUpdate. No updates for table: " + dbTableName);
         return true;
      }
      if (updateRows.isEmpty() || updateRows.get(0).size() != updateColNames.size()) {
         log.warn("execUpdate. No updates or update array and match array sizes are not equal");
         return false;
      }
      if (matchColNames != null) {
         if (matchRows == null || matchColNames.size() != matchRows.get(0).size()) {
            log.error("execUpdate. Match column name (" + matchColNames.size() + 
                      ") and value array sizes are not equal");
            return false;
         }
         if (matchRows.size() != updateRows.size()) {
            log.error("execUpdate. Match row size (" + matchRows.size() + 
                  ") and update row size (" + updateRows.size() + ") are not equal");
            return false;            
         }
      }
      //..... Prepare SQL ......

      String sql_s = "UPDATE " + dbTableName + " SET ";
      
      for (int i = 0; i < updateColNames.size(); i++) {
         sql_s += updateColNames.get(i) + "= ?,";
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(","));            // remove last comma
      
      sql_s += " WHERE 1=1 ";
      
      if (matchColNames != null && matchColNames.isEmpty() == false) {
         for (int i = 0; i < matchColNames.size(); i++) {
            sql_s += " AND " + matchColNames.get(i) + "= ?";
         }
      }
      //..... Prepare statement and execute SQL ......
      
      PreparedStatement stmt = null;      
      try {
         conn.setAutoCommit(false);
         stmt = conn.prepareStatement(sql_s);
         
         boolean match_b = true;
         if (matchRows == null || matchRows.isEmpty()) {
            match_b = false;
         }
         for (int i = 0; i < updateRows.size(); i++) {      // for each row (line of values)
            List<Object> row = updateRows.get(i);
            
            if (match_b && matchRows.get(i) != null) {      // combine column type and values
               row.addAll(matchRows.get(i));                // for 'match' and 'update' columns
            }
            //..... Set statement parameters ......
            
            res_b = setStatementData(conn, stmt, null, row);
            if (res_b == false) return false;
          
            stmt.addBatch();                 // Add statement to batch            
            if (i > 0 && i % 1000 == 0) {    // Execute batch of 1000 records
               stmt.executeBatch();
               conn.commit();
            }
         }
         int[] num = stmt.executeBatch();                         // Execute final batch
         conn.commit();
         conn.setAutoCommit(true);                    // return value back for other operations
      }
      catch (SQLException sqle) {
         log.error("execUpdate. Error in INSERT statement processing. SQL: " + sql_s + 
                   ". Message: " + sqle.getMessage() + "; " + ExceptionUtils.getStackTrace(sqle));
         res_b = false;
      }
      catch (NullPointerException npe) {
         log.error("execUpdate. Null pointer: " + npe.getMessage() + 
                   "; " + ExceptionUtils.getStackTrace(npe));
         res_b = false;
      }
      catch (Exception e) {
         log.error("execUpdate. General Error. SQL: " + sql_s + ". Message: " + e.getMessage() + 
                   "; " + ExceptionUtils.getStackTrace(e));
         res_b = false;
      }
      finally {
         if (stmt != null) {
            try {
               stmt.close();
            } 
            catch (SQLException sqle) {
               log.error("execUpdate. Error in closing prepared statement: " + 
                          sqle.getMessage() + "; " + ExceptionUtils.getStackTrace(sqle));
               res_b = false;
            }
         }
      }
      return res_b;
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private String getColumnCSV (DBTable table)
   {
      String sql_s = ""; 
      for (int i = 0; i < table.getColumnNum(); i++) {
         DBColumn col = table.getColumn(i);
         if (col.isAutoIncrement() == false) {
            sql_s += col.getName() + ",";
         }
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(","));         // remove last comma
      return sql_s;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public int execInsertNotExists(Connection conn,
                                  DBEntry    entry)   //
   {      
      int num = -1;
      if (entry == null || conn == null) {
         log.error("execInsertNotExists. Connection and/or entry are nulls");
         return num;
      }
      DBTable table    = entry.getTable();
      String tableName = table.getName();
      
      //..... Prepare SQL ......
      
      String sql_s = "INSERT INTO " + tableName + " (";

      int colNum = table.getColumnNum();
      for (int i = 0; i < colNum; i++) {
         String colName = table.getColumnNames().get(i);
         sql_s += colName + ((i < colNum - 1) ? "," : ") VALUES(");
      }
      for (int i = 0; i < colNum; i++) {                             // for each column
         if (table.getColumn(i).isAutoIncrement() == false) {
            sql_s += (table.getColumn(i).getTypeIdx() == typeInet) ? "?::inet," : "?,";
         }
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(",")) + ") ON CONFLICT DO NOTHING";

      //..... setup column type and values and insert record ......
      
      ArrayList<Integer> colTypes = new ArrayList<Integer>();
      ArrayList<Object>  values   = new ArrayList<Object>();
      
      for (int j = 0; j < entry.getRowNum(); j++) {                  // for each record (row)
         for (int i = 0; i < table.getColumnNum(); i++) {            // for each column
            if (table.getColumn(i).isAutoIncrement() == false) {              
               colTypes.add(table.getColumn(i).getTypeIdx());
               values.add(entry.getValue(j, i));
            }
         }
      }
      PreparedStatement stmt = null; 
      
      try {
         stmt = setPreparedStatement(conn, sql_s, colTypes, values);
         num  = stmt.executeUpdate();
         if (conn.getAutoCommit() == false) {
            conn.commit();
         }
      }
      catch (SQLException sqle) {
         log.error("DBExecute.execUpsert. Error in UPSERT statement processing: " + sqle.getMessage());
         num = -1;
      }
      catch (NullPointerException npe) {
         log.error("DBExecute.execUpsert. Null pointer: " + npe.getMessage());
         num = -1;
      }
      catch (Exception e) {
         log.error("DBExecute.execUpsert. General Error: " + e.getMessage());
         num = -1;
      }
      finally {
         closeAll(null, stmt, null);
      }
      return num;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
  
   public boolean execDelete(Connection        conn,
                             ArrayList<String> paramColNames,  // criteria to delete with "AND"
                             DBEntry           entry)  
   {
      boolean res_b = true;

      if (entry == null || conn == null) {
         log.error("DBExecute.execUpsert. Connection and/or entry are nulls");
         return false;
      }
      DBTable table    = entry.getTable();
      String tableName = table.getName();

      //..... Prepare SQL ......

      String sql_s = "DELETE from " + tableName + " WHERE 1=1";
      for (int i = 0; i < paramColNames.size(); i++) {
         sql_s += " AND " + paramColNames.get(i) + "= ?";
      }
      //..... Setup column type and values and execute ......
      
      PreparedStatement stmt = null;
      ArrayList<Integer> colTypes = new ArrayList<Integer>();

      for (int i = 0; i < paramColNames.size(); i++) {                     // for each criteria
         DBColumn col = table.getColumnByName(paramColNames.get(i));
         colTypes.add(col.getTypeIdx());
      }
      for (int j = 0; j < entry.getRowNum(); j++) {                        // for each record (row)
         ArrayList<Object> values = new ArrayList<Object>();
            
         for (int i = 0; i < paramColNames.size(); i++) {                  // for each criteria
            values.add(entry.getValue(j, paramColNames.get(i)));
         }
         try {
            stmt = setPreparedStatement(conn, sql_s, colTypes, values);
            stmt.executeUpdate();
            if (conn.getAutoCommit() == false) {
               conn.commit();
            }
         }
         catch (SQLException sqle) {
            log.error("DBExecute.execDelete. Error in DELETE statement processing: " + sqle.getMessage());
            res_b = false;
         }
         catch (NullPointerException npe) {
            log.error("DBExecute.execUpsert. Null pointer: " + npe.getMessage());
            res_b = false;
         }
         catch (Exception e) {
            log.error("DBExecute.execUpsert. General Error: " + e.getMessage());
            res_b = false;
         }
      }
      closeAll(null, stmt, null);
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   
   public int execDelete(Connection   conn,
                         String       tableName,
                         List<String> paramColNames,  // criteria to delete with "AND"
                         List<String> values)  
   {
      int num = 0;

      if (conn == null) {
         log.error("DBExecute.execDelete. Cannot establish connection");
         return -1;
      }
      if (paramColNames != null && paramColNames.size() != values.size()) {
         log.error("DBExecute.execDelete. Numbers of input parameters and values are different");
         return -1;
      }
      //..... Prepare SQL ......

      String sql_s = "DELETE from " + tableName + " WHERE 1=1";
      
      if (paramColNames != null) {
         for (int i = 0; i < paramColNames.size(); i++) {
            sql_s += " AND " + paramColNames.get(i) + "='" + values.get(i) + "'";
         }
      }
      //..... Execute ......
      
      PreparedStatement stmt = null;
      
      try {
         stmt = conn.prepareStatement(sql_s);
         num  = stmt.executeUpdate();
         if (conn.getAutoCommit() == false) {
            conn.commit();
         }
         log.info("DBExecute.execDelete. Deleted " + num + " record(s) from table " + tableName);
      }
      catch (Exception e) {
         log.error("DBExecute.execDelete. SQL: " + sql_s + " Error: " + e.getMessage());
         num = -1;
      }
      closeAll(null, stmt, null);
      return num;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public int execDelete(Connection conn,
                         String     sql_s)
   { 
      return execSQL(conn, sql_s);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public int execSQL(Connection conn,
                      String     sql_s)
   { 
      int num = 0;
      if (conn == null) {
         log.error("DBExecute.execSQL. Cannot establish connection");
         return -1;
      }
      //..... Execute ......
   
      PreparedStatement stmt = null;   
      try {
         stmt = conn.prepareStatement(sql_s);
         num  = stmt.executeUpdate();
         if (conn.getAutoCommit() == false) {
            conn.commit();
         }
         log.debug("DBExecute.execSQL. Executed (deleted/updated)" + num + " record(s)");
      }
      catch (Exception e) {
         log.error("DBExecute.execSQL. SQL: " + sql_s + " Error: " + e.getMessage());
         num = -1;
      }
      closeAll(null, stmt, null);
      return num;
   }
   //----------------------------------------------------------------------------------------------
   // Execute DML statement
   //----------------------------------------------------------------------------------------------
   
   public int execDML(Connection conn,
                      String     sql_s)
   { 
      int num = 0;
      if (conn == null) {
         log.error("DBExecute.execDML. Cannot establish connection");
         return -1;
      }
      //..... Execute ......
   
      PreparedStatement stmt = null;  
      try {
         stmt = conn.prepareStatement(sql_s);
         num  = stmt.executeUpdate();           // return 1 if DML work properly, otherwise return 0

         log.debug("DBExecute.execDML. Executed DML: " + sql_s);
      }
      catch (Exception e) {
         log.error("DBExecute.execDML. DML SQL: " + sql_s + " Error: " + e.getMessage());
         num = -1;
      }
      closeAll(null, stmt, null);
      return num;
   }
   //----------------------------------------------------------------------------------------------
   // Create table
   //----------------------------------------------------------------------------------------------
   
   public int createTable(Connection conn,
                          String     tableName,
                          String     parentTableName,
                          String[]   columnNames,
                          Integer[]  columnTypes,
                          String     primaryKey,
                          String     qualificator)             // temporary, unlogged, etc. 
   {      
      if (tableName == null || (columnNames == null ^ columnTypes == null)) {
         log.error("DBExecute.createTable. table name is null or column names and types not matched");
         return -1;
      }
      if (columnNames != null && columnTypes != null && columnNames.length != columnTypes.length) {
         log.error("DBExecute.createTable. Length of column names != length of column types");
         return -1;
      }
      String sql_s = "CREATE " + ((qualificator != null) ? qualificator : "") + 
                     " TABLE IF NOT EXISTS " + tableName + "(";
      
      if (columnNames != null) {
         for (int i = 0; i < columnNames.length; i++) {
            String typeName = null;
            try {
               typeName = DBUtils.getJDBCTypeName(columnTypes[i]);
            }
            catch (Exception e) {
               log.error("DBExecute.createTable. Cannot find the name for DB type: " + columnTypes[i]);
            }
            sql_s += ((i == 0) ? "" : ",") + columnNames[i] + " " + typeName;

            if (primaryKey != null && primaryKey.equalsIgnoreCase(columnNames[i])) {
               sql_s += " PRIMARY KEY";
            }
         }
      }
      sql_s += ")";           // close columns list
      
      if (parentTableName != null) {
         sql_s += " inherits(" + parentTableName + ")";
      }
      //..... Execute DML statement ......   

      int num = execDML(conn, sql_s);
      
      return num;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean validateEntry(Connection conn,
                                DBEntry    entry) throws SQLException
   {
      String tableName = entry.getTable().getName();
      
      DatabaseMetaData mtdt = conn.getMetaData();
      ResultSet        rs   = mtdt.getTables(null, SCHEMA_PUBLIC, tableName ,new String[]{"TABLE"});

      //.... TBD ......
      
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // 
   //----------------------------------------------------------------------------------------------
      
   public DBEntry execFunction(Connection         conn,
                               String             funcName,
                               ArrayList<Integer> types,
                               ArrayList<Object>  params)
   {
      DBEntry entries  = null;

      //..... Prepare procedure string ......
      
      String sql_s = "SELECT * FROM " + funcName + "(";
      for (int i = 0; i < params.size(); i++) {
         sql_s += "?,";
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(",")) + ")";
      
      PreparedStatement stmt = null; 
      ResultSet rs           = null;
      
      try {
         stmt = setPreparedStatement(conn, sql_s, types, params);

         //..... Get results ......   
         
         if (stmt != null) {
            conn.setAutoCommit(false);
            rs = stmt.executeQuery();
            entries = parseResultSet(rs, null);
         }
      }
      catch (SQLException sqle) {
         log.error("DBExecute.execFunction. Error in processing procedure " + funcName + " : " + sqle.getMessage());
         System.out.println(sqle.getMessage());
      }
      catch (NullPointerException npe) {
         log.error("DBExecute.execFunction. Error in PL/SQL procedure." + funcName + " : " + npe.getMessage());
      }
      catch (Exception e) {
         log.error("DBExecute.execFunction. General Error." + funcName + " : " + e.getMessage());
         System.out.println(e.getMessage());
      }
      finally {
         closeAll(rs, stmt, null);
      }
      return entries;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public DBEntry execQuery(Connection conn,
                            String     sql_s,
                            String[]   exclusions)
   {
      Statement stmt  = null;
      ResultSet rs    = null;
      DBEntry entries = null;
 
      try {
         stmt    = conn.createStatement();
         rs      = stmt.executeQuery(sql_s);
         entries = parseResultSet(rs, exclusions);
      }
      catch (SQLException sqle) {
         log.error("DBExecute.execQuery. Error.execQuery: in SQL " + sql_s + " : " + sqle.getMessage());
         System.out.println(sqle.getMessage());
      }
      catch (NullPointerException npe) {
         log.error("DBExecute.execQuery. Error in SQL: " + sql_s + " : " + npe.getMessage());
      }
      catch (Exception e) {
         log.error("DBExecute.execQuery. General Error." + sql_s + " : " + e.getMessage());
         System.out.println(e.getMessage());
      }
      finally {
         closeAll(rs, stmt, null);
      }
      return entries;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public DBEntry execSimpleSelect(Connection    conn,
                                   String        tableName,
                                   List<String>  colNames,     // criteria to select with "AND"
                                   List<String>  operators,    // operators: <, > =, >=, etc.
                                   List<String>  values,
                                   List<Integer> types) 
   {
      String sql_s = "SELECT * FROM " + tableName + " WHERE ";
      
      for (int i = 0; i < colNames.size(); i++) {
         if (types.get(i) == typeVarchar     || types.get(i) == typeText ||
             types.get(i) == typeLongVarchar || types.get(i) == typeChar ||
             types.get(i) == typeUUID        || types.get(i) == typeInet) {
            values.set(i, "'" + values.get(i) + "'");
         }
         sql_s += colNames.get(i) + operators.get(i) + values.get(i) + 
                  ((i == colNames.size() - 1) ? "" : " AND "); 
      }
      DBExecute exec  = new DBExecute();  
      DBEntry   entry = exec.execQuery(conn, sql_s, null);
      
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   protected DBEntry parseResultSet(ResultSet rs,
                                    String[]  exclusions)  // list of column which should not be returned
   {
      DBEntry entry = new DBEntry();
      DBTable tab   = new DBTable();
      entry.setTable(tab);
      
      try {
         ResultSetMetaData md = rs.getMetaData();
         int colNum = md.getColumnCount();         
         
         for (int i = 1; i <= colNum; i++) {
            String rsColName = md.getColumnName(i);
            if (rsColName.equals(COL_UNNAMED)) {
               rsColName = COL_NAME_DEFAULT;
            }
            //rsColName = DBUtils.formColumnName(rsColName);  // format name for presentation
            
            if (exclusions != null && DBUtils.contains(exclusions, rsColName)) continue;
                        
            DBColumn col = new DBColumn(rsColName, null, md.getColumnType(i), i - 1);            
            if (md.isAutoIncrement(i)) {
               col.setAutoIncrement(true);
            }
            col.setTableName(md.getTableName(i));
            tab.addColumn(i - 1, col);
         }
         while (rs.next()) {
            Map <Integer, Object> row = entry.newRow();

            for (Map.Entry<Integer, DBColumn> colEntry : tab.getColumns().entrySet()) {
               int rsIdx   = colEntry.getKey() + 1;   
               int colIdx  = rsIdx - 1;        
               int typeIdx = tab.getColumn(colIdx).getTypeIdx();
               
               switch(typeIdx) {
               case typeInt:
                  Integer valueInt = rs.getInt(rsIdx);
                  valueInt = rs.wasNull() ? null : valueInt;                  
                  entry.setRowValue(row, colIdx, valueInt);
                  break;
               case typeLong:
                  Long valueLong = rs.getLong(rsIdx);
                  valueLong = rs.wasNull() ? null : valueLong;                  
                  entry.setRowValue(row, colIdx, valueLong);
                 break;                  
               case typeDate:
               case typeTimestamp:
                  Object value = rs.getTimestamp(rsIdx);
                  if (value != null) {
                     value = new java.util.Date(((java.sql.Timestamp)value).getTime());
                  }
                  entry.setRowValue(row, colIdx, value);
                  break;
               case typeTimestampTZ:
                  Instant valueTimestampTZ = rs.getObject(rsIdx, Instant.class);
                  entry.setRowValue(row, colIdx, valueTimestampTZ);
                  break;
               case typePgArray:
                  Array arr = rs.getArray(rsIdx);
                  if (arr != null) {
                     entry.setRowValue(row, colIdx, (Object[])arr.getArray()); 
                  }
                  else {
                     entry.setRowValue(row, colIdx, null); 
                  }
                  break;
               case typeText:
                  entry.setRowValue(row, colIdx, rs.getString(rsIdx));   
                  break;
               case typeNumeric:
                  entry.setRowValue(row, colIdx, rs.getBigDecimal(rsIdx));   
                  break;
               case typeBit:
               case typeBoolean:
                  entry.setRowValue(row, colIdx, rs.getBoolean(rsIdx));   
                  break;
               case typeOther:                                                      // code: 1111
                  String colName = tab.getColumn(colIdx).getName().toLowerCase();
                  if (colName.contains(uuidTypeName) == true || colName.contains(uidTypeName) == true) {   // UUID
                     UUID uuid = (UUID)rs.getObject(rsIdx);
                     entry.setRowValue(row, colIdx, uuid);
                  }
                  else {
                     entry.setRowValue(row, colIdx, rs.getObject(rsIdx));           // All others
                  }
                  break;
               default:                                                          
                  entry.setRowValue(row, colIdx, rs.getObject(rsIdx));              // All others
                  break;
               }
            }
            entry.addRow(row);
         }
      }
      catch (SQLException e) {
         log.error("DBExecute.parseResultSet. Error in parsing of the ResultSet: " + e.getMessage());
         return null;
      }      
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
    
   private PreparedStatement setPreparedStatement(Connection         conn,
                                                  String             sql_s,
                                                  ArrayList<Integer> types,
                                                  ArrayList<Object>  params) throws SQLException, 
                                                                                    UnknownHostException
   {
      if (types.size() != params.size()) {
         log.error("DBExecute.setPrepareStatement. Sizes of input arrays are not equal." );
         return null;
      }
      PreparedStatement stmt = conn.prepareStatement(sql_s);
      
      boolean res_b = setStatementData(conn, stmt, types, params);
      if (res_b == false) return null;
      
      return stmt;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private boolean setStatementData(Connection        conn,
                                    PreparedStatement stmt,
                                    List<Integer>     types,
                                    List<Object>      params) throws SQLException, 
                                                                     UnknownHostException
   {
      int     sqlIdx;
      Object  val = null;

      for (int i = 0; i < params.size(); i++) {
         sqlIdx   = i + 1;         
         val = params.get(i);
         
         int typeIdx;
         if (types == null) {
            typeIdx = getObjectType(val);
         }
         else {
            typeIdx = types.get(i);
         }
         if ((val == null || val.toString().isEmpty()) && typeIdx != typeUUID && typeIdx != typeInet) {
            stmt.setNull(sqlIdx, typeIdx);
            continue;
         } 
         //..... Mapping ......
            
         switch(typeIdx) {            
         case typeInt:
         case typeSmallInt:
            if (val instanceof Integer) stmt.setInt(sqlIdx, (Integer)val);
            else                        stmt.setInt(sqlIdx, Integer.parseInt(val.toString()));
            break;
         case typeLong:
         case typeNumeric:
            if (val instanceof BigDecimal) stmt.setBigDecimal(sqlIdx, (BigDecimal)val);
            else                           stmt.setBigDecimal(sqlIdx, new BigDecimal(val.toString()));
            break;
         case typeDouble:
            if (val instanceof Double) stmt.setDouble(sqlIdx, (Double)val);
            else                       stmt.setDouble(sqlIdx, Double.parseDouble(val.toString()));
            break;
         case typeReal:
            if (val instanceof Float) stmt.setFloat(sqlIdx, (Float)val);
            else                      stmt.setFloat(sqlIdx, Float.parseFloat(val.toString()));
            break;
         case typeBit:
         case typeBoolean:       stmt.setBoolean(sqlIdx,    (Boolean)val);    break; 
         case typeChar:       
         case typeLongVarchar:
         case typeVarchar:       stmt.setString(sqlIdx,     val.toString());  break;
         case typeXML:           stmt.setSQLXML(sqlIdx,     (SQLXML)val);     break;
         
         case typeUUID:          
            if (val instanceof UUID) stmt.setObject(sqlIdx, val);
            else                     stmt.setObject(sqlIdx, BGUtils.getUUID((String)val));
            break;
         case typeInet:
            if (val instanceof InetAddress) stmt.setObject(sqlIdx, ((InetAddress)val).getHostAddress());
            else if (val instanceof String) stmt.setObject(sqlIdx, InetAddress.getByName((String)val)); 
            else                            stmt.setObject(sqlIdx, val.toString());
            break;
         case typeDate:          //stmt.setDate(sqlIdx,       (java.sql.Date)((Date)valueObj));                    break;
         case typeTimestamp:     //stmt.setTimestamp(sqlIdx,  new java.sql.Timestamp(((Date)valueObj).getTime())); break;
         case typeTimestampTZ:   //stmt.setTimestamp(sqlIdx,  new java.sql.Timestamp(((Date)valueObj).getTime())); break;
            try {
               Instant valInstant = null;
               if (val instanceof Date) {
                  valInstant = ((Date)val).toInstant();
               }
               else if (val instanceof Instant) {
                  valInstant = (Instant)val;
               }
               OffsetDateTime dateTimeTz = OffsetDateTime.ofInstant(valInstant, ZoneId.of(DBProvider.TimeZoneId));                 
               stmt.setObject(sqlIdx, dateTimeTz);
               break;
            }
            catch(Exception e) {
               log.error("DBExecute.setPreparedStatement. Value: " + val + " cannot be converted to Date/Time");                  
            }
            stmt.setNull(sqlIdx, types.get(i));
            break;
         case typePgArray:
            try {
               Array sql_arr = null;
               if (val instanceof String[]) {
                  sql_arr = (Array)conn.createArrayOf(textTypeName, (String[])val);
               }
               else if (val instanceof Double[]) {
                  sql_arr = (Array)conn.createArrayOf(doubleTypeName, (Double[])val);
               }
               else if (val instanceof Integer[]) {
                  sql_arr = (Array)conn.createArrayOf(intTypeName, (Integer[])val);
               }
               else if (val instanceof String[][]) {
                  sql_arr = (Array)conn.createArrayOf(textTypeName, (String[][])val);
               }
               else {
                  log.error("setPreparedStatement. Value: " + val + " of unknown type cannot be converted to SQL array");
                  return false;
               }
               stmt.setArray(sqlIdx, sql_arr); 
               break;
            }
            catch (Exception e) {
               log.error("DBExecute.setPreparedStatement. Value: " + val + " cannot be converted to SQL array. " +
                         ExceptionUtils.getStackTrace(e));
               return false;
            }
            //stmt.setNull(sqlIdx, types.get(i));
            //break;
         default:
            log.error("DBExecute.setPreparedStatement. " + types.get(i) + " not supported as a parameter type");
            return false;
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public DBEntry getMetadataFromDB(String dbName,
                                    String tableName)
   {
      Connection conn = new DBConnection(dbName).getConnection();
      if (conn == null) {
         log.error("DBExecute.getMetadataFromDB. Cannot get connection to DB: " + dbName);
         return null;
      }
      DBEntry entry = getMetadataFromDB(conn, tableName);
      closeAll(null, null, conn);
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   
   public DBEntry getMetadataFromDB(Connection conn,
                                    String     tableName)
   {
      String sql_s = "SELECT * FROM " + tableName + " limit 0";
      DBEntry entry = execQuery(conn, sql_s, null);
      entry.getTable().setName(tableName);
      
      ResultSet foreignKeys = null;
      try {
         DatabaseMetaData metaData = conn.getMetaData();
         foreignKeys = metaData.getImportedKeys(conn.getCatalog(), null, tableName);
   
         while (foreignKeys.next()) {
            //  String fkTableName = foreignKeys.getString("FKTABLE_NAME");       // FK table = this tableName
            String fkColumnName = foreignKeys.getString("FKCOLUMN_NAME");     // FK column in the table
            //  String pkTableName = foreignKeys.getString("PKTABLE_NAME");       // parent table FK points to
            //  String pkColumnName = foreignKeys.getString("PKCOLUMN_NAME");     // parent column FK points to

            entry.getTable().getColumnByName(fkColumnName).setFkey(true);
            entry.getTable().addFkey(fkColumnName);
         }
      }
      catch (Exception e) {
         log.error("DBExecute.getMetadataFromDB. Cannot get metadata for table : " + tableName);
      }
      finally {
         closeAll(foreignKeys, null, null);
      }
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   // Get PostgreSQL version
   //----------------------------------------------------------------------------------------------

   public static String getPostgresVersion(Connection conn)
   {
      try {
         DatabaseMetaData metaData = conn.getMetaData();
         return metaData.getDatabaseProductVersion();
      }
      catch (Exception e) {
         log.error("DBExecute.getPostgresVersion. Cannot get DB metadata");
      }
      return null;
   }   
   //----------------------------------------------------------------------------------------------
   // Add column (attribute) to the table if not exists
   //----------------------------------------------------------------------------------------------
      
   public boolean addColumns(Connection conn,
                             String     dbTableName,    // table name in DB
                             DBTable    table)          // table with columns to add to DB 
   {
      //..... Get columns .....
      // modify table column names to avoid conflicts with DB keyword (add "_")

      modifyColumnNames(conn, table);
      
      List<String> dbColumnNames    = getDBColumnNames(conn, dbTableName);    // DB columns
      List<String> entryColumnNames = table.getColumnNames();                 // Entry columns
      
      dbColumnNames    = new ArrayList<String>(dbColumnNames);
      entryColumnNames = new ArrayList<String>(entryColumnNames);     
      
      //..... Remove all DB columns from entry column list ......
      
      entryColumnNames.removeAll(dbColumnNames);
      
      //..... Insert to DB table only new columns ......
      
      if (entryColumnNames.isEmpty()) return true;
      
      String sql_s = "ALTER TABLE " + dbTableName;
      for (String colName : entryColumnNames) {
         sql_s += " ADD COLUMN " + colName + " " + table.getColumnByName(colName).getType() + ",";
      }
      sql_s = sql_s.substring(0, sql_s.length() - 1);      // remove last comma

      int num = execDML(conn, sql_s);
      if (num == -1) return true;       // return true even for error, because it is 
                                        // probably related to that column already exists
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Add column (attribute) to the table if not exists
   //----------------------------------------------------------------------------------------------
      
   public boolean addAttrColumns(Connection conn,
                                 String     dbTableName,    // table name in DB
                                 BGModel    model,
                                 int        sectIdx)        // index of the object type
   {
      //..... Get columns .....
      
      List<String> dbColumnNames  = getDBColumnNames(conn, dbTableName);  // DB columns
      List<String> modelAttrNames = model.getAttrNames(sectIdx);          // Model type attributes
      
      dbColumnNames  = new ArrayList<String>(dbColumnNames);
      modelAttrNames = new ArrayList<String>(modelAttrNames);
      BGUtils.toLowerCase(modelAttrNames);
      
      //..... Remove all DB columns from entry column list ......
      
      modelAttrNames.removeAll(dbColumnNames);
      
      //..... Insert to DB table only new columns ......
      
      if (modelAttrNames.isEmpty()) return true;
      
      String sql_s = "ALTER TABLE " + dbTableName;
      for (String colName : modelAttrNames) {
         Integer attrIdx     = model.getAttrIdx(sectIdx, colName);
         String attrTypeName = model.getAttrTypeName(sectIdx, attrIdx);
         
         if (attrIdx == null || attrTypeName == null) return false;
         
         sql_s += " ADD COLUMN " + colName.toLowerCase() + " " + attrTypeName + ",";
      }
      sql_s = sql_s.substring(0, sql_s.length() - 1);      // remove last comma

      int num = execDML(conn, sql_s);
      if (num == -1) return true;       // return true even for error, because it is 
                                        // probably related to that column already exists
      return true;
   }   
   //----------------------------------------------------------------------------------------------
   // Get column names of specified table
   //----------------------------------------------------------------------------------------------

   public List<String> getDBColumnNames(Connection conn,
                                        String     tableName)
   {
      ResultSet rs     = null;
      List<String> colNames_al = new ArrayList<String>();

      try {
         DatabaseMetaData dbmd = conn.getMetaData();
         rs = dbmd.getColumns(null, null, tableName, null);
         while (rs.next()) {
            colNames_al.add(rs.getString("COLUMN_NAME"));
         }
      }
      catch (Exception e) {
         log.error("DBExecute.getColumnNames. Cannot get metadata for table: " + tableName + 
                   ". Error msg: " + e.getMessage());
         System.out.println(e.getMessage());
      }
      finally {
         closeAll(rs, null, null);
      }
      return colNames_al;
   }  
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public void modifyColumnNames(Connection   conn,
                                 List<String> colNames)
   {
      String[] keywords_sa = getPgKeywords(conn); 
      for (int i = 0; i < colNames.size(); i++) {
         String colName = colNames.get(i);
         if (BGUtils.getStringIdx(colName, keywords_sa) > -1) {
            colNames.set(i, "_" + colName);
         }
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public void modifyColumnNames(Connection conn,
                                 DBTable    table)
   {
      String[] keywords_sa = getPgKeywords(conn); 
         
      for (DBColumn column : table.getColumns().values()) {
         String colName  = column.getName();
         if (BGUtils.getStringIdx(colName, keywords_sa) > -1) {
            column.setName("_" + colName.toLowerCase());
         }
         else {
            column.setName(colName.toLowerCase());
         }        
      }
   }
   //----------------------------------------------------------------------------------------------
   // Get object type based on instanceof
   //----------------------------------------------------------------------------------------------
   
   public int getObjectType(Object value)
   {
      if      (value instanceof String)      return typeText;
      else if (value instanceof Double)      return typeDouble;
      else if (value instanceof Integer)     return typeInt;
      else if (value instanceof Boolean)     return typeBoolean;
      else if (value instanceof Date)        return typeDate;
      else if (value instanceof UUID)        return typeUUID;
      else if (value instanceof InetAddress) return typeInet;
      else if (value instanceof String[])    return typeTextArray;
      else if (value instanceof Integer[])   return typeIntArray;
      else if (value instanceof int[])       return typeIntArray;
      else if (value instanceof Double[])    return typeDoubleArray;
      else if (value instanceof double[])    return typeDoubleArray;
      else if (value instanceof Instant)     return typeTimestampTZ;
            
      return typeVarchar;      // default value
   }
   //----------------------------------------------------------------------------------------------
   // Get type from row values
   //----------------------------------------------------------------------------------------------
   
   public Integer[] getTypesFromValues(List<List<Object>> rows)
   {
      if (rows == null || rows.isEmpty()) return null;
         
      int columnNum = rows.get(0).size();
      Integer[] types = new Integer[columnNum];
      
      for (List<Object> row : rows) {
         for (int i = 0; i < columnNum; i++) {
            if (types[i] == null) {
               types[i] = getObjectType(row.get(i));
            }
         }
         if (Arrays.asList(types).contains(null) == false) break;
      }
      return types;
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public String[] getPgKeywords(Connection conn)
   {
      if (pgKeywords == null) {
         String sql_s = "SELECT word FROM pg_get_keywords() WHERE catcode='R'";
         
         DBEntry entry = execQuery(conn, sql_s, null);
         
         List<String> keywords_al = new ArrayList<String>();
         for (int i = 0; i < entry.getRowNum(); i++) {
            keywords_al.add(entry.getRawStringValue(i, 0));            
         }
         pgKeywords = keywords_al.toArray(new String[keywords_al.size()]);
      }    
      return pgKeywords;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public boolean closeConn(Connection conn)
   {
      return closeAll(null, null, conn);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean closeAll(ResultSet  rs,
                           Statement  stmt,
                           Connection conn)
   {
      boolean res_b = true;
      
      if (rs != null) { 
         try {
            rs.close(); 
         } 
         catch (SQLException e) {
            log.error("closeAll. Cannot close resultset: " + e.getMessage());
            res_b = false;
         }
      }
      if (stmt != null) {
         try {
            stmt.close();
         } 
         catch (SQLException e) {
            log.error("closeAll. Cannot close statement: " + e.getMessage());
            res_b = false;
         }
      }
      if (conn != null) {
         try {
            conn.close(); 
         } 
         catch (SQLException e) {
            log.error("closeAll. Cannot close statement: " + e.getMessage());
            res_b = false;
         }
      }
      return res_b;
   }
}
//======================================= End of Class ============================================ 
