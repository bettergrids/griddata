package org.dspace.app.webui.parser.gridlab;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.parser.BGItem;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.util.BGUtils;

public class GlmParser {

   private static final Logger log = Logger.getLogger(GlmParser.class);
   
   //..... Constants ......
   
   public static final String COMMENT_CONST      = "//";
   public static final String OBJECT_CONST       = "object";
   public static final String MODULE_CONST       = "module";
   public static final String CLOCK_CONST        = "clock";
   public static final String OPEN_CONST         = "{";
   public static final String CLOSE_CONST        = "}";
   public static final String END_LINE_CONST     = ";";
   
   public static final String RECORDER_CONST     = "recorder";
   public static final String PARENT_CONST       = "parent";
   public static final String FILE_CONST         = "file";
   public static final String NAME_CONST         = "name";
   public static final String OBJ_INDEX_CONST    = "index";
   public static final String FROM_CONST         = "from";
   public static final String TO_CONST           = "to";
   public static final String LENGTH_CONST       = "length";

   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static GlmModel parseFile(String file_s) 
   {
      int       idx1;
      boolean   isInside  = false;            // is this line inside the object parsing
      GlmModel  model     = new GlmModel();
      GlmObject obj       = null;
      int       parentIdx = 0;
      
      //..... Read input file ......
   
      try (BufferedReader br = new BufferedReader(new FileReader(file_s))) {
         do {         
            String line_s = br.readLine();            
            if (line_s == null) break;
            if (line_s.isEmpty()) continue;
            line_s = line_s.trim();
            
            //..... Remove comments ......
         
            idx1 = line_s.indexOf(COMMENT_CONST);
            if (idx1 == 0) continue;
            else if (idx1 > -1) {
               line_s = line_s.substring(0, idx1).trim();
            }
            line_s = line_s.replaceAll("\\s+"," ");         // replace all duplicate white spaces and LFs
            
            //..... Parse object type (first line) ......
            
            if (isInside == false) {
               if (line_s.startsWith(OBJECT_CONST + " ") && line_s.endsWith(OPEN_CONST)) {
                  obj = new GlmObject();
                  isInside = true;
                  line_s   = BGUtils.removeLastString(line_s, OPEN_CONST);      
                  String[] word_sa = line_s.trim().split("[ :]+");      // split on " " and ":"
                  if (word_sa.length > 1) {
                     obj.setType(word_sa[1]);
                     
                     if (word_sa.length > 2) {
                        obj.setId(Integer.parseInt(word_sa[2]));
                        obj.setFullId(word_sa[1] + ":" + word_sa[2]);
                     }
                     else {
                        obj.setFullId(word_sa[1]);
                     }
                  }
                  else {
                     log.error("GlmParser.parseFile. No object type specified: " + line_s);
                     return null;
                  }
                  if (obj.getId() != null) {
                     GlmAttr attr = new GlmAttr();
                     attr.setName(OBJ_INDEX_CONST);
                     attr.setAttrValue(obj.getId().toString());
                     obj.addAttr(attr);
                  }
               }
               else if (line_s.startsWith(MODULE_CONST + " ")) {
                  //TBD
               }
               else if (line_s.startsWith(CLOCK_CONST + " ")) {
                  //TBD
               }
               else {
                  //TBD
               }
            }
            //..... Parse object attributes (inside object) ......
            
            else {    
               if (line_s.startsWith(CLOSE_CONST)) {     // closing object

                  //..... Special cases ......

                  if (obj.getType().equalsIgnoreCase(RECORDER_CONST)) {
                     GlmAttr parentAttr = obj.getAttrObj(PARENT_CONST);
                     if (parentAttr != null) {
                        obj.setFullId(RECORDER_CONST + "_" + parentAttr.getValue());
                     }
                  }
                  //..... Set object "name" if it does not exist ......
                  
                  obj.getName();
                  
                  // if object does not have numeric id, and has only type
                  // build fullId as a type and object name to make object unique
                  
                  if (obj.getId() == null) {
                     obj.setFullId(obj.getFullId() + "__" + UUID.randomUUID().toString());
                  }
                  obj.setModel(model);
                  model.addObject(obj);         // add object to the model

                  isInside = false;
                  
                  //..... Process "parent-child" relation ......
                  // Create artificial object of the "parent" type
                  
                  String parent_s = (String)obj.getAttr(PARENT_CONST);
                  if (parent_s != null) {
                     
                     GlmObject parentObj = new GlmObject();
                     parentObj.setFullId(UUID.randomUUID().toString());
                     parentObj.setType(PARENT_CONST);
                     parentObj.setModel(model);
                     parentObj.setName(PARENT_CONST + "_" + parentIdx);
                     parentObj.setId(parentIdx);
                     
                     GlmAttr fromAttr = new GlmAttr();
                     fromAttr.setName(GlmModel.FROM_NAME);
                     fromAttr.setAttrValue(parent_s);

                     GlmAttr toAttr = new GlmAttr();
                     toAttr.setName(GlmModel.TO_NAME);
                     toAttr.setAttrValue(obj.getName());
                     
                     parentObj.addAttr(fromAttr);
                     parentObj.addAttr(toAttr);
                     model.addObject(parentObj);
                     
                     parentIdx++;
                  }
                  continue;
               }
               if (line_s.endsWith(GlmParser.END_LINE_CONST) == false) {
                  log.error("GlmParser.parseFile. Object line not closed with \"" + END_LINE_CONST + "\":" + line_s);
                  return null;
               }
               //..... Parse attribute line ......
               
               int pos = line_s.indexOf(" ");
               String attrName = line_s.substring(0, pos).trim();
               if (attrName.equalsIgnoreCase(FROM_CONST) || attrName.equalsIgnoreCase(TO_CONST)) {
                  attrName = "_" + attrName.toLowerCase();
               }
               GlmAttr attr = new GlmAttr();
               attr.setName(attrName);
               String attrValue = line_s.substring(pos).trim();
               
               // Remove units from the attribute "Length"
               // to avoid issues while inserting to the numeric DB field
               
               if (attrName.equalsIgnoreCase(LENGTH_CONST)) {
                  String[] attrValue_sa = attrValue.split(" ");
                  if (attrValue_sa.length > 1) {
                     attrValue = attrValue_sa[0];
                  }
               }
               attr.setAttrValue(attrValue);

               //..... Add attribute to the object ......
               
               obj.addAttr(attr);
            }
         }
         while (true);
      }
      catch (FileNotFoundException e) {
         log.error("GlmParser.parseFile. File " + file_s + " not found. " + e.getMessage());
         return null;
      } 
      catch (IOException e) {
         log.error("GlmParser.parseFile. General error in parsing file " + file_s + ". " + e.getMessage());
         return null;
      }
      //..... Model attributes ......
      
      //model.setDspaceId(BGUtils.getNameFromFile(file_s));
      model.setName(BGUtils.getNameFromFile(file_s));
      model.setPath(file_s);
      model.calcTypeCounts();
      model.setFormat(BGModel.MODEL_FORMAT_GRIDLAB);
      model.setFormatVersion(null);
      
      return model;
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public static void main(String[] args) 
   {      
      org.apache.log4j.BasicConfigurator.configure();
      
      GlmModel model5 = parseFile("D:\\tmp_share\\R4-25.00-1.glm");
      String json_s = model5.toJson();
      
      DBEntry entry   = model5.getEntry("node", "R4-25-00-1_node_226");
      entry.printContent();
      entry   = model5.getEntry(null, "triplex_line_configuration:1");
      entry.printContent();
      
      GlmModel model0 = parseFile("C:\\tmp_share\\AL0001_glmfile_equip_manual.glm");
      
      entry   = model0.getEntry(null, "N_900019002_Cap");
      entry.printContent();
      
      
      
      BGUtils.stringToFile(json_s, "C:\\tmp_share\\AL0001_glmfile_equip_manual.json");
      
      GlmModel model1 = parseFile("C:\\tmp_share\\R1-25.00-1.glm");
      json_s = model1.toJson();
      BGUtils.stringToFile(json_s, "C:\\tmp_share\\R1-25.00-1.json");
            
      GlmModel model2 = parseFile("C:\\tmp_share\\R4-25.00-1.glm");
      json_s = model2.toJson();    
      BGUtils.stringToFile(json_s, "C:\\tmp_share\\R4-25.00-1.json");
      
      BGItem item = new BGItem();
      item.setDspaceUID(UUID.fromString("0f2eff25-0d7e-4a84-826b-3a706edc1d94"));
      
      item.addModel(model0);
      item.addModel(model1);
      item.addModel(model2);
      
      item.populateMetadata();
      
      //DBEntry entry = model.getInfoEntry();
      //DBEntry entry = model1.getEntry(null, null);
      //DBEntry entry = model1.getEntry(null, "transformer_configuration:42");
      //entry.printContent();
      
      
   }
}
//======================================= End of Class ============================================
