package org.dspace.app.webui.parser.powerworld;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGParser;
import org.dspace.app.webui.parser.BGTypes;
import org.dspace.app.webui.util.BGUtils;

//=================================================================================================
// DATA DataName(object_type, [list_of_fields], file_type_specifier, create_if_not_found)
//{ 
// data_list_1 
// ........
// data_list_n 
// }
//=================================================================================================

public class PowParser extends BGParser 
{
   private static final Logger log = Logger.getLogger(PowParser.class);
   
   //..... Constants ......
   
   public static final String COMMENT_CONST       = "//";
   public static final String OBJECT_CONST        = "data";
   public static final String SECT_OPEN_CONST     = "{";
   public static final String SECT_CLOSE_CONST    = "}";
   public static final String ATTR_OPEN_CONST     = "[";
   public static final String ATTR_CLOSE_CONST    = "]";
   public static final String HEAD_OPEN_CONST     = "(";
   public static final String HEAD_CLOSE_CONST    = ")";
   public static final String COMMA_CONST         = ",";
   public static final String SUBDATA_OPEN_CONST  = "<SUBDATA";
   public static final String SUBDATA_CLOSE_CONST = "</SUBDATA>";
   
   public static final String NUM_SUFFIX_CONST    = "Num";
   
   //..... Ignore sections started with this prefix ......
   
   public static final String[] SECT_VALID_SA      = {PowModel.TYPE_NAME_INFO, PowModel.TYPE_NAME_OWNER,
                                                      PowModel.TYPE_NAME_BUS, PowModel.TYPE_NAME_LOAD, 
                                                      PowModel.TYPE_NAME_GENERATOR, PowModel.TYPE_NAME_SHUNT,
                                                      PowModel.TYPE_NAME_TRANSFORMER, PowModel.TYPE_NAME_BRANCH,
                                                      PowModel.TYPE_NAME_AREA, PowModel.TYPE_NAME_ZONE, 
                                                      PowModel.TYPE_NAME_SUBSTATION, PowModel.TYPE_NAME_MULTILINE,
                                                      PowModel.TYPE_NAME_LINE, PowModel.TYPE_NAME_XFORMER};
         
   public static final String   IGNORE_TYPE_CONST   = "__ignore_";
   
   public static final String[] SUFFIX_REMOVE_SA    = {"Num3W", "Num"};
   
   //..... Map constants ......
   
   public static final String POW_BUS_FROM   = "BusNum";
   public static final String POW_BUS_TO     = "BusNum:1";
   public static final String POW_SUB        = "sub";
   public static final String POW_GEN        = "gen";   
  
   public static final String[] POW_TYPES_IN_SA  = {POW_SUB, POW_GEN, PowModel.TYPE_NAME_MULTILINE};
   public static final String[] POW_TYPES_OUT_SA = {PowModel.TYPE_NAME_SUBSTATION, 
                                                    PowModel.TYPE_NAME_GENERATOR,
                                                    BGTypes.BGTYPE_MULTI_SECTION_LINE};   
   //..... Members ......
   
   private static Map<String,String> termMapper = new HashMap<String,String>();  // pow.term->new term
   
   //..... Constructor .....
   
   public PowParser(String file_s) throws FileNotFoundException 
   {
      super(file_s);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static PowModel parseFile(String file_s) 
   {
      boolean  isInside  = false;                       // is this line inside the object parsing
      PowModel model     = new PowModel(); 
      String   objType_s = null;
      int      attrNum   = 0;
      boolean  res_b     = true;
      
      //..... Read input file ......

      try {
         BGParser parser = new BGParser(file_s);
         parser.setDoNormalize(true);
         parser.setSkipEmpty(true);
         parser.setComments(COMMENT_CONST);
      
         do {
            String line_s = parser.getLine();
            if (line_s == null) break;

            //..... Data Declaration line ......
            
            if (isInside == false) {
               if (line_s.toLowerCase().startsWith(OBJECT_CONST)) {
                  objType_s = parseSectDeclaration(parser, model, line_s);
                  if (objType_s.equals(IGNORE_TYPE_CONST)) {
                     continue;
                  }
                  attrNum   = model.getAttrNames(objType_s).size();
                  isInside  = true;
               }
               // ignore other sections
            }
            //..... Data line ......
            
            else {
               res_b &= parseObjects(parser, model, objType_s, attrNum, line_s);
               isInside = false;
            }
         }
         while (true);
      }
      catch (FileNotFoundException e) {
         log.error("PowParser.parseFile. File " + file_s + " not found. " + e.getMessage());
         return null;
      } 
      catch (IOException e) {
         log.error("PowParser.parseFile. General I/O error in parsing file " + file_s + ". " + e.getMessage() +
                   "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
         return null;
      }
      catch (Exception e) {
         log.error("PowParser.parseFile. File: " + file_s + ". " + e.getMessage() +
                   "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
         return null;
      }
      //..... Post-processing ......

      updateObjectTypes(model);              // Change object type if necessary
      updateAttrNames(model);                // Remove leading "_" from attribute names
      removeDuplicateTypes(model);           // remove duplicate type, like: "area-1"
      
      //..... Model attributes ......
      
      //model.setDspaceId(BGUtils.getNameFromFile(file_s));
      model.setName(BGUtils.getNameFromFile(file_s));
      model.setPath(file_s);
      model.calcTypeCounts();
      model.setFormat(BGModel.MODEL_FORMAT_POWERWORLD);
      
      return model;
   }
   //----------------------------------------------------------------------------------------------
   // Parse DATA declaration block
   //----------------------------------------------------------------------------------------------
   
   private static String parseSectDeclaration(BGParser parser,
                                              PowModel model,
                                              String   line_s) throws IOException              
   {
      String objType_s = null;
      
      //..... Get entire declaration block ......
      
      while (line_s.contains(HEAD_CLOSE_CONST) == false) {
         String line1_s = parser.getLine();
         if (line1_s == null) {
            log.error("parseSectDeclaration. Got unexpected null when reading next line after: " + line_s);
            return null;
         }
         line_s += line1_s;
      }
      line_s = line_s.replaceAll("\\s+"," ");         // replace all duplicate white spaces and LF/CR      
      
      //..... Parse object (section) type ......
      
      int idx0 = line_s.indexOf(HEAD_OPEN_CONST) + 1;
      int idx1 = line_s.indexOf(COMMA_CONST);
      int idx2 = line_s.indexOf(ATTR_OPEN_CONST) + 1;
      
      if (idx0 >= 0 && idx1 > idx0 && idx2 > idx1) {
         objType_s = line_s.substring(idx0, idx1).toLowerCase().trim();    // extract an object type
         objType_s = remapTerm(objType_s);
         line_s    = line_s.substring(idx2);
      }
      else {
         log.error("parseSectDeclaration. Cannot extract section type from the line: " + line_s);
         return null;
      }
      //..... Ignore data presentation sections ......
      
      int idx = BGUtils.getStringStartIdx(objType_s, SECT_VALID_SA);
      if (idx == -1) {
         skipIgnoreSection(parser);
         return IGNORE_TYPE_CONST;
      }
      //..... Parse parameter names ......
      
      int idx3 = line_s.indexOf(ATTR_CLOSE_CONST);
      int idx4 = line_s.indexOf(HEAD_CLOSE_CONST);

      if (idx3 == -1 || idx4 < idx3) {
         log.error("parseSectDeclaration. Cannot parse attribute declaration: " + line_s);
         return null;      
      }
      line_s = line_s.substring(0, idx3);
      
      String[] line_sa = BGUtils.splitQuoted(line_s, COMMA_CONST);
      ArrayList<String> attrNames_al = new ArrayList<String>(Arrays.asList(line_sa));
            
      // Re-map attribute names (if needed)      
      
      attrNames_al = remapAttrNames(objType_s, attrNames_al);
     
      // First attribute should be "name", constructed from the object type.
      // Insert attribute "name" on a first position.
      
      // attrNames_al.add(0, PowModel.NAME_NAME);

      // Check if this object type already exists and attributes are the same.
      // If not - craete a new object type with index added to the type name
      
      String[] objType_sa = model.getObjTypeNames();
      if (objType_sa != null) {
         idx = BGUtils.getStringIdx(objType_s, model.getObjTypeNames()); 
         if (idx != -1) {
            List<String> attrNamesExists_al = model.getAttrNames(objType_s);
            
            // Check if this object name with the same list 
            // of attributes is exist in the model
            
            if (Objects.equals(attrNames_al, attrNamesExists_al)) return objType_s;
            
            objType_s = model.generateObjTypeName(objType_s);               
         }
      }
      //..... Add list of attributes to the model ......
            
      model.setAttrNames(objType_s, attrNames_al);
      return objType_s;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static boolean parseObjects(BGParser parser,
                                       PowModel model,
                                       String   objType_s,
                                       int      attrNum,
                                       String   line_s) throws IOException
   {
      int objIdx = 0;
      
      while (line_s != null && line_s.startsWith(SECT_CLOSE_CONST) == false) {
         
         if (objType_s.equalsIgnoreCase(IGNORE_TYPE_CONST) == false) {
         
            //..... Parse and ignore <SUBDATA name> block ......
      
            if (line_s.toUpperCase().startsWith(SUBDATA_OPEN_CONST)) {
               do {
                  line_s = parser.getLine();
                  if (line_s == null) {
                     log.error("parseObject. Unexpected end of file (line == null)" + 
                               " while parsing <SUBDATA>");
                     return false;
                  }
               }
               while(line_s.startsWith(SUBDATA_CLOSE_CONST) == false);
            }   
            //..... Get all attributes for the object ......
         
            else {           
               String[] attr_sa = new String[0];               
               while (line_s != null && line_s.startsWith(SECT_CLOSE_CONST) == false) {
               
                  if (line_s.equals(SECT_OPEN_CONST))  {
                     line_s = parser.getLine();
                     continue;
                  }  
                  line_s = line_s.replace("\"\"", "\" \"");    // otherwise splitQuoted ignore empry element
                  
                  String[] attrAdd_sa = BGUtils.splitQuoted(line_s);
                  attr_sa = (String[])ArrayUtils.addAll(attr_sa, attrAdd_sa);        
            
                  //..... Add new object to the model ......
            
                  if (attr_sa.length == attrNum) {
                     PowObject obj = new PowObject(model);
                     obj.setType(objType_s);
                     obj.setNameAndAttrs(objType_s, attr_sa);                     
                     model.addObject(obj);
                     break;
                  }
                  else if (attr_sa.length > attrNum) {
                     log.error("parseObjects. Number of object " + objType_s +
                               " attributes: '" + attr_sa + "' does not match attribute declaration: " +
                               model.getAttrNames(objType_s));
                     return false;
                  }
                  line_s = parser.getLine(); 
                  if (line_s == null) return false;
               }
            }
         }
         //..... Start parsing a new object ......
         
         line_s = parser.getLine();
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Skip ignore section
   //----------------------------------------------------------------------------------------------
   
   private static boolean skipIgnoreSection(BGParser parser) throws IOException
   {
      // The right curly brace "}" must appear on its own line at the end of the data list 

      String line_s = null;
      do {
         line_s = parser.getLine();
         if (line_s == null) return false; 
      }
      while (line_s.equals(SECT_CLOSE_CONST) == false);
      
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static ArrayList<String> remapAttrNames(String            objType_s,
                                                   ArrayList<String> attrNames_al)
   {
      int idx0 = BGUtils.getStringIdx(POW_BUS_FROM, attrNames_al, null, null);
      int idx1 = BGUtils.getStringIdx(POW_BUS_TO,   attrNames_al, null, null);
      
      if (idx0 >= 0 && idx1 >= 0 && objType_s.equalsIgnoreCase(PowModel.TYPE_NAME_BUS) == false) {
         attrNames_al.set(idx0, PowModel.FROM_NAME);
         attrNames_al.set(idx1, PowModel.TO_NAME);
      }
      for (int i = 0; i < attrNames_al.size(); i++) {
         String attrName_s = attrNames_al.get(i);
         
         int idx = BGUtils.getStringPos(attrName_s, SUFFIX_REMOVE_SA);
         if (idx >= 0) {
            for (int j = 0; j < SUFFIX_REMOVE_SA.length; j++) {
               attrName_s = attrName_s.replace(SUFFIX_REMOVE_SA[j], "");
            }            
            attrName_s = remapTerm(attrName_s);
            attrName_s = "_" + attrName_s.toLowerCase();
         }
         attrNames_al.set(i, attrName_s.replace(":", "_"));
      }
      return attrNames_al;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String remapTerm(String term_s)
   {
      if (termMapper.isEmpty()) {
         if (setMapper() == false) return term_s;
      }
      String newTerm_s = termMapper.get(term_s.toLowerCase());      
      if (newTerm_s != null) {
         return newTerm_s;
      }
      return term_s;
   }
   //----------------------------------------------------------------------------------------------
   
   public static boolean setMapper()
   {
      if (POW_TYPES_IN_SA.length != POW_TYPES_OUT_SA.length) {
         log.error("setMapper. Lengths of POW term array = " + POW_TYPES_IN_SA.length + 
                   " and BG term array = " + POW_TYPES_OUT_SA.length + " are different");
         return false;
      }
      for (int i = 0; i < POW_TYPES_IN_SA.length; i++) {
         termMapper.put(POW_TYPES_IN_SA[i], POW_TYPES_OUT_SA[i]);
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Change object type for "Branch", based on subtype: "BranchDeviceType" 
   //----------------------------------------------------------------------------------------------
   
   private static boolean updateObjectTypes(PowModel model)
   {
      List<String> objType_al = BGUtils.getElementsStartsWith(PowModel.TYPE_NAME_BRANCH, model.getObjTypeNames());
            
      for (String objType_s : objType_al) {
         int attrIdx = BGUtils.getStringIdx(PowModel.BRANCH_DEVICE_TYPE_NAME, 
                                            model.getAttrNames(objType_s), null, null);
         
         // Delete this BRANCH type (section) because it does not
         // include BRANCH_DEVICE_TYPE_NAME attribute, so it cannot be
         // mapped to any object type
         
         if (attrIdx == -1) {
            model.deleteObjType(objType_s);
            continue;
         }        
         //..... Set new type to the object, based on value of "BranchDeviceTypes" ......
         
         PowObject[] objs = model.getObjects(objType_s);
         for (PowObject obj : objs) {
            String newObjType_s = (String)obj.getAttr(attrIdx);
            if (newObjType_s != null && !newObjType_s.isEmpty()) {
               obj.setType(newObjType_s.toLowerCase() + "_" + PowModel.TYPE_NAME_BRANCH);
               model.moveObject(obj, objType_s);
            }
         }
         // Re-map object type and its attributes
         
         int objNum = model.getObjects(objType_s).length;
         if (objNum == 0) {
            model.deleteObjType(objType_s);
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Remove duplicate sections (types)
   //----------------------------------------------------------------------------------------------
   
   private static boolean removeDuplicateTypes(PowModel model)
   {
      for (String objType_s : model.getObjTypeNames()) {
         for (String dupObjType_s : model.getObjTypeNames()) {
            if (dupObjType_s.startsWith(objType_s + "-")) {
               int num0 = model.getAttrNames(objType_s).size();
               int num1 = model.getAttrNames(dupObjType_s).size();
               if (num0 >= num1) {
                  model.deleteObjType(dupObjType_s);
               }
               else {
                  model.deleteObjType(objType_s);
                  model.remapObjTypeName(dupObjType_s, objType_s);
               }              
            }
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Remove leading "_" from attribute names except _from, _to
   //----------------------------------------------------------------------------------------------

   private static boolean updateAttrNames(PowModel model)
   {
      for (ArrayList<String>attrNames_al : model.getAttrNamesHm().values()) {
         for (int i = 0; i < attrNames_al.size(); i++) {
            String attrName_s = attrNames_al.get(i);
            if (attrName_s.startsWith("_")                       &&
                !attrName_s.equalsIgnoreCase(PowModel.FROM_NAME) &&
                !attrName_s.equalsIgnoreCase(PowModel.TO_NAME)) {
               attrNames_al.set(i, attrName_s.substring(1));
            }
         }
      }
      return true;
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {
      org.apache.log4j.BasicConfigurator.configure();
      DBEntry entry;
      
      String fileName_s = "D:\\tmp_share\\powerworld\\ACTIVSg200.aux";
      
      PowModel model = parseFile(fileName_s);
      if (model == null) {
         log.error("main. Cannot parse file: " + fileName_s);
         return;
      }
      model.setUuid(UUID.randomUUID());
      
      entry = model.getEntry(null, "bus_0"); 
      
      //..... To JSON ......
      
      String json_s = model.toJson();
      BGUtils.stringToFile(json_s, "D:\\tmp_share\\powerworld\\ACTIVSg200.json");

      //..... Print entry data ......
         
      System.out.println("=== GRG ========================= " + fileName_s + " ==========================");                 
      
      
      entry = model.getInfoEntry();
      entry.printContent();
   
      for (int i = 0; i < model.getTypesNum(); i++) {
         String sectName = model.getObjTypeNames()[i];
          
         System.out.println("---------------- Section: " + sectName + " ---------------------");
            
         entry = model.getEntry(sectName, null); 
         if (entry != null) {
            entry.printContent();
         }
      }
      System.exit(0);
   }
}
//======================================= End of Class ============================================

