package org.dspace.app.webui.parser.ieee;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Types;
import java.util.Date;

import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.util.BGUtils;

public class CdfParser implements CdfTypes{
   
   private static final Logger log = Logger.getLogger(CdfParser.class);
   
   //..... Constants ......
   
   public static final Integer OUTSIDE_OF_SECTION = -10009;    // line is outside of the object 
   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static CdfModel parseFile(String file_s) 
   {
      int       objTypeIdx = OUTSIDE_OF_SECTION; 
      Integer   objIdx     = 0;
      CdfModel  model      = new CdfModel();
      String    line_s     = null;
      
      //..... Read input file ......

      try (BufferedReader br = new BufferedReader(new FileReader(file_s))) {
         do {         
            line_s = br.readLine();
            if (line_s == null) break;
            if (line_s.isEmpty()) continue;
            //line_s = line_s.trim();
            
            //..... Normalize whitespaces ......
         
            //line_s = line_s.replaceAll("\\s+"," ");      // replace all duplicate white spaces and LFs
            //line_s = line_s.trim();
            
            //..... Start parsing object block .....
            
            if (objTypeIdx == OUTSIDE_OF_SECTION) {
               
               //..... Some irrelevant lines (if any) ......
               
               if (line_s.trim().startsWith(END_OF_DATA)) {
                  break;
               }
               //..................................
               
               objIdx = 0;
               
               if (model.getObjectNum() == 0) {
                  objTypeIdx = SECT_TITLE_IDX;
                  CdfObject obj = parseObjectLine(line_s, SECT_TITLE_IDX);    // first section title line
                  
                  if (obj.getAttrNum() == 0 || !(obj.getAttr(0) instanceof Date)) {    // some irrelevant line
                        continue;                                          
                  }
                  obj.setType(TYPES_SA[objTypeIdx]);
                  obj.setName(TYPES_SA[objTypeIdx] + "_" + objIdx);
                  obj.setId(objIdx);
                  
                  // Replace chars "W" or "S" to "Winter" or "Summer"
                  
                  String abbr_s = (String)obj.getAttr(4);
                  int keyIdx = BGUtils.getStringIdx(abbr_s, SEASON_KEY_SA);
                  if (keyIdx != -1) obj.setAttr(4, SEASON_VAL_SA[keyIdx]);

                  obj.setModel(model);
                  model.addObject(objTypeIdx, obj.getName(), obj);
                  
                  objTypeIdx = OUTSIDE_OF_SECTION;
               }
               else {                                                         // title line
                  objTypeIdx = parseTitleLine(line_s);
                  if (objTypeIdx == -1) {
                     log.error("CdfParser.parseFile.1. Line: " + line_s + " cannot be recognized as a valid CDF title");
                     return null;
                  }
               }
            }
            //..... End line ......
            
            else if (isEndLine(line_s, objTypeIdx)) {
               if (objTypeIdx == SECT_TLINE_IDX) break;     // do not read other lines if exists
               objTypeIdx = OUTSIDE_OF_SECTION;
            }            
            //..... Object line ......
            
            else {
               CdfObject obj = parseObjectLine(line_s, objTypeIdx);
               obj.setType(TYPES_SA[objTypeIdx]);
               obj.setName(TYPES_SA[objTypeIdx] + "_" + objIdx);
               obj.setId(objIdx);
               
               //..... Special object processing ......
               
               if (objTypeIdx == SECT_BUS_IDX) { 
                  obj.setId((Integer)BGUtils.stringToNumeric((String)obj.getAttr(0)));
                  obj.setAttr(0, SECT_BUS_NAMES_SA[0] + "_" + obj.getId());
                  obj.setName((String)obj.getAttr(0));
               }
               else if (objTypeIdx == SECT_BRANCH_IDX) {
                  obj.setAttr(0, SECT_BUS_NAMES_SA[0] + "_" + obj.getAttr(0));
                  obj.setAttr(1, SECT_BUS_NAMES_SA[0] + "_" + obj.getAttr(1));
               }
               obj.setModel(model);
               model.addObject(objTypeIdx, obj.getName(), obj);
               
               objIdx++;
            }
         }       
         while (true);
      }
      catch (FileNotFoundException e) {
         log.error("CdfParser.parseFile. File " + file_s + " not found. " + e.getMessage());
         return null;
      } 
      catch (IOException e) {
         log.error("CdfParser.parseFile. General I/O error in parsing file " + file_s + ". " + e.getMessage());
         return null;
      }
      catch (Exception e) {
         log.error("CdfParser.parseFile. File: " + file_s + ". Error in line: \"" + line_s + "\". " + e.getMessage());
         return null;
      }
      //..... Model attributes ......
   
      //model.setDspaceId(BGUtils.getNameFromFile(file_s));
      model.setName(BGUtils.getNameFromFile(file_s));
      model.setPath(file_s);
      model.calcTypeCounts();
      model.setFormat(BGModel.MODEL_FORMAT_IEEE_COM);
      model.setFormatVersion(null);
   
      return model;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static CdfObject parseObjectLine(String line_s, 
                                            int    sectIdx)
   {
      CdfObject obj = new CdfObject();
      int len       = line_s.length();
      
      // Assign object type first to allow parser to initialize array
      // of attributes with length specified by type idx (section idx)
      
      obj.setTypeIdx(sectIdx);
      
      //..... for each attribute (column) ......
      
      int correction = 0;
      
      for (int i = 0; i < ATTR_TYPES_AA[sectIdx].length; i++) {
         
         int pos1 = START_AA[sectIdx][i] - 1 - correction;
         int pos2 = STOP_AA[sectIdx][i];
         correction = 0;
         
         if (len > pos1 && len < pos2) pos2 = len;
         if (len <= pos1) break;
         
         String attrValue_s = line_s.substring(pos1, pos2);
         
         //..... Attempt to fix positioning issues ......
         
         int type = ATTR_TYPES_AA[sectIdx][i];
         if (type == Types.INTEGER || type == Types.DOUBLE) {
            String test_s = attrValue_s.trim();         
            if (test_s.contains(" ")) {
               int posEnd  = test_s.indexOf(" ");
               int len1    = test_s.substring(posEnd).length();
               int len2    = BGUtils.trimLeft(test_s.substring(posEnd)).length();
               
               attrValue_s = test_s.substring(0, posEnd);
               correction  = len1 - len2;
            }
         }
         //..... Get value (with type) ......
         
         //String df = (ATTR_TYPES_AA[sectIdx][i] == Types.DATE) ? DATE_FORMAT_S : null;
         Object attrValue = obj.valueOfType(attrValue_s, ATTR_TYPES_AA[sectIdx][i], null);
         
         if (attrValue != null) {
            obj.setAttr(i, attrValue);
         }
      }
      return obj;
   }
   //----------------------------------------------------------------------------------------------
   // Get title line (first line of section
   //----------------------------------------------------------------------------------------------
   
   private static int parseTitleLine(String line_s)
   {
      return BGUtils.getStringStartIdx(line_s, TITLES_SA);
   }
   //----------------------------------------------------------------------------------------------
   // Get end line of section
   //----------------------------------------------------------------------------------------------
   
   private static boolean isEndLine(String line_s, 
                                    int    sectIdx)
   {
      if (sectIdx >= SECT_TITLE_NAMES_SA.length) return true;
      if (SECT_END_SA[sectIdx] == null)          return false;
      
      int len = SECT_END_SA[sectIdx].length();      
      return line_s.substring(0, len).equals(SECT_END_SA[sectIdx]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {      
      org.apache.log4j.BasicConfigurator.configure();
      
      //CdfModel model0 = parseFile("C:\\tmp_share\\cdf\\14BusPF.cdf");
      //CdfModel model0 = parseFile("C:\\tmp_share\\cdf\\300BusPF.cdf");
      //CdfModel model0 = parseFile("C:\\tmp_share\\cdf\\57BusPF.txt");
      //CdfModel model0 = parseFile("C:\\tmp_share\\cdf\\118BusPF.cdf");
      //CdfModel model0 = parseFile("C:\\tmp_share\\cdf\\30BusPF.txt");
      
      CdfModel model0 = parseFile("C:\\tmp_share\\17GenDynamicSolvedPowerFlow.cdf");
      
      
      String json_s = model0.toGraphJson();
      
      boolean res = BGUtils.stringToFile(json_s, "C:\\tmp_share\\17GenDynamic_graph.json");

      DBEntry entry;
      entry = model0.getInfoEntry();
      entry.printContent();
      
      entry = model0.getEntry("title", null);
      entry.printContent();
      
      entry = model0.getEntry("bus", null);
      entry.printContent();
      
      entry = model0.getEntry("branch", null);
      entry.printContent();
      
      entry = model0.getEntry("loss_zones", null);
      entry.printContent();
      
      entry = model0.getEntry("interchange", null);
      entry.printContent();

      entry = model0.getEntry("tie_lines", null);
      entry.printContent();

      
      //String json_s = model0.toJson();
   }
}
//======================================= End of Class ============================================
