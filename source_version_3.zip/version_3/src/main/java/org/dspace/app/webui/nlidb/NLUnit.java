package org.dspace.app.webui.nlidb;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class NLUnit
{
   private static final Logger log = Logger.getLogger(NLAttribute.class);
   
   //..... Common members ......
   
   private String type;                // type of measured object, like "voltage", "capacity", etc.
   
   private List<String> name_al  = new ArrayList<String>();
   private List<Double> coef_al   = new ArrayList<Double>();

   //..... Methods ......
   
   public String getType()
   {
      return type;
   }
   public void setType(String type)
   {
      this.type = type;
   }
   public List<String> getNames()
   {
      return name_al;
   }
   public void setNames(List<String> name_al)
   {
      this.name_al = name_al;
   }
   public List<Double> getCoefs()
   {
      return coef_al;
   }
   public void setCoefs(List<Double> coef_al)
   {
      this.coef_al = coef_al;
   }
   public void addUnit(String name,
                       Double coef) 
   {
      if (name != null && coef != null) {
         name_al.add(name);
         coef_al.add(coef);
      }
   }
   public Double getCoeff(String name) 
   {
      int idx = name_al.indexOf(name);
      if (idx == -1) return null;
      
      return coef_al.get(idx);
   }
}
