package org.dspace.app.webui.parser.grg;

import org.dspace.app.webui.parser.BGAttr;
import org.dspace.app.webui.util.BGUtils;

import com.google.gson.JsonArray;

public class GrgAttr extends BGAttr 
{   
   //..... Constructors ......
   
   public GrgAttr() {};
   
   public GrgAttr(String name, String value)
   {
      this.name     = name;
      this.value    = value;
      this.valueObj = BGUtils.stringToNumeric(value);
   }
   
   public GrgAttr(String name, JsonArray valueArr)
   {
      this.name     = name;
      this.valueObj = toStringArray(valueArr);
      this.value    = String.join(",", (String[])valueObj);
   }
}
//======================================= End of Class ============================================
