package org.dspace.app.webui.parser.opendss;

import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.dspace.app.webui.model.DBColumn;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.parser.gridlab.GlmAttr;
import org.dspace.app.webui.parser.gridlab.GlmParser;
import org.dspace.app.webui.util.BGUtils;

public class DssObject extends BGObject {

   //..... Members ......
   
   private DssModel model;

   LinkedHashMap<String, DssAttr> attr_hm = new LinkedHashMap<String,DssAttr>();
   ArrayList<String> attrNames = null; 

   //..... Getters/Setters ......
   
   @Override
   public DssModel getModel() {
      return model;
   }
   public void setModel(DssModel model) {
      this.model = model;
   }
   @Override
   public void setModel(BGModel model) {
      this.model = (DssModel)model;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean addAttr(DssAttr attr)
   {
      if (attr.getName() != null) {
         attr_hm.put(attr.getName(), attr);
         return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   
   public boolean addAttr(String name_s,
                          String value_s)
   {
      if (name_s == null || name_s.isEmpty() || value_s == null) {
         return false;
      }
      DssAttr attr = new DssAttr(this, name_s, value_s);
      attr_hm.put(attr.getName(), attr);
      return true;
   }
   //----------------------------------------------------------------------------------------------
   
   public DssAttr getAttrObj(String name)
   {
      return attr_hm.get(name);
   }
   //----------------------------------------------------------------------------------------------
   
   public boolean ifAttrExists(String value_s)
   {
      int idx = value_s.indexOf(".");
      if (idx >= 0) {
         value_s = value_s.substring(0, idx);
      }
      String val_s = (String)getAttr(DssModel.FROM_NAME);
      if (val_s != null && val_s.equalsIgnoreCase(value_s)) return true;
      
      val_s = (String)getAttr(DssModel.TO_NAME);
      if (val_s != null && val_s.equalsIgnoreCase(value_s)) return true;
      
      return false;
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Object getAttr(String name)
   {
      DssAttr attr = attr_hm.get(name);
      if (attr != null) {
         return attr.getObjValue();
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public void setAttrNames()
   {
      attrNames = new ArrayList<String>();

      //..... A few columns to display first ......
      
      attrNames.add(DssParser.NAME_CONST);
      
      if (attr_hm.get(DssParser.FROM_CONST) != null) {
         attrNames.add(DssParser.FROM_CONST);
      }
      if (attr_hm.get(DssParser.TO_CONST) != null) {
         attrNames.add(DssParser.TO_CONST);
      }
      //..... Add all object attribute names ......
      
      for (String attrName : attr_hm.keySet()) {
         if (attrNames.contains(attrName) == false) {
            attrNames.add(attrName);
         }
      }
   }
   //----------------------------------------------------------------------------------------------
   // Get array of all attribute names of this object
   //----------------------------------------------------------------------------------------------

   @Override
   public String[] getAttrNames()
   {
      if (attrNames == null) {
        setAttrNames();
      }
      return attrNames.toArray(new String[attrNames.size()]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public List<Object> getAttrs() 
   {
      List<Object> attr_al = new ArrayList<Object>();
      for (DssAttr attr : attr_hm.values()) {
         attr_al.add(attr.getValue());
      }
      return attr_al;
   }
   //----------------------------------------------------------------------------------------------

   @Override
   public Object getAttr(int idx) 
   { 
      DssAttr attr = getAttrObj(getAttrNames()[idx]);
      if (attr == null) return null;
      
      return attr.getValue();
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public boolean isLinkObject()
   {
      if (BGUtils.getStringIdx(type, DssModel.LINK_TYPE_NAMES) >= 0) {
         return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   // Get table with column declarations
   //----------------------------------------------------------------------------------------------
   
   @Override
   public DBTable getTable() 
   {
      //..... Setup table ......

      String objType_s = getType();
      if (objType_s == null) return null;
      
      DBTable table = new DBTable();
      table.setName(getName());

      for (int i = 0; i < getAttrNames().length; i++) {
         DBColumn col = new DBColumn(getAttrNames()[i], null, Types.VARCHAR, i);
         table.addColumn(i, col);
      }
      return table;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();

      //String objTypeId = type + ((id == null) ? "" : "_" + id.toString());
      
      //..... Start with object type, id and name (if any) as attributes ......
      
      json_sb.append("{\t\"object_type\" : \"" + type + "\",\n" );
      if (id != null) {
         json_sb.append("\t\"object_id\" : " + id.toString() + ",\n");
      }
      if (name != null) {
         json_sb.append("\t\"object_name\" : \"" + name + "\",\n");
      }
      //..... For each attribute ......
      
      for (DssAttr attr : attr_hm.values()) {
         json_sb.append(attr.toJson());
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n},\n");
      
      return json_sb.toString();
   }
}
