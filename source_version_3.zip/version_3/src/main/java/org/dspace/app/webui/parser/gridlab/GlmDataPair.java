package org.dspace.app.webui.parser.gridlab;

public class GlmDataPair {
   
   //..... Members ......
   
   private String name;
   private Object value;
   private String units;
   
   //..... Methods ......
   
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getUnits() {
      return units;
   }
   public void setUnits(String units) {
      this.units = units;
   }
   //----------------------------------------------------------------------------------------------
   
   public Object getValue() 
   {
      Object valueObj = null;
      String valueStr = (String)value;
      
      //..... Set attribute value ......
      
      String[] val_sa = valueStr.split(" ");
      try {
         valueObj = Double.parseDouble(val_sa[0]);    // if its numeric
         if (val_sa.length > 1) {
            setUnits(val_sa[1]);
         }
         if ((Double)valueObj % 1 == 0) {
            valueObj = Integer.parseInt(val_sa[0]);
         }
         return valueObj;
      }
      catch (Exception e1) {
         
         //..... The value is not numeric ......
      
         return valueStr;
      }
   }
   //----------------------------------------------------------------------------------------------
   
   public void setValue(Object value) 
   {   
      this.value = value;
   }
}
