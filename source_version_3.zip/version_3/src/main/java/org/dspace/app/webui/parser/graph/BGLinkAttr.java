package org.dspace.app.webui.parser.graph;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class BGLinkAttr {
   
   private static final Logger log = Logger.getLogger(BGLinkAttr.class);

   //..... Members ......
   
   private String       linkType;       // type of object which connects "this" and target
   private String       targetName;     // name of the target node 
   private Double       distance;
   private Integer      hops;
   private List<String> path_al = new ArrayList<String>();
   
   //..... Methods ......
   
   public String getLinkType() {
      return linkType;
   }
   public void setLinkType(String linkType) {
      this.linkType = linkType;
   }
   public String getTargetName() {
      return targetName;
   }
   public void setTargetName(String nodeToName) {
      this.targetName = nodeToName;
   }
   public Double getDistance() {
      return distance;
   }
   public void setDistance(Double distance) {
      this.distance = distance;
   }
   public Integer getHops() {
      return hops;
   }
   public void setHops(Integer hops) {
      this.hops = hops;
   }
   public List<String> getPath() {
      return path_al;
   }
   public void setPath(List<String> path_al) {
      this.path_al = path_al;
   }
   public BGLinkAttr copy()
   {
      BGLinkAttr newLink = new BGLinkAttr();
      newLink.linkType   = this.linkType;
      newLink.hops       = this.hops;
      newLink.distance   = this.distance;
      newLink.targetName = this.targetName;
      newLink.path_al    = this.path_al;
      
      return newLink;
   }
}
