package org.dspace.app.webui.parser.cyme;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGParser;
import org.dspace.app.webui.util.BGUtils;

public class CymParser extends BGParser 
{   
   private static final Logger log = Logger.getLogger(CymParser.class);
   
   //..... Constants ......
   
   public static final String  SECT_HEAD_OPEN_CONST  = "[";
   public static final String  SECT_HEAD_CLOSE_CONST = "]";
   public static final String  FORMAT_LINE_CONST     = "format_";
   public static final String  DECLARE_DELIM_CONST   = "=";
   public static final String  DEFAULT_LINE_CONST    = "default";
   public static final String  ATTR_DELIM_CONST      = ",";
     
   //..... Constructor ......
   
   public CymParser(String file_s) throws FileNotFoundException 
   {
      super(file_s);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static CymModel parseFile(String file_s) 
   {
      CymModel model     = new CymModel(); 
      String   objType_s = null;
      int      attrNum   = 0;
      boolean  res_b     = true;
      
      //..... Read input file ......

      try {
         BGParser parser = new BGParser(file_s);
         parser.setDoNormalize(true);
         parser.setSkipEmpty(true);
      
         do {
            String line_s = parser.getLine();
            if (line_s == null) break;

            //..... New section declaration line ......
            
            if (line_s.startsWith(SECT_HEAD_OPEN_CONST) && line_s.endsWith(SECT_HEAD_CLOSE_CONST)) {
               objType_s = line_s.substring(1, line_s.length() - 1).trim();
               continue;
            }
            //..... Attributes declaration ......
            
            else if (line_s.toLowerCase().startsWith(FORMAT_LINE_CONST)) {               
               res_b = parseAttrDeclaration(model, objType_s, line_s);
               if (res_b == false) return null;
            }
            //..... Defaults declaration ......
            
            else if (line_s.toLowerCase().startsWith(DEFAULT_LINE_CONST)) {
               res_b = parseAttrDefaults(model, objType_s, line_s);
               if (res_b == false) return null;
            }
            //..... Object's line ......
            
            else {
             
               
            }
            /*
               if (line_s.toLowerCase().startsWith(OBJECT_CONST)) {
                  objType_s = parseSectDeclaration(parser, model, line_s);
                  if (objType_s.equals(IGNORE_TYPE_CONST)) {
                     continue;
                  }
                  attrNum   = model.getAttrNames(objType_s).size();
                  isInside  = true;
               }
               // ignore other sections
            }
            //..... Data line ......
            
            else {
               res_b &= parseObjects(parser, model, objType_s, attrNum, line_s);
               isInside = false;
            }
            */
         }
         while (true);
      }
      catch (FileNotFoundException e) {
         log.error("PowParser.parseFile. File " + file_s + " not found. " + e.getMessage());
         return null;
      } 
      catch (IOException e) {
         log.error("PowParser.parseFile. General I/O error in parsing file " + file_s + ". " + e.getMessage() +
                   "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
         return null;
      }
      catch (Exception e) {
         log.error("PowParser.parseFile. File: " + file_s + ". " + e.getMessage() +
                   "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
         return null;
      }
      //..... Post-processing ......

      //updateObjectTypes(model);              // Change object type if necessary
      //updateAttrNames(model);                // Remove leading "_" from attribute names
      //removeDuplicateTypes(model);           // remove duplicate type, like: "area-1"
      
      //..... Model attributes ......
      
      //model.setDspaceId(BGUtils.getNameFromFile(file_s));
      model.setName(BGUtils.getNameFromFile(file_s));
      model.setPath(file_s);
      model.calcTypeCounts();
      model.setFormat(BGModel.MODEL_FORMAT_POWERWORLD);
      
      return model;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static CymObject parseObject(CymModel model,
                                        String   objType_s, 
                                        String   line_s)
   {
      CymObject obj = new CymObject(model);
      obj.setType(objType_s);

      List<String> attr_sa = BGUtils.StringToArrayList(line_s, ATTR_DELIM_CONST);
      List<String> attrNames_sa = model.getAttrNames(objType_s);
      
      if (attr_sa == null || attrNames_sa == null || attr_sa.size() != attrNames_sa.size()) {
         log.error("parseObject. Attributes for object type " + objType_s + 
                   " do not exist or does not match number of attr.names");
         return null;
      }
/*      
      obj.
      
      
      //..... for each attribute (column) ......
      
      int correction = 0;
      
      for (int i = 0; i < ATTR_TYPES_AA[sectIdx].length; i++) {
         
         int pos1 = START_AA[sectIdx][i] - 1 - correction;
         int pos2 = STOP_AA[sectIdx][i];
         correction = 0;
         
         if (len > pos1 && len < pos2) pos2 = len;
         if (len <= pos1) break;
         
         String attrValue_s = line_s.substring(pos1, pos2);
         
         //..... Attempt to fix positioning issues ......
         
         int type = ATTR_TYPES_AA[sectIdx][i];
         if (type == Types.INTEGER || type == Types.DOUBLE) {
            String test_s = attrValue_s.trim();         
            if (test_s.contains(" ")) {
               int posEnd  = test_s.indexOf(" ");
               int len1    = test_s.substring(posEnd).length();
               int len2    = BGUtils.trimLeft(test_s.substring(posEnd)).length();
               
               attrValue_s = test_s.substring(0, posEnd);
               correction  = len1 - len2;
            }
         }
         //..... Get value (with type) ......
         
         //String df = (ATTR_TYPES_AA[sectIdx][i] == Types.DATE) ? DATE_FORMAT_S : null;
         Object attrValue = obj.valueOfType(attrValue_s, ATTR_TYPES_AA[sectIdx][i], null);
         
         if (attrValue != null) {
            obj.setAttr(i, attrValue);
         }
      }
      */
      return obj;
   }
   //----------------------------------------------------------------------------------------------
   // Get title line (first line of section
   //----------------------------------------------------------------------------------------------
   
   private static boolean parseAttrDeclaration(CymModel model,
                                               String   objType_s,
                                               String   line_s)
   {
      //..... Verify format string consistency ......
      
      int delimIdx = line_s.indexOf(DECLARE_DELIM_CONST);
      String sectName_s = line_s.substring(FORMAT_LINE_CONST.length(), delimIdx).trim();
      if (sectName_s.equalsIgnoreCase(objType_s) == false) {
         log.error("parseAttrDeclaration. 'FORMAT' string (" + sectName_s + 
                   ") does not match to the current object type (" + objType_s + ")");
         return false;
      }
      //..... Get attributes ......
      
      line_s = line_s.substring(delimIdx + 1);
      String[] line_sa = BGUtils.splitQuoted(line_s, ATTR_DELIM_CONST);
      model.setAttrNames(objType_s, (ArrayList<String>)Arrays.asList(line_sa));
      model.addObjTypeName(objType_s);
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Get title line (first line of section
   //----------------------------------------------------------------------------------------------
   
   private static boolean parseAttrDefaults(CymModel model,
                                            String   objType_s,
                                            String   line_s)
   {
      //..... Verify defaults consistency ......
      
      int delimIdx = line_s.indexOf(ATTR_DELIM_CONST);
      line_s = line_s.substring(delimIdx + 1).trim();
      List<String>def_al = BGUtils.StringToArrayList(line_s, ATTR_DELIM_CONST);
      
      List<String> attrNames_al = model.getAttrNames(objType_s);
      if (attrNames_al == null || attrNames_al.size() != def_al.size()) {
         log.error("parseAttrDefaults. Attributes for object type " + objType_s + 
                   " do not exist or does not match number of defaults");
         return false;  
      }
      model.setAttrDefs(objType_s, new ArrayList<Object>(def_al));
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

}
