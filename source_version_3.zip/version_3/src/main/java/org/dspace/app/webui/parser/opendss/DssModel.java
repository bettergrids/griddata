package org.dspace.app.webui.parser.opendss;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBColumn;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGSetList;

public class DssModel extends BGModel {

   private static final Logger log = Logger.getLogger(DssModel.class);
   
   //..... Constants ......
   
   public static final String DSS_EXTENTION_CONST = "dss";
      
   //..... Object type names ......
   
   public static final String TYPE_NAME_BUS           = "bus";
   public static final String TYPE_NAME_TRANSFORMER   = "transformer";
   public static final String TYPE_NAME_LINE          = "line";
   public static final String TYPE_NAME_FUSE          = "fuse";
   public static final String TYPE_NAME_SWITCH        = "switch";
   public static final String TYPE_NAME_BREAKER       = "breaker";
   public static final String TYPE_NAME_REGCONTROL    = "regcontrol";
   public static final String TYPE_NAME_CAPACITOR     = "capacitor";
   public static final String TYPE_NAME_LINECODE      = "linecode";
   public static final String TYPE_NAME_LINEGEOMETRY  = "linegeometry";
   public static final String TYPE_NAME_LOAD          = "load";
   public static final String TYPE_NAME_LOADSHAPE     = "loadshape";
   public static final String TYPE_NAME_WIREDATA      = "wiredata";
   public static final String TYPE_NAME_GENERATOR     = "generator";
   
   public static final String TYPE_NAME_PARENT        = "parent";
   
   public static final String FROM_NAME               = "_from";
   public static final String TO_NAME                 = "_to";
   public static final String LENGTH_NAME             = "length";
   
   public static final String[] NODE_TYPE_NAMES = {TYPE_NAME_BUS,                           // 600
                                                   TYPE_NAME_LOAD,
                                                   TYPE_NAME_LOADSHAPE, // 103
                                                   TYPE_NAME_CAPACITOR,
                                                   TYPE_NAME_GENERATOR,
                                                   TYPE_NAME_WIREDATA,
                                                   TYPE_NAME_REGCONTROL,
                                                   TYPE_NAME_LINECODE,
                                                   TYPE_NAME_LINEGEOMETRY};                     // 104

   public static final String[] LINK_TYPE_NAMES = {TYPE_NAME_LINE,                  // 110
                                                   TYPE_NAME_SWITCH,                         // 111
                                                   TYPE_NAME_BREAKER,
                                                   TYPE_NAME_TRANSFORMER,                    // 112
                                                   TYPE_NAME_FUSE,                           // 114
                                                   TYPE_NAME_PARENT};                      // 118
   //..... Members ......
   
   private Map<String, String>file_hm = new LinkedHashMap<String, String>();
   private Map<String, String>cmd_hm  = new HashMap<String, String>(); 
   
   private Map<String, Map<String,DssObject>> objects_hm2 = new HashMap<String, Map<String,DssObject>>();
   private Map<String, String[]> attrNames_sal = new HashMap<String, String[]>();;    
   
   //..... Methods ......
   
   public Map<String, String> getFilesMap() {
      return file_hm;
   }
   public void setFilesMap(Map<String, String>file_hm) {
      this.file_hm = file_hm;
   }
   public Collection<String> getFiles() {
      return file_hm.values();
   }
   public Collection<String> getFileNames() {
      return file_hm.keySet();
   }
   public String getFile(String fileName_s) {
      return file_hm.get(fileName_s);
   }
   public void addFile(String fileName_s,
                       String content_s)
   {
      file_hm.put(fileName_s, content_s);
   }
   public Map<String, String> getCommands() {
      return cmd_hm;
   }
   public void setCommand(String fileName_s, 
                          String command) {
      cmd_hm.put(fileName_s, command);
   }
   
   public String getCommand(String fileName_s) {
      return cmd_hm.get(fileName_s);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean addObject(DssObject obj)
   {
      String type_s = obj.getType();   
      if (obj.getName() != null && type_s != null) {
         
         Map<String,DssObject> objects_hm = objects_hm2.get(type_s);
         if (objects_hm == null) {
            objects_hm = new LinkedHashMap<String,DssObject>();
            objects_hm2.put(type_s, objects_hm);
         }
         objects_hm.put(obj.getName(), obj);                 
         return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public DssObject getObject(String name_s)
   {
      int idx = name_s.indexOf(".");
      if (idx > 0) {
         name_s = name_s.substring(0, idx);     // remove bus extensions
      }
      for (Map<String,DssObject> objects_hm : objects_hm2.values()) {
         DssObject obj = objects_hm.get(name_s);
         if (obj != null) return obj;
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   
   public int getObjectCnt()
   {
      int cnt = 0;
      for (Map<String,DssObject> objects_hm : objects_hm2.values()) {
         if (objects_hm != null) {
            cnt += objects_hm.size();
         }
      }
      return cnt;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public BGObject[] getObjects() 
   {
      List<BGObject> objs = new ArrayList<BGObject>();
      
      for (Map<String,DssObject> objects_hm : objects_hm2.values()) {
         objs.addAll(objects_hm.values()); 
      }
      return objs.toArray(new DssObject[objs.size()]);
   }
   //----------------------------------------------------------------------------------------------
   // Calculate counts of different types (node, fuse, etc.)
   //----------------------------------------------------------------------------------------------
   
   @Override
   public boolean calcTypeCounts() 
   {
      //..... Calculate counts of all types ......
      
      for (Entry<String, Map<String,DssObject>> entry : objects_hm2.entrySet()) {
         String type_s                   = entry.getKey();
         Map<String,DssObject> object_hm = entry.getValue();
         
         typeCounts.put(type_s, object_hm.size());
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Get number of objects of specific type
   //----------------------------------------------------------------------------------------------
   
   public Integer getNextObjectTypeIdx(String type_s)
   {
      int cnt = (typeCounts.containsKey(type_s) ? typeCounts.get(type_s) : -1) + 1;
      typeCounts.put(type_s, cnt);
      return cnt;
   }  
   //----------------------------------------------------------------------------------------------
   // Get objects of specific type
   //----------------------------------------------------------------------------------------------
   
   @Override
   public BGObject[] getObjects(String typeName_s) 
   {
      Map<String,DssObject> objects_hm = objects_hm2.get(typeName_s);
      if (objects_hm != null) {
         return objects_hm.values().toArray(new DssObject[objects_hm.values().size()]);
      }
      return new BGObject[0];    // return empty array;
   }
   //----------------------------------------------------------------------------------------------
   // Get all model attributes (BGSetList keeps only unique values)
   //----------------------------------------------------------------------------------------------
   
   private void setAttrNames(String type_s)
   {
      BGSetList<String> attrSet = new BGSetList<String>();
      
      //..... A few columns to display first ......
      
      attrSet.add(DssParser.NAME_CONST);
      attrSet.add(DssParser.FROM_CONST);
      attrSet.add(DssParser.TO_CONST);
      
      //..... All other attributes ......
      
      Map<String,DssObject> objects_hm = objects_hm2.get(type_s);
      
      if (objects_hm != null && objects_hm.isEmpty() == false) {
         for (DssObject obj : objects_hm.values()) {         
            attrSet.addAll(new ArrayList<String>(Arrays.asList(obj.getAttrNames())));
         }
         attrNames_sal.put(type_s, attrSet.toArray(new String[attrSet.size()]));
      }
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public List<String> getAttrNames(String type_s) 
   {
      if (attrNames_sal.get(type_s) == null) {
         setAttrNames(type_s);
         if (attrNames_sal.get(type_s) == null) {
            return new ArrayList<String>();
         }
      }
      return new ArrayList<String>(Arrays.asList(attrNames_sal.get(type_s)));
   }
   //----------------------------------------------------------------------------------------------

   @Override
   public String[] getObjTypeNames() 
   {
      return ArrayUtils.addAll(NODE_TYPE_NAMES, LINK_TYPE_NAMES);
      //return objects_hm2.keySet().toArray(new String[objects_hm2.keySet().size()]);
   }
   //----------------------------------------------------------------------------------------------

   @Override
   public String[] getStaticObjTypeNames() 
   {
      return ArrayUtils.addAll(NODE_TYPE_NAMES, LINK_TYPE_NAMES);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public Integer getTypesNum() 
   {
      return typeCounts.size();
   }
   //----------------------------------------------------------------------------------------------
   // Get entry with object types statistics
   //----------------------------------------------------------------------------------------------
   
   public DBEntry getInfoEntry() 
   {
      DBEntry entry = new DBEntry();
      
      //..... Setup table ......

      DBTable table = new DBTable();
      table.setName(getName());
      
      table.addColumn(0, new DBColumn(TYPE_CONST,  null, Types.VARCHAR, 0));   // column index: 0
      table.addColumn(1, new DBColumn(COUNT_CONST, null, Types.INTEGER, 1));   // column index: 1
      
      entry.setTable(table);
      
      //..... Calculate counts of all types ......
      
      for (String nodeType_s : getObjTypeNames()) {
         BGObject[] objs = getObjects(nodeType_s);
         if (objs == null || objs.length == 0) continue;
         
         Map<Integer, Object> row = entry.newRow();  
         entry.setRowValue(row, 0, nodeType_s);            // column index: 0  (type name)
         entry.setRowValue(row, 1, objs.length);         // column index: 1  (object count)
         entry.addRow(row);
      }
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   // Get entry with object types statistics as one row
   //----------------------------------------------------------------------------------------------
   
   public DBEntry getModelInfoAsRow() 
   {
      DBEntry entry = new DBEntry();
      
      //..... Create table ......

      DBTable table = new DBTable();
      table.setName(INFO_TABLE_NAME);
      entry.setTable(table);
      
      Map<Integer, Object> row = entry.newRow();
      
      for(int i = 0; i < INFO_TABLE_COLUMNS.length; i++) {
         table.addColumn(i, new DBColumn(INFO_TABLE_COLUMNS[i],  null, INFO_TABLE_TYPES[i], i));
      }
      entry.setRowValue(row, 0, this.getUuid());
      entry.setRowValue(row, 1, this.getName());
      entry.setRowValue(row, 2, this.getPath());
      entry.setRowValue(row, 3, this.getFormat());
      entry.setRowValue(row, 4, this.getDbTableName());
      entry.setRowValue(row, 5, this.getDescription());
      entry.setRowValue(row, 6, this.getVisible());
      entry.addRow(row);
      
      //..... Add type columns to the table ......
      
      int colNum = table.getColumnNum();
      
      int idx = 0;
      for (String nodeType_s : getObjTypeNames()) {         
         BGObject[] objs = getObjects(nodeType_s);
         if (objs == null) continue;
         
         int    colIdx   = colNum + idx++;
         table.addColumn(colIdx, new DBColumn(nodeType_s,  null, Types.INTEGER, colIdx));
         entry.setRowValue(row, colIdx, getTypeCount(nodeType_s));
      }
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public DBEntry getEntry(String  nodeType_s,
                           String  nodeName_s)                      
   {
      return getEntry(nodeType_s, nodeName_s, true);
   }
   //----------------------------------------------------------------------------------------------

   public DBEntry getEntry(String  nodeType_s,
                           String  nodeName_s,
                           boolean setNumeric_b)
   {
      if (nodeType_s == null && nodeName_s == null) {    // do not support entry for all objects
         return new DBEntry();                           // return empty entry
      }      
      //..... Setup entry ......

      DBEntry entry = new DBEntry();

      //..... Add column declarations and data for specific object ...... 

      if (nodeName_s != null) {
         BGObject obj = getObject(nodeName_s);
         if (obj == null) {
            entry.setTable(getTable(nodeType_s));
            return entry;
         }
         DBTable table = obj.getTable();
         if (table == null) {
            table = getTable(nodeType_s);
         }
         entry.setTable(table);
         
         //..... Add data ......
         
         Map<Integer, Object> row = entry.newRow();
         for (int i = 0; i < table.getColumnNum(); i++) {
            entry.setRowValue(row, i, obj.getAttr(i));
         }
         entry.addRow(row);
      }
      //..... Add columns declarations for specific type .....
      
      else if (nodeType_s != null) {
         DBTable table = getTable(nodeType_s);
         entry.setTable(table);
         
         BGObject[] objs = getObjects(nodeType_s);
         if (objs == null || objs.length == 0) {
            return entry;
         }         
         for (BGObject obj : objs) {           
            Map<Integer, Object> row = entry.newRow();
            for (DBColumn col : table.getColumns().values()) {
               entry.setRowValue(row, col.getIdx(), obj.getAttr(col.getName()));
            }
            entry.addRow(row);
         }
      }
      entry.setCompactTable();         // remove columns with all null values
      if (setNumeric_b) {
         entry.setNumericColumns();    // set column types numeric/integer, based on data
      }
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   // Get table declaration from the model
   //----------------------------------------------------------------------------------------------

   public DBTable getTable(String objType_s) 
   {
      //..... Setup table ......

      if (objType_s == null) return null;
      
      DBTable table = new DBTable();
      table.setName(objType_s);

      int attrLen = getAttrNames(objType_s).size();      
      
      for (int i = 0; i < attrLen; i++) {         
         String colName_s = getAttrNames(objType_s).get(i);
         DBColumn col     = new DBColumn(colName_s, null, Types.VARCHAR, i);
         table.addColumn(i, col);
      }
      return table;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   //----------------------------------------------------------------------------------------------
   // Return array of specific types objects
   //----------------------------------------------------------------------------------------------   
 
   @Override
   public BGObject[] getLinkObjects() 
   {
      List<BGObject> objs_al = new ArrayList<BGObject>(); 
      
      for (String nodeType_s : getObjTypeNames()) {
         List<String> attrNames = getAttrNames(nodeType_s);
     
         if (attrNames.contains(FROM_NAME) && attrNames.contains(TO_NAME)) {
            BGObject[] objs = getObjects(nodeType_s);
            objs_al.addAll(Arrays.asList(objs));           
         }
      }
      return objs_al.toArray(new DssObject[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public String[] getLinkObjTypeNames() 
   {
      /*
      List<String> objs_al = new ArrayList<String>(); 
         
      for (String nodeType_s : getObjTypeNames()) {
         List<String> attrNames = getAttrNames(nodeType_s);
        
         if (attrNames.contains(FROM_NAME) && attrNames.contains(TO_NAME)) {
            objs_al.add(nodeType_s);           
         }
      }
      return objs_al.toArray(new String[objs_al.size()]);
      */
      return LINK_TYPE_NAMES;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
 
   @Override
   public String[] getNodeObjTypeNames() 
   {
      /*
      List<String> objs_al = new ArrayList<String>(); 
      
      for (String nodeType_s : getObjTypeNames()) {
         List<String> attrNames = getAttrNames(nodeType_s);
        
         if ((attrNames.contains(FROM_NAME) && attrNames.contains(TO_NAME)) == false) {
            objs_al.add(nodeType_s);           
         }
      }
      return objs_al.toArray(new String[objs_al.size()]);
      */
      return NODE_TYPE_NAMES;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public BGObject[] getObjects(int typeIdx) 
   {
      return getObjects(getObjTypeNames()[typeIdx]);   
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();
      //json_sb.append("{\"" + GlmParser.OBJECT_CONST + "s\": {\n");
      json_sb.append("{\n\""  + DssParser.OBJECT_CONST + "\": [\n");
      
      //..... For each object ......
      
      long j = 0;
      for (Map<String,DssObject> objects_hm : objects_hm2.values()) {      
         if (objects_hm != null && objects_hm.isEmpty() == false) {
            for (DssObject obj : objects_hm.values()) {         
               json_sb.append(obj.toJson());
               
               //..... It might be too big, so to unbvlock it add sleep procedure ......
               
               if (++j % 500 == 0) {
                  try {
                     TimeUnit.MILLISECONDS.sleep(10);
                  }
                  catch (InterruptedException e) {
                     log.error("toJson. Timeout.Stack Trace: " + ExceptionUtils.getStackTrace(e));
                  }
               }
               //........................................................................
            }
         }
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n]\n}");
      
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public String getObjTypeName(int sectIdx) 
   {
      int len = getObjTypeNames().length;
      if (sectIdx < 0 || sectIdx >= len) {
         log.error("DssModel.getObjTypeName. Model: " + getName() + 
                   ". Type with index: " + sectIdx + " does not exist");
         return null;
      }
      return getObjTypeNames()[sectIdx];
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public List<Integer> getAttrTypes(int typeIdx) {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public Integer getAttrIdx(int sectIdx, String attrName) {
      // TODO Auto-generated method stub
      return null;
   }
   @Override
   public List<String> getAttrNames(int typeIdx) {
      // TODO Auto-generated method stub
      return null;
   }

}
