package org.dspace.app.webui.parser;

public interface BGTypes {

   //--------------------------- Major object types --------------------------------
   

   public static final String BGTYPE_OBJECT        = "_object";
   
   public static final String BGTYPE_BUS           = "bus";
   
   public static final String BGTYPE_LOAD          = "load";
   public static final String BGTYPE_GENERATOR     = "generator";
   public static final String BGTYPE_BRANCH        = "branch";
   public static final String BGTYPE_LINE          = "line";
   public static final String BGTYPE_FUSE          = "fuse";
   
   public static final String BGTYPE_TRANSFORMER   = "transformer";
   public static final String BGTYPE_SHUNT         = "shunt";
   public static final String BGTYPE_SWITCH        = "switch";
   public static final String BGTYPE_AREA          = "area";
   public static final String BGTYPE_ZONE          = "zone";
   public static final String BGTYPE_OWNER         = "owner";
   public static final String BGTYPE_METER         = "meter";
   public static final String BGTYPE_CAPACITOR     = "capacitor";
   public static final String BGTYPE_RECORDER      = "recorder";
   public static final String BGTYPE_REGULATOR     = "regulator";
   
   public static final String BGTYPE_RECLOSER      = "recloser";
   public static final String BGTYPE_CONDUCTOR     = "conductor";
   public static final String BGTYPE_GEN_COST      = "generator_cost";
   
   public static final String BGTYPE_PARENT        = "parent";
   
   public static final String[] BGTYPE_NAMES_SA = {BGTYPE_BUS, BGTYPE_LOAD, BGTYPE_GENERATOR
         
   };
   
   
    

   
   
   //--------------------------- Major object indices ------------------------------ 

   public static final int BGTYPE_TYPE_SHIFT             = 16;
   
   public static final int BGTYPE_NODE_IDX               = (1 << BGTYPE_TYPE_SHIFT);
   public static final int BGTYPE_BUS_IDX                = (1 << BGTYPE_TYPE_SHIFT);
   public static final int BGTYPE_LOAD_IDX               = (3 << BGTYPE_TYPE_SHIFT);
   public static final int BGTYPE_GENERATOE_IDX          = (4 << BGTYPE_TYPE_SHIFT);
   public static final int BGTYPE_BRANCH_IDX             = (5 << BGTYPE_TYPE_SHIFT);
   public static final int BGTYPE_LINE_IDX               = (6 << BGTYPE_TYPE_SHIFT);
   public static final int BGTYPE_TRANSFORMER_IDX        = (7 << BGTYPE_TYPE_SHIFT);
   public static final int BGTYPE_FUSE_IDX               = (8 << BGTYPE_TYPE_SHIFT);
   public static final int BGTYPE_METER_IDX              = (9 << BGTYPE_TYPE_SHIFT);
   
   //---------------------------- Object sub-types ---------------------------------
   
   public static final String BGTYPE_NODE                         = "node";
   public static final String BGTYPE_TRANS_2WIND                  = "two_winding_transformer";
   
   public static final String BGTYPE_TRIPLEX_LINE                 = "triplex_line";
   public static final String BGTYPE_MULTI_SECTION_LINE           = "multi section line";
   
   public static final String BGTYPE_TRIPLEX_NODE                 = "triplex_node";
   public static final String BGTYPE_TRIPLEX_METER                = "triplex_meter";
   
   
   
   public static final String BGTYPE_OVERHEAD_LINE_CONDUCTOR      = "overhead_line_conductor";
   public static final String BGTYPE_UNDERGROUND_LINE_CONDUCTOR   = "underground_line_conductor";
   //public static final String BGTYPE_TRIPLEX_LINE_CONDUCTOR       = "triplex_line_conductor";
   
   //public static final String BGTYPE_TRIPLEX_LINE_CONDUCTOR       = "triplex_line_conductor";

   
   //------------------------ Object sub-types indices -----------------------------
   
   public static final int BGTYPE_TRANS_2WIND_IDX        = BGTYPE_TRANSFORMER_IDX + 01;
   public static final int BGTYPE_TRANS_3WIND_IDX        = BGTYPE_TRANSFORMER_IDX + 02;
   public static final int BGTYPE_TRANS_BRANCH_IDX       = BGTYPE_TRANSFORMER_IDX + 03;
   public static final int BGTYPE_TRANSWIND_BRANCH_IDX   = BGTYPE_TRANSFORMER_IDX + 04;
   
   public static final int BGTYPE_LINE_UNDER_IDX         = BGTYPE_LINE_IDX + 01;
   public static final int BGTYPE_LINE_OVER_IDX          = BGTYPE_LINE_IDX + 02;
   public static final int BGTYPE_LINE_TRIPLEX_IDX       = BGTYPE_LINE_IDX + 03;
   
   //----------------------------- Object map arrays -------------------------------
   
   
   
   
   
}
