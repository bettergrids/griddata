package org.dspace.app.webui.parser;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.dspace.app.util.SubmissionInfo;
import org.dspace.app.webui.model.DBConnection;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.model.DBExecute;
import org.dspace.app.webui.model.DBProvider;
import org.dspace.app.webui.model.DBTypes;
import org.dspace.app.webui.submit.step.JSPUploadStep;
import org.dspace.app.webui.util.BGUtils;
import org.dspace.content.Bitstream;
import org.dspace.content.Bundle;
import org.dspace.content.Item;

public class BGItem {

   private static final Logger log = Logger.getLogger(BGItem.class);
   
   //..... Constants ......
   
   public static final String METATYPE_COL_CONST         = "metaType";      // metadata type column name
   public static final String FIELD_ID_COL_CONST         = "fieldId";       // field id column name
   
   public static final String GRID_SCHEMA_CONST          = "grid";          // name of metadata schema 'grid'
   public static final String GRID_ELEMENT_IDENTIFIER    = "identifier";    // schema element name
   public static final String GRID_QUALIFIER_URL         = "url";           // schema element name
   
   public static final String FORMAT_FIELD_CONST         = "format";        // name of element in the metadatafieldregistry
   public static final String FORMAT_VERSION_FIELD_CONST = "formatversion"; // name of element in the metadatafieldregistry
   
   //..... Constructors ......
   
   public BGItem() {};

   public BGItem(SubmissionInfo subInfo) {
      if (subInfo != null) {
         this.subInfo = subInfo;
      }
   }
   //..... Members ......
   
   private SubmissionInfo subInfo;
   private Item           dspaceItem;
   private UUID           dspaceUID;
   private String         format;            // format of the primary bitstream (model)
   private Double         formatVersion;     //
   private UUID           primaryUID;        // dspaceUID (UUID) of the model (file)

   private Map<String, BGModel> models_hm  = new HashMap<String, BGModel>();  // <dspaceId, BGModel>
   private Map<String, Object> metaData_hm = new HashMap<String, Object>();   // <attrName, value>
   
   //..... Methods ......
   
   public Map<String, BGModel> getModels() {
      return models_hm;
   }
   public String[] getModelIds ()
   {      
      Set<String> keys = models_hm.keySet();
      return keys.toArray(new String[keys.size()]);
   }
   public BGModel getModel(String dspaceId) {
      return models_hm.get(dspaceId);
   }
   public void addModel(BGModel model) {
      models_hm.put(model.getDspaceId(), model);
   }
   public void addModel(String dspaceId, BGModel model) {
      models_hm.put(dspaceId, model);
   }
   public void removeModel(UUID dspaceUID)
   {
      models_hm.remove(dspaceUID);
      if (primaryUID != null && primaryUID.equals(dspaceUID)) {
         primaryUID = null;
      }
   }
   public UUID getUuid() {
      return subInfo.getSubmissionItem().getItem().getID();
   }
   public Bundle getBundle() {
      return subInfo.getBundle();
   }
   public Item getDspaceItem() {
      return dspaceItem;
   }
   public void setDspaceItem(Item dspaceItem) {
      this.dspaceItem   = dspaceItem;
      if (dspaceItem != null) {
         this.dspaceUID = dspaceItem.getID();
      }
   }
   public UUID getDspaceUID() {
      return dspaceUID;
   }
   public void setDspaceUID(UUID dspaceUID) {
      this.dspaceUID = dspaceUID;
   }
   public String getFormat() {
      return format;
   }
   public void setFormat(String format) {
      this.format = format;
   }
   public Double getFormatVersion() {
      return formatVersion;
   }
   public void setFormatVersion(Double formatVersion) {
      this.formatVersion = formatVersion;
   }
   public UUID getPrimaryUID() {
      return primaryUID;
   }
   public void setPrimaryUID(UUID primaryUID) {
      this.primaryUID = primaryUID;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean parseModelFiles()
   {
      if (subInfo == null || subInfo.getBundle() == null) return false;
      boolean res = true;
         
      Bundle bundle  = subInfo.getBundle();
      if (bundle.getPrimaryBitstream() != null) {
         primaryUID = bundle.getPrimaryBitstream().getID();
      }
      else {
         primaryUID = null;
      }
      List<Bitstream> bitstreams = bundle.getBitstreams();
      
      for (Bitstream bs : bitstreams) {
         
         String filePath_s   = JSPUploadStep.getFilePath(bs);
         String fileFormat_s = getBitstreamFormat(bs, filePath_s);
         //String modelName_s  = BGUtils.getNameFromFile(bs.getSource());
         
         BGModel model = BGParser.parseFile(fileFormat_s, filePath_s);
         if (model != null) {
            //model.setName(modelName_s);               // real name from source file
            model.setDspaceId(bs.getInternalId());    // internal_id column in the bitstream table
            model.setUuid(bs.getID());
            this.addModel(model);
         }
         else {
            res = false;
            log.error("BGItem.parseModelFiles. Cannot parse file = " + bs.getSource() + "; path = " + filePath_s);
         }
      }
      return res;
   }
   //----------------------------------------------------------------------------------------------
   
   public void setModels(Map<String, Object> models)
   {
      models_hm = new HashMap<String, BGModel>();     // populate the new map
      
      for (Map.Entry<String, Object> entry : models.entrySet()) {
         String  dspaceId = entry.getKey();
         BGModel model    = (BGModel)entry.getValue();
         
         models_hm.put(dspaceId, model);
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String getBitstreamFormat (Bitstream bs,
                                            String    filePath_s)
   {
      String fileFormat_s = null;  
      try {
         fileFormat_s = bs.getUserFormatDescription();
         log.info("BGItem.getBitstreamFormat. File format from bitstream: " + fileFormat_s);
      }
      catch (Exception e) {
         log.info("BGItem.getBitstreamFormat. Cannot get file format from bitstream = " + bs.getSource() + "; path = " + filePath_s);
      }
      //..... Get file format from extension ......
      
      if (fileFormat_s == null) {
         String fileExt_s = BGUtils.getFileExtension(filePath_s);
         int idx = BGUtils.getStringIdx(fileExt_s, BGModel.MODEL_FILE_EXT_SA);
         log.info("BGItem.getBitstreamFormat. idx: " + idx);
         if (idx > 0) {
            fileFormat_s = BGModel.MODEL_FILE_FORMATS_SA[idx];
         }
         log.info("BGItem.getBitstreamFormat. File format from file extension: " + fileFormat_s);
      }
      return fileFormat_s;
   }
   //----------------------------------------------------------------------------------------------
   // populate DSpace DB metadatavalue table
   //----------------------------------------------------------------------------------------------
   
   public boolean populateMetadata()
   {
      boolean res       = true;
      String  tableName = "metadatavalue";
      
      //..... Get DSpace DB connection ......
      
      DBConnection dbConn = new DBConnection(DBProvider.DSpaceDB);
      Connection conn     = dbConn.getConnection(); 
      
      //..... Get list of metadata types IDs from DSpace DB ......
      
      String sql_s = "SELECT mf.element "      + METATYPE_COL_CONST + 
                     ", mf.metadata_field_id " + FIELD_ID_COL_CONST +
                     " FROM metadatafieldregistry mf, metadataSchemaRegistry ms " +
                     "WHERE mf.metadata_schema_id = ms.metadata_schema_id " + 
                     "AND ms.short_id = 'grid' AND mf.element NOT IN " + 
                     "('identifier', 'storage', 'model', 'subject', 'version', 'publisher', 'formatversion')"; 

      DBExecute exec = new DBExecute();
      DBEntry entry = exec.execQuery(conn, sql_s, null);
      
      entry.singularizeColumn(METATYPE_COL_CONST);
      
      //..... Calculate total models sums by type ......
      
      calcGridMetadata(entry);
      
      //..... Calculate sum for all metadata types found in DB ......
     
      int metaTypeColIdx = entry.getTable().findColumnIdx(METATYPE_COL_CONST);
      int fieldIdColIdx  = entry.getTable().findColumnIdx(FIELD_ID_COL_CONST);
      
      ArrayList<Integer> colTypesIns = new ArrayList<Integer>();
      colTypesIns.add(DBTypes.typeInt);
      colTypesIns.add(DBTypes.typeText);
      colTypesIns.add(DBTypes.typeVarchar);
      colTypesIns.add(DBTypes.typeInt);
      colTypesIns.add(DBTypes.typeUUID);     // uuid
      
      ArrayList<String> paramNamesIns = new ArrayList<String>();
      paramNamesIns.add("metadata_field_id");
      paramNamesIns.add("text_value");
      paramNamesIns.add("text_lang");
      paramNamesIns.add("place");
      paramNamesIns.add("dspace_object_id");
      
      ArrayList<Object> values; 
      
      for (Map<Integer, Object> row : entry.getRows()) {       // for each type: 'node', 'bus', etc
         
         String metaName  = entry.getRowValue(row, metaTypeColIdx).toString();
         Object metaValue = metaData_hm.get(metaName);
         if (metaValue == null) continue;

         Integer metadata_field_id = (Integer)entry.getRowValue(row, fieldIdColIdx);
         
         //..... Delete existing record (if exists) ...... 
         
         sql_s = "DELETE FROM " + tableName + " WHERE metadata_field_id = " + metadata_field_id.toString() + 
                 " AND dspace_object_id = '" + dspaceUID.toString() + "'"; 

         Integer num = exec.execDelete(conn, sql_s);
         if (num != 0 && num != 1) {
            log.error("BGItem.populateMetadata. Deleted " + num + " records. Expected 0 or 1");
         }
         //..... Insert new record ......
         
         values = new ArrayList<Object>();
         values.add(entry.getRowValue(row, fieldIdColIdx));
         values.add(metaValue);
         values.add("en_US");
         values.add(0);
         values.add(dspaceUID.toString());

         res &= exec.execInsert(conn, tableName, colTypesIns, paramNamesIns, values);
         
      }
      dbConn.close();
      return res;
   }
   //----------------------------------------------------------------------------------------------
   // Calculate sum of "grid" metadata 
   //----------------------------------------------------------------------------------------------
   
   public boolean calcGridMetadata(DBEntry metaEntry)
   {
      metaData_hm = new HashMap<String, Object>();

      //..... Initialize metaData_hm ......
      // this is needed to delete the last item model

      int metaTypeColIdx = metaEntry.getTable().findColumnIdx(METATYPE_COL_CONST);

      // for each type: 'node', 'bus', etc., but not for 'formatVersion'!
      
      for (Map<Integer, Object> row : metaEntry.getRows()) { 
         String typeName = metaEntry.getRowValue(row, metaTypeColIdx).toString();         
         metaData_hm.put(typeName, 0);
      }
      //..... Populate metaData_hm with real values (if found) ......
      
      for (BGModel model : models_hm.values()) {      // for each model
         
         //..... Calculate sums for each attribute (bus, node, etc) over all models ......
         
         for (Map.Entry<String, Integer> entry : ((BGModel)model).getTypeCounts().entrySet()) {
            String  metaType = entry.getKey();
            Integer cnt      = entry.getValue();
            
            if (metaData_hm.containsKey(metaType)) {
               cnt += (Integer)(metaData_hm.get(metaType));
               metaData_hm.put(metaType, cnt);      
            }
         }
         //..... Get format and format version for each model ......
         
         if (primaryUID == null) {
            primaryUID = model.getUuid();    // just for the initial 1st model setting
         }
         if (primaryUID != null && primaryUID.equals(model.getUuid())) {
            metaData_hm.put(FORMAT_FIELD_CONST, model.getFormat());
            //metaData_hm.put(FORMAT_VERSION_FIELD_CONST, model.getFormatVersion());
         }
      }
      //..... Default metaData ......
      
      if (models_hm.values().size() > 0) {
         //  metaData_hm.put("feeder",1);
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {
      org.apache.log4j.BasicConfigurator.configure();
      
      
      
      
      BGItem item = new BGItem();
      item.populateMetadata();
   }
   
   
   
}
//======================================= End of Class ============================================