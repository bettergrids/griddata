package org.dspace.app.webui.nlidb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

public class NLNumConverter implements NLLexicon
{
   private static final Logger log = Logger.getLogger(NLNumConverter.class);
        
   private static Long value = null;
   
   private static HashMap <String, Long>nums_hm = new HashMap <String, Long>();
   private static String[] smallDigs_sa = null;
   private static String[] largeDigs_sa = null;
   private static String[] allDigs_sa   = null;
   
   private static List<String> allDigs_al = null; 
   
   //----------------------------------------------------------------------------------------------
   // 
   //----------------------------------------------------------------------------------------------
   
   private static final NLNumConverter INSTANCE = new NLNumConverter();
    
   private NLNumConverter() {
      init();
   }
   public static final NLNumConverter getInstance() 
   {
      return INSTANCE;
   }
   public Long getValue() {
      return value;
   }
   public void setValue(Long value) {
      NLNumConverter.value = value;
   }

   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   private static void init()
   {
      if (nums_hm.isEmpty()) {
         int i;
         for (i = 0; i < _DIGITS_SA.length; i++) {
            nums_hm.put(_DIGITS_SA[i], (long)(i + 1));
         }
         for (i = 0; i < _TEENS_SA.length; i++) {
            nums_hm.put(_TEENS_SA[i], (long)(i + 10));
         }
         for (i = 0; i < _TENS_SA.length; i++) {
            nums_hm.put(_TENS_SA[i], (long)((i + 2) * 10));
         }
         nums_hm.put(_POWER_SA[0], 1000L);
         nums_hm.put(_POWER_SA[1], 1000000L);
         nums_hm.put(_POWER_SA[2], 1000000000L);
         
         nums_hm.put(_HUNDRED_SA[0], 100L);
         
         nums_hm.put(_ZERO_SA[0], 0L);
         nums_hm.put(_ZERO_SA[1], 0L);
      }
      if (smallDigs_sa == null) {
         smallDigs_sa = Stream.of(_DIGITS_SA, _TEENS_SA, _TENS_SA).flatMap(Stream::of).toArray(String[]::new);
      }
      if (largeDigs_sa == null) {
         largeDigs_sa = Stream.of(_HUNDRED_SA, _POWER_SA).flatMap(Stream::of).toArray(String[]::new);
      }
      if (allDigs_sa == null) {
         allDigs_sa = Stream.of(largeDigs_sa, smallDigs_sa, _ZERO_SA).flatMap(Stream::of).toArray(String[]::new);
         allDigs_al = Arrays.asList(allDigs_sa);
      }
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String translateNumbers(String text_s)
   {
      String[] text_sa     = text_s.trim().split(" ");
      List<String> text_al = new ArrayList<String>(Arrays.asList(text_sa));
      String   num_s    = "";
      
      //..... Check if "text_s" contains a text presentation of number ......
      
      int idx1 = 0;
      while (idx1 < text_al.size()) {
         int idx2 = idx1;
         while (idx2 < text_al.size() && allDigs_al.contains(text_al.get(idx2))) {
            num_s += text_al.get(idx2++) + " ";                // collect all words of number
         }
         if (idx2 > idx1) {
            try {
               Long value = getNumber(num_s.trim());
               text_al.set(idx1, value.toString());
               
               idx1 += 1;                                      // delete tokens if text number
               for (int i = idx1; i < idx2; i++) {             // comprises more than one word  
                  text_al.remove(idx1);
               }
            }
            catch (Exception e) {                              // should not be here
               text_s = "Text '" + num_s + "' cannot be converted to number";
               log.error("translateNumbers. " + text_s);
               return NLTranslator.RES_ERROR + text_s;
            }
            idx1  = idx2;
            num_s = "";
         }
         else {
            idx1++;
         }
      }         
      text_s = StringUtils.join(text_al, " ");
      return text_s;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String translateNumber(String text_s,  // return original text presentation 
                                        int    pos)     // starting position
   {
      String   num_s   = "";
      String   words_s = null;
      String[] num_sa  = text_s.substring(pos).split(" ");
      
      //..... Try to find is the current string a number ......
      
      try {
         value = new Long(num_sa[0]);           // This is just a number, like "30"
         return num_sa[0];
      }
      catch (Exception e) {                     // This is not a number
      }
      //..... Check if it is a text presentation of number ......
      
      int i = 0;
      while (i < num_sa.length && Arrays.asList(allDigs_sa).contains(num_sa[i])){
         num_s += num_sa[i] + " ";
         pos   += num_sa[i].length() + 1;
         i++;
      };
      if (num_s.length() == 0) {                   // This is not a text number
         return null;
      }
      //..... This should be a text number ......
      
      try {
         words_s = num_s.trim();
         value = getNumber(words_s);
         return words_s;                            // needs to count the new position after this number
      }
      catch (Exception e) {
         log.error("Text " + words_s + " cannot be convert to the number");    // should not be here
         value = null;                             
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   // All word here are DIGITS, TEENS or TENS
   //----------------------------------------------------------------------------------------------
   
   private static Long getSmallNumber(String[] num_sa,
                                      int      startIdx,
                                      int      lastIdx)
   {
      if (num_sa == null || startIdx < 0 || lastIdx < startIdx) return null;
      if (num_sa.length == 0) return 0L;
      
      int len       = lastIdx - startIdx + 1;
      String text_s = String.join(" ", num_sa);
      
      if (len != 1 && len != 2) {
         log.error("smallNumConvert. Cannot convert " + text_s + " to number");
         return null;
      }
      int idx = Arrays.asList(_TEENS_SA).indexOf(num_sa[startIdx]);      // Start with teens
      if (idx >= 0) {
         if (len == 2) {
            log.error("smallNumConvert. Cannot convert " + text_s + " to number");
            return null;
         }
         return nums_hm.get(_TEENS_SA[idx]);
      }
      idx = Arrays.asList(_DIGITS_SA).indexOf(num_sa[startIdx]);         // Start with digits
      if (idx >= 0) {
         if (len == 2) {
            log.error("smallNumConvert. Cannot convert " + text_s + " to number");
            return null;
         }
         return nums_hm.get(_DIGITS_SA[idx]);
      }
      idx = Arrays.asList(_TENS_SA).indexOf(num_sa[startIdx]);           // Start with tens
      if (idx >= 0) {
         Long val = nums_hm.get(_TENS_SA[idx]);
         if (len == 2) {
            int idx2 = Arrays.asList(_DIGITS_SA).indexOf(num_sa[lastIdx]);
            if (idx2 >= 0) {
               return val + nums_hm.get(_DIGITS_SA[idx2]);
            }
            log.error("smallNumConvert. Cannot convert " + text_s + " to number");
            return null;
         }
         return val;
      }
      idx = Arrays.asList(_ZERO_SA).indexOf(num_sa[startIdx]);           // Zero
      if (idx >= 0) {
         if (len == 2) {
            int idx2 = Arrays.asList(_DIGITS_SA).indexOf(num_sa[lastIdx]);
            if (idx2 >= 0) {
               return nums_hm.get(_DIGITS_SA[idx2]);
            }
         }
         return nums_hm.get(_ZERO_SA[idx]);
      }
      return null;
   }   
   //----------------------------------------------------------------------------------------------
   // Power
   //----------------------------------------------------------------------------------------------
   
   private static Long getPower (String[] num_sa,
                                 int      startIdx,
                                 int      lastIdx)
   {
      Long value    = null;
      String text_s = String.join(" ", num_sa);
      
      if (startIdx != lastIdx) {
         log.error("getPower. p.1. Cannot convert " + text_s + " to number");
      }
      int curIdx = Arrays.asList(_POWER_SA).indexOf(num_sa[startIdx]);
      if (curIdx >= 0) {
         value = nums_hm.get(_POWER_SA[curIdx]);
         return value;
      }
      log.error("getPower. p.2. Cannot convert " + text_s + " to number");
      return value;
   }
   //----------------------------------------------------------------------------------------------
   // Input text_s - only words from _DIGITS_SA, _TEENS_SA, TENS, _POWER_SA, _ZERO_SA
   //----------------------------------------------------------------------------------------------
   
   private static Long getNumber (String text_s)      // input only word numbers
   {
      if (text_s == null || text_s.length() == 0) return null;
      
      text_s.trim();
      String[] num_sa = text_s.split("\\s+");
      int len         = num_sa.length;
      
      //..... If it's ZERO or NO ......
      
      if (Arrays.asList(_ZERO_SA).indexOf(num_sa[0]) >= 0) {
         if (len == 1) {
            return 0L;
         }
         else {
            log.error("getNumber. p.1. Cannot convert " + text_s + " to number");
            return null;
         }
      }
      //..... Start with power and should end here ......

      int curIdx = 0;
      if (_HUNDRED_SA[0].equalsIgnoreCase(num_sa[curIdx])) {
         if (curIdx + 1 == len) {
            return nums_hm.get(num_sa[curIdx]);
         }
         else {
            log.error("getNumber. p.2. Cannot convert " + text_s + " to number");
            return null;            
         }
      }
      else {
         int idx = Arrays.asList(_POWER_SA).indexOf(num_sa[curIdx]);      
         if (idx >= 0) {
            if (curIdx + 1 == len) {
               return getPower(num_sa, 0, curIdx);
            }
            else {
               log.error("getNumber. p.3. Cannot convert " + text_s + " to number");
               return null;                       
            }
         }
      }
      //..... Start with the simple number ......
      
      Long value            = 0L;
      curIdx                = 0;
      boolean isPowerNow    = false;         
      Long val_simple       = 0L;
      Long val_power        = 0L;
      
      while(curIdx < len) {

         int beforeIdx = curIdx;
         
         //..... Convert simple number ......
         
         if (isPowerNow == false) { 
            while (curIdx < len && Arrays.asList(smallDigs_sa).indexOf(num_sa[curIdx]) >= 0) {
               curIdx++;
            };
            val_simple = getSmallNumber(num_sa, beforeIdx, curIdx - 1);
            if (val_simple == null) return null;
            
            if (curIdx == len) {                 // last tokens
               value += val_simple;
               return value;
            }
            if (_HUNDRED_SA[0].equalsIgnoreCase(num_sa[curIdx])) {     // hundred
               val_simple *= nums_hm.get(_HUNDRED_SA[0]);
               curIdx++;

               beforeIdx = curIdx;
               while (curIdx < len && Arrays.asList(smallDigs_sa).indexOf(num_sa[curIdx]) >= 0) {
                  curIdx++;
               };
               if (beforeIdx < curIdx) {
                  Long val_tmp = getSmallNumber(num_sa, beforeIdx, curIdx - 1);
                  if (val_tmp == null) return null;
                  
                  val_simple += val_tmp;
               }
            }
            if (curIdx == len) {                 // last tokens
               value += val_simple;
               return value;
            }
            isPowerNow = true;
         }
         //..... Convert power ......
         
         else {
            while (curIdx < len && Arrays.asList(_POWER_SA).indexOf(num_sa[curIdx]) >= 0) {
               curIdx++;
            };
            if (curIdx != beforeIdx + 1) {
               log.error("getNumber. p.4. Cannot convert " + text_s + " to number");
            }           
            val_power = getPower(num_sa, beforeIdx, curIdx - 1);
            if (val_power == null) return null;
            
            if (value == 0 || value > val_power) {
               value += val_simple * val_power;
            }
            else {
               log.error("getNumber. p.5. Cannot convert " + text_s + " to number");
               return null;
            }
            isPowerNow = false;
         }
      }
      return value;
   }   
   //==============================================================================================
   //
   //==============================================================================================
   
   public static void main(String args[]){
      org.apache.log4j.BasicConfigurator.configure();
      
      NLNumConverter testInstance = NLNumConverter.getInstance();
      //String text_s = "nine hundred ninety nine billion nine hundred ninety nine million nine hundred ninety nine thousand nine hundred ninety nine";
      String text_s = "nine hundred fifty two billion one hundred twenty million seven hundred nine thousand nine hundred ten";
      text_s += " loads";
      String res_s = NLNumConverter.translateNumber(text_s, 0);
      //Long result = NLNumConverter.getNumber("one hundred twenty two");
      System.out.println("Text   : "+ res_s);
      System.out.println("Result : "+ testInstance.value);
  }
}
//========================================= End of File ===========================================
