package org.dspace.app.webui.parser.ieee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBColumn;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGUtils;

public class CdfObject extends BGObject implements CdfTypes {

   private static final Logger log = Logger.getLogger(CdfObject.class);
   
   //..... Members ......
   
   // type idx: 0 - title, 1 - bus, 2 - branch, 3 - loss zones, 4 - interchange, 5 - tie lines
   
   private Integer  typeIdx      = null; 
   private Object[] attr_oa      = null;
   private String[] attrNames_sa = null;
   private CdfModel model;
   
   //..... Methods ......
   
   public Integer getAttrNum() 
   {
      if (attr_oa != null) {
         return attr_oa.length;
      }
      return 0;
   }   

   public Integer getTypeIdx() {
      return typeIdx;
   }

   public void setTypeIdx(Integer typeIdx) 
   {
      this.typeIdx = typeIdx;
      if (attr_oa == null) {
         attr_oa = new Object[ATTR_NAMES_SAA[typeIdx].length];
      }
   }

   @Override
   public Object getAttr(String attrName_s)
   {
      int idx = BGUtils.getStringIdx(attrName_s, getAttrNames());
      if (idx == -1) return null;
      return getAttr(idx);
   }

   @Override
   public List<Object> getAttrs() 
   {
      return new ArrayList<Object>(Arrays.asList(attr_oa));   
   }

   @Override
   public BGModel getModel() {
      return model;
   }
   public void setModel(CdfModel model) {
      this.model = model;
   }
   @Override
   public void setModel(BGModel model) {
      this.model = (CdfModel)model;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   /*
   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();

      //String objTypeId = type + ((id == null) ? "" : "_" + id.toString());
      
      //..... Start with object type, id and name (if any) as attributes ......
      
      json_sb.append("{\t\"object_type\" : \"" + type + "\",\n" );
      if (id != null) {
         json_sb.append("\t\"object_id\" : " + id.toString() + ",\n");
      }
      if (name != null) {
         json_sb.append("\t\"object_name\" : \"" + name + "\",\n");
      }
      //..... For each attribute ......
      
      for (int i = 0; i < getAttrNum(); i++) {
         String attrJson_s = BGObject.attrToJson(getAttrNames()[i], getAttr(i), null);
         json_sb.append(attrJson_s);
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n},\n");
      return json_sb.toString();
   }
   */
   //----------------------------------------------------------------------------------------------
   
   public String[] getAttrNames()
   {
      if (attrNames_sa == null) {
         setAttrNames();
      }
      return attrNames_sa;
   }
   //----------------------------------------------------------------------------------------------
   
   //----------------------------------------------------------------------------------------------
   // Set attribute names
   //----------------------------------------------------------------------------------------------
   
   public void setAttrNames()
   {
      if (typeIdx != null) {
         attrNames_sa = ATTR_NAMES_SAA[typeIdx];
      }
   }   
   //----------------------------------------------------------------------------------------------
   // Get table with column declarations
   //----------------------------------------------------------------------------------------------
   
   @Override
   public DBTable getTable() 
   {
      //..... Setup table ......

      String objType_s = getType();
      if (objType_s == null) return null;
      
      DBTable table = new DBTable();
      table.setName(objType_s);

      int attrLen = getAttrNames().length;      
      
      for (int i = 0; i < attrLen; i++) {         
         String  colName_s = ATTR_NAMES_SAA[typeIdx][i];
         Integer colType   = ATTR_TYPES_AA[typeIdx][i];

         DBColumn col = new DBColumn(colName_s, null, colType, i);
         table.addColumn(i, col);
      }
      return table;
   }
   //----------------------------------------------------------------------------------------------
/*   
   public static DBTable getTable(String objType_s) 
   {
      //..... Setup table ......

      if (objType_s == null) return null;
      int typeIdx = BGUtils.getStringIdx(objType_s, TYPES_SA);
      if (typeIdx == -1) return null;
      
      
      DBTable table = new DBTable();
      table.setName(objType_s);

      int attrLen = ATTR_NAMES_SAA[typeIdx].length;      
      
      for (int i = 0; i < attrLen; i++) {         
         String  colName_s = ATTR_NAMES_SAA[typeIdx][i];
         Integer colType   = ATTR_TYPES_AA[typeIdx][i];

         DBColumn col = new DBColumn(colName_s, null, colType, i);
         table.addColumn(i, col);
      }
      return table;
   }
   */
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Object getAttr(int idx) 
   {
      if (attr_oa != null && attr_oa.length > idx) {
         return attr_oa[idx];
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   
   public void setAttr(int idx, Object attr) 
   {
      if (attr_oa == null) {
         attr_oa = new Object[ATTR_NAMES_SAA[typeIdx].length];
      }
      if (attr_oa.length > idx) {
         attr_oa[idx] = attr;
      }
      else {
         log.error("CdfObject.setAttr. index idx = " + idx + " >= length of attr_oa = " + attr_oa.length);
      }
   }
}
//======================================= End of Class ============================================