package org.dspace.app.webui.parser.powerworld;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;

public class PowModel extends BGModel
{
   private static final Logger log = Logger.getLogger(PowModel.class);
   
   //..... Constants. Node type names ......
      
   public static final String TYPE_NAME_INFO               = "pwcaseinformation";
   public static final String TYPE_NAME_BUS                = "bus";
   public static final String TYPE_NAME_GENERATOR          = "generator";
   public static final String TYPE_NAME_TRANSFORMER        = "transformer";
   public static final String TYPE_NAME_TRANS_BRANCH       = "transformer_branch";
   public static final String TYPE_NAME_TRANSWIND_BRANCH   = "transformerwinding_branch";
   public static final String TYPE_NAME_XFORMER            = "gicxformer";
   public static final String TYPE_NAME_BRANCH             = "branch";
   public static final String TYPE_NAME_OWNER              = "owner";
   public static final String TYPE_NAME_LOAD               = "load";
   public static final String TYPE_NAME_SHUNT              = "shunt";
   public static final String TYPE_NAME_AREA               = "area";
   public static final String TYPE_NAME_ZONE               = "zone";   
   public static final String TYPE_NAME_SUBSTATION         = "substation";
   public static final String TYPE_NAME_LINE               = "line";
   public static final String TYPE_NAME_LINE_BRANCH        = "line_branch";
   public static final String TYPE_NAME_MULTILINE          = "multisectionline";
   
   public static final String FROM_NAME                  = "_from";
   public static final String TO_NAME                    = "_to";
   public static final String LENGTH_NAME                = "length";
   public static final String NAME_NAME                  = "name";
     
   public static final String[] NODE_TYPE_NAMES = {TYPE_NAME_BUS,                            // 900
                                                   TYPE_NAME_LOAD,                           // 901
                                                   TYPE_NAME_GENERATOR,                      // 902
                                                   TYPE_NAME_SHUNT};                         // 903
                                                                          
   public static final String[] LINK_TYPE_NAMES = {TYPE_NAME_TRANSFORMER,                    // 904
                                                   TYPE_NAME_TRANS_BRANCH,                   // 905
                                                   TYPE_NAME_TRANSWIND_BRANCH,               // 906
                                                   TYPE_NAME_XFORMER,                        // 907
                                                   TYPE_NAME_BRANCH,                         // 908
                                                   TYPE_NAME_LINE,                           // 909
                                                   TYPE_NAME_LINE_BRANCH,                    // 910
                                                   TYPE_NAME_MULTILINE};                     // 911
   
   public static final String BRANCH_DEVICE_TYPE_NAME  = "branchdevicetype";
   
   //..... Members ......
   
   //          objType        objName object
   private Map<String, HashMap<String,PowObject>> object_mhm = new LinkedHashMap<String, HashMap<String,PowObject>>();

   private List<String> objTypeNames_al        = new ArrayList<String>();
   
   //          objType
   private Map<String, ArrayList<String>>  attrNames_hml = new LinkedHashMap<String, ArrayList<String>>();
   private Map<String, ArrayList<Integer>> attrTypes_hml = new LinkedHashMap<String, ArrayList<Integer>>();
   
   //..... These maps needed only in the parsing stage ......
   
   private Map<String, Integer> objTypeNameidx = new HashMap<String, Integer>();
   private Map<String, Integer> objNameidx     = new HashMap<String, Integer>();
   
   //---------------------------------------------------------------------------------------------
   // Get attribute names hash map
   //---------------------------------------------------------------------------------------------
   
   public Map<String, ArrayList<String>> getAttrNamesHm()
   {
      return attrNames_hml;
   }
   //----------------------------------------------------------------------------------------------
   // Generate indices for object name and for type name
   //----------------------------------------------------------------------------------------------

   public Integer getNewObjNameidx(String objType_s) 
   {
      Integer idx = objNameidx.get(objType_s);
      if (idx == null) {
         idx = 0;
      }
      else {
         idx += 1;
      }
      objNameidx.put(objType_s, idx);
      return idx;
   }
   //----------------------------------------------------------------------------------------------
   
   public String generateObjTypeName(String objType_s) 
   {
      Integer idx = objTypeNameidx.get(objType_s);
      if (idx == null) {
         idx = 0;
      }
      idx += 1;
      objTypeNameidx.put(objType_s, idx);
      return objType_s + "-" + idx;
   }
   //----------------------------------------------------------------------------------------------
   // Get object hashmap
   //----------------------------------------------------------------------------------------------
   
   public Map<String, HashMap<String,PowObject>> getObjectsHm()
   {
      return object_mhm;
   }
   //----------------------------------------------------------------------------------------------
   // Get/Add object to specific section
   //----------------------------------------------------------------------------------------------
      
   public List<String> getAttrNames(String objType_s) 
   {      
      if (attrNames_hml != null) {
         return attrNames_hml.get(objType_s);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   // Add new object type name
   //----------------------------------------------------------------------------------------------
   
   public void addObjTypeName(String objType_s)
   {
      if (objTypeNames_al.contains(objType_s) == false) {
         objTypeNames_al.add(objType_s);
      }
   }
   //----------------------------------------------------------------------------------------------
   // Delete object type section
   //----------------------------------------------------------------------------------------------
   
   public boolean deleteObjType(String objType_s)
   {
      object_mhm.remove(objType_s);
      objTypeNames_al.remove(objType_s);
      attrNames_hml.remove(objType_s);
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Re-map object type name
   //----------------------------------------------------------------------------------------------
   
   public boolean remapObjTypeName(String fromType_s,
                                   String toType_s)
   {
      if (remapAttrObjTypeName(fromType_s, toType_s) == false) return false;

      objTypeNames_al.remove(fromType_s);
      objTypeNames_al.add(toType_s);
      
      object_mhm.put(toType_s, object_mhm.remove(fromType_s));
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Re-map attributes to different object type name
   //----------------------------------------------------------------------------------------------
   
   public boolean remapAttrObjTypeName(String fromType_s,
                                       String toType_s)
   {
      if (fromType_s == null || toType_s == null) return false;
      if (attrNames_hml.get(fromType_s) == null)  return false;
      
      attrNames_hml.put(toType_s, attrNames_hml.remove(fromType_s));
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Set attribute names of type specified
   //----------------------------------------------------------------------------------------------
   
   public void setAttrNames(String            objType_s,
                            ArrayList<String> attrNames_al)
   {  
      if (objTypeNames_al.indexOf(objType_s) == -1) {
         objTypeNames_al.add(objType_s);
      }
      attrNames_hml.put(objType_s, attrNames_al);
   }
   //----------------------------------------------------------------------------------------------
   // Get all object types
   //----------------------------------------------------------------------------------------------

   @Override
   public String[] getObjTypeNames() 
   {
      return objTypeNames_al.toArray(new String[objTypeNames_al.size()]);
      //return ArrayUtils.addAll(NODE_TYPE_NAMES, LINK_TYPE_NAMES);
   }
   //----------------------------------------------------------------------------------------------
   // Get all object types for calculating paths
   //----------------------------------------------------------------------------------------------

   public String[] getStaticObjTypeNames() 
   {
      return ArrayUtils.addAll(NODE_TYPE_NAMES, LINK_TYPE_NAMES);
   }

   //----------------------------------------------------------------------------------------------
   // Add attribute name for object of type specified
   //----------------------------------------------------------------------------------------------
   
   public void addAttrName(String objType_s,
                           String attrName_s)
   {  
      if (objTypeNames_al.indexOf(objType_s) == -1) {
         objTypeNames_al.add(objType_s);
      }
      if (attrNames_hml.get(objType_s) == null) {
         attrNames_hml.put(objType_s, new ArrayList<String>());
      }
      attrNames_hml.get(objType_s).add(attrName_s);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean addObject(PowObject obj)
   {
      if (obj == null || obj.getName() == null || obj.getType() == null) return false;
   
      String type_s = obj.getType();
      String name_s = obj.getName();
      if (object_mhm.get(type_s) == null) {
         object_mhm.put(type_s, new HashMap<String,PowObject>());
      }
      object_mhm.get(type_s).put(name_s, obj);
      return true;
   }
   //----------------------------------------------------------------------------------------------
   
   public boolean moveObject(PowObject obj, 
                             String    fromType_s)
   {
      if (fromType_s == null) return false;
      
      addObject(obj);

      if (getAttrNames(obj.getType()) == null) {
         this.setAttrNames(obj.getType(), (ArrayList<String>)getAttrNames(fromType_s));
      }
      object_mhm.get(fromType_s).remove(obj.getName());
      return true;
   }

   //----------------------------------------------------------------------------------------------
   
   @Override
   public PowObject getObject(String name_s)
   {
      for (HashMap<String,PowObject> obj_hm : object_mhm.values()) {
         if (obj_hm.get(name_s) != null) {
            return obj_hm.get(name_s);
         }
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public PowObject[] getObjects(String objType_s) 
   {
      HashMap<String,PowObject> objs = object_mhm.get(objType_s);
      if (objs == null) return new PowObject[0];
      
      List<BGObject> values =  new ArrayList<BGObject>(objs.values());
      return values.toArray(new PowObject[values.size()]);
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public PowObject[] getObjects() 
   {
      List<PowObject>objs_al = new ArrayList<PowObject>();
      for (HashMap<String,PowObject> objs_hm : object_mhm.values()) {
         objs_al.addAll(objs_hm.values());         
      }
      return objs_al.toArray(new PowObject[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public BGObject[] getObjects(int typeIdx) 
   {
      try {
         String objType_s = (String)object_mhm.keySet().toArray()[typeIdx];
         return getObjects(objType_s);
      }
      catch (Exception e) {
         log.error("getObjects. Cannot find objects with type index " + typeIdx);
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public boolean calcTypeCounts() 
   {
      //..... Calculate counts of all types ......
   
      if (typeCounts.isEmpty()) {
         for (Map.Entry <String, HashMap<String,PowObject>> entry : object_mhm.entrySet()) {            
            String  objType_s  = entry.getKey();
            Integer objTypeCnt = entry.getValue().size();
            
            typeCounts.put(objType_s, objTypeCnt);
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public BGObject[] getLinkObjects() 
   {
      List<PowObject> objs_al = new ArrayList<PowObject>(); 
      
      for (String objType_s : getObjTypeNames()) {
         List<String> attrNames = getAttrNames(objType_s);
     
         if (attrNames.contains(PowModel.FROM_NAME) && attrNames.contains(PowModel.TO_NAME)) {
            PowObject[] objs = getObjects(objType_s);
            objs_al.addAll(Arrays.asList(objs));           
         }
      }
      return objs_al.toArray(new PowObject[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
      
   @Override
   public Integer getTypesNum() 
   {
      return getObjTypeNames().length;
      //return NODE_TYPE_NAMES.length + LINK_TYPE_NAMES.length;
   }
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();
      json_sb.append("{\n\""  + BGObject.OBJECT_CONST + "\": [\n");
      
      //..... For each object ......
      
      for (HashMap<String,PowObject> objs : object_mhm.values()) {
         if (objs == null) continue; 
      
         for (PowObject obj : objs.values()) {
            json_sb.append(obj.toJson());
         }
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n]\n}");
      
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getNodeObjTypeNames() 
   {
      return objTypeNames_al.toArray(new String[objTypeNames_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public String[] getLinkObjTypeNames() 
   {
      List<String> objs_al = new ArrayList<String>(); 
      
      for (int sectIdx = 0; sectIdx < getTypesNum(); sectIdx++) {    
         List<String> attrNames = getAttrNames(sectIdx);
        
         if (attrNames.contains(PowModel.FROM_NAME) && attrNames.contains(PowModel.TO_NAME)) {
            String objType_s = getObjTypeName(sectIdx);
            objs_al.add(objType_s);           
         }
      }
      return objs_al.toArray(new String[objs_al.size()]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String getObjTypeName(int sectIdx) {
      // TODO Auto-generated method stub
      return null;
   }
   @Override
   public List<String> getAttrNames(int typeIdx) {
      // TODO Auto-generated method stub
      return null;
   }
   @Override
   public List<Integer> getAttrTypes(int typeIdx) {
      // TODO Auto-generated method stub
      return null;
   }
   @Override
   public Integer getAttrIdx(int sectIdx, String attrName) {
      // TODO Auto-generated method stub
      return null;
   }
}
