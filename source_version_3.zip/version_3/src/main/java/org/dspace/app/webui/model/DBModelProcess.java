package org.dspace.app.webui.model;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.UUID;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.nlidb.NLMapper;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.parser.BGParser;
import org.dspace.app.webui.submit.step.JSPUploadStep;
import org.dspace.app.webui.util.BGUtils;
import org.dspace.content.Bitstream;
import org.dspace.content.Bundle;
import org.dspace.content.Item;
import org.dspace.core.Context;

public class DBModelProcess implements DBTypes {

   private static final Logger log = Logger.getLogger(DBModelProcess.class);
   
   //..... Members ......
   
   private Item    item;
   private Boolean result_b;
   private Context context;

   HashMap<UUID, BGModel> models_hm = new HashMap<UUID, BGModel>();   // containers to keep Item information
   
   //..... Constructor ......
   
   public DBModelProcess(Context context, Item item)
   {
      this.context = context;
      this.item    = item;
   }
   //..... Methods .....
   
   public Item getItem() {
      return item;
   }
   public void setItem(Item item) {
      this.item = item;
   }
   public Boolean getResult_b() {
      return result_b;
   }
   public void setResult_b(Boolean result_b) {
      this.result_b = result_b;
   }
   public Context getContext() {
      return context;
   }
   public void setContext(Context context) {
      this.context = context;
   }
   //----------------------------------------------------------------------------------------------
   // Process all bitstream of specified item. This is a part of processing which is not included 
   // in the thread, because items information (context) is not available after sending response
   // by servlet
   //----------------------------------------------------------------------------------------------

   public boolean prepareFilesToProcess()
   {
      boolean res_b = true;
      
      if (item == null || item.getBundles() == null) {
         log.error("DBModelProcess.prepareFilesToProcess. Item and/or item bundles equal null");
         return false;
      }
      for (Bundle bundle : item.getBundles()) {
         if (bundle == null) continue;
         for (Bitstream bs : bundle.getBitstreams()) {
            
            String filePath_s   = JSPUploadStep.getFilePath(bs);
            String fileFormat_s = null;
            try {
               fileFormat_s = bs.getFormatDescription(getContext()).trim();
            } 
            catch (SQLException e1) {
               log.error("DBModelProcess.prepareFilesToProcess. Cannot get bitstream format. Error: " + 
                         e1.getMessage() + "; Stack Trace: " + ExceptionUtils.getStackTrace(e1));
               res_b = false;
            }
            //..... Instantiate model ......
            
            BGModel model = BGModel.createModel(fileFormat_s);
            if (model == null) continue;
            
            try {
               model.setUuid(bs.getID());
               model.setFormat(fileFormat_s);
               model.setPath(filePath_s);
               model.setName(bs.getName().replace(".", "-"));
               model.setDescription(bs.getDescription());
               model.setVisible(!item.isWithdrawn() & item.isDiscoverable() & !bs.isDeleted());
               models_hm.put(bs.getID(), model);
            
               log.info("DBModelProcess.prepareFilesToProcess. Format: " + model.getFormat() + 
                        "; UUID: " + model.getUuid() + "; Path:" + model.getPath());
            }
            catch(Exception e)  {
               log.info("DBModelProcess.prepareFilesToProcess. Cannot get all item/bitstream parameters" +
                        "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
               res_b = false;
            }
         }
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Process all bitstream of specified item. This is a part of processing which is not included 
   // to the thread, because items information (context) is not available after servlet send
   // response
   //----------------------------------------------------------------------------------------------

   public boolean prepareAllBitstampsToProcess()
   {
      boolean res_b = true;
      
      if (item == null || item.getBundles() == null) {
         log.error("DBModelProcess.prepareAllBitstampsToProcess. Item and/or item bundles equal null");
         return false;
      }
      for (Bundle bundle : item.getBundles()) {
         if (bundle == null) continue;
         for (Bitstream bs : bundle.getBitstreams()) {
            
            String filePath_s   = JSPUploadStep.getFilePath(bs);
            String fileFormat_s = null;
            try {
               fileFormat_s = bs.getFormatDescription(getContext()).trim();
            } 
            catch (SQLException e1) {
               log.error("DBModelProcess.prepareAllBitstampsToProcess. Cannot get bitstream format. Error: " + 
                         e1.getMessage() + "; Stack Trace: " + ExceptionUtils.getStackTrace(e1));
               res_b = false;
            }
            //..... Instantiate model ......
            
            BGModel model = BGModel.createModel(fileFormat_s);
            if (model == null) continue;
            
            model.setUuid(bs.getID());
            model.setFormat(fileFormat_s);
            model.setPath(filePath_s);
            model.setName(bs.getName());
            models_hm.put(bs.getID(), model);
            
            log.info("DBModelProcess.prepareAllBitstampsToProcess. Format: " + model.getFormat() + 
                     "; UUID: " + model.getUuid() + "; Path:" + model.getPath());
         }
      }
      return res_b;
   }   
   //----------------------------------------------------------------------------------------------
   // THREAD part of processing. Process all prepared models.
   //----------------------------------------------------------------------------------------------

   public boolean processModels()
   {
      //..... Open DB connection ......
      
      log.debug("processModels. Started processing item: " + item.getID());
      
      DBConnection dbConn = new DBConnection(DBProvider.GraphDB);
      Connection conn     = dbConn.getConnection();
      DBExecute  exec     = new DBExecute();

      //..... For each model: parse and save models ......
      
      boolean res_b = true;
      for (Entry<UUID, BGModel> entry : models_hm.entrySet()) {
         UUID key      = entry.getKey();
         BGModel model = entry.getValue();
         if (model == null) continue;
         
         model = processBitstream(conn, exec, model, true);
         if (model == null || model.getObjects() == null || model.getObjects().length == 0) {
            res_b = false;
            continue;
         }         
         models_hm.put(key, model);    // save processed model for further link calculation
      }
      //..... For each model: calculate and save link and type paths data ......
      
      for (BGModel model : models_hm.values()) {
         if (model == null) continue;
         res_b &= processModelLinks(conn, exec, model);
      }
      //..... Verify that table _modelinfo and _model2 are in sync ......
      
      String sql_s = "DELETE FROM " + BGModel.INFO_TABLE_NAME + " mi WHERE NOT EXISTS " +
                     "(SELECT 1 FROM " + BGModel.PARENT_TABLE_NAME + " m2 WHERE mi." +
                     DBTypes.modelId + " = m2." + DBTypes.modelId + ")";
      exec.execDML(conn, sql_s);
      
      dbConn.close();
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Process (parse, save in Graph DB) bitstream (file). This is a part of processing prepared 
   // for running in thread.
   //
   // modelIn  - used only as a container for prepared Item information (file path, file format,
   //            and bitstream uuid
   //----------------------------------------------------------------------------------------------
   
   public BGModel processBitstream(Connection conn,
                                   DBExecute  exec,
                                   BGModel    modelIn,      // used only as a container
                                   boolean    override_b)
   {
      //..... Check if this bitstream already processed ......
      
      boolean res_b = true;
      
      if (override_b == false) {
         res_b = checkModelExist(conn, exec, modelIn.getUuid());
         if (res_b) return null;
      }
      BGModel model = BGParser.parseFile(modelIn);      
      if (model == null) {
         log.error("processBitstream. Cannot parse file: " + modelIn.getPath() + 
                   "; Model format: " + modelIn.getFormat());
         return null;
      }
      model.setUuid(modelIn.getUuid());
      model.setName(modelIn.getName());
      model.setDescription(modelIn.getDescription());
      model.setVisible(modelIn.getVisible());
      
      //..... Save model (bitstream) in the Graph DB ......
      
      res_b = saveParsedModel(conn, exec, model, override_b); 
      if (res_b == false) return null;
      
      log.info("processBitstream. Parsed and saved model: " + model.getName());
      return model;
   }
   //----------------------------------------------------------------------------------------------
   // Second step to process model (as a second part of the thread processing):
   // - calculate all branch links;
   // - save calculated data arrays (linkup, linkdown, hopsup, etc.) in the branch objects records 
   //   of corresponding model.
   // - calculate and save typeId paths in the _paths table
   //----------------------------------------------------------------------------------------------
   
   public boolean processModelLinks(Connection conn,
                                    DBExecute  exec,
                                    BGModel    model)
   {
      //..... Check if this model already processed (it should be processed!)......

      boolean res_b = checkModelExist(conn, exec, model.getUuid());
      if (res_b == false) {
         log.error("processModelLinks. Cannot find model: " + model.getName() + 
                   " in the Graph DB");
         return false;
      }
      //..... Calculate links for the model ......
      
      Long startStamp = Instant.now().toEpochMilli();
      log.info("processModelLinks. Started calculating links for model : " + model.getName());
      
      res_b = model.calculateLinks();
      if (res_b == false) {
         log.error("processModelLinks. Error in calculating links for the model: " + 
                    model.getName());
         return false;
      }
      //..... Save calculated data in the Graph DB ......
      
      res_b = saveModelLinks(conn, exec, model);
      
      Double spentSec = new Double(Instant.now().toEpochMilli() - startStamp) / 1000.0;
      log.info("processModelLinks. Finished calculating links for model : " + model.getName() + 
            "; Total time: " + spentSec + " sec; Result: " + res_b); 

      //..... Calculate model type paths in the Graph DB (_paths table) ......
   
      startStamp = Instant.now().toEpochMilli();
      log.info("processModelLinks. Started calculating type paths for model : " + model.getName());

      res_b &= model.calculateTypePaths();      
      res_b &= saveTypePaths(conn, exec, model);
            
      spentSec = new Double(Instant.now().toEpochMilli() - startStamp) / 1000.0;
      log.info("processModelLinks. Finished calculating type paths for model : " + model.getName() + 
            "; Total time: " + spentSec + " sec; Result: " + res_b); 

      return res_b;
   }   
   //----------------------------------------------------------------------------------------------
   // Check the info table on containing the specified model (based on UUID)
   //----------------------------------------------------------------------------------------------
   
   public boolean checkModelExist(Connection conn,
                                  DBExecute  exec,
                                  UUID       modelUid)
   {
      List<String> colNames  = Arrays.asList(BGModel.PARENT_TABLE_COLUMNS[0]);
      List<String> values    = Arrays.asList(modelUid.toString());
      List<String> operators = Arrays.asList("=");
      List<Integer> types    = Arrays.asList(typeUUID);
      
      DBEntry entry = exec.execSimpleSelect(conn, BGModel.INFO_TABLE_NAME, colNames,
                                            operators, values, types);
      if (entry == null || entry.isEmpty()) {
         return false;
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Get original file name from the DSpace DB
   //----------------------------------------------------------------------------------------------

   public String getOrigFileName(Connection dspaceConn,
                                 DBExecute  exec,
                                 UUID       bitstreamUid)
   {
      String sql_s = "SELECT text_value FROM metadatafieldregistry WHERE" +
                     " metadata_field_id = 70 AND dspace_object_id = '" +
                     bitstreamUid + "'";
      
      DBEntry entry = exec.execQuery(dspaceConn, sql_s, null);
      
      if (entry != null) {
         return entry.getValue(0, 0).toString();
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------
   // Save parsed model in the Graph DB
   //----------------------------------------------------------------------------------------------

   public boolean saveParsedModel (Connection conn,
                                   DBExecute  exec,
                                   BGModel    model,
                                   boolean    override_b)   // need to override existing records
   {
      if (model == null || model.getFormat() == null) {
         log.error("ModelProcess.saveParsedModel. Model " + model.getName() + 
                   " and/or model format are null");
         return false;
      }
      String[] objTypeNames = model.getObjTypeNames();
      if (objTypeNames == null || objTypeNames.length == 0) {
         log.error("ModelProcess.saveParsedModel. Model " + model.getName() + 
                   ". No model objects specified");
         return false;
      }
      boolean res_b = true;
      
      //..... Override model ......
      
      if (override_b) {
         res_b = deleteModel(conn, exec, model.getUuid());
         if (res_b == false) return false;
      }
      //..... Check if model already exists in Graph DB ......
      
      else {
         res_b = checkModelExist(conn, exec, model.getUuid());
         if (res_b == true) return true;
      }
      //..... Make a record in the model info table ......
      
      res_b = saveModelInfo(conn, exec, model);
      
      //..... Create model DB table, like "_psse", "_cdf", etc. (if needed) ......
      
      createModelTable(conn, exec, model.getDbTableName(), BGModel.PARENT_TABLE_NAME);

      //..... GridLab-D model processing (from DBEntry)......
      
      switch(model.getFormat()) {
      case BGModel.MODEL_FORMAT_GRIDLAB:
      case BGModel.MODEL_FORMAT_OPENDSS:
      case BGModel.MODEL_FORMAT_GRG:
      case BGModel.MODEL_FORMAT_POWERWORLD:
         
         for (int sectIdx = 0; sectIdx < objTypeNames.length; sectIdx++) {
            
            String sectName = objTypeNames[sectIdx];
            DBEntry entry   = model.getEntry(sectName, null, false);
            if (entry.isEmpty()) continue;
            
            res_b = insertModelSect(conn, exec, model.getDbTableName(), model.getUuid(), sectName, entry);
            
            if (res_b == false) {
               log.error("ModelProcess.saveParsedModel. Model " + model.getName() + 
                         ". Error in parsing section " + objTypeNames[sectIdx]);               
               deleteModel(conn, exec, model.getUuid());
               return false;
            }
         }
         break;
         
       //..... All other (table based) model formats ......
         
      default:
         for (int sectIdx = 0; sectIdx < objTypeNames.length; sectIdx++) {
            if (model.getObjects(sectIdx).length == 0) continue; 

            res_b = insertModelSect(conn, exec, model, sectIdx);
            
            if (res_b == false) {
               log.error("BGParser.testModels. Model " + model.getName() + 
                         ". Error in parsing section " + objTypeNames[sectIdx]);
               deleteModel(conn, exec, model.getUuid());
               return false;
            }
         }
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Save parsed model in the Graph DB
   //----------------------------------------------------------------------------------------------

   public boolean saveModelLinks (Connection conn,
                                  DBExecute  exec,
                                  BGModel    model)
   {
      if (model == null || model.getFormat() == null) {
         log.error("saveModelLinks. Model " + model.getName() + " and/or model format are null");
         return false;
      }
      boolean res_b = true;
      
      //..... DB table name ......
      
      String dbTableName = BGModel.getDbTableName(model.getFormat());
      UUID   modelUidVal = model.getUuid();
      
      //..... Match and Update column names ......
      
      String attrName_bus = model.getAttrName_bus();
      
      List<String> matchColNames  = Arrays.asList(modelId, nodeType, attrName_bus);
      List<String> updateColNames = Arrays.asList(BGModel.LINKS_COLUMN_NAMES);
      
      //..... For each "link" type ......

      List<List<Object>> matchRows  = new ArrayList<List<Object>>();
      List<List<Object>> updateRows = new ArrayList<List<Object>>();
      
      for (int linkIdx = 0; linkIdx < model.getNodeObjTypeNames().length; linkIdx++) {
         
         String objType_s = model.getNodeObjTypeNames()[linkIdx];
         BGObject[] objs  = model.getObjects(objType_s);
         
         //..... For each object ......
         
         for (int i = 0; i < objs.length; i++) {         
            BGObject obj       = objs[i];
                        
            if ((obj.getLinksUp()   == null || obj.getLinksUp().isEmpty()) && 
                (obj.getLinksDown() == null || obj.getLinksDown().isEmpty())) {
               continue;
            }
            Object objNodeType = obj.getType();
            Object objBus      = obj.getAttr(attrName_bus);
            
            List<Object> matchRow = new ArrayList<Object>();
            matchRow.add(modelUidVal);
            matchRow.add(objNodeType);
            matchRow.add(objBus);
            matchRows.add(matchRow);
            
            List<Object> updateRow = new ArrayList<Object>();
            
            updateRow.add(obj.getLinkNodes(true));
            updateRow.add(obj.getLinkHops(true));
            updateRow.add(obj.getLinkDistances(true));
            
            updateRow.add(obj.getLinkNodes(false));
            updateRow.add(obj.getLinkHops(false));
            updateRow.add(obj.getLinkDistances(false));
            
            updateRows.add(updateRow);
         }
      }
      //..... Execute update ......
      
      res_b = exec.execUpdate(conn, dbTableName, matchColNames, matchRows, updateColNames, updateRows);
      if (res_b == false) {
         log.error("saveModelLinks. Model " + model.getName() + ". Failed insert links");
         return false;
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Save model info. Add record to the _modelinfo table
   //----------------------------------------------------------------------------------------------
   
   public boolean saveModelInfo(Connection conn,
                                DBExecute  exec,
                                BGModel    model)
   {
      if (createInfoTable(conn, exec) == false) return false;
      
      DBEntry entry = model.getModelInfoAsRow();
      exec.modifyColumnNames(conn, entry.getTable());
      
      boolean res_b = exec.addColumns(conn, BGModel.INFO_TABLE_NAME, entry.getTable());
      if (res_b == false) return false;
      
      //..... Add mandatory columns from NLMapper ......
            
      DBTable mandatoryTable = new DBTable();
      int colIdx = 0;
      for (String colName : NLMapper._NODETYPE_KEY_SA) {
         DBColumn column = new DBColumn(colName, null, DBTypes.typeInt, colIdx);
         mandatoryTable.addColumn(colIdx, column);
         colIdx++;
      }
      res_b = exec.addColumns(conn, BGModel.INFO_TABLE_NAME, mandatoryTable);
      if (res_b == false) return false;

      //..... Insert info data ......
      
      List<String>columnMatch = Arrays.asList(BGModel.INFO_TABLE_COLUMNS[0]);
      res_b = exec.execUpsert(conn, columnMatch, null, entry);
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Create DBEntry for TEMP table with model links
   //----------------------------------------------------------------------------------------------

   private static boolean saveTypePaths(Connection conn,
                                        DBExecute  exec,
                                        BGModel    model)
   {
      boolean res_b = true;
            
      //..... Create entry with table from DB ......
      // modeluid    UUID
      // paths       int[]  -- typeId paths
      
      DBEntry entry = exec.getMetadataFromDB(conn, BGModel.PATHS_TABLE_NAME);
      DBTable table = entry.getTable();
      
      List<List<Object>> rows = new ArrayList<List<Object>>();     
      
      for (Integer[] path : model.getPaths()) {
         if (path == null) continue;
         
         ArrayList<Object> row = new ArrayList<Object>();
         row.add(model.getUuid());
         row.add(path);
         rows.add(row);
      }
      //..... Insert data to the database ......
      
      if (rows.isEmpty() == false) {
         Integer[] columnTypes = exec.getTypesFromValues(rows);
      
         res_b = exec.execBulkInsert (conn, table.getName(), Arrays.asList(columnTypes), 
                                      table.getColumnNames(), rows);
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Delete model from Graph DB
   //----------------------------------------------------------------------------------------------
   
   public static boolean deleteModel(UUID modelUid)
   {
      DBConnection dbConn = new DBConnection(DBProvider.GraphDB);
      Connection conn     = dbConn.getConnection(); 
      DBExecute exec      = new DBExecute();
      
      boolean res_b = deleteModel(conn, exec, modelUid);
      if (res_b) {
         log.info("deleteItem. model: " + modelUid + " was deleted from the Graph DB");
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Delete model from Graph DB
   //----------------------------------------------------------------------------------------------
   
   public static boolean deleteModel(Connection conn,
                                     DBExecute  exec,
                                     UUID       modelUid)
   {
      boolean res_b = true;
      
      //..... Delete from parent table ......
      
      List<String> paramColNames = Arrays.asList(modelId);
      List<String> values        = Arrays.asList(modelUid.toString());

      //..... Delete model from _paths table ......
      
      int res = exec.execDelete(conn, BGModel.PATHS_TABLE_NAME, paramColNames, values);
      if (res == -1) {
         log.error("ModelProcess.deleteModel. Cannot delete model: " + values.get(0) + 
                   " from " + BGModel.PATHS_TABLE_NAME + " table");
         res_b = false;
      }
      //..... Delete from parent table ......
      
      res = exec.execDelete(conn, BGModel.PARENT_TABLE_NAME, paramColNames, values);
      if (res == -1) {
         log.error("ModelProcess.deleteModel. Cannot delete model: " + values.get(0) + 
                   " from " + BGModel.PARENT_TABLE_NAME + " table");
         res_b = false;
      }
      //..... Delete from model info table ......
      
      res = exec.execDelete(conn, BGModel.INFO_TABLE_NAME, paramColNames, values);
      if (res == -1) {
         log.error("ModelProcess.deleteModel. Cannot delete model: " + values.get(0) + 
                   " from " + BGModel.INFO_TABLE_NAME + " table");
         res_b = false;
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Delete item models from Graph DB
   //----------------------------------------------------------------------------------------------

   public boolean deleteItem()
   {
      boolean com_b = true;
      
      if (item == null || item.getBundles() == null) {
         log.error("DBModelProcess.deleteItem. Item and/or item bundles equal null");
         return false;
      }
      DBConnection dbConn = new DBConnection(DBProvider.GraphDB);
      Connection conn     = dbConn.getConnection(); 
      DBExecute exec      = new DBExecute();
      
      for (Bundle bundle : item.getBundles()) {
         if (bundle == null) continue;
         for (Bitstream bs : bundle.getBitstreams()) {
            
            //..... Check that bitstream is not associated with other bundles ......
            
            try {
               String sql_s = "SELECT count(*) cnt FROM bundle2bitstream WHERE " +
                              "bitstream_id='" + bs.getID().toString() + "'";
               
               DBEntry entry = DBFunctions.execSelect(sql_s, DBProvider.DSpaceDB);
               List<Object> res = entry.getColumnValues("cnt");
               Long resLong = (Long)res.get(0);
               if (resLong > 1) {
                  continue;         // skip deleting this bitstream
               }
            }
            catch (Exception e) {
               log.error("deleteItem. Stack Trace: " + ExceptionUtils.getStackTrace(e));
            }
            //..... Delete bitstream/model from Graph DB ......
            
            boolean res_b = deleteModel(conn, exec, bs.getID());
            if (res_b) {
               log.info("deleteItem. model: " + bs.getID() + " was deleted from the Graph DB");
            }
            com_b &= res_b;
         }
      }
      return com_b;
   }   
   //----------------------------------------------------------------------------------------------
   // Execute insert model to the database type-by-type (section)
   //----------------------------------------------------------------------------------------------
      
   public static boolean insertModelSect (Connection conn,
                                          DBExecute  exec,
                                          BGModel    model,
                                          int        sectIdx)
   {
      boolean res_b = true;      
      
      //..... Update DB table (add columns) if needed ......
      
      String dbTableName = model.getDbTableName();
      
      res_b = exec.addAttrColumns(conn, dbTableName, model, sectIdx);
      if (res_b == false) return false;
         
      //..... Add common attributes ......
         
      List<String>  columnNames = new ArrayList<String>(Arrays.asList(colCommonNames));
      List<Integer> columnTypes = new ArrayList<Integer>(Arrays.asList(colCommonTypes));
      
      addEntryColumns(columnNames, columnTypes, model.getAttrNames(sectIdx), model.getAttrTypes(sectIdx));
      
      List<List<Object>> rows = new ArrayList<List<Object>>();
      
      //..... Re-map model parameters ......
             
      for (BGObject obj : model.getObjects(sectIdx)) {
         List<Object> row = new ArrayList<Object>();
         
         for (int i = 0; i < columnNames.size(); i++) {
            String  colName = columnNames.get(i);
            
            if      (colName.equals(DBTypes.modelId))   row.add(model.getUuid());
            else if (colName.equals(DBTypes.nodeType))  row.add(model.getObjTypeName(sectIdx));
            else if (colName.equals(DBTypes.tableName)) row.add(dbTableName);
            else if (model.getAttrNames(sectIdx).contains(colName)) {
               row.add(obj.getAttr(colName));
            }
            else {
               row.add(null);
            }
         }
         rows.add(row);
      }
      //..... Insert entry data to the database ......
            
      res_b = exec.execBulkInsert (conn, dbTableName, columnTypes, columnNames, rows);
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Execute insert records to DB
   //----------------------------------------------------------------------------------------------
   
   public static boolean insertModelSect (Connection conn,
                                          DBExecute  exec,
                                          String     dbTableName,     // DB table name
                                          UUID       modelUid,
                                          String     nodeType,
                                          DBEntry    entry)           // entry data to insert
   {

      boolean res_b = true;

      //..... Update DB table (add columns) if needed ......
      
      res_b = exec.addColumns(conn, dbTableName, entry.getTable());
      if (res_b == false) return false;
         
      //..... Add common attributes to keep column names unique ......
         
      List<String>  columnNames = new ArrayList<String>(Arrays.asList(colCommonNames));
      List<Integer> columnTypes = new ArrayList<Integer>(Arrays.asList(colCommonTypes));
      
      DBTable table = entry.getTable();
      addEntryColumns(columnNames, columnTypes, table.getColumnNames(), table.getColumnTypes());
         
      //..... Re-map model parameters ......
      
      List<List<Object>> rows = new ArrayList<List<Object>>();
      
      for (int j = 0; j < entry.getRowNum(); j++) {                  
         ArrayList<Object> row = new ArrayList<Object>();
         
         for (int i = 0; i < columnNames.size(); i++) {
            String  colName = columnNames.get(i);
            
            if      (colName.equals(DBTypes.modelId))   row.add(modelUid);
            else if (colName.equals(DBTypes.nodeType))  row.add(nodeType);
            else if (colName.equals(DBTypes.tableName)) row.add(dbTableName);
            else if (table.getColumnNames().contains(colName)) {
               row.add(entry.getValue(j, colName));
            }
            else {
               row.add(null);
            }
         }
         rows.add(row);
      }
      //..... Insert entry data to the database ......
         
      res_b = exec.execBulkInsert (conn, dbTableName, columnTypes, columnNames, rows);
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Add common attributes to keep column names unique
   //----------------------------------------------------------------------------------------------
   
   private static void addEntryColumns(List<String>  columnNames,
                                       List<Integer> columnTypes,
                                       List<String>  addNames,
                                       List<Integer> addTypes) 
   {
      for (int i = 0; i < addNames.size(); i++) {
         if (columnNames.contains(addNames.get(i)) == false) {
            columnNames.add(addNames.get(i));
            columnTypes.add(addTypes.get(i));
         }
      }
   }
   //----------------------------------------------------------------------------------------------
   // Create model table (_psse, _gridlab, _cdf, etc.) if not exists
   //----------------------------------------------------------------------------------------------
      
   public static boolean createModelTable(Connection conn,
                                          DBExecute  exec,
                                          String     tableName,
                                          String     parentTableName)
   {
      int num = exec.createTable(conn, tableName, parentTableName, null, null, null, null);
      if (num == -1) return false;
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Create model informational table (_modelinfo) if not exists
   //----------------------------------------------------------------------------------------------
      
   public static boolean createInfoTable(Connection conn,
                                         DBExecute  exec)
   {    
      int num = exec.createTable(conn, 
                                 BGModel.INFO_TABLE_NAME, 
                                 null,
                                 BGModel.INFO_TABLE_COLUMNS, 
                                 BGModel.INFO_TABLE_TYPES, 
                                 BGModel.INFO_TABLE_COLUMNS[0],
                                 null);
      if (num == -1) return false;
      return true;
   }
   //---------------------------------------------------------------------------------------------
   // Physically delete item bistreams
   //---------------------------------------------------------------------------------------------

   public boolean deleteItemBitstreams()
   {      
      if (item == null || item.getBundles() == null) {
         log.error("deleteItemBitstreams. Item and/or item bundles equal null");
         return false;
      }
      boolean res_b = true;
      
      for (Bundle bundle : item.getBundles()) {
         if (bundle == null) continue;
         
         for (Bitstream bs : bundle.getBitstreams()) {
            if (bs == null) continue;
            if (DBFunctions.isBitstreamInMultBundles(bs.getID())) continue;
       
            String filePath_s = JSPUploadStep.getFilePath(bs);
            res_b &= BGUtils.deleteFile(filePath_s);
            
            log.info("deleteItemBitstreams. Deleted model: " + bs.getName() + "; file: " + filePath_s); 
         }
      }
      return res_b;
   }
}
//======================================= End of Class ============================================
