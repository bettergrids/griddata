package org.dspace.app.webui.parser.opendss;

import java.util.Collection;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.Enumeration;
import java.util.HashMap;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.util.BGUtils;

public class DssArchive {

   private static final Logger log = Logger.getLogger(DssArchive.class);
   
   //..... Contants .....
   
   public static final String ZIP_SEPARATOR_CONST = "/";
   
   //..... Members ......
   
   private Map<String, DssModel> models_hm   = new HashMap<String, DssModel>();
   
   //..... Getters/Setters ......
   
   public Map<String, DssModel> getModelsMap() {
      return models_hm;
   }
   public Collection<DssModel> getModels() {
      return models_hm.values();
   }
   public DssModel getModel(String name_s) {
      return models_hm.get(name_s);
   }
   //----------------------------------------------------------------------------------------------
   // Unzip archive to the array of strings
   //----------------------------------------------------------------------------------------------   
   
   public boolean extractModels(String filePath_s) 
   {
      boolean res_b     = true;
      ZipFile file      = null;
      String  dirName_s = null;
      boolean first_b   = true;     // is it a first file of model?
      DssModel model    = null;
      
      try {
      
         //..... This is not an archive, just ordinary file ......
      
         if (BGUtils.isArchive(filePath_s) == false) {
            model = new DssModel();
            String fileName_s = BGUtils.getNameFromFile(filePath_s);      // get file name
            model.setName(fileName_s);
            models_hm.put(fileName_s, model);
                  
            String content_s = BGUtils.readFile(filePath_s);
            if (content_s == null) return false;
         
            model.addFile(fileName_s, content_s);
            return true;
         }     
         //..... The input file is a zip-archive ......
      
         file = new ZipFile(filePath_s);
         Enumeration<? extends ZipEntry> entries = file.entries();
                 
         while (entries.hasMoreElements()) {
            ZipEntry entry = entries.nextElement();            
            if (entry.isDirectory()) {
               dirName_s = getLastArchiveFolder(entry.getName());
               first_b = true;
               continue;
            }
            //..... Check if it is "dss" file ......

            String ext_s = BGUtils.getFileExtension(entry.getName());
            if (ext_s.equalsIgnoreCase(DssModel.DSS_EXTENTION_CONST) == false) {
               continue;
            }
            //..... Create model ......
            
            if (first_b) {
               model = new DssModel();
               if (dirName_s == null) {
                  dirName_s = BGUtils.getNameFromFile(filePath_s);
               }
               model.setName(dirName_s);
               models_hm.put(dirName_s, model);
               first_b = false;
            }
            //..... Read file to string ......
           
            String fileName_s = BGUtils.getFileNameFromPath(entry.getName(), ZIP_SEPARATOR_CONST).toLowerCase();
            
            InputStream is          = file.getInputStream(entry);
            BufferedInputStream bis = new BufferedInputStream(is);
            
            String content_s = IOUtils.toString(bis, "UTF-8");
            
            if (model == null) {
               log.error("unzipArchive. model is null. Error in algorithm logic");
               return false;
            }
            model.addFile(fileName_s, content_s);
            
            bis.close();
            is.close();
         }
      }
      catch (Exception e) {
         log.error("unzipArchive. Cannot read file/archive " + filePath_s + 
                   "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
         res_b = false;
      }
      finally {
         try {
            if (file != null) file.close();
         } 
         catch (IOException ioex) {
            log.error("unzipArchive. Cannot close file " + filePath_s + 
                  " properly; Stack Trace: " + ExceptionUtils.getStackTrace(ioex));
            res_b = false;
         }
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String getLastArchiveFolder(String path_s)
   {   
      path_s = path_s.substring(0, path_s.length() - 1);    // remove last "/"
      int idx = path_s.lastIndexOf("/");
      return path_s.substring(idx + 1);
   }
   //----------------------------------------------------------------------------------------------
   // Get master file
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {      
      org.apache.log4j.BasicConfigurator.configure();
      
      String line_s   = " abc=2,c=\"two words\" {3 4, 5}\t (yes no)\t\t 'a, b, c' ";
      
      line_s = "New Transformer.CTrafo(CRamaEE():P1R_nCCTT14->P1R_nCCTT14_BT) phases=1 windings=3" + 
               " wdg=1 bus=P1R_nCCTT14.3 kv=7.19956 kva=10 tap=1 wdg=2 bus=P1R_nCCTT14_BT.1.0" + 
               " kv=0.120089 kva=10 tap=1.03 wdg=3 bus=P1R_nCCTT14_BT.0.2 kv=0.120089 kva=10" + 
               " tap=1.03 %RS=[0.41605 0.832101 0.832101] XHL=1.08 XHT=1.08 XLT=0.72 %noloadloss=0.68" + 
               " basefreq=60 sub=No\r\n"; 
            
      //line_s = "New Transformer.CTrafo(CRamaEE(), :P1R_nCCTT14 P1R_nCCTT14_BT)abc \"phases = 1\",top[24, 12]\t{17} ";
      
      String delims_s = "\t, ";
      //String quotes_s = "[\"'\\[\\](){}]";          // "\"|\'|\\[|\\]|\\(|\\)|\\{|\\}";
      
      //String[] line_sa = line_s.split(",| (?=(?:[^\\\"]*\\\"[^\\\"]*\\\")*[^\\\"]*$)", -1);
            
            //line_s.split("\\s*,\\s*(?=((\\\\[\"\\\\]|[^\"\\\\])*\"(\\\\[\"\\\\]|[^\"\\\\])*\")*(\\\\[\"\\\\]|[^\"\\\\])*$)");
      
      //String line_sa = Splitter.on("[]")..exceptWhenSurroundedBy('"').split(value)
      
      String[] line_sa = BGUtils.splitQuoted(line_s, delims_s);
      
      line_s = line_sa[0];
      String fileName_s = "D:\\tmp_share\\OpenDSS\\GSO_Base_Network-1.zip";
      
      DssArchive zip = new DssArchive();
      boolean res_b = zip.extractModels(fileName_s);
      
      int b = 2;

   }
}
//======================================= End of Class ============================================ 

