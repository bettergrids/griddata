package org.dspace.app.webui.model;

import java.sql.JDBCType;
import java.text.NumberFormat;
import java.text.ParsePosition;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class DBUtils implements DBTypes
{
   private static final Logger log = Logger.getLogger(DBUtils.class);
   
   //----------------------------------------------------------------------------------------------
   
   public static <T> boolean contains(final T[] array, final T v) 
   {
      if (v == null) {
          for (final T e : array)
              if (e == null)
                  return true;
      } 
      else {
          for (final T e : array)
              if (e == v || v.equals(e))
                  return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   
   public static <T> boolean containsLike(final T[] array, final T v) 
   {
      if (v == null) {
          for (final T e : array)
              if (e == null)
                  return true;
      }
      else if (v instanceof String) {
         for (final T e : array)
            //if (((String)e).toLowerCase().startsWith(((String)v).toLowerCase()))
            if (StringUtils.containsIgnoreCase((String)v, (String)e)) 
                return true;
      }
      else {
          for (final T e : array)
              if (e == v || v.equals(e))
                  return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String formColumnName(String name_s)
   {
      int idx = ArrayUtils.indexOf(colNamesList, name_s);
      if (idx >= 0) {
         return colNamesTrans[idx];
      }
      name_s = name_s.replaceAll("^_+", "").replaceAll("_", " ");
      name_s = toTitleCase(name_s);
      return name_s;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public static String toTitleCase(String input_s) 
   {
      if (input_s == null || input_s.isEmpty()) return "";
      
      String[] arr    = input_s.replaceAll("\\s+"," ").trim().split(" ");
      StringBuffer sb = new StringBuffer();

      for (int i = 0; i < arr.length; i++) {
          sb.append(Character.toUpperCase(arr[i].charAt(0))).append(arr[i].substring(1)).append(" ");
      }          
      return sb.toString().trim();
   }  
   //----------------------------------------------------------------------------------------------
   // 
   //----------------------------------------------------------------------------------------------
   
   public static boolean isNumeric(String str)
   {
     return str.matches("-?\\d+(\\.\\d+)?");  //match a number with optional '-' and decimal.
   }
   //----------------------------------------------------------------------------------------------
   // Another method to check if given string can be converted to number
   //----------------------------------------------------------------------------------------------
   
   public static boolean isFormatNumeric(String str)
   {
     NumberFormat  formatter = NumberFormat.getInstance();
     ParsePosition pos       = new ParsePosition(0);
     formatter.parse(str, pos);
     return str.length() == pos.getIndex();
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static boolean isInteger(String str)
   {
      return str.matches("^-?\\d+$");

   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public static String getJDBCTypeName(int typeIdx)
   {
      String typeName = null;
      try {
         switch(typeIdx) {
         case DBTypes.typeUUID:
            typeName = uuidTypeName;
            break;
         case DBTypes.typeInet:
            typeName = inetTypeName;
            break;
         case DBTypes.typeIntArray:
            typeName = intArrayTypeName;
            break;
         default:
            typeName = JDBCType.valueOf(typeIdx).getName();
         }
      }
      catch (Exception e) {
         log.error("DBUtils.getJDBCTypeName. Cannot get SQL Type name for type = " + typeIdx);
         return null;
      }
      return typeName.toLowerCase();
   }
}
//======================================= End of Class ============================================
