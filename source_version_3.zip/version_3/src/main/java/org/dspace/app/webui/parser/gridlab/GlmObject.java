package org.dspace.app.webui.parser.gridlab;

import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBColumn;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGUtils;

public class GlmObject extends BGObject {

   private static final Logger log = Logger.getLogger(GlmObject.class);
   
   //..... Constants .....
   
   public static final String PARENT_NAME = "parent";
   
   //..... Members ......
   
   private String   fullId = null;    // full object ID, like: "regulator:876"
   private GlmModel model;

   LinkedHashMap<String,GlmAttr> attr_hm = new LinkedHashMap<String,GlmAttr>();
   ArrayList<String> attrNames = null; 
   
   //..... Methods ......
   
   public String getFullId() {
      return fullId;
   }
   public void setFullId(String fullId) {
      this.fullId = fullId;
   }
   
   @Override
   public String getName() {
      if (name == null) {
         setName();
      }      
      return name;
   }
   public void setName() 
   {
      GlmAttr nameAttr = getAttrObj(GlmParser.NAME_CONST);
      if (nameAttr == null) {
         nameAttr = new GlmAttr();
         nameAttr.setName(GlmParser.NAME_CONST);
         nameAttr.setValue(fullId);
         addAttr(nameAttr);
      }
      name = nameAttr.getValue();
   }
   public void setName(String nameValue) 
   {
      name = nameValue;
   }
   @Override
   public BGModel getModel() {
      return model;
   }
   @Override
   public void setModel(BGModel model) {
      this.model = (GlmModel)model;
   }
   public void setModel(GlmModel model) {
      this.model = model;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean addAttr(GlmAttr attr)
   {
      if (attr.getName() != null) {
         attr_hm.put(attr.getName(), attr);
         return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   
   public GlmAttr getAttrObj(String name)
   {
      return attr_hm.get(name);
   }
   //----------------------------------------------------------------------------------------------
   
   public Object getAttr(String name)
   {
      GlmAttr attr = attr_hm.get(name);
      if (attr != null) {
         return attr.getObjValue();
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------   

   @Override
   public Object getAttr(int idx) 
   { 
      GlmAttr attr = getAttrObj(getAttrNames()[idx]);
      if (attr == null) return null;
      
      return attr.getValue();
   }
   //----------------------------------------------------------------------------------------------
   
   public void setAttrNames()
   {
      attrNames = new ArrayList<String>();

      //..... A few columns to display first ......
      
      attrNames.add(GlmParser.NAME_CONST);
      attrNames.add(GlmParser.OBJ_INDEX_CONST);
//      attrNames.add(GlmParser.FROM_CONST);
//      attrNames.add(GlmParser.TO_CONST);
      
      //..... Add all object attribute names ......
      
      for (String attrName : attr_hm.keySet()) {
         attrNames.add(attrName);
      }
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getAttrNames()
   {
      if (attrNames == null) {
        setAttrNames();
      }
      return attrNames.toArray(new String[attrNames.size()]);
   }
   //----------------------------------------------------------------------------------------------

   LinkedHashMap<String,GlmAttr> getAttrsHM() 
   {
      return attr_hm;
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public List<Object> getAttrs() 
   {
      List<Object> attr_al = new ArrayList<Object>();
      for (GlmAttr attr : attr_hm.values()) {
         attr_al.add(attr.getValue());
      }
      return attr_al;
   }
   //----------------------------------------------------------------------------------------------
   // Convert ClmObject to JSON format string
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String toJson()
   {
      StringBuffer json_sb = new StringBuffer();

      //String objTypeId = type + ((id == null) ? "" : "_" + id.toString());
      
      //..... Start with object type, id and name (if any) as attributes ......
      
      json_sb.append("{\t\"object_type\" : \"" + type + "\",\n" );
      if (id != null) {
         json_sb.append("\t\"object_id\" : " + id.toString() + ",\n");
      }
      if (name != null) {
         json_sb.append("\t\"object_name\" : \"" + name + "\",\n");
      }
      //..... For each attribute ......
      
      for (GlmAttr attr : attr_hm.values()) {
         if (attr.getName().equals(GlmParser.OBJ_INDEX_CONST)) {
            continue;
         }
         json_sb.append(attr.toJson());
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n},\n");
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   // Get table with column declarations
   //----------------------------------------------------------------------------------------------

   @Override
   public DBTable getTable() 
   {
      //..... Setup table ......

      String objType_s = getType();
      if (objType_s == null) return null;
      
      DBTable table = new DBTable();
      table.setName(getName());

      for (int i = 0; i < getAttrNames().length; i++) {
         DBColumn col = new DBColumn(getAttrNames()[i], null, Types.VARCHAR, i);
         table.addColumn(i, col);
      }
      return table;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   @Override
   public Integer getObjTypeId() 
   {
      String objType = this.getType();
      try {
         Integer modelTypeIdx = BGUtils.getStringIdx(model.getFormat(), BGModel.MODEL_FILE_FORMATS_SA);
         Integer baseIdx = BGModel.OBJ_TYPE_ID_BASE[modelTypeIdx];
         Integer typeIdx = BGUtils.getStringIdx(objType, model.getObjTypeNames());
         
         return baseIdx + typeIdx;
      }
      catch (Exception e) {
         log.error("getObjTypeId. Cannot find object type id for " + getName() + 
                   "Stack trace: " + ExceptionUtils.getStackTrace(e));
         return null;
      }
   }
}
//======================================= End of Class ============================================
