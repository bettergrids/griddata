package org.dspace.app.webui.nlidb;

import java.net.InetAddress;
import java.time.Instant;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBSingleEntry;
import org.dspace.app.webui.model.DBTypes;

public class NLQuery extends DBSingleEntry implements DBTypes {
   
   private static final Logger log = Logger.getLogger(NLQuery.class);
   
   //..... Column of the _query table ......
   
   public static final String QUERY_TABLE_NAME = "_query";

   //..... Column of the _query table ......
   
   final static String OID     = "_oid";
   final static String USERID  = "useruid";
   final static String IPADDR  = "ipaddr";
   final static String CREATED = "created";
   final static String QUERY   = "query";
   final static String STATUS  = "status"; 
   
   private final static String[]  columnNames   = {OID, USERID, IPADDR, CREATED, QUERY, STATUS};
   private final static Integer[] columnTypes   = {typeBigInt, typeUUID, typeInet, typeTimestampTZ, typeText, typeInt};
   private final static Boolean[] autoIncrement = {true, false, false, false, false, false};
   
   //..... Members ......

   private Object[] values_oa = new Object[columnNames.length];     // column values
   
   //..... Methods ......
   
   @Override
   public String getTableName() {
      return QUERY_TABLE_NAME;
   }
   @Override
   public String[] getColumnNames() {
      return columnNames;
   }
   @Override
   public Integer[] getColumnTypes() {
      return columnTypes;
   }
   @Override
   public Object[] getValues() {
      return values_oa;
   }
   @Override
   public Boolean[] getAutoIncrement() {
      return autoIncrement;
   }
   
   public Long getOid() {
      return (Long)values_oa[0];
   }
   public UUID getUserUid() {
      return (UUID)values_oa[1];
   }
   public void setUserUid(UUID userUid) {
      values_oa[1] = userUid;
   }
   public InetAddress getIpAddr() {
      return (InetAddress)values_oa[2];
   }
   public void setIpAddr(InetAddress ipAddr) {
      values_oa[2] = ipAddr;
   }
   public Instant getCreated() {
      return (Instant)values_oa[3];
   }
   public void setCreated(Instant created) {
      values_oa[3] = created;
   }
   public String getQuery() {
      return values_oa[4].toString();
   }
   public void setQuery(String query) {
      values_oa[4] = query;
   }
   public Integer getStatus() {
      return (Integer)values_oa[5];
   }
   public void setStatus(Integer status) {
      values_oa[5] = status;
   }
}
//======================================= End of Class ============================================ 