/**
 * The contents of this file are subject to the license and copyright
 * detailed in the LICENSE and NOTICE files at the root of the source
 * tree and available online at
 *
 * http://www.dspace.org/license/
 */
package org.dspace.app.webui.servlet;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.backup.BGConfig;
import org.dspace.app.webui.backup.BGSystem;
import org.dspace.app.webui.util.JSPManager;
import org.dspace.authorize.AuthorizeException;
import org.dspace.core.Context;
import org.dspace.core.LogManager;
import org.dspace.eperson.EPerson;
import org.dspace.eperson.factory.EPersonServiceFactory;
import org.dspace.eperson.service.EPersonService;

/**
 * Servlet for handling editing user profiles
 * 
 * @author Robert Tansley
 * @version $Revision$
 */
public class EditProfileServlet extends DSpaceServlet
{
   private static final long serialVersionUID = -1808941151756365343L;
   
   public static final String filePrefix  = "filePath_";
   public static String       photoFolder = null;

   /** Logger */
    private static final Logger log = Logger.getLogger(EditProfileServlet.class);
    
    protected transient EPersonService personService = EPersonServiceFactory.getInstance().getEPersonService();

    @Override
    protected void doDSGet(Context context, HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException,
            SQLException, AuthorizeException
    {
        // A GET displays the edit profile form. We assume the authentication
        // filter means we have a user.
        log.info(LogManager.getHeader(context, "view_profile", ""));

        request.setAttribute("eperson", context.getCurrentUser());

        JSPManager.showJSP(request, response, "/register/edit-profile.jsp");
    }
    //---------------------------------------------------------------------------------------------
    // POST
    //---------------------------------------------------------------------------------------------
    
    @Override
    protected void doDSPost(Context             context, 
                            HttpServletRequest  request,
                            HttpServletResponse response) throws ServletException, IOException,
                                                                 SQLException, AuthorizeException
    {
        // Get the user - authentication should have happened
        EPerson eperson = context.getCurrentUser();
        
        HashMap <String,String>par_hm = setRequestParameters(0, context, eperson, request);  
        
        // Find out if they're trying to set a new password
        boolean settingPassword = false;
        String password = par_hm.get("password");
        
        //log.info("EditProfileServlet.doDSPost.updateUserProfile. password: " + password);
        //log.info("EditProfileServlet.doDSPost.updateUserProfile. passwordLength: " + password.length());
        //log.info("EditProfileServlet.doDSPost.updateUserProfile. eperson.getRequireCertificate(): " + eperson.getRequireCertificate());
        
        if (!eperson.getRequireCertificate() && password != null && password.length() > 0) {
            settingPassword = true;
        }
        // log.info("EditProfileServlet.doDSPost.updateUserProfile. settingPassword: " + settingPassword);
        
        // Set the user profile info
        boolean ok = updateUserProfile(context, eperson, par_hm);
        
        if (!ok) {
            request.setAttribute("missing.fields", Boolean.TRUE);
        }
        if (ok && settingPassword)
        {
            // They want to set a new password.
            ok = confirmAndSetPassword(eperson, request, par_hm);

            if (!ok)
            {
                request.setAttribute("password.problem", Boolean.TRUE);
            }
        }        
        if (ok) {
           // Update the DB
           log.info(LogManager.getHeader(context, "edit_profile", "password_changed=" + settingPassword));
           personService.update(context, eperson);

           // Show confirmation
           request.setAttribute("password.updated", settingPassword);
           JSPManager.showJSP(request, response, "/register/profile-updated.jsp");

           context.complete();
        }
        else {
           log.info(LogManager.getHeader(context, "view_profile", "problem=true"));
           request.setAttribute("eperson", eperson);
           JSPManager.showJSP(request, response, "/register/edit-profile.jsp");
        }
    }

    /**
     * Update a user's profile information with the information in the given
     * request. This assumes that authentication has occurred. This method
     * doesn't write the changes to the database (i.e. doesn't call update.)
     * 
     * @param eperson
     *            the e-person
     * @param request
     *            the request to get values from
     * 
     * @return true if the user supplied all the required information, false if
     *         they left something out.
     */
    public boolean updateUserProfile(Context                 context,
                                     EPerson                 eperson,
                                     HashMap<String, String> par_hm) throws SQLException
    {
       //..... Update the eperson ......
       
       String firstName    = par_hm.get("first_name");
       String lastName     = par_hm.get("last_name");
       String organization = par_hm.get("organization");
       
       eperson.setFirstName(context,    firstName);
       eperson.setLastName(context,     lastName);
       eperson.setOrganization(context, organization);
       eperson.setLanguage(context,     par_hm.get("language"));
       
       personService.setMetadataSingleValue(context, eperson, "eperson", "phone", null, null, par_hm.get("phone"));

       // Check all required fields are there
       
       return (!StringUtils.isEmpty(firstName) && !StringUtils.isEmpty(lastName) && !StringUtils.isEmpty(organization));
    }

    /**
     * Set an eperson's password, if the passwords they typed match and are
     * acceptible. If all goes well and the password is set, null is returned.
     * Otherwise the problem is returned as a String.
     * 
     * @param eperson
     *            the eperson to set the new password for
     * @param request
     *            the request containing the new password
     * 
     * @return true if everything went OK, or false
     */
    public  boolean confirmAndSetPassword(EPerson                 eperson,
                                          HttpServletRequest      request,
                                          HashMap<String, String> par_hm)
    {
        // Get the passwords
        String password        = par_hm.get("password");
        String passwordConfirm = par_hm.get("password_confirm");

        // Check it's there and long enough
        if ((password == null) || (password.length() < 6)) {
            return false;
        }
        // Check the two passwords entered match
        if (!password.equals(passwordConfirm)) {
            return false;
        }
        // Everything OK so far, change the password
        personService.setPassword(eperson, password);

        return true;
    }
    //---------------------------------------------------------------------------------------------
    //
    //---------------------------------------------------------------------------------------------
    
    public static String getPhotoFileName(EPerson eperson) 
    {
       return findFileNameUnknownExtension(eperson.getID().toString(), null);
    }
    //---------------------------------------------------------------------------------------------
    
    public static String getPhotoFileName(String uuid_s) 
    {
       return findFileNameUnknownExtension(uuid_s, null);
    }
    //---------------------------------------------------------------------------------------------
    //
    //---------------------------------------------------------------------------------------------    
    
    public static String extractFileExtension(String fileName) 
    {
       String ext_s = "";
       int i = fileName.lastIndexOf('.');
       int p = Math.max(fileName.lastIndexOf('/'), fileName.lastIndexOf('\\'));

       if (i > p) {
          ext_s = fileName.substring(i + 1);
       }
       return ext_s;
    }    
   //---------------------------------------------------------------------------------------------
   //
   //---------------------------------------------------------------------------------------------    
    
   private static String findFileNameUnknownExtension(String fileNameNoExt,
                                                      String fileFolder)        // may be null
   {
      if (fileFolder == null) {
         fileFolder = getPhotoFolder();   
      }
      if (fileFolder == null) {
         return null;
      }
      File dir = new File(fileFolder);
      File[] files = dir.listFiles((d, name) -> name.contains(fileNameNoExt)); 
      
      if (files == null || files.length == 0) {
         return null;
      }
      return files[0].getName();
   }
   //---------------------------------------------------------------------------------------------
   //
   //---------------------------------------------------------------------------------------------
   
   public static String getPhotoPath(String uuid_s)   // person UUID as a string
   {
      String photoFolder = getPhotoFolder();
      return photoFolder + findFileNameUnknownExtension(uuid_s, photoFolder);
   }
   //---------------------------------------------------------------------------------------------
   //
   //---------------------------------------------------------------------------------------------    
    
   public static String getPhotoFolder()
   {
      if (photoFolder != null) return photoFolder;
      
      if (BGSystem._WINDOWS.equalsIgnoreCase(BGSystem.getOSType())) {
         photoFolder = BGConfig.getBgProperty("photo.folder.windows");
      }
      else if (BGSystem._LINUX.equalsIgnoreCase(BGSystem.getOSType())) {
         photoFolder = BGConfig.getBgProperty("photo.folder.linux");
      }
      else {
         log.error("Operating system : " + BGSystem.getOSType() + " is not supported");
         return null;
      }
      return photoFolder;
   }
   //---------------------------------------------------------------------------------------------
   //
   //---------------------------------------------------------------------------------------------    

   private static boolean deletePreviousPhotos(String userUUID_s,
                                               String extension,
                                               String fileFolder)
   {
      if (extension.length() == 0) return false;
      
      if (fileFolder == null) {
         fileFolder = getPhotoFolder();   
      }
      if (fileFolder == null) {
         return false;
      }
      File dir = new File(fileFolder);
      File[] files = dir.listFiles((d, name) -> name.contains(userUUID_s)); 
      
      if (files == null || files.length == 0) {
         return true;
      }
      for (int i = 0; i < files.length; i++) {
         String ext = extractFileExtension(files[i].getName());
         if (ext.equalsIgnoreCase(extension)) continue;
         
         try {
            Files.deleteIfExists(files[i].toPath());
         } 
         catch (IOException e) {
            log.error("deletePreviousPhotos. Cannot delete file: " + files[i].getPath() + "; " + e.getMessage());
         }
      }
      return true;
   }
   
   //---------------------------------------------------------------------------------------------
   // selector: 1 - only text parameters (fields); 2 - only file; 0 - both; 
   //---------------------------------------------------------------------------------------------    
    
   public static HashMap<String, String>setRequestParameters(int                selector,
                                                             Context            context, 
                                                             EPerson            eperson,  // may be null if selector == 1
                                                             HttpServletRequest request) 
   {
      HashMap<String, String> par_hm = new HashMap<String, String>();
       
      try {
         List<FileItem> items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
         for (FileItem item : items) {
             
            //..... Process regular form fields (input type="text|radio|checkbox|etc", select, etc) ......
             
            if (item.isFormField() && (selector == 0 || selector == 1)) {                   
               par_hm.put(item.getFieldName(), item.getString());
               //log.info("EditProfileServlet.doDSPost.updateUserProfile. FieldName: "  + item.getFieldName());
               //log.info("EditProfileServlet.doDSPost.updateUserProfile. FieldValue: " + item.getString());
            } 
            //..... Process form file field (input type="file") ......
             
            else if (selector == 0 || selector == 2) {
               String fieldName       = filePrefix + item.getFieldName();
               String fieldValue      = FilenameUtils.getName(item.getName());
                  
               String fileExtension   = extractFileExtension(fieldValue);
               
               if (fileExtension.length() > 0) {
                  String fileFolder      = getPhotoFolder();                  
                  String targetFilePath  = fileFolder + File.separator + eperson.getID().toString() + "." + fileExtension;

                  par_hm.put(fieldName, targetFilePath);
               
                  //log.info("EditProfileServlet.doDSPost.updateUserProfile. fileExtension: "  + fileExtension);
                  //log.info("EditProfileServlet.doDSPost.updateUserProfile. fileName: "  + fieldName);
                  log.info("EditProfileServlet.doDSPost.updateUserProfile. fileValue: " + targetFilePath);
                  
                  //..... Upload file ......
                   
                  InputStream fileStream = item.getInputStream();
                  File targetFile = new File(targetFilePath);
                  FileUtils.copyInputStreamToFile(fileStream, targetFile);
                  IOUtils.closeQuietly(fileStream);
                  
                  //..... Delete other photos of this user with different extensions ......
                  
                  deletePreviousPhotos(eperson.getID().toString(), fileExtension, fileFolder);
               }
            }
            
         }
      }
      catch (FileUploadException e) {
         log.error("EditProfileServlet.doDSPost.updateUserProfile. Cannot upload file. "  + e.getMessage());
         return null;
      }
      catch (IOException e) {
         log.error("EditProfileServlet.doDSPost.updateUserProfile. I/O problem "  + e.getMessage());
         return null;
      }
      return par_hm;
   }
}
