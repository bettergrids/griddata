package org.dspace.app.webui.util;

import java.util.ArrayList;
import java.util.Collection;

public class BGSetList<T> extends ArrayList<T> {
   private static final long serialVersionUID = -777847600891708287L;

   @Override
   public boolean add(T t) {
      return !super.contains(t) && super.add(t);
   }

   @Override
   public void add(int index, T element) {
      if (!super.contains(element)) super.add(index, element);
   }

   @Override
   public boolean addAll(Collection<? extends T> c) {
      boolean added = false;
      for (T t : c)
         added |= add(t);
      return added;
   }

   @Override
   public boolean addAll(int index, Collection<? extends T> c) {
      boolean added = false;
      for (T t : c)
         if (!super.contains(t)) {
            super.add(index++, t);
            added = true;
         }
         return added;
   }
}

