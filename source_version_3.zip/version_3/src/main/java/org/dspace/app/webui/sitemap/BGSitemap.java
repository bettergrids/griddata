package org.dspace.app.webui.sitemap;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;

import org.apache.log4j.Logger;
import org.dspace.app.webui.backup.BGConfig;
import org.dspace.app.webui.model.DBConnection;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.model.DBExecute;
import org.dspace.app.webui.util.BGUtils;

public class BGSitemap {

   private static final Logger log = Logger.getLogger(BGSitemap.class);

   //..... Singleton ......

   private BGSitemap(){};
   
   protected static final BGSitemap INSTANCE = new BGSitemap();

   public static final BGSitemap getInstance() 
   {
      initOptions();
      return INSTANCE;
   }   
   private static final String _communities = "community";
   private static final String _collections = "collection";
   private static final String _items       = "item";
  
   private static Double priority        = null;
   private static String frequency       = null;
   private static String URLPrefix       = null;
   private static String filePath        = null;
   private static String dbName          = null;

   private static Date lastUpdateDate   = null;
   private static Date nextUpdateDate   = null;
   
   private static final String[] optionNames_sa = {_communities, _collections, _items};
  
   private static LinkedHashMap<String,Boolean> options_hm = null;
   private static ArrayList<String> staticLinks_al;
   
   public static ArrayList<String> getStaticLinks() {
      return staticLinks_al;
   }
   public static void setStaticLinks(ArrayList<String> staticLinks) {
      BGSitemap.staticLinks_al = staticLinks;
   }
   public static void setStaticLinks(String staticLinks_s) {
      BGSitemap.staticLinks_al = new ArrayList<String>(BGUtils.StringToArrayList(staticLinks_s, "\n"));
   }
   public static Date getLastUpdateDate() {
      if (lastUpdateDate == null) {
         return getLastSitemapUpdate();
      }
      return lastUpdateDate;
   }
   public static void setLastUpdateDate(Date lastUpdateDate) {
      BGSitemap.lastUpdateDate = lastUpdateDate;
   }
   public static Date getNextUpdateDate() {
      return nextUpdateDate;
   }
   public static void setNextUpdateDate(Date nextUpdateDate) {
      BGSitemap.nextUpdateDate = nextUpdateDate;
   }
   public static String[] getOptionNames() {
      return optionNames_sa;
   }
   public static Double getPriority() {
      if (priority == null) {         
         priority = BGConfig.getDoubleProperty("sitemap.priority");
      }
      return priority;
   }
   public static void setPriority(Double priority) {
      BGSitemap.priority = priority;
   }
   public static String getFrequency() {
      if (frequency == null) {
         frequency = BGConfig.getBgProperty("sitemap.frequency");
      }
      return frequency;
   }
   public static void setFrequency(String frequency) {
      BGSitemap.frequency = frequency;
   }
   public static String getURLPrefix() {
      if (URLPrefix == null) {
         URLPrefix = BGConfig.getBgProperty("sitemap.URL.prefix");
      }
      return URLPrefix;
   }
   public static void setURLPrefix(String uRLPrefix) {
      URLPrefix = uRLPrefix;
   } 
   public static String getFilePath() {
      if (filePath == null) {
         filePath = BGConfig.getBgProperty("sitemap.filepath");
      }
      return filePath;
   }
   public static void setFilePath(String filePath) {
      BGSitemap.filePath = filePath;
   }
   public static String getDbName() {
      if (dbName == null) {
         dbName = BGConfig.getBgProperty("db.name");
      }
      return dbName;
   }
   public static void setDbName(String dbName) {
      BGSitemap.dbName = dbName;
   }
   //..... Options ......
   
   public static void initOptions()
   {
      if (options_hm == null) {
         options_hm = new LinkedHashMap<String,Boolean>();
     
         for (int i = 0; i < optionNames_sa.length; i++) {
            options_hm.put(optionNames_sa[i], true);
         }
      }
      if (staticLinks_al == null) {
         staticLinks_al = new ArrayList<String>();
      }
      priority  = getPriority();
      frequency = getFrequency();  
      URLPrefix = getURLPrefix();
      filePath  = getFilePath();
      dbName    = getDbName();
   }
   
   public static LinkedHashMap<String,Boolean> getOptions()
   {
      return options_hm;
   }   
   
   public static Boolean[] getOptionsBoolean()
   {
      return options_hm.values().toArray(new Boolean[options_hm.size()]);
   }
   
   public static Boolean getOption(int idx)
   {
      return (Boolean)options_hm.values().toArray()[idx];
   }
   
   public static void setOption(int idx, Boolean status)
   {
      options_hm.put(optionNames_sa[idx], status);
   }
   
   public static void setOptions(Boolean[] options_ba)
   {
      for (int i = 0; i < optionNames_sa.length; i++) {
         setOption(i, options_ba[i]);
      }
   }

   public static void setOptions(Boolean options_b)
   {
      for (int i = 0; i < optionNames_sa.length; i++) {
         setOption(i, options_b);
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
 
   public boolean doSitemap() 
   {
      return generateSitemapFile(getDbName());      
   }
   //----------------------------------------------------------------------------------------------
   
   public static void reset()
   {
      setOptions(true);
      nextUpdateDate = null;
   }
   //----------------------------------------------------------------------------------------------
   // Get the last sitemap update based on a sitemap.xml file attributes
   //----------------------------------------------------------------------------------------------

   public static Date getLastSitemapUpdate() 
   {
      //..... Get attributes of sitemap.xml file ......
      
      Date date = null;
      
      try {
         Path file = Paths.get(getFilePath());
         BasicFileAttributes attrs = Files.readAttributes(file, BasicFileAttributes.class);
      
         FileTime ftime = attrs.lastModifiedTime();
           
         date = new Date(ftime.toMillis());
      }
      catch (Exception e) {
         log.info("BGSitemap.getLastSitemapUpdate. Cannot find file on path:" + getFilePath());
      }
      return date;
   }
   //----------------------------------------------------------------------------------------------
   // Generate sitemap.xml file string
   //----------------------------------------------------------------------------------------------
   
   private String getHandles(Connection conn,
                             String     date_s)    
   {
      String prefix_s = getURLPrefix();
      String freq_s   = getFrequency();
      String prior_s  = getPriority().toString();
   
      StringBuffer sql_sb = new StringBuffer();
      
      String base_s = "SELECT '<url><loc>" + prefix_s + "' || trim(handle) || '</loc><lastmod>" + 
                      date_s + "</lastmod><changefreq>" + freq_s + "</changefreq><priority>" + 
                      prior_s + "</priority></url>' FROM handle WHERE "; 
      
      if (options_hm.get(_communities)) {
         sql_sb.append(base_s);
         sql_sb.append("resource_id in (SELECT uuid FROM " + _communities + ")");
      }
      if (options_hm.get(_collections)) {
         if (sql_sb.length() == 0) {
            sql_sb.append(base_s);
         }
         else {
            sql_sb.append(" OR ");
         }
         sql_sb.append("resource_id in (SELECT uuid FROM " + _collections + ")");
      }
      if (options_hm.get(_items)) {
         if (sql_sb.length() == 0) {
            sql_sb.append(base_s);
         }
         else {
            sql_sb.append(" OR ");
         }
         sql_sb.append("resource_id in (SELECT uuid FROM " + _items + ")");
      }
      if (sql_sb.length() == 0) return "";
      
      String sitemap_s = sql_sb.toString();
      
      DBExecute exec  = new DBExecute();  
      DBEntry   entry = exec.execQuery(conn, sitemap_s, null);

      return entry.printToString();
   }
   //----------------------------------------------------------------------------------------------
   // Write file sitemap.xml
   //----------------------------------------------------------------------------------------------
   
   public boolean generateSitemapFile(String dbName_s)                                           
   {     
      Connection conn = new DBConnection(dbName_s).getConnection();     // get DB connection
      
      String date_s = BGUtils.getNow_yyyy_MM_dd();
      
      StringBuffer res_sb = new StringBuffer("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                                             "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n");      
      //..... Static (common) links ......
      
      if (staticLinks_al != null && !staticLinks_al.isEmpty()) {         
         for (String line_s : staticLinks_al) {
            String res_s = "<url><loc>"              + line_s.replaceAll("\\s+","") + 
                           "</loc><lastmod>"         + date_s + 
                           "</lastmod><changefreq>"  + frequency + 
                           "</changefreq><priority>" + priority.toString() + 
                           "</priority></url>\n";
            
            res_sb.append(res_s);
         }
      }
      String handles_s = getHandles(conn, date_s);
      res_sb.append(handles_s);      
      res_sb.append("</urlset>\n");
            
      try {
         Files.write(Paths.get(getFilePath()), res_sb.toString().getBytes());
         log.info("generateSitemap. File " + getFilePath() + " saved");
      }
      catch (IOException e) {
         log.error("generateSitemap. Cannot write to file: " + filePath + ";" + e.getMessage());
         return false;
      }
      return true;    
   }
   //----------------------------------------------------------------------------------------------
   //  Main function for testing
   //----------------------------------------------------------------------------------------------   
   
   public static void main(String[] args) 
   {
      org.apache.log4j.BasicConfigurator.configure();

      BGSitemap sm = BGSitemap.getInstance();

      sm.generateSitemapFile("dspace");
      
      log.info("Done!");
   }
}
