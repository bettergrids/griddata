package org.dspace.app.webui.spellcheck;

import org.apache.lucene.search.spell.JaroWinklerDistance;
import org.apache.lucene.search.spell.LevensteinDistance;
import org.apache.lucene.search.spell.NGramDistance;

public class Similarity 
{
   //----------------------------------------------------------------------------------------------
   // Calculates similarity (a number within 0 and 1.0) between two strings. 1.0 is a best option.
   // Return result as an average of similarity coefficients, calculated by different methods 
   //----------------------------------------------------------------------------------------------
   
   public static double getSimilarity(String str1_s, 
                                      String str2_s) 
   {
      //..... str1_s should be the longest string ......
      
      str1_s = str1_s.toLowerCase();
      str2_s = str2_s.toLowerCase();
      
      int longLen = str1_s.length();
      if (str1_s.length() < str2_s.length()) {
         String tmp_s = str1_s;
         str1_s       = str2_s;
         str2_s       = tmp_s;
         longLen      = str1_s.length();
      }
      if (longLen == 0) {
         return 1.0;                // both strings are zero length
      }
      // Using three methods of Apache lucene.search.spell getDistance 
      // In case it's not available - use getLevDistance(String, String) - see below
 
      LevensteinDistance  levenstein  = new LevensteinDistance();       // Levenshtein distance
      JaroWinklerDistance jaroWinkler = new JaroWinklerDistance();      // Jaro–Winkler distance
      NGramDistance       nGram       = new NGramDistance();            // N-gram distance
      
      float levDistance = levenstein.getDistance(str1_s, str2_s);
      float jwDistance  = jaroWinkler.getDistance(str1_s, str2_s);
      float ngDistance  = nGram.getDistance(str1_s, str2_s);
      
      ///System.out.println(str1_s + " - " + str2_s + "; lev: " + levDistance + "jw: " + 
      //                   jwDistance + "; ng: " + ngDistance); 
      
      double distance = (levDistance + jwDistance + ngDistance) / 3.0;      
      return distance;
     
      //return (longLen - editDistance(long_s, short_s)) / (double) longLen;
   }
   //----------------------------------------------------------------------------------------------
   // Levenshtein Edit Distance algorithm implementation
   //----------------------------------------------------------------------------------------------
 
   public static int getLevDistance(String str1_s, 
                                    String str2_s) 
   {
      str1_s = str1_s.toLowerCase();      // longer string
      str2_s = str2_s.toLowerCase();      // shorter string

      int[] costs = new int[str2_s.length() + 1];
     
      for (int i = 0; i <= str1_s.length(); i++) {
         int lastValue = i;
         for (int j = 0; j <= str2_s.length(); j++) {
            if (i == 0) {
               costs[j] = j;
            }
            else {
               if (j > 0) {
                  int newValue = costs[j - 1];
                  if (str1_s.charAt(i - 1) != str2_s.charAt(j - 1)) {
                     newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
                  }
                  costs[j - 1] = lastValue;
                  lastValue    = newValue;
               }
            }
         }
         if (i > 0) {
            costs[str2_s.length()] = lastValue;
         }
      }
      return costs[str2_s.length()];
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public static void printSimilarity(String s, String t) 
   {
     System.out.println(String.format(
       "%.3f is the similarity between \"%s\" and \"%s\"", getSimilarity(s, t), s, t));
   }
 }