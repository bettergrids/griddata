package org.dspace.app.webui.parser.psse;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Types;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.parser.BGParser;
import org.dspace.app.webui.parser.gridlab.GlmAttr;
import org.dspace.app.webui.parser.gridlab.GlmModel;
import org.dspace.app.webui.parser.gridlab.GlmObject;
import org.dspace.app.webui.util.BGUtils;

public class PssParser extends BGParser implements PssTypes {
   
   private static final Logger log = Logger.getLogger(PssParser.class);
   
   //..... Constants ......
   
   private static final String  COMENT_SIGN      = "/";
   private static final String  SECTION_END      = "0";
   private static final String  FILE_END         = "Q";

   private static final String[] FUNC_NAMES = {"parseHeaderLine", "parseComments", "parseBusSect",
                                               "parseLoadSect", "parseFixedShuntSect", "parseGeneratorSect",
                                               "parseBranchSect", "parseTransSect", "parseTransSect",
                                               "parseAreaSect", "parseDC2Sect", "parseVoltageSect", 
                                               "parseSwitchedShuntSect","parseTictSect","parseMTDCSect",
                                               "parseMSLDSect", "parseZoneSect","parseInterAreaSect", 
                                               "parseOwnerSect", "parseFactsSect", "parseGNESect", 
                                               "parseInductSect"};
   //..... Constructor ......
   
   public PssParser(String file_s) throws FileNotFoundException 
   {
      super(file_s);
   }
   //----------------------------------------------------------------------------------------------
   // Parse model file
   //----------------------------------------------------------------------------------------------
   
   public static PssModel parseFile(String file_s) 
   {
      PssModel model      = new PssModel();
      Integer nextSectIdx = null;
      
      boolean[] done = new boolean[FUNC_NAMES.length];
      for (int i = 0; i < done.length; i++) {
         done[i] = false;
      }
      
      try {
         PssParser parser = new PssParser(file_s);
         //parser.setDoNormalize(true);
         parser.setSkipEmpty(false);
      
         parseHeaderLine(parser, model);
         parseComments(parser, model);
         
         //..... Parse sections ......
         
         nextSectIdx = SECT_BUS_IDX;
         do {
            int inputSectIdx = nextSectIdx;
            if (nextSectIdx >= done.length) break;       // file is processed
            
            if (done[nextSectIdx] == false) { 
               nextSectIdx = parseSection(nextSectIdx, parser, model);
               done[inputSectIdx] = true;
               
               if (nextSectIdx == null) break;           // file is processed

               //..... Special processing if there are no comments ...... 
               
               if (nextSectIdx == -1) {
                  nextSectIdx = inputSectIdx + 1;
                  
                  //..... Skip FIXED SHUNT section for versions < 31 ......
                  
                  if (nextSectIdx == SECT_FIX_SHUNT_IDX && model.getFormatVersion() < PssModel.VERSION_31) {
                     nextSectIdx += 1;
                  }
                  //..... Change position of SWITCHED SHUNT section ......
                  // Versions <= 30 : position = 11
                  // Versions >  30 : position = 18 (after FACTS) 
                  
                  if (model.getFormatVersion() > PssModel.VERSION_30) {
                     if (nextSectIdx == SECT_SW_SHUNT_IDX) {            // skip section SWITCHED SHUNT
                        nextSectIdx = SECT_TICT_IDX;                     
                     }
                     else if (nextSectIdx == SECT_GNE_IDX) {            // it should be SWITCHED SHUNT here
                        nextSectIdx = SECT_SW_SHUNT_IDX;       
                     }
                     else if (nextSectIdx == SECT_TICT_IDX) {           // return back from SWITCHED SHUNT
                        nextSectIdx = SECT_GNE_IDX;
                     }
                  }
               }
            }
            else {
               nextSectIdx++;
            }
         }
         while(true);
      }
      catch (FileNotFoundException e) {
         log.error("PssParser.parseFile. File " + file_s + " not found. " + e.getMessage());
         return null;
      } 
      catch (IOException e) {
         log.error("PssParser.parseFile. General I/O error in parsing file " + file_s + ". " + e.getMessage());
         return null;
      }
      catch (Exception e) {
         log.error("PssParser.parseFile. File: " + file_s + ". " + e.getMessage());
         return null;
      }
      //..... Model attributes ......
      
      //model.setDspaceId(BGUtils.getNameFromFile(file_s));
      model.setName(BGUtils.getNameFromFile(file_s));
      model.setPath(file_s);
      model.calcTypeCounts();
      model.setFormat(BGModel.MODEL_FORMAT_PSSE);
      
      return model;
   }
   //----------------------------------------------------------------------------------------------
   // 0. Find version from the first line
   //----------------------------------------------------------------------------------------------
   
   private static Integer parseHeaderLine(PssParser parser,
                                          PssModel  model) throws IOException
   {
      String line_s = parser.getLine();
      if (line_s == null) return null;
      
      PssObject obj = new PssObject(model, SECT_HEADER_IDX);
      obj.setType(SECT_NAMES_SA[SECT_HEADER_IDX]);
      obj.setName(SECT_NAMES_SA[obj.getSectIdx()]);
      
      //..... Try to get version from comments ......
      // Do it first, because this more detailed information with decimal value.
      // In some files, SBASE is followed by a comment with the 
      // REV number such as: "/ PSS/E-29.0" or "/ PSS(tm)E-30 RAW"
         
      Double version = null;
      
      int verIdx = line_s.indexOf("/ PSS");
      if (verIdx >=0 ) {
         String ver_s = line_s.substring(verIdx + 4);      
         Matcher m = Pattern.compile("[^0-9\\.]*([0-9\\.]+).*").matcher(ver_s);
         if (m.matches()) {
            version = BGUtils.stringToDouble(m.group(1), 1);
         }
      }
      //...... Remove comments ......

      if (line_s.indexOf(COMENT_SIGN) >= 0) {
         line_s = BGUtils.deleteFrom(line_s, COMENT_SIGN).trim();
      }
      //..... Split for getting attributes ......
      
      line_s = line_s.replace(",", " ");
      line_s = line_s.replaceAll("\\s+"," ").trim();                    // String normalization
      String[] line_sa = line_s.split(" ", -1);
      int len = line_sa.length;
      
      //...... Get version as a 3rd number ......
      
      if (version == null && len >= 3) {
         version = BGUtils.stringToDouble(line_sa[2].trim());
      }
      if (version == null) {
         version = PssModel.VERSION_DEFAULT;
      }
      //..... Parse header (first line) ......
      
      for (int i = 0; i < len; i++) {
         obj.addAttr(obj.valueOfType(line_sa[i].trim(),HEADER_ATTR_TYPES_A[i]));
      }
      //..... Set version ......
      
      obj.setAttr(HEADER_ATTR_VERSION_IDX, version.toString());
      obj = model.setDefaultValues(obj, 0);
      
      model.addObject(obj);
      model.setFormatVersion(version);
      model.setAttrSpec(SECT_HEADER_IDX);
      
      return SECT_COMMENTS_IDX;
   }
   //----------------------------------------------------------------------------------------------
   // 1. Read comment lines ( 2 lines)
   //----------------------------------------------------------------------------------------------
   
   private static Integer parseComments(PssParser parser,
                                        PssModel  model) throws IOException
   {       
      String line1_s = parser.getLine();
      if (line1_s == null) return null;

      String line2_s = parser.getLine();
      if (line2_s == null) return null;
      
      if (!line1_s.isEmpty() || !line2_s.isEmpty()) {
         PssObject obj = new PssObject(model, SECT_COMMENTS_IDX);
         obj.setType(SECT_NAMES_SA[SECT_COMMENTS_IDX]);
         obj.setName(SECT_NAMES_SA[obj.getSectIdx()]);
      
         obj.addAttr(line1_s);
         obj.addAttr(line2_s);
      
         model.addObject(obj);
         model.setAttrSpec(SECT_COMMENTS_IDX);
      }
      return SECT_BUS_IDX;
   }
   //----------------------------------------------------------------------------------------------
   // 2. Parse BUS section
   //----------------------------------------------------------------------------------------------
   
   public static Integer parseBusSect(PssParser parser,
                                      PssModel model) throws IOException
   {
      //..... Version specifics ......
      
      model.setAttrSpec(SECT_BUS_IDX);
      
      //..... For each BUS object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         
         PssObject obj = parseObjectLine(SECT_BUS_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj = model.setDefaultValues(obj, 0);
         
         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_BUS_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_BUS_IDX] + "_" + obj.getAttr(0));
         obj.setAttr(0, obj.getName());
       
         //obj.setName(obj.getAttrName(1));
         //obj.setAttrExtendedValue(SECT_NAMES_SA[SECT_AREA_IDX]);
         //obj.setAttrExtendedValue(SECT_NAMES_SA[SECT_ZONE_IDX]);
         //obj.setAttrExtendedValue(SECT_NAMES_SA[SECT_OWNER_IDX]);
                  
         model.addObject(obj);
      }
      while(true);
   }
   //----------------------------------------------------------------------------------------------
   // 3. Parse LOAD section
   //----------------------------------------------------------------------------------------------
   
   public static Integer parseLoadSect(PssParser parser,
                                        PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      model.setAttrSpec(SECT_LOAD_IDX);
      
      //..... For each LOAD object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         
         PssObject obj = parseObjectLine(SECT_LOAD_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj = model.setDefaultValues(obj, 0);
         
         obj.setType(SECT_NAMES_SA[SECT_LOAD_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_LOAD_IDX] + "_" + obj.getAttr(0) + "_" + obj.getAttr(1));
         obj.setAttr(0, SECT_NAMES_SA[SECT_BUS_IDX] + "_" + obj.getAttr(0));
         obj.setId(idx++);
         
         //obj.setAttrExtendedValue(SECT_NAMES_SA[SECT_AREA_IDX]);
         //obj.setAttrExtendedValue(SECT_NAMES_SA[SECT_ZONE_IDX]);
         
         model.addObject(obj);
      }
      while(true);
   }
   //----------------------------------------------------------------------------------------------
   // 4. FIXED SHUNT section
   //----------------------------------------------------------------------------------------------

   public static Integer parseFixedShuntSect(PssParser parser,
                                              PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      if (model.getFormatVersion() < PssModel.VERSION_31) return SECT_FIX_SHUNT_IDX + 1;
   
      model.setAttrSpec(SECT_FIX_SHUNT_IDX);
      
      //..... For each FIXED SHUNT object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         
         PssObject obj = parseObjectLine(SECT_FIX_SHUNT_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj.setType(SECT_NAMES_SA[SECT_FIX_SHUNT_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_FIX_SHUNT_IDX] + "_" + obj.getAttr(0) + "_" + obj.getAttr(1)); 
         obj.setAttr(0, SECT_NAMES_SA[SECT_BUS_IDX] + "_" + obj.getAttr(0));
         obj.setId(idx++);
         
         model.addObject(obj);
      }
      while(true);
   }
   //----------------------------------------------------------------------------------------------
   // 5. GENERATOR section
   //----------------------------------------------------------------------------------------------

   public static Integer parseGeneratorSect(PssParser parser,
                                             PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      model.setAttrSpec(SECT_GEN_IDX);
      
      //..... For each GENERATOR object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         
         PssObject obj = parseObjectLine(SECT_GEN_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj.setType(SECT_NAMES_SA[SECT_GEN_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_GEN_IDX] + "_" + obj.getAttr(0) + "_" + obj.getAttr(1));
         obj.setAttr(0, SECT_NAMES_SA[SECT_BUS_IDX] + "_" + obj.getAttr(0));
         obj.setId(idx++);
         
         model.addObject(obj);
      }
      while(true);      
   }
   //----------------------------------------------------------------------------------------------
   // 6. BRANCH section
   //----------------------------------------------------------------------------------------------

   public static Integer parseBranchSect(PssParser parser,
                                          PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      model.setAttrSpec(SECT_BRANCH_IDX);
      
      //..... For each BRANCH object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         
         PssObject obj = parseObjectLine(SECT_BRANCH_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_BRANCH_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_BRANCH_IDX] + "_" + obj.getId());
         
         obj.setAttr(0, SECT_NAMES_SA[SECT_BUS_IDX] + "_" + obj.getAttr(0));     // From
         obj.setAttr(1, SECT_NAMES_SA[SECT_BUS_IDX] + "_" + obj.getAttr(1));     // To
         
         model.addObject(obj);
      }
      while(true);      
   }
   //----------------------------------------------------------------------------------------------
   // 7. TRANSFORMER section
   //----------------------------------------------------------------------------------------------

   public static Integer parseTransSect(PssParser parser,
                                        PssModel  model) throws IOException
   {    
      int transType = 5;      // 4 - two winding transformer, 5 - three winding transformer
      
      //..... Version specifics ......
      
      if (model.getFormatVersion() < PssModel.VERSION_29) return SECT_TRANS2_IDX + 1;
      
      model.setAttrSpec(SECT_TRANS3_IDX);     // set names/defaults/types for 3-winding transformers
      model.setAttrSpec(SECT_TRANS2_IDX);     // set names/defaults/types for 2-winding transformers

      //..... For each TRAMSFORMER object ......
      
      int idx = 0;
      do {         
         PssObject obj = new PssObject(model, SECT_TRANS3_IDX);   // preliminary section setting 
         
         //..... For 4 or 5 object lines ......
              
         for (int i = 0; i < transType; i++) {                    // five (or four) line object
         
            String line_s = parser.getLine();
            if (line_s ==  null || isModelEnd(line_s)) return null;
            
            if (isSectionEnd(line_s)) {                           // end of section
               obj.setNextSectIdx(getNextSection(line_s));
               if (obj.getNextSectIdx() != null) {
                  return obj.getNextSectIdx();
               }
            }
            String[] attr_sa = line_s.split(",", -1);             // -1 needs to keep trailing empties

            // Find if it's two or three winding transformer
            
            if (i == 0) {   
               String k_bus_s = attr_sa[K_BUS_IDX].toString();
               if (k_bus_s.trim().equals("0")) {
                  transType = 4;
                  obj.setSectIdx(SECT_TRANS2_IDX);
               }
            }
            obj.addAttrs(attr_sa, i);                          // add i-line with defaults if needed
         }
         //..... Set common object attributes  ......

         obj.setId(idx++);        
         obj.setType(SECT_NAMES_SA[obj.getSectIdx()]);            
         obj.setName(SECT_NAMES_SA[obj.getSectIdx()] + "_" + obj.getId());
         obj.setAttr(0, SECT_NAMES_SA[SECT_BUS_IDX]  + "_" + obj.getAttr(0));     // From
         obj.setAttr(1, SECT_NAMES_SA[SECT_BUS_IDX]  + "_" + obj.getAttr(1));     // To
         
         model.addObject(obj);
      }
      while(true);
   }
   //----------------------------------------------------------------------------------------------
   // 8. AREA interchange section
   //----------------------------------------------------------------------------------------------

   public static Integer parseAreaSect(PssParser parser,
                                        PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      model.setAttrSpec(SECT_AREA_IDX);
      
      //..... For each GENERATOR object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         PssObject obj = parseObjectLine(SECT_AREA_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj.setType(SECT_NAMES_SA[SECT_AREA_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_AREA_IDX] + "_" + obj.getAttr(0));
         obj.setAttr(0, obj.getName());
         obj.setId(idx++);
         
         model.addObject(obj);
      }
      while(true);      
   }
   //----------------------------------------------------------------------------------------------
   // 9. Two-terminal DC transmission line section
   //----------------------------------------------------------------------------------------------

   public static Integer parseDC2Sect(PssParser parser,
                                       PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      if (model.getFormatVersion() < PssModel.VERSION_30) return SECT_DC2_IDX + 1;
      
      model.setAttrSpec(SECT_DC2_IDX);
      
      //..... For each Two-terminal DC transmission object line ......
      
      int idx = 0;
      do {         
         PssObject obj = new PssObject(model, SECT_DC2_IDX);
         
         //..... DC2 object: 3-lines ......

         for (int i = 0; i < DC2_ATTR_NAMES_SAA.length; i++) {    // three line object
         
            String line_s = parser.getLine();
            if (line_s ==  null || isModelEnd(line_s)) return null;
            
            if (isSectionEnd(line_s)) {                           // end of section
               obj.setNextSectIdx(getNextSection(line_s));
               if (obj.getNextSectIdx() != null) {
                  return obj.getNextSectIdx();
               }
            }
            String[] attr_sa = line_s.split(",", -1);
            obj.addAttrs(attr_sa, i);
         }
         //..... Set object attributes  ......
         
         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_DC2_IDX]);            
         obj.setName(SECT_NAMES_SA[SECT_DC2_IDX] + "_" + obj.getId()); 
         model.addObject(obj);
      }
      while(true);
   }
   //----------------------------------------------------------------------------------------------
   // 10. Voltage source converter
   //----------------------------------------------------------------------------------------------

   public static Integer parseVoltageSect(PssParser parser,
                                           PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      model.setAttrSpec(SECT_VSC_IDX);
      
      //..... For each VOLTAGE object line ......
      
      int idx = 0;
      do {         
         PssObject obj = new PssObject(model, SECT_VSC_IDX);
         
       //..... Voltage object: 3-lines ......
         
         for (int i = 0; i < VSC_ATTR_NAMES_SAA.length; i++) {    // three line object
            
            String line_s = parser.getLine();
            if (line_s ==  null || isModelEnd(line_s)) return null;
            
            if (isSectionEnd(line_s)) {                           // end of section
               obj.setNextSectIdx(getNextSection(line_s));
               if (obj.getNextSectIdx() != null) {
                  return obj.getNextSectIdx();
               }
            }
            String[] attr_sa = line_s.split(",", -1);
            obj.addAttrs(attr_sa, i);
         }
         //..... Set object attributes  ......
         
         obj.setId(idx++);         
         obj.setType(SECT_NAMES_SA[SECT_VSC_IDX]);            
         obj.setName(SECT_NAMES_SA[SECT_VSC_IDX] + "_" + obj.getAttr(0)); 
         model.addObject(obj);
      }
      while(true);
   }
   //----------------------------------------------------------------------------------------------
   // 11. Switched Shunt Data
   //----------------------------------------------------------------------------------------------

   public static Integer parseSwitchedShuntSect(PssParser parser,
                                                PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      if (model.getFormatVersion() < PssModel.VERSION_26) return SECT_SW_SHUNT_IDX + 1;
      
      model.setAttrSpec(SECT_SW_SHUNT_IDX);
      
      //..... For each Transformer Impedance Correction object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         PssObject obj = parseObjectLine(SECT_SW_SHUNT_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_SW_SHUNT_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_SW_SHUNT_IDX] + "_" + obj.getId());
         
         model.addObject(obj);
      }
      while(true);      
   }
   //----------------------------------------------------------------------------------------------
   // 12. Transformer Impedance Correction Tables
   //----------------------------------------------------------------------------------------------

   public static Integer parseTictSect(PssParser parser,
                                        PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      if (model.getFormatVersion() < PssModel.VERSION_29) return SECT_TICT_IDX + 1;
      
      model.setAttrSpec(SECT_TICT_IDX);
      
      //..... For each Transformer Impedance Correction object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         PssObject obj = parseObjectLine(SECT_TICT_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_TICT_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_TICT_IDX] + "_" + obj.getId());
         
         model.addObject(obj);
      }
      while(true);      
   }
   //----------------------------------------------------------------------------------------------
   // 13. Multi-Terminal DC Line Data
   //----------------------------------------------------------------------------------------------

   public static Integer parseMTDCSect(PssParser parser,
                                        PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      model.setAttrSpec(SECT_MTDC_IDX);
      
      //..... For each MTDC object line ......
      
      int idx = 0;
      do {         
         PssObject obj = new PssObject(model, SECT_MTDC_IDX);
         
         //..... Multi-terminal object: 4-lines ......
         
         for (int i = 0; i < MTDC_ATTR_NAMES_SAA.length; i++) {
         
            String line_s = parser.getLine();
            if (line_s ==  null || isModelEnd(line_s)) return null;
            
            if (isSectionEnd(line_s)) {                           // end of section
               obj.setNextSectIdx(getNextSection(line_s));
               if (obj.getNextSectIdx() != null) {
                  return obj.getNextSectIdx();
               }
            }            
            String[] attr_sa = line_s.split(",", -1);
            obj.addAttrs(attr_sa, i);
         }
         //..... Set object attributes  ......
         
         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_MTDC_IDX]);            
         obj.setName(SECT_NAMES_SA[SECT_MTDC_IDX] + "_" + obj.getAttr(0));
         model.addObject(obj);
      }
      while(true);
   }
   //----------------------------------------------------------------------------------------------
   // 14. Multi-Section Line Data
   //----------------------------------------------------------------------------------------------

   public static Integer parseMSLDSect(PssParser parser,
                                        PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      model.setAttrSpec(SECT_MSLD_IDX);
      
      //..... For each Transformer Impedance Correction object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         PssObject obj = parseObjectLine(SECT_MSLD_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_MSLD_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_MSLD_IDX] + "_" + obj.getId());
         
         model.addObject(obj);
      }
      while(true);      
   }
   //----------------------------------------------------------------------------------------------
   //  15. Zone Data
   //----------------------------------------------------------------------------------------------

   public static Integer parseZoneSect(PssParser parser,
                                        PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      if (model.getFormatVersion() < PssModel.VERSION_29) return SECT_ZONE_IDX + 1;
      
      model.setAttrSpec(SECT_ZONE_IDX);
      
      //..... For each ZONE object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         PssObject obj = parseObjectLine(SECT_ZONE_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_ZONE_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_ZONE_IDX] + "_" + obj.getAttr(0));
         obj.setAttr(0, obj.getName());
         
         model.addObject(obj);
      }
      while(true);      
   }
   //----------------------------------------------------------------------------------------------
   //  16. Inter-area transfer data
   //----------------------------------------------------------------------------------------------

   public static Integer parseInterAreaSect(PssParser parser,
                                             PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      if (model.getFormatVersion() < PssModel.VERSION_29) return SECT_IATD_IDX + 1;
      
      model.setAttrSpec(SECT_IATD_IDX);
      
      //..... For each INTER-AREA object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         PssObject obj = parseObjectLine(SECT_IATD_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_IATD_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_IATD_IDX] + "_" + obj.getId()); 

         model.addObject(obj);
      }
      while(true);      
   }
   //----------------------------------------------------------------------------------------------
   //  17. Owner Data
   //----------------------------------------------------------------------------------------------

   public static Integer parseOwnerSect(PssParser parser,
                                         PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      if (model.getFormatVersion() < PssModel.VERSION_29) return SECT_OWNER_IDX + 1;
      
      model.setAttrSpec(SECT_OWNER_IDX);
      
      //..... For each OWNER object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         PssObject obj = parseObjectLine(SECT_OWNER_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_OWNER_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_OWNER_IDX] + "_" + obj.getAttr(0));
         obj.setAttr(0, obj.getName());
         
         model.addObject(obj);
      }
      while(true);      
   }
   //----------------------------------------------------------------------------------------------
   //  18. FACTS device data
   //----------------------------------------------------------------------------------------------

   public static Integer parseFactsSect(PssParser parser,
                                         PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      if (model.getFormatVersion() < PssModel.VERSION_30) return SECT_FACTS_IDX + 1;
      
      model.setAttrSpec(SECT_FACTS_IDX);
      
      //..... For each FACTS object line ......
      
      int idx = 0;
      do {
         String line_s = parser.getLine();
         PssObject obj = parseObjectLine(SECT_FACTS_IDX, model, line_s);
         if (obj == null) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_FACTS_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_FACTS_IDX] + "_" + obj.getId()); 
         
         model.addObject(obj);
      }
      while(true);      
   }
   //----------------------------------------------------------------------------------------------
   //  19. GNE Data
   //----------------------------------------------------------------------------------------------

   public static Integer parseGNESect(PssParser parser,
                                       PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      if (model.getFormatVersion() < PssModel.VERSION_32) return SECT_GNE_IDX + 1;
      
      model.setAttrSpec(SECT_GNE_IDX);
      
      //..... For each GNE object line ......
      
      Integer nextSectIdx = -1;
      int idx = 0;
      do {
         PssObject obj = new PssObject(model, SECT_GNE_IDX);
         
         String line_s = parser.getLine();
         if (line_s ==  null || isModelEnd(line_s)) return null;
         
         if (isSectionEnd(line_s)) {                           // end of section
            obj.setNextSectIdx(getNextSection(line_s));
            if (obj.getNextSectIdx() != null) {
               nextSectIdx = obj.getNextSectIdx();
               break;
            }
         }            
         String[] attr_sa = line_s.split(",", -1);
         
         //..... Assign attributes ......
      
         obj.addAttrs(attr_sa, 0);

         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_GNE_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_GNE_IDX] + "_" + obj.getId());         
         
         model.addObject(obj);
      }
      while(true);      
      
      if (idx == 0) return SECT_GNE_IDX + 1;
      
      //..... Calculate and add number of buses to names, types and defaults ......
      
      int busNumMax = 0;
      for (BGObject obj : model.getObjects(SECT_GNE_IDX)) {
         int curNum = ((PssObject)obj).getAttrNum();
         if (curNum > busNumMax) busNumMax = curNum;
      }
      if (busNumMax > NTERN_IDX) {
         model.removeAttrSpec(SECT_GNE_IDX, BUS_1_NAME);
         model.removeAttrSpec(SECT_GNE_IDX, BUS_NTERM_NAME);
      
         for (int i = 0; i < busNumMax; i++) {
            int busIdx = NTERN_IDX + 1 + i;
            model.getAttrNames(SECT_GNE_IDX).add(busIdx, "bus_" + i);
            model.getAttrDefs(SECT_GNE_IDX, 0).add(busIdx, null);
            model.getAttrTypes(SECT_GNE_IDX).add(busIdx, Types.VARCHAR);
         }
      }
      //..... Add blank buses to each object if busNum < busNumMax ...... 
              
      for (BGObject bgObj : model.getObjects(SECT_GNE_IDX)) {
         PssObject obj  = (PssObject)bgObj;

         Integer busNum = null;
         Object busNum_o = obj.valueOfType(obj.getAttr(NTERN_IDX).toString(), Types.INTEGER);
         if (busNum_o instanceof Integer) {
            busNum = (Integer)busNum_o;
         }
         if (busNum == null && obj.getAttrNum() > GNE_MIN_ATTR_NUM) {
            busNum = obj.getAttrNum() - GNE_MIN_ATTR_NUM; 
         }
         if (busNum != null && busNum < busNumMax) {
            int diff = busNumMax - busNum;
            for (int i = 0; i < diff; i++) {
               int busIdx = NTERN_IDX + busNum + i + 1;
               obj.getAttrs().add(busIdx, null);
            }
         }
      }
      return nextSectIdx;
   }
   //----------------------------------------------------------------------------------------------
   //  20. Induction Machine data
   //----------------------------------------------------------------------------------------------

   public static Integer parseInductSect(PssParser parser,
                                          PssModel  model) throws IOException
   {
      //..... Version specifics ......
      
      if (model.getFormatVersion() < PssModel.VERSION_33) return SECT_INDUCT_IDX + 1;
      
      model.setAttrSpec(SECT_INDUCT_IDX);
      
      //..... For each INDUCTION MACHINE object line ......

      int idx = 0;
      do {
         String line_s = parser.getLine();
         PssObject obj = parseObjectLine(SECT_INDUCT_IDX, model, line_s);
         if (obj == null || obj.getNextSectIdx() == -1) return null;
         if (obj.getNextSectIdx() != null) {
            return obj.getNextSectIdx();
         }
         obj.setId(idx++);
         obj.setType(SECT_NAMES_SA[SECT_INDUCT_IDX]);
         obj.setName(SECT_NAMES_SA[SECT_INDUCT_IDX] + "_" + obj.getId());        
         
         model.addObject(obj);
      }
      while(true);      
   }
   //----------------------------------------------------------------------------------------------
   // Parse object line
   //----------------------------------------------------------------------------------------------
   
   private static PssObject parseObjectLine(int      sectIdx,
                                            PssModel model,
                                            String   line_s)
   {
      if (line_s == null || isModelEnd(line_s)) return null;
      
      // line_s = BGUtils.deleteFrom(line_s, COMENT_SIGN);     // remove comments (if any)
      
      PssObject obj = new PssObject(model, sectIdx);

      if (isSectionEnd(line_s)) {
         obj.setNextSectIdx(getNextSection(line_s));
         return obj;
      }
      String[] attr_sa = line_s.split(",", -1);
   
      //..... Assign attributes ......
   
      obj.addAttrs(attr_sa, 0);
      return obj;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
  
   private static boolean isSectionEnd(String line_s)
   {
      line_s = line_s.trim();
      
      if (line_s.startsWith(SECTION_END)) {
         int pos2 = line_s.indexOf(COMENT_SIGN);
         if (pos2 == -1) pos2 = line_s.length();
         
         line_s = line_s.substring(SECTION_END.length(), pos2).trim();
         if (line_s.isEmpty()) {
            return true;
         }
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
  
   private static boolean isModelEnd(String line_s)
   {
      line_s = line_s.trim();
      
      if (line_s.startsWith(FILE_END)) {
         int pos2 = line_s.indexOf(COMENT_SIGN);
         if (pos2 == -1) pos2 = line_s.length();
         
         line_s = line_s.substring(FILE_END.length(), pos2).trim();
         if (line_s.isEmpty()) {
            return true;
         }
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static Integer getNextSection(String line_s)
   {
      int beginIdx = line_s.toUpperCase().indexOf(BEGIN_NAME);         // index of word "BEGIN"
      if (beginIdx < 0) return -1;
      
      int startIdx = beginIdx + BEGIN_NAME.length();     // start index to search section name
      if (line_s.length() <= startIdx) return -1;
      
      for (int sectIdx = 0; sectIdx < SECT_COMMENTS_SAA.length; sectIdx++) {
         if (SECT_COMMENTS_SAA[sectIdx] == null) continue;
      
         String sect_s = line_s.substring(startIdx).toUpperCase();
         sect_s = sect_s.replaceAll("\\s+"," ").trim();                     // replace dup.white spaces
         
         if (BGUtils.getOptionStartStringIdx(sect_s, SECT_COMMENTS_SAA[sectIdx]) >=0) {
            return sectIdx;
         }
      }
      return -1;
   };
   //----------------------------------------------------------------------------------------------
   // Call method based on section Idx (reflection)
   //----------------------------------------------------------------------------------------------
   
   private static Integer parseSection(Integer   sectIdx,
                                       PssParser parser,
                                       PssModel  model) throws FileNotFoundException
   {
      if (sectIdx < 0 || sectIdx >= FUNC_NAMES.length) return null;
   
      Integer nextSectIdx = null;
      try {
         Method func = parser.getClass().getMethod(FUNC_NAMES[sectIdx], PssParser.class, PssModel.class);
         func.setAccessible(true);
         nextSectIdx = (Integer)func.invoke(parser, parser, model);
         
      }
      catch (SecurityException e) { 
         log.error("PssParser.parseSection. Security exception. Section = " + sectIdx + "; Message: " + e.getMessage());
      }
      catch (NoSuchMethodException e) { 
         log.error("PssParser.parseSection. No Such Method: " + FUNC_NAMES[sectIdx] + "; Section = " + sectIdx + 
                   "; Message: " + e.getMessage());
      }
      catch (IllegalArgumentException e) {
         log.error("PssParser.parseSection. Illegal Argument. Method: " + FUNC_NAMES[sectIdx] + "; Section = " + sectIdx + 
                   "; Message: " + e.getMessage());
      }
      catch (IllegalAccessException e) {
         log.error("PssParser.parseSection. Illegal Access. Method: " + FUNC_NAMES[sectIdx] + "; Section = " + sectIdx + 
                   "; Message: " + e.getMessage());
      }
      catch (InvocationTargetException e) {
         log.error("PssParser.parseSection. Invocation Target Exception. Method: " + FUNC_NAMES[sectIdx] + 
                   "; Section = " + sectIdx + "; Message: " + e.getMessage());
      }
      return nextSectIdx;
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {
      //String as = "12, 3,abc,, 14,,, 17,,";
      //String [] asa = as.split(",", -1);
      
      
     // String input = "/ PSS(tm)E-30";
     // Matcher m = Pattern.compile("[^0-9\\.]*([0-9\\.]+).*").matcher(input);
      
      //Matcher m = p.matcher(input);
      //Matcher m = Pattern.compile("(?!=\\d\\.\\d\\.)([\\d.]+)").matcher(input);
      //Matcher m = Pattern.compile("[^0-9]*([0-9]+).*").matcher(input);
      //if (m.matches()) {
      //   System.out.println(m.group(1));
      //}
      /*
      org.apache.log4j.BasicConfigurator.configure();
      
      DBConnection dbConn = new DBConnection(DBProvider.GraphDB);
      Connection conn     = dbConn.getConnection();
      DBExecute  exec     = new DBExecute();

//      BGModel model = BGParser.parseFile(BGModel.MODEL_FORMAT_PSSE, "C:\\tmp_share\\SDET 500bus case.raw");
//      BGModel model = BGParser.parseFile(BGModel.MODEL_FORMAT_PSSE, "C:\\tmp_share\\IEEE 118 Bus.RAW");
//      BGModel model = BGParser.parseFile(BGModel.MODEL_FORMAT_PSSE, "C:\\tmp_share\\Brazilian_7_bus_Equiv_Model.RAW");
//      BGModel model = BGParser.parseFile(BGModel.MODEL_FORMAT_PSSE, "C:\\tmp_share\\IEEE300Bus.raw");
//      BGModel model = BGParser.parseFile(BGModel.MODEL_FORMAT_PSSE, "C:\\tmp_share\\IEEE RTS 96 bus.RAW");
//      BGModel model = BGParser.parseFile(BGModel.MODEL_FORMAT_PSSE, "C:\\tmp_share\\NETS-NYPS 68 Bus System.RAW");
//      BGModel model = BGParser.parseFile(BGModel.MODEL_FORMAT_PSSE, "C:\\tmp_share\\Benchmark_4ger_33_2015.RAW");
//      BGModel model = BGParser.parseFile(BGModel.MODEL_FORMAT_PSSE, "C:\\tmp_share\\powersystem.raw");
      
      
      //..... Test reading from graph DB ......
      
      String modelId   = "de9a9c7c-0f8b-4e48-bd4c-936e954461f4";
      String nodeName  = null;
      String nodeType  = "area";
      String colName   = null;
      String tableName = "_psse"; 
      
      BGModel model = BGParser.parseFile(BGModel.MODEL_FORMAT_PSSE, "C:\\tmp_share\\IEEE 24 bus.RAW");
      
      if (model == null) return;

      model.setUuid(UUID.randomUUID());
      String json_s = model.toJson();
      
      DBEntry entry;
      entry = model.getEntry("zone", null);
      entry.printContent();
      
      entry = model.getInfoEntry();
      entry.printContent();
      
      for (int i = 0; i < model.getTypesNum(); i++) {
         String sectName = model.getObjTypeNames()[i];
         entry = model.getEntry(sectName, null); 
         if (entry != null) {
            entry.printContent();
         }       
      }
      //..... For each model attribute type ......
      
      String[] objTypeNames = model.getObjTypeNames();
      if (objTypeNames == null) return;
      
      for (int sectIdx = 0; sectIdx < objTypeNames.length; sectIdx++) {
         if (model.getObjects(sectIdx).length > 0) {
            boolean res_b = ModelProcess.execBulkInsert (conn, exec, model, sectIdx);
            if (res_b == false) return;
         }
      }
      dbConn.close();

      //String json_s = model0.toJson();
      System.exit(0);
      */
   }
}
 //======================================= End of Class ============================================