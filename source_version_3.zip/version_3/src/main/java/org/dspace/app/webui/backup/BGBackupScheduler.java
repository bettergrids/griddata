package org.dspace.app.webui.backup;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;

public class BGBackupScheduler {

   private static final Logger log = Logger.getLogger(BGBackupScheduler.class);

   private static ScheduledExecutorService executorService = null;

   private static final String name          = "BGBackupScheduler";
   public  static final String SET_SERVICE   = "set_service";
   public  static final String STOP_SERVICE  = "stop_service";
   
   private static BGBackup backup;

   private static int numOfDays = 1;            // run every N days
   private static int startHour = 12;
   private static int startMin  = 0;
   private static int startSec  = 0;

   private static String serviceStatus    = null;        // current status of input form     
   private static volatile boolean isBusy = false;
   private static volatile ScheduledFuture<?> scheduledTask = null;

   private AtomicInteger completedTasks = new AtomicInteger(0);

   //..... Constructor ......
   
   private BGBackupScheduler() {};
   
   protected static final BGBackupScheduler INSTANCE = new BGBackupScheduler();
   
   public static final BGBackupScheduler getInstance()
   {
      BGBackupScheduler.backup = BGBackup.getInstance();
      BGBackupForm.getInstance();
      return INSTANCE;
   }

   public static final BGBackupScheduler getInstance(int      numOfDays,
                                                     int      targetHour,
                                                     int      targetMin)
   {
      BGBackupScheduler.backup = BGBackup.getInstance();
      init (backup, numOfDays, targetHour, targetMin);
      BGBackupForm.getInstance();
      return INSTANCE;
   }
   
   public static void init(BGBackup backup,
                           int      numOfDays,
                           int      targetHour,
                           int      targetMin)
   {
      BGBackupScheduler.backup    = backup;
      delayInit(numOfDays, targetHour, targetMin);
   }
   
   public static void delayInit(int numOfDays,
                                int targetHour,
                                int targetMin)
   {
      BGBackupScheduler.numOfDays = numOfDays;
      BGBackupScheduler.startHour = targetHour;
      BGBackupScheduler.startMin  = targetMin;
      BGBackupScheduler.startSec  = 0;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
    
   public static ScheduledFuture<?> getScheduledTask() {
      return scheduledTask;
   }
   public static void setScheduledTask(ScheduledFuture<?> scheduledTask) {
      BGBackupScheduler.scheduledTask = scheduledTask;
   }
   public static int getNumOfDays() {
      return numOfDays;
   }
   public static void setNumOfDays(int numOfDays) {
      BGBackupScheduler.numOfDays = numOfDays;
   }
   public static int getStartHour() {
      return startHour;
   }
   public static void setStartHour(int startHour) {
      BGBackupScheduler.startHour = startHour;
   }
   public static int getStartMin() {
      return startMin;
   }
   public static void setStartMin(int startMin) {
      BGBackupScheduler.startMin = startMin;
   }
   public static String getServiceStatus() {
      return serviceStatus;
   }
   public static void setServiceStatus(String serviceStatus) {
      BGBackupScheduler.serviceStatus = serviceStatus;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static boolean isFormModified(String    formServiceStatus,
                                        Boolean[] formOptions_ba,
                                        int       formHour,
                                        int       formMin,
                                        int       formDays,
                                        int       formKeepArchives)
   {        
      if (getServiceStatus() == null || getServiceStatus().equals(formServiceStatus) == false){
         return true;
      }
      if (STOP_SERVICE.equals(formServiceStatus)) return false;  // STOP service was not changed and 
                                                                 // any other setting are not important     
      Boolean[] options_sa = BGBackup.getOptionsBoolean();
      
      if (formOptions_ba.length != options_sa.length) return true;
      
      for (int i = 0; i < options_sa.length; i++) {
         if (options_sa[i] != formOptions_ba[i]) return true;
      }
      if (startHour != formHour) return true;
      if (startMin  != formMin)  return true;
      if (numOfDays != formDays) return true;
      
      if (BGBackup.getKeepArchivesNum() != formKeepArchives) return true;
      return false;
   }
   //----------------------------------------------------------------------------------------------
   
   public static boolean isFormModified()
   {
      return isFormModified(BGBackupForm.getServiceStatus(),
                            BGBackupForm.getOptions(),
                            BGBackupForm.getStartHour(),
                            BGBackupForm.getStartMin(),
                            BGBackupForm.getNumOfDays(),
                            BGBackupForm.getKeepArchivesNum());
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static void setFormFromClasses()
   {
      BGBackupForm.setServiceStatus(serviceStatus);
      BGBackupForm.setOptions(BGBackup.getOptionsBoolean());
      
      BGBackupForm.setNumOfDays(numOfDays);
      BGBackupForm.setStartHour(startHour);
      BGBackupForm.setStartMin(startMin);
      
      BGBackupForm.setKeepArchivesNum(BGBackup.getKeepArchivesNum());
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static void setFormFromPage(String   serviceStatus_s,
                                      String[] optionNames_sa,
                                      int      startHour,
                                      int      startMin,
                                      int      numOfDays,
                                      Integer  keepArchivesNum)
   {
      BGBackupForm.setServiceStatus(serviceStatus_s);
      BGBackupForm.setOptionsFromForm(optionNames_sa);
      
      BGBackupForm.setNumOfDays(numOfDays);
      BGBackupForm.setStartHour(startHour);
      BGBackupForm.setStartMin(startMin);
      
      if (keepArchivesNum == null) {
         BGBackupForm.setKeepArchivesNum(BGBackup.getKeepArchivesNum());
      }
      else {
         BGBackupForm.setKeepArchivesNum(keepArchivesNum);
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public void start() 
   {
      
      if (executorService != null) {
         stop();
      }
      try {
         //..... Start a new service ......
         
         executorService = Executors.newSingleThreadScheduledExecutor();
         log.info(name + " new service started: [" + completedTasks.get() + "] : " + getCurrentTime());
      
         //..... Start new schedule ......
      
         long initDelay = computeNextDelay(1, startHour, startMin, startSec);    // in seconds
         long period    = numOfDays * 86400;                                     // in seconds
               
         scheduledTask = executorService.scheduleAtFixedRate(doTaskWork(), initDelay, period, TimeUnit.SECONDS);        
         
         Date nextArchiveDate = new Date(System.currentTimeMillis() + initDelay * 1000); 
         BGBackup.setNextArchiveDate(nextArchiveDate);

         log.info(name + " task will start in " + initDelay + " sec.");
      }
      catch (Exception e) {
         log.error(name + ". Cannot create new scheduler. " + e.getMessage());
      }
   }
   //----------------------------------------------------------------------------------------------
   
   public String getCurrentTime()
   {
      Calendar now = Calendar.getInstance();    // return current time     
      return BGBackup.getFormattedDate(now.getTime());
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
    
   private Runnable doTaskWork() { 
      return () -> {
         boolean status = true;
         log.info(name + " [" + completedTasks.get() + "] start: " + getCurrentTime());
         try {
            isBusy = true;
            status = backup.doBackup();
            log.info(name + " [" + completedTasks.get() + "] finish with status = " + status + " at " + getCurrentTime());
            log.info(name + " total number of completed tasks: " + completedTasks.incrementAndGet());
         } 
         catch (Exception e) {
            log.error(name + " throw exception in " + getCurrentTime() + ". " + e.getMessage());
         } 
         finally {
            isBusy = false;
            
            long delay = computeNextDelay(numOfDays, startHour, startMin, startSec);      // in seconds
            Date nextArchiveDate = new Date(System.currentTimeMillis() + delay * 1000); 
            BGBackup.setNextArchiveDate(nextArchiveDate);
            log.info(name + " next backup is scheduled on " + BGBackup.getFormattedDate(nextArchiveDate));
         }
      };
   }
   //----------------------------------------------------------------------------------------------
   // Calculate delay for next execution in SECONDS
   //----------------------------------------------------------------------------------------------

   private static long computeNextDelay(int targetDays,
                                        int targetHour, 
                                        int targetMin, 
                                        int targetSec) 
   {
      LocalDateTime localNow        = LocalDateTime.now();
      ZoneId currentZone            = ZoneId.systemDefault();
      ZonedDateTime zonedNow        = ZonedDateTime.of(localNow, currentZone);
      ZonedDateTime zonedNextTarget = zonedNow.withHour(targetHour).withMinute(targetMin).withSecond(targetSec);
      
      if (zonedNow.compareTo(zonedNextTarget) >= 0) {
         zonedNextTarget = zonedNextTarget.plusDays(1);
      }
      zonedNextTarget = zonedNextTarget.plusDays(targetDays - 1);
      Duration duration = Duration.between(zonedNow, zonedNextTarget);
      return duration.getSeconds();
   }
   //----------------------------------------------------------------------------------------------
   // 
   //----------------------------------------------------------------------------------------------

   public static void stop() 
   {      
      //..... Cancel current task ......
      
      if (scheduledTask != null) { 
         try {
            boolean result = scheduledTask.cancel(true);
            log.info(name + " cancelled immediately. Status: " + result + " (false means it was done or cancelled before)");
            scheduledTask = null;
         }
         catch(Exception e) {
            log.error(name + " cannot be cancelled. " + e.getMessage());
         }
      }
      //..... Shutdown service ......
      
      if (executorService == null) {
         log.info(name + " service is not specified. No need to stop.");
         return;
      }   
      try {
         if (executorService != null) {
            log.info(name + " is stopping.");
            executorService.shutdownNow();
         }  
         // wait one minute to termination if busy and try again
         
         if (isBusy) {
            log.info(name + " is waiting for termination. Task is busy");
            boolean result = executorService.awaitTermination(1, TimeUnit.MINUTES);
            if (result) {
               log.info(name + " service was terminated successfully.");
            }
            else {
               log.info(name + " service could not be terminated!");
            }
         }
         log.info(name + " stopped.");        
      } 
      catch (InterruptedException ie) {
         log.error(name + " wait for termination exception. " + ie.getMessage());
      }
      catch (Exception e) {
         log.error(name + " cannot stop the service. " + e.getMessage());
      }
      finally {
         BGBackup.setNextArchiveDate(null);
         log.info(name + " finished stopping process");
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static long getTimeForNextExecution()
   {
      if (scheduledTask == null) return -1;
      return scheduledTask.getDelay(TimeUnit.MINUTES);
   }
   //----------------------------------------------------------------------------------------------
   //  Main function for testing
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {
      org.apache.log4j.BasicConfigurator.configure();

      BGBackupScheduler bs = BGBackupScheduler.getInstance(1, 21, 42);
      
      String[] str_sa ={"dbCmd", "configFolder"};
      setFormFromPage("stop_service",
                       str_sa,
                       21,
                       45,
                       1,
                       3);
            
      Boolean[] opt_ba = BGBackupForm.getOptions();
      
      BGBackupConfig.setDspaceHome("C:\\dspace");
      BGBackupConfig.setArchiveFolder("C:\\tmp_share\\backup");      
      BGBackupConfig.setRepPrefix("123456789");
      
      BGBackup.setOptions(true);
      
      bs.start();
      
      try {
         TimeUnit.MINUTES.sleep(5);
         stop();
         bs = BGBackupScheduler.getInstance(1, 21, 45);
         bs.start();
         
      } catch (InterruptedException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
   }
}
//======================================= End of File =============================================