package org.dspace.app.webui.forum;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.UUID;

import javax.mail.MessagingException;

import org.apache.log4j.Logger;
import org.dspace.app.webui.backup.BGConfig;
import org.dspace.app.webui.model.DBConnection;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.model.DBExecute;
import org.dspace.app.webui.model.DBProvider;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.util.JSPManager;
import org.dspace.core.ConfigurationManager;
import org.dspace.core.Email;
import org.dspace.core.I18nUtil;
import org.dspace.core.LogManager;
import org.dspace.eperson.EPerson;
import org.dspace.services.ConfigurationService;
import org.dspace.services.factory.DSpaceServicesFactory;
import org.dspace.core.Context;

public class BGForum {

   private static final Logger log = Logger.getLogger(BGForum.class);
   
   private static final int ratingDistrSize = 6;
   private static DBTable commentTab = null;
   
   private DBProvider provider = new DBProvider(DBProvider.DSpaceDB);
   
   private String     dbName         = provider.getDbName();
   private Double     ratingAve      = 0.0;
   private Integer    ratingAveRound = 0;
   private Integer[]  ratingDistr    = new Integer[ratingDistrSize];
   
   //..... Constructor ......
   
   public BGForum() {
      if (commentTab == null) {
         DBExecute exec = new DBExecute();
         commentTab     = exec.getMetadataFromDB(dbName, BGComment.receiveTableName()).getTable();
      }
   }
   //..... Bean methods ......
   
   public String getDbName() {
      return dbName;
   }
   public void setDbName(String dbName) {
      this.dbName = dbName;
   }
   public DBTable getTable() {
      return commentTab;
   }
   public void setTable(DBTable table) {
      commentTab = table;
   }
   public Double getRatingAve() {
      return ratingAve;
   }
   public void setRatingAve(Double ratingAve) {
      this.ratingAve = ratingAve;
   }
   public Integer getRatingAveRound() {
      return ratingAveRound;
   }
   public void setRatingAveRound(Integer ratingAveRound) {
      this.ratingAveRound = ratingAveRound;
   }
   public Integer[] getRatingDistr() {
      return ratingDistr;
   }
   public void setRatingDistr(Integer[] ratingDistr) {
      this.ratingDistr = ratingDistr;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public DBEntry getComments(UUID    itemUID,         // if null - for all items
                              UUID    userUID,         // if null - for all users 
                              Integer rating,          // if null - for all ratings
                              String  searchTitle_s,   // if null - no search in titles
                              String  searchMsg_s,     // if null - no search in messages
                              Date    createdFrom_d,
                              Date    createdTo_d,
                              Date    lastModifiedFrom_d,
                              Date    lastModifiedTo_d)

   {
      Connection conn = new DBConnection(dbName).getConnection();       // get DB connection      
      DBExecute  exec = new DBExecute(); 
      
      String sql_s = "SELECT * FROM " + commentTab.getName() + " ORDER BY last_modified DESC";
   
      DBEntry entry = null;
      entry = exec.execQuery(conn, sql_s, null);
      exec.closeAll(null, null, conn);
      
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   
   public DBEntry getAllComments()
   {
      DBEntry entry = getComments(null,null,null,null,null,null,null,null,null);
      calculateRating(entry);

      return entry;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public BGComment getSpecificComment(BGComment[] coms,
                                       UUID        item_uuid,     
                                       UUID        user_uuid)
   {
      //..... This user already have comment on this item ......
      
      if (user_uuid != null && item_uuid != null && coms != null && coms.length != 0) {
         for (int i = 0; i < coms.length; i++) {
            if (coms[i].getUser_uuid().equals(user_uuid)) {
               return coms[i];
            }
         }
      }
      //..... Create new comment ......
      
      BGComment com = new BGComment(true);
      com.setItem_uuid(item_uuid);
      com.setUser_uuid(user_uuid);
      return com;
   }  
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private void calculateRating(DBEntry entry)
   {
      int RatingColIdx = entry.getTable().getColumnByName("rating").getIdx();
      
      ratingAve = 0.0;
      for (int i = 0; i < ratingDistrSize; i++) {
         ratingDistr[i] = 0;
      }
      int num = 0;
      for (int rowIdx = 0; rowIdx < entry.getRowNum(); rowIdx++) {
         Integer rating = (Integer)entry.getValue(rowIdx, RatingColIdx);
         
         if (rating != null && rating != 0) {         
            ratingAve += rating;
            ratingDistr[rating]++;
            num++;
         }
         else {
            ratingDistr[0]++;
         }
      }
      if (num > 0) {
         ratingAve      /= num;
         ratingAveRound  = (int)Math.round(ratingAve);
         
         for (int i = 0; i < ratingDistrSize; i++) {
            ratingDistr[i] = (int)Math.round(new Double(ratingDistr[i]) * 100.0 / num);
         }         
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public BGComment[] getComments(UUID itemUID,
                                  UUID userUID)                         // if null - for all users
   {
      Connection conn = new DBConnection(dbName).getConnection();       // get DB connection      
      DBExecute  exec = new DBExecute(); 
      
      String sql_s = "SELECT * FROM " + commentTab.getName() + " WHERE item_uuid = '" + itemUID.toString() + "'" +
                     ((userUID != null) ? " AND user_uuid = '" + userUID.toString() + "'" : "") +
                     " ORDER BY last_modified DESC";
   
      DBEntry entry = null;
      entry = exec.execQuery(conn, sql_s, null);
      
      Object[] obj_arr = entry.getClassObjects(BGComment.class);
      BGComment[] coms = Arrays.copyOf(obj_arr, obj_arr.length, BGComment[].class);

      calculateRating(entry);
     
      //..... Get User names from UUID ......
      
      sql_s = "SELECT dspace_object_id, string_agg(text_value, ' ' order by metadata_field_id) " +
              "FROM metadatavalue WHERE dspace_object_id IN (SELECT uuid FROM eperson) AND " +
              "metadata_field_id IN (1,2) GROUP BY dspace_object_id";
      
      entry = exec.execQuery(conn, sql_s, null);
      exec.closeAll(null, null, conn);
      
      for (int j = 0; j < coms.length; j++) {
         for (int i = 0; i < entry.getRowNum(); i++) {            
            if (coms[j].getUser_uuid().equals((UUID)entry.getValue(i, 0))) {
               coms[j].assignUserName((String)entry.getValue(i, 1));
               break;
            }
         }
      }     
      return coms;
   }  
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public BGComment[] getComments(String itemUID_s,
                                  String userUID_s)  // if null - for all users
   {
      try {
         UUID item_uuid = UUID.fromString(itemUID_s); 
         UUID user_uuid = (userUID_s == null) ? null : UUID.fromString(userUID_s); 
         return getComments(item_uuid, user_uuid);
      }
      catch (IllegalArgumentException e) {
         log.error("getComments. Cannot convert " + itemUID_s + " and/or " + userUID_s + " to UUID type.");
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean upsertComment(String  item_uuid_s,
                                String  user_uuid_s,
                                String  title,
                                String  message,
                                Integer rating)
   {
      boolean res_b = true;
      
      DBEntry entry = new DBEntry();
      entry.setTable(commentTab);
      
      BGComment comment = new BGComment();
      
      UUID item_uuid = null;
      UUID user_uuid = null;
      try {
         item_uuid = UUID.fromString(item_uuid_s);
         user_uuid = UUID.fromString(user_uuid_s);
      }
      catch(Exception e) {
         log.error("upsertComment. Cannot convert string(s): " + item_uuid_s + ", " + user_uuid_s +
                   " to UUID: " + e.getMessage());
      }
      comment.setItem_uuid(item_uuid);
      comment.setUser_uuid(user_uuid);
      comment.setTitle(title);
      comment.setMessage(message);
      comment.setRating(rating);
      
      Date currentDate = new Date();
      comment.setCreated(currentDate);
      comment.setLast_modified(currentDate);
      
      entry.addRowFromObject(comment);
      
      ArrayList<String> notUpdateCols = new ArrayList<String>();
      notUpdateCols.add("created");
      
      ArrayList<String> matchColNames = new ArrayList<String>();
      for (int i = 0; i < entry.getTable().getFkeys().size(); i++) {
         matchColNames.add(entry.getTable().getFkeys().get(i).getName());
      }
      DBExecute exec = new DBExecute();

      Connection conn = new DBConnection(DBProvider.DSpaceDB).getConnection();
      if (conn == null) {
         log.error("upsertComment. Cannot get connection to DB: " + DBProvider.DSpaceDB);
         return false;
      }
      res_b = exec.execUpsert(conn, matchColNames, notUpdateCols, entry);
      res_b &= exec.closeAll(null, null, conn);
      
      return res_b;      
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public int deleteComment(String  item_uuid_s,
                            String  user_uuid_s)
   {
      int num = 0;
      
      if (item_uuid_s == null || user_uuid_s == null) {
         log.error("deleteComment. item_uuid and/or user_uuid are nulls");
         return -1;        
      }
      Connection conn = new DBConnection(DBProvider.DSpaceDB).getConnection();
      if (conn == null) {
         log.error("deleteComment. Cannot get connection to DB: " + DBProvider.DSpaceDB);
         return -1;
      }
      //..... Prepare parameters ......
      
      ArrayList<String> params = new ArrayList<String>();
      params.add("item_uuid");
      params.add("user_uuid");
      
      ArrayList<String> values = new ArrayList<String>();
      values.add(item_uuid_s);
      values.add(user_uuid_s);
      
      //..... Execute ......
      
      DBExecute exec = new DBExecute();
      
      num = exec.execDelete(conn, BGComment.receiveTableName(), params, values);
      if (exec.closeAll(null, null, conn) == false) {
         return -1;
      };
      return num;      
   }   
   //----------------------------------------------------------------------------------------------
   // Send notification email
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("deprecation")
   public boolean sendNotification(Context  context,
                                   String   itemURL,
                                   String   comment_s)    
   { 
      try {
         ConfigurationService config = DSpaceServicesFactory.getInstance().getConfigurationService();
         
         EPerson user     = context.getCurrentUser();           
         String  userName = user.getFirstName() + " " + user.getLastName();

         String instName = config.getProperty("dspace.name");
         String instURL  = config.getProperty("dspace.url");
         
         String[] recipients = BGConfig.getBgArrayProperty("forum.recepients");

         String templatePath_s = I18nUtil.getEmailFilename(context.getCurrentLocale(), "comment_notify");
         
         return sendNotification(instName, instURL, itemURL, userName, user.getEmail(), 
                                 recipients, templatePath_s, comment_s); 
      }
      catch (Exception e) {
         log.error("sendNotification. Cannot send email. Error message: " + e.getMessage());
         return false;
      }
   }
   //----------------------------------------------------------------------------------------------
   // Send notification email
   //----------------------------------------------------------------------------------------------

   public boolean sendNotification(String   instanceName,
                                   String   instanceURL,
                                   String   itemURL,
                                   String   userName,
                                   String   userEmail,
                                   String[] recipients,        // email recipients
                                   String   templatePath_s,    // email template file name (comment_notify, e.g.)
                                   String   comment_s) throws IOException, MessagingException    
   { 
      //..... Create email based on the file template ......
   
      Email email = Email.getEmail(templatePath_s);    

      //..... template attributes by order ......
      // {0} The name of the BetterGrids instance
      // {1} The URL of the BetterGrids instance 
      // {2} Sender name:
      // {3} Sender email:
      // {4} Date:
      // [5] Item URL:
      // [6] Comment text         
         
      email.addArgument(instanceName);
      email.addArgument(instanceURL);
      email.addArgument(userName);                                         // Sender name
      email.addArgument(userEmail);
      email.addArgument(new Date());
      email.addArgument(itemURL);
      email.addArgument(comment_s);

      email.setReplyTo(userEmail);        // the reply will be send to the user who created this comment

      for (int i = 0; i < recipients.length; i++) {      // create list of recipients
         email.addRecipient(recipients[i]);
      }
      email.send();

      log.info("sendNotification. Comment notification email from user " + userName +
               " regarding item:" + itemURL + " has been sent to BetterGrids curators");
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {
      org.apache.log4j.BasicConfigurator.configure();
            
      boolean testing_email_b  = true;
      boolean testing_upsert_b = false;
      
      BGForum forum = new BGForum();
      
      //..... Testing email .....
      
      if (testing_email_b) {
         
         String instName       = "BetterGrids";
         String instURL        = "http://47.35.23.30:8080/bettergrids ";
         String itemURL        = "http://47.35.23.30:8080/bettergrids/handle/123456789/73";
         String userName       = "System Administrator"; 
         String userEmail      = "admin@bettergrids.org";
         String[] recipients   = {"nickolay.makarov@gridbright.com", "admin@bettergrids.org"};
         String templatePath_s = "C:\\dspace\\config\\emails\\comment_notify";
         String comment_s      = "Test comment text";
         
         try {
            boolean res = forum.sendNotification(instName, instURL, itemURL, userName, userEmail, 
                                                 recipients, templatePath_s, comment_s);
         } 
         catch (Exception e) {
            e.printStackTrace();
         }
      }
      //..... Testing upsert ......
      
      if (testing_upsert_b) {
         String  item_uuid_s = "b231db34-0f48-4ac3-bce7-69dcc4d357f3";
         String  user_uuid_s = "9551bb64-bd98-489d-96ae-75257ac16202";
         String  title       = "New testing title 7";
         String  message     = "Repository Upsert testing 7";
         Integer rating      = 2;
         
         forum.upsertComment(item_uuid_s, user_uuid_s, title, message, rating);
         
         //..... testing "get" comments ......
      
         BGComment[] coms;
         try {
            UUID item_uuid = UUID.fromString("b231db34-0f48-4ac3-bce7-69dcc4d357f3"); 
            UUID user_uuid = UUID.fromString("9551bb64-bd98-489d-96ae-75257ac16202"); 
         
            int num = forum.deleteComment(item_uuid.toString(), user_uuid.toString());
            coms    = forum.getComments(item_uuid, null);
         
            for (int i = 0; i < coms.length; i++) {
               String date_s = BGTime.formatDate(coms[i].getLast_modified());
               System.out.println(date_s);
            
               String ago_s = BGTime.getTimeAgo(coms[i].getLast_modified());
               System.out.println(ago_s);
            }
         }
         catch (Exception e) {
            log.error("main. Cannot convert item_uuid and/or user_uuid strings to UUID type.");
            return;
         }
         DBEntry entry = forum.getAllComments();
       
         Object[] obj_arr = entry.getClassObjects(BGComment.class);
         coms             = Arrays.copyOf(obj_arr, obj_arr.length, BGComment[].class);
      
         entry.printContent();
      }
   }
}
//========================================= End of Class ==========================================
