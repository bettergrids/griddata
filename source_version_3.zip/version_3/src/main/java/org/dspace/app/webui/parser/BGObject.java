package org.dspace.app.webui.parser;

import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.model.DBTypes;
import org.dspace.app.webui.parser.graph.BGGraphMap;
import org.dspace.app.webui.parser.graph.BGGraphSearch;
import org.dspace.app.webui.parser.graph.BGLinkAttr;
import org.dspace.app.webui.util.BGUtils;

public abstract class BGObject implements DBTypes {
   
   private static final Logger log = Logger.getLogger(BGObject.class);
   
   //..... Constants ......
   
   public static final String OBJECT_CONST = "object";
   public static final String DATE_FORMAT  = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
      
   //..... Members ......
   
   protected Integer id       = null;    // like "876"
   protected String  type     = null;    // like "regulator"
   protected String  name     = null;    // 
      
   //..... Graph members ......
   
   private List<BGLinkAttr> linksUp   = null;
   private List<BGLinkAttr> linksDown = null;
   
   private Map<String, List<LinkedList<String>>> pathsUp   = null;    // all posible paths to other nodes
   private Map<String, List<LinkedList<String>>> pathsDown = null;    //
   
   //..... Getters/Setters ......
   
   public Integer getId() {
      return id;
   }
   public void setId(Integer id) {
      this.id = id;
   }
   public String getType() {
      return type;
   }
   public void setType(String type) {
      this.type = type;
   }
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public List<BGLinkAttr> getLinksUp() {
      return linksUp;
   }
   public List<BGLinkAttr> getLinksDown() {
      return linksDown;
   }
   public Map<String, List<LinkedList<String>>> getPathsUp() {
      return pathsUp;
   }
   public void setPathsUp(Map<String, List<LinkedList<String>>> pathsUp) {
      this.pathsUp = pathsUp;
   }
   public Map<String, List<LinkedList<String>>> getPathsDown() {
      return pathsDown;
   }
   public void setPathsDown(Map<String, List<LinkedList<String>>> pathsDown) {
      this.pathsDown = pathsDown;
   }
   //..... Methods ......
   
   public void initLinks() 
   {
      if (this.linksUp == null) {
         this.linksUp = new ArrayList<BGLinkAttr>();
      }
      if (this.linksDown == null) {
         this.linksDown = new ArrayList<BGLinkAttr>();
      }
   }
   //----------------------------------------------------------------------------------------------
   // Add new link
   //----------------------------------------------------------------------------------------------
   
   public void addLink(boolean    down_b,       // true - down; false - up
                       BGLinkAttr newLink, 
                       Integer    idx)          // position where to add link
   {
      List<BGLinkAttr> curLinks = this.linksDown;
      if (down_b == false) {
         curLinks = this.linksUp;
      }
      if (curLinks == null) {
         curLinks = new ArrayList<BGLinkAttr>();
      }
      if (newLink != null) {
         if (idx != null && idx >= 0 && idx < curLinks.size()) {
            curLinks.add(idx, newLink);
         }
         else {
            curLinks.add(newLink);
         }
      }
   }
   //----------------------------------------------------------------------------------------------
   // Graph (links) Methods
   //----------------------------------------------------------------------------------------------
   
   public String[] getLinkTypes(boolean down_b)      // true - DOWN
   {
      if (down_b  && linksUp   == null) return null;
      if (!down_b && linksDown == null) return null;
      
      List<BGLinkAttr> links = (down_b) ? linksDown : linksUp;
      
      List<String> linkType_al = new ArrayList<String>(); 
      for (BGLinkAttr linkAttr : links) {
         linkType_al.add(linkAttr.getLinkType());
      }
      return linkType_al.toArray(new String[linkType_al.size()]);     
   }
   //----------------------------------------------------------------------------------------------

   public String[] getLinkNodes(boolean down_b)
   {
      if (down_b  && linksUp   == null) return null;
      if (!down_b && linksDown == null) return null;
      
      List<BGLinkAttr> links = (down_b) ? linksDown : linksUp;
      
      List<String> nodeName_al = new ArrayList<String>(); 
      for (BGLinkAttr linkAttr : links) {
         nodeName_al.add(linkAttr.getTargetName());
      }
      return nodeName_al.toArray(new String[nodeName_al.size()]);     
   }
   //----------------------------------------------------------------------------------------------
   
   public Integer[] getLinkHops(boolean down_b)
   {
      if (down_b  && linksUp   == null) return null;
      if (!down_b && linksDown == null) return null;
      
      List<BGLinkAttr> links = (down_b) ? linksDown : linksUp;
      
      List<Integer> nodeHops_al = new ArrayList<Integer>(); 
      for (BGLinkAttr linkAttr : links) {
         nodeHops_al.add(linkAttr.getHops());
      }
      return nodeHops_al.toArray(new Integer[nodeHops_al.size()]);     
   }
   //----------------------------------------------------------------------------------------------
   
   public Double[] getLinkDistances(boolean down_b)
   {
      if (down_b  && linksUp   == null) return null;
      if (!down_b && linksDown == null) return null;
      
      List<BGLinkAttr> links = (down_b) ? linksDown : linksUp;
      
      List<Double> nodeDist_al = new ArrayList<Double>(); 
      for (BGLinkAttr linkAttr : links) {
         nodeDist_al.add(linkAttr.getDistance());
      }
      return nodeDist_al.toArray(new Double[nodeDist_al.size()]);     
   }
   //----------------------------------------------------------------------------------------------
   // Return value casted to Double or Integer if possible. Otherwise return original string
   //----------------------------------------------------------------------------------------------
   
   public Object valueOfType(String value_s)
   {
      return BGUtils.stringToNumeric(value_s);
   }
   //----------------------------------------------------------------------------------------------
   
   public Object valueOfType(String  value_s, 
                             Integer dataType)
   {
      return valueOfType(value_s, dataType, null);
   }   
   //----------------------------------------------------------------------------------------------
   
   public Object valueOfType(String  value_s, 
                             Integer dataType,
                             String  dateFormat_s)
   {
      value_s = value_s.trim();
      if (dataType == null) {
         return BGUtils.stringToNumeric(value_s);
      }
      try {
         switch (dataType) {
         case Types.INTEGER:
            Integer valueInt = Integer.parseInt(value_s);
            return valueInt;
         case Types.DOUBLE:
            Double valueDbl = Double.parseDouble(value_s);
            return valueDbl;
         case Types.DATE:
            if (dateFormat_s == null) {
               return BGUtils.getDateOpt(value_s);
            }
            DateFormat dateFormat = new SimpleDateFormat(dateFormat_s); 
            return dateFormat.parse(value_s);
         case Types.VARCHAR:
         default:
            return value_s;
         }
      }
      catch (Exception e) {
         return BGUtils.stringToNumeric(value_s);     // if dataType is wrong
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public int getAttrType(Object value)
   {
      if      (value instanceof String)    return typeText;
      else if (value instanceof Double)    return typeDouble;
      else if (value instanceof Integer)   return typeInt;
      else if (value instanceof Date)      return typeDate;
      else if (value instanceof UUID)      return typeUUID;
      else if (value instanceof String[])  return typeTextArray;
      else if (value instanceof Integer[]) return typeIntArray;
      else if (value instanceof int[])     return typeIntArray;
      else if (value instanceof Double[])  return typeDoubleArray;
      else if (value instanceof double[])  return typeDoubleArray;
      else if (value instanceof Instant)   return typeTimestampTZ;
            
      return typeVarchar;      // default value
   }
   //----------------------------------------------------------------------------------------------
   // Calculate links to all nodes
   //----------------------------------------------------------------------------------------------
   
   public boolean calculateLinks(BGModel    model,
                                 BGGraphMap graphMap, 
                                 boolean    linksDown_b)
   {
      Map<String, List<LinkedList<String>>> paths_hm = new HashMap<String, List<LinkedList<String>>>();
    
      for (BGObject obj : model.getObjects()) {
         if (obj == this) continue;
                  
         BGGraphSearch bgSearch = new BGGraphSearch();
         bgSearch.calculateAllPaths(name, obj.getName(), graphMap);
         List<LinkedList<String>>paths = bgSearch.getPaths();
         if (paths != null && paths.isEmpty() == false) {
            paths_hm.put(obj.getName(), paths);
         }
      }
      if (linksDown_b) {
         this.setPathsDown(paths_hm);
      }
      else {
         this.setPathsUp(paths_hm);
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Calculate links to all nodes
   //----------------------------------------------------------------------------------------------
   
   public int findNodesInside(BGModel    model,
                              BGGraphMap graphMap,
                              String     what_s,
                              String     where_s,
                              int        what_min,
                              int        hops)   
   {
      for (BGObject obj : model.getObjects()) {
         if (obj == this) continue;
                  
         if (this.getName().equals("R3-12-47-3_meter_109")) {
            System.out.println("inside object: " + obj.getName());
            
         }
         BGGraphSearch bgSearch = new BGGraphSearch();
         int what_num = bgSearch.findNodesInside(name, obj.getName(), graphMap, what_s, where_s, what_min, hops);
         if (what_num > 0) {
            return what_num;
         }
      }
      return 0;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static DBTable getTableFromType(String objType_s)
   {
      return null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("unchecked")
   public static String attrToJson(String attrName,
                                   Object value,
                                   String units)   
   {
      StringBuffer json_sb = new StringBuffer();
      
      if (attrName.toCharArray()[0] == '_') {
         attrName = attrName.substring(1);
      }
      json_sb.append("\t\"" + attrName + "\" : ");
         
      //..... String array ......
         
      if (value instanceof String[]) {
         String[] val_sa = (String[])value;
         json_sb.append("[");  
            
         for (int i = 0; i < val_sa.length; i++) {
            if (i < val_sa.length - 1) {
               json_sb.append("\"" + val_sa[i] + "\",");
            }
            else {
               json_sb.append("\"" + val_sa[i] + "\"]");
            }
         }
         json_sb.append(",\n");
      }
      //..... Numeric array ......
         
      else if (value instanceof Double[]) {
         Double[] val_da = (Double[])value;
         json_sb.append("[");  
            
         for (int i = 0; i < val_da.length; i++) {
            if (i < val_da.length - 1) {
               json_sb.append(val_da[i] + ",");
            }
            else {
               json_sb.append(val_da[i] + "]");
            }
         }
         json_sb.append(",\n");
      }
      //..... Property type ......

      else if (value instanceof HashMap) {
         json_sb.append("{\n");
            
         HashMap<String,ArrayList<Object>> val_hm = (HashMap<String,ArrayList<Object>>)value;
         for (Map.Entry<String,ArrayList<Object>> entry : val_hm.entrySet()) {
            String elemName           = entry.getKey();
            ArrayList<Object> elemVal = entry.getValue(); 
            json_sb.append("\t\"" + elemName + "\" : ");
             
            if (elemVal.size() > 1) {              // it's an array
               json_sb.append("[");
            }
            for (Object val : elemVal) {
               if (val instanceof Double) {
                  json_sb.append(val.toString() + ",");
               }
               else {
                  json_sb.append("\"" + val.toString() + "\",");
               }
            }
            json_sb.deleteCharAt(json_sb.length() - 1);     // delete last ","
            json_sb.append("],\n");
         }
         json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
         json_sb.deleteCharAt(json_sb.length() - 1);     // delete last ","
         json_sb.append("\n\t},\n");
      }
      //..... Numeric data ......
         
      else if (value instanceof Double || value instanceof Integer) {
            
         if (units != null) {    // create sub-object
            json_sb.append("{\"value\" : " + value.toString());
            json_sb.append(", \"units\" : \"" + units + "\"}");
         }
         else {
            json_sb.append(value.toString());
         }
         json_sb.append(",\n");
      }
      //..... Complex number ......
      
      else if (value instanceof Object[]) {
         json_sb.append("{\"real\" : " + ((Object[])value)[0] + ", \"imag\" : " + ((Object[])value)[1]);        
         json_sb.append(", \"form\" : \"" + ((Object[])value)[2] + "\"},\n");        
      }
      //..... Date ......
      
      else if (value instanceof Date) {
         SimpleDateFormat jsonFormat = new SimpleDateFormat(DATE_FORMAT);
         json_sb.append("\"" + jsonFormat.format((Date)value) + "\",\n");
      }      
      //..... Just string ......
         
      else if (value instanceof String){
         String value_s = (String)value;
         value = value_s.replaceAll(":", "-").replaceAll("\"", "'");
         if (value_s.startsWith("\"")) {
            json_sb.append(value_s + ",\n");
         }
         else {
            json_sb.append("\"" + value_s + "\",\n");
         }
      }
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   // 
   //----------------------------------------------------------------------------------------------
   
   public boolean sortLinks()
   {
      
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public Integer getObjTypeId()
   {
      return this.getObjTypeId(this.getType());
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public Integer getObjTypeId(String typeName) 
   {
      Integer modelTypeIdx = BGUtils.getStringIdx(getModel().getFormat(), BGModel.MODEL_FILE_FORMATS_SA);
      int sectIdx = BGUtils.getStringIdx(typeName, getModel().getObjTypeNames());
         
      if (sectIdx == -1) {
         log.error("getObjTypeId. Cannot find object type id for " + typeName);
         return null;
      }
      return BGModel.OBJ_TYPE_ID_BASE[modelTypeIdx] + sectIdx;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public static Integer getObjTypeId(String format_s,   // model format
                                      String typeName)   // object type name
   {
      Integer modelTypeIdx = BGUtils.getStringIdx(format_s, BGModel.MODEL_FILE_FORMATS_SA);
      int sectIdx = BGUtils.getStringIdx(typeName, BGModel.getStaticObjTypeNames(format_s));
         
      if (sectIdx == -1) {
         //log.error("getObjTypeId. Cannot find object type id for " + typeName + "; Format: " + format_s);
         return null;
      }
      return BGModel.OBJ_TYPE_ID_BASE[modelTypeIdx] + sectIdx;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public String toJson() 
   {
      StringBuffer json_sb = new StringBuffer();

      //String objTypeId = type + ((id == null) ? "" : "_" + id.toString());
      
      //..... Start with object type and id (if any) as attributes ......
      
      json_sb.append("{\t\"object_type\" : \"" + type + "\",\n" );
      if (id != null) {
         json_sb.append("\t\"object_id\" : " + id.toString() + ",\n");
      }
      if (name != null) {
         json_sb.append("\t\"object_name\" : \"" + name + "\",\n");
      }
      //..... For each attribute ......
      
      int num = this.getAttrs().size();
      for (int i = 0; i < num; i++) {
         if (getAttr(i) == null) continue;
         if (i >= getAttrNames().length) continue;
         
         String attrJson_s = BGObject.attrToJson(getAttrNames()[i], this.valueOfType(getAttr(i).toString()), null);
         json_sb.append(attrJson_s);
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n},\n");
      return json_sb.toString();
   }
   //----------------------------------------------------------------------------------------------
   // Abstract methods
   //----------------------------------------------------------------------------------------------
   
   public abstract    DBTable getTable();
   public abstract    Object getAttr(int idx);
   public abstract    Object getAttr(String attrName);
   public abstract    List<Object> getAttrs();
   public abstract    BGModel getModel();
   public abstract    void setModel(BGModel model);
   public abstract    String[] getAttrNames();
}
//======================================= End of Class ============================================
