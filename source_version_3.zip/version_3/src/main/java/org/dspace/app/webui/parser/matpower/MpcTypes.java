package org.dspace.app.webui.parser.matpower;

import java.sql.Types;

public interface MpcTypes {

   //..... Comments ......
   
   public static final String   COMMENT_CONST_1       = "#";
   public static final String   COMMENT_CONST_2       = "%";
   
   public static final String[] COMMENT_CONST_SA      = {COMMENT_CONST_1, COMMENT_CONST_2}; 
   
   //............................... Short data descriptions ......................................
   
   public static final String[] VERSION_SA            = {"version"};
   public static final String[] BASE_MVA_SA           = {"baseMVA"};

   public static final String[] BUS_DATA_SA           = {"bus", "type", "Pd", "Qd", "Gs", "Bs", "area", "Vm", "Va", "base_KV", "zone", 
                                                         "V_max", "V_min"};
   
   public static final String[] GEN_DATA_SA           = {"bus", "Pg", "Qg", "Q_max", "Q_min", "Vg", "mBase", "status_g", "P_max", "P_min", "Pc1", 
                                                         "Pc2", "Qc1_min", "Qc1_max", "Qc2_min", "Qc2_max", "ramp_agc", "ramp_10", "ramp_30",  
                                                          "ramp_q", "apf"};
   
   public static final String FROM_NAME   = "_from";
   public static final String TO_NAME     = "_to";
   public static final String LENGTH_NAME = "length";    //!!!!****** LENGTH TEMPORARY ******

   public static final String[] BRANCH_DATA_SA        = {FROM_NAME, TO_NAME, "r", "x", "b", "rate_a", "rate_b", "rate_c", "ratio", "angle",
                                                         "status_b", "ang_min", "ang_max", "PF", "QF", "PT", "QT"};
   
   public static final String[] GEN_COST_SA           = {"model", "startup", "shutdown", "N"};

   public static final String[][] OBJECT_NAMES_SAA    = {VERSION_SA, BASE_MVA_SA, BUS_DATA_SA, GEN_DATA_SA, BRANCH_DATA_SA,
                                                         GEN_COST_SA};
  
   //............................... Full descriptions to show ....................................
   
   public static final String[] VERSION_SHOW_SA       = {"Format Version"};
   public static final String[] BASE_MVA_SHOW_SA      = {"Base MVA"};

   
   public static final String[] BUS_DATA_SHOW_SA      = {"Bus Number", "Bus Type", "Real Power Demand (MW)", "Reactive Power Demand (MVar)",
                                                         "Shunt Conductance (MW)", "Shunt Susceptance (MVAr)", "Area Number", 
                                                         "Voltage Magnitude (pu)", "voltage angle (deg.)", "Base Voltage (kV)", 
                                                         "Loss Zone", "Max.Voltage Magnitude (pu)", "Min.Voltage Magnitude (pu)"};
   
   public static final String[] GEN_DATA_SHOW_SA      = {"Bus Number", "Real Power Output (MW)", "Reactive Power Output (MVar)",
                                                         "Max.Reactive Output (MVAr)", "Min.Reactive Output (MVAr)",
                                                         "Voltage Magnitude Setpoint (pu)", "Total MVA", "Status", "Max.Real Output (MW)",
                                                         "Min.Real Output (MW)", "Lower Real Output (MW)", "Upper Real Output (MW)",
                                                         "Min.Reactive Output at Pc1 (MVAr)", "Max.Reactive Output at Pc1 (MVAr)",
                                                         "Minimum Reactive Output at Pc2 (MVAr)", "Max.Reactive Output at Pc2 (MVAr)",
                                                         "Ramp Rate for Load (MW/min)", "Ramp Rate Reserve 10 min.(MW)",
                                                         "Ramp Rate Reserve 30 min.(MW)", "Ramp Rate Reactive Power (MVAr/min)",
                                                         "Area Participation Factor"};
         
   public static final String[] BRANCH_DATA_SHOW_SA   = {"From Bus", "To Bus", "Resistance (pu)", "Reactance (pu)", "Charging Susceptance (pu)",
                                                         "MVA Rating A", "MVA Rating B", "MVA Rating C", "Ratio", "Angle (deg)",
                                                         "Init.Branch Status", "Min.Angle Difference (deg)", "Max.Angle Difference(deg)"};
    
   public static final String[] GEN_COST_SHOW_SA      = {"Model Type", "Startup Cost (USD)", "Shutdown Cost (USD)", "Number of Cost Points",
                                                         "Total Cost Parameters"};
   
   //.................................. Column Data Types .........................................
   
   public static final Integer[] VERSION_TYPES_A      = {Types.VARCHAR}; 
   public static final Integer[] BASE_MVA_TYPES_A     = {Types.DOUBLE};
   public static final Integer[] BUS_TYPES_A          = {Types.VARCHAR, Types.INTEGER, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE,
                                                         Types.INTEGER, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.INTEGER, Types.DOUBLE, 
                                                         Types.DOUBLE};
   
   public static final Integer[] GEN_TYPES_A          = {Types.VARCHAR, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE,
                                                         Types.DOUBLE, Types.INTEGER, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE,
                                                         Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE,Types.DOUBLE, Types.DOUBLE, 
                                                         Types.DOUBLE, Types.DOUBLE, Types.DOUBLE};
   
   public static final Integer[] BRANCH_TYPES_A       = {Types.VARCHAR, Types.VARCHAR, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE,
                                                         Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.INTEGER, Types.DOUBLE,
                                                         Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE, Types.DOUBLE};
   
   public static final Integer[] GEN_COST_TYPES_A     = {Types.INTEGER, Types.DOUBLE, Types.DOUBLE, Types.INTEGER, Types.VARCHAR}; 
   
   public static final Integer[][] TYPE_IDS_AA        = {VERSION_TYPES_A, BASE_MVA_TYPES_A, BUS_TYPES_A, GEN_TYPES_A, BRANCH_TYPES_A, 
                                                         GEN_COST_TYPES_A};
   
   //.................................... General arrays ..........................................
   
   public static final String[] OBJECT_TYPE_NAMES_SA    = {"mpc.version", "mpc.baseMVA", "mpc.bus", "mpc.gen", "mpc.branch", "mpc.gencost"};
   public static final String[] OBJECT_TYPE_SHOW_SA     = {"version", "base_MVA", "bus", "generator", "branch", "cost"};

   public static final String[][] OBJECT_TYPES_SAA      = {VERSION_SA, BASE_MVA_SA, BUS_DATA_SA, GEN_DATA_SA, BRANCH_DATA_SA, GEN_COST_SA};

   public static final String[][] OBJECT_TYPES_SHOW_SAA = {VERSION_SHOW_SA, BASE_MVA_SHOW_SA, BUS_DATA_SHOW_SA, GEN_DATA_SHOW_SA, 
                                                           BRANCH_DATA_SHOW_SA, GEN_COST_SHOW_SA};
    
   //...................................... Array indices .........................................
   
   public static final int TYPE_VERSION_IDX       = 0;  // index of the VERSION type
   public static final int TYPE_BASE_MVA_IDX      = 1;  // index of the BASE MVA type
   public static final int TYPE_BUS_IDX           = 2;  // index of the BUS type
   public static final int TYPE_GEN_IDX           = 3;  // index of the GEN type
   public static final int TYPE_BRANCH_IDX        = 4;  // index of the BRANCH type
   public static final int TYPE_COST_IDX          = 5;  // index of the GEN.COST type
   
   public static final int TYPE_COST_COEF_NUM_IDX = 3;  // for GEN.COST type: index of column with number of coeffs.
   
   // For generators: > 0 - machine in service; <= 0 - machine out of service
   // For branches  : = 0 - out of service;      = 1 - in service
       
   public static final String[] GEN_DATA_STATUS_SA    = {"Out of Service", "In Service"};
   public static final String[] COST_MODEL_TYPE_SA    = {"", "Linear", "Polynomial"};
   
}
