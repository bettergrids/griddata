package org.dspace.app.webui.forum;

import java.util.Date;
import java.util.UUID;

import org.dspace.app.webui.model.DBTableImage;

public class BGComment implements DBTableImage
{
   private static String tableName = "_comment";
   
   private long    oid;
   private UUID    item_uuid;
   private UUID    user_uuid;
   private String  title;
   private String  message;
   private Integer rating;         // rating >= 0 AND rating < 6
   private Date    created;
   private Date    last_modified;
   
   private String  userName;
   
   public BGComment() {}

   public BGComment(boolean init_b)
   {
      if (init_b) {
         title         = "";
         message       = "";
         rating        = 0;
         created       = new Date();
         last_modified = new Date();
      }
   }
   
   public static String receiveTableName() {
      return tableName;
   }

   public long getOid() {
      return oid;
   }

   public void setOid(long oid) {
      this.oid = oid;
   }

   public UUID getItem_uuid() {
      return item_uuid;
   }

   public void setItem_uuid(UUID item_uuid) {
      this.item_uuid = item_uuid;
   }

   public UUID getUser_uuid() {
      return user_uuid;
   }

   public void setUser_uuid(UUID user_uuid) {
      this.user_uuid = user_uuid;
   }

   public String getTitle() {
      return title;
   }

   public void setTitle(String title) {
      this.title = title;
   }

   public String getMessage() {
      return message;
   }

   public void setMessage(String message) {
      this.message = message;
   }

   public Integer getRating() {
      return rating;
   }

   public void setRating(Integer rating) {
      this.rating = rating;
   }

   public Date getCreated() {
      return created;
   }

   public void setCreated(Date created) {
      this.created = created;
   }

   public Date getLast_modified() {
      return last_modified;
   }

   public void setLast_modified(Date last_modified) {
      this.last_modified = last_modified;
   };
   //----------------------------------------------------------------------------------------------
   //  Not bean related functions
   //----------------------------------------------------------------------------------------------
   public String receiveUserName()
   {
      return userName;
   }
   
   public void assignUserName(String userName)
   {
      this.userName = userName; 
   }
}
