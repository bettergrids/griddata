package org.dspace.app.webui.model;

import java.sql.Connection;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.exception.ExceptionUtils;
//import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.nlidb.*;
import org.dspace.app.webui.parser.BGModel;

public class DBFunctions implements DBTypes, NLLexicon
{
   private static final Logger log = Logger.getLogger(DBFunctions.class);
   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getModelCond(String[] nodeTypes,        // types of node in condition part
                                      String[] ops,              // operations: <,>,=, etc.
                                      int[]    condValues,       // condition values (count of nodetypes)    
                                      String[] logics,           // logical condition: AND, OR 
                                      String   modelId,          // search all models if null
                                      String   modelType,        // search all models types if null
                                      String   modelIdName_s,    // 'modeluid'
                                      String   modelTypeName_s,  // 'modeltype'
                                      String[] exclusions,       // columns which should not be viewed
                                      String   repoTableName_s,  // '_model'
                                      String   nodetypeName_s,   // 'nodetype'
                                      String   tableName_s,      // '_gridlab'
                                      String   dbName_s)         // 'graph'
   {
      DBConnection dbConn = new DBConnection(dbName_s);
      Connection conn     = dbConn.getConnection();              // get DB connection
      
      //..... Processing of conditions ......
      
      int    i;
      String attr_s  = "";
      String sel_s   = "";
      String where_s = ""; 
      String cond_s  = "";
      String ti;
      DBEntry entry  = null;      
      
      if (nodeTypes != null && nodeTypes.length > 0) {
         
         //..... Verification ......
         
         if (ops == null || nodeTypes == null || logics == null ||
               nodeTypes.length != ops.length        || 
               nodeTypes.length != condValues.length ||
               nodeTypes.length != logics.length + 1) {
            log.error("Error in input data. Arrays of attribute names, operations and values are not equal.");
            return null;
         }
         //..... Nuild query ......
         
         for (i = 0; i < nodeTypes.length; i++) {
            ti = "t" + i;
            
            attr_s  += ", " + ti + "." + nodetypeName_s + ", " + ti + ".cnt " + ti + "cnt";
            sel_s   += ", (SELECT " + modelIdName_s + "," + nodetypeName_s + ", count(*) cnt FROM " + 
                       tableName_s + " WHERE " + nodetypeName_s + "='" + nodeTypes[i] +"' GROUP BY " +
                       modelIdName_s +"," + nodetypeName_s + ") " + ti;
            where_s += " AND tm." + modelIdName_s + "=" + ti + "." + modelIdName_s;
            cond_s  += " " + logics[0] + " " + ti + "cnt" + ops[i] + condValues[i];
         }
         String sql_s = "SELECT * FROM (SELECT tm.*" + attr_s + " FROM " + repoTableName_s + " tm" +
                        sel_s + " WHERE 1 = 1" + where_s + ") ta WHERE 1 = 1" + cond_s;
         
         if (modelId != null) {
            sql_s += " AND " + modelIdName_s + "='" + modelId + "'";
         }
         if (modelType != null) {
            sql_s += " AND " + modelTypeName_s + "='" + modelType + "'";
         }                       
         DBExecute exec  = new DBExecute();  
         entry           = exec.execQuery(conn, sql_s, exclusions);
      
         entry.setCompactTable();      // remove columns with all null values
         entry.setNumericColumns();    // set column types numeric/integer, based on data
      }
      dbConn.close();
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String buildSQL(String[]  nodeTypes,         // types of node in condition part
                                 String[]  ops,               // operations: <,>,=, etc.
                                 String[]  condValues,        // condition values (count of nodetypes)    
                                 String[]  logics,            // logical condition: AND, OR 
                                 String    modelUid,          // modeluid value (search all models if null)
                                 String    modelFormat,       // model format (search all models formats if null)
                                 String    modelUidName_s,    // 'modeluid'
                                 String    modelFormatName_s, // 'format'
                                 String[]  exclusions,        // columns which should not be viewed
                                 String    repoTableName_s,   // '_modelinfo'
                                 String    nodetypeName_s,    // 'nodetype'
                                 String    tableName_s,       // '_gridlab'
                                 String    dbName_s)          // 'graph'
   {
      //..... Processing of conditions ......
   
      int    i;
      String attr_s  = "";
      String sel_s   = "";
      String where_s = ""; 
      String cond_s  = "";
      String ti;
      String  sql_s  = "";
   
      //..... Get nodetypes for model(s) ...... 
      
      if (nodeTypes == null || nodeTypes.length == 0) {
         if (modelUid != null) {        
            sql_s = "SELECT " + nodetypeName_s + ", count(*) cnt FROM " + tableName_s +
                    " WHERE " + modelUidName_s + "='" + modelUid + "'" + 
                    ((modelFormat == null) ? "" : " AND " + modelFormatName_s + "='" + modelFormat + "'") +
                    " GROUP BY " + nodetypeName_s + " ORDER BY cnt DESC";
         }
         else {
            sql_s = "SELECT * FROM " + repoTableName_s + 
                    ((modelFormat == null) ? "" : " WHERE " + modelFormatName_s + "='" + modelFormat + "'") +
                    " ORDER BY " + modelUidName_s;
         }
         return sql_s;
      }
      //..... No conditions (count all attributes)......
       
      Inflector inf = Inflector.getInstance();
      
      if (ops        == null) ops        = new String[nodeTypes.length];
      if (condValues == null) condValues = new String[nodeTypes.length];
      if (logics     == null) logics     = new String[nodeTypes.length];
      
      for (i = 0; i < nodeTypes.length; i++) {
         if (ops[i] == null)        ops[i]        = ">";
         if (condValues[i] == null) condValues[i] = "0";
         if (logics[i] == null)     logics[i]     = "AND";
      }
      //..... Build a query ......
      
      for (i = 0; i < nodeTypes.length; i++) {
         ti = "t" + i;
         String nodetype_val   = nodeTypes[i].replace(" ", "_");
         String nodeType_Label = inf.pluralize(nodetype_val);
         
         attr_s  += ", " + ti + "." + nodetypeName_s + ", " + ti + ".cnt " + nodeType_Label;
         sel_s   += ", (SELECT " + modelUidName_s + "," + nodetypeName_s + ", count(*) cnt FROM " + 
                    tableName_s + " WHERE " + nodetypeName_s + "='" + nodetype_val +"' GROUP BY " +
                    modelUidName_s +"," + nodetypeName_s + ") " + ti;
         where_s += " AND tm." + modelUidName_s + "=" + ti + "." + modelUidName_s;
         cond_s  += " " + logics[0] + " " + nodeType_Label + ops[i] + condValues[i];
      }
      sql_s = "SELECT * FROM (SELECT tm.*" + attr_s + " FROM " + repoTableName_s + " tm" +
              sel_s + " WHERE 1 = 1" + where_s + ") ta WHERE 1 = 1" + cond_s;
      
      if (modelUid != null) {
         sql_s += " AND " + modelUidName_s + "='" + modelUid + "'";
      }
      if (modelFormat != null) {
         sql_s += " AND " + modelFormatName_s + "='" + modelFormat + "'";
      }
      return sql_s;
   }
   //----------------------------------------------------------------------------------------------
   
   public static String buildSQL(String[]  nodeTypes,        // types of node in condition part
                                 String[]  ops,              // operations: <,>,=, etc.
                                 String[]  condValues,       // condition values (count of nodetypes)    
                                 String[]  logics,           // logical condition: AND, OR
                                 String    modelId,          // modelID (all models if null)
                                 String    modelType)        // search all models types if null
   {
      return buildSQL(nodeTypes, ops, condValues, logics, modelId, modelType,
            DBTypes.modelId, "modeltype", modelExclusions, "_model", "nodetype", "_gridlab", "graph");
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getModelCond(String[] nodeTypes,        // types of node in condition part
                                      String[] ops,              // operations: <,>,=, etc.
                                      int[]    condValues,       // condition values (count of nodetypes)    
                                      String[] logics)           // logical condition: AND, OR
   {
      return getModelCond(nodeTypes, ops, condValues, logics, null, null,
                          DBTypes.modelId, "modeltype", modelExclusions, "_model", "nodetype", 
                          "_gridlab", "graph");
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getRepoInfo(String   modelTypeCol_s,    // 'modeltype'
                                     String   tableNameCol_s,    // 'tablename'
                                     String[] exclusions,        // columns which should not be viewed
                                     String   repoTableName_s,   // '_model'
                                     String   dbName_s)          // 'graph'
   {
      DBConnection dbConn = new DBConnection(dbName_s);
      Connection conn     = dbConn.getConnection();              // get DB connection
      
      String sql_s = "SELECT * FROM getRepositoryInfo('"+ repoTableName_s + "','" + tableNameCol_s + "','" + modelTypeCol_s + "')";
           
      log.info("DBFunctions.getRepoInfo. SQL = " + sql_s); 
      
      DBExecute exec  = new DBExecute();  
      DBEntry   entry = exec.execQuery(conn, sql_s, exclusions);
      
      if (entry != null) {
         entry.setCompactTable();      // remove columns with all null values
         entry.setNumericColumns();    // set column types numeric/integer, based on data
      }
      else {
         log.error("getRepoInfo. ERROR: Function exec.execQuery returned null");
      }
      dbConn.close();
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getRepoInfo()
   {
      return getRepoInfo("format", "tablename", null, "_modelinfo", "graph");
      //return getRepoInfo("modeltype", "tablename", null, "_model2", "graph");
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getModelsByType(String   modelIdName_s,     // 'modeluid'
                                         String[] exclusions,        // columns which should not be viewed
                                         String   repoTableName_s,   // '_modelinfo'
                                         String   modelType_s,       // 'GRIDLAB D', 'PTI PSS'
                                         String   dbName_s)          // 'graph'
   {
      DBConnection dbConn = new DBConnection(dbName_s);
      Connection conn     = dbConn.getConnection();                  // get DB connection
      
      String tableName_s = BGModel.getDbTableName(modelType_s);
      log.debug("DBFunctions.getModelsByType. Model Type = " + modelType_s + "; Table Name = " + tableName_s); 
      
      //..... Query ...... 
      
      String sql_s = "SELECT t1.modelname, t1.modeluid, t1.description, t2.cnt objectcnt FROM " + 
                     repoTableName_s + " t1, (SELECT " + modelIdName_s + ", count(*) cnt FROM " + tableName_s + 
                     " GROUP BY " +  modelIdName_s + ") t2 WHERE t1." +
                     modelIdName_s + " = t2." + modelIdName_s;
      
      log.info("DBFunctions.getModelsByType. SQL = " + sql_s); 
      
      DBExecute exec  = new DBExecute();  
      DBEntry   entry = exec.execQuery(conn, sql_s, exclusions);
      
      if (entry != null) {
         //entry.setCompactTable();      // remove columns with all null values
         entry.setNumericColumns();    // set column types numeric/integer, based on data
      }
      dbConn.close();
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   // 
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getModelsByType(String modelType_s)   // 'PTI PSS', e.g. 
   {
      //..... Get data from Graph DB ......
      
      DBEntry graphEntry = getModelsByType(DBTypes.modelId, null, "_modelinfo", modelType_s, "graph");
      
      //..... Collect UUIDs of all models ......
      
      List<Object> modelUid_oal = graphEntry.getColumnValues(DBTypes.modelId);      
      List<String> modelUid_sal = modelUid_oal.stream().map(Object::toString).collect(Collectors.toList());
            
      //..... Get data from DSpace DB ......
            
      DBEntry dspaceEntry = getDSpaceItemInfo(modelUid_sal);
      
      //..... Merge two entries on model UUID ......
      
      dspaceEntry.extendEntry(graphEntry, DBTypes.modelId);
      
      try {            
         int sortColumnIdx = dspaceEntry.getTable().getColumnNum() - 1;
         dspaceEntry.setColIdxToSort(sortColumnIdx);
         dspaceEntry.sortRows();
      }
      catch(Exception e) {
         log.error("getModelsBySearch. Cannot sort entry by column Idx = 9. Stack Trace: " + 
                   ExceptionUtils.getStackTrace(e));
      }
      // These lines are not needed because we hide required columns in JSP
      //String[] exclusions = {DBTypes.modelId};
      //dspaceEntry.applyExclusions(exclusions);      // remove column modeluid from the entry
      
      dspaceEntry.setCompactTable();
      
      return dspaceEntry;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getModelList(String[] colname_sa,     // names of columns
                                      String   logic_s,        // logics: AND / OR
                                      String[] oper_sa,        // relation: <, >, <=, >=, =, !=
                                      String[] val_sa,         // set of values
                                      String   modelIdName_s,  // 'modelid'
                                      String   nodeName_s,     // 'name'
                                      String   tableName_s,    // '_gridlab'
                                      String   dbName_s)       // 'graph'
   {
      DBConnection dbConn = new DBConnection(dbName_s);
      Connection conn     = dbConn.getConnection();            // get DB connection
   
      String sql_s = "SELECT " + modelIdName_s + ", count(*) cnt FROM " + tableName_s + " WHERE ";
   
      for (int i = 0; i < colname_sa.length; i++) {
         sql_s += colname_sa[i] + oper_sa[i] + val_sa[i] + ((i == colname_sa.length - 1) ? "" : " AND "); 
      }
      sql_s += " ORDER BY " + nodeName_s;
   
      DBExecute exec  = new DBExecute();  
      DBEntry   entry = exec.execQuery(conn, sql_s, null);
   
      entry.setNumericColumns();    // set column types numeric/integer, based on data
   
      dbConn.close();
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodeTypeList(String modelId_s,
                                         String modelIdName_s,
                                         String typeName_s,
                                         String tableName_s,
                                         String dbName_s)
   {
      DBConnection dbConn = new DBConnection(dbName_s);
      Connection conn     = dbConn.getConnection();            // get DB connection
   
      //..... Prepare SQL ......
   
      String sql_s = "SELECT " + typeName_s + ", count(*) cnt FROM " + tableName_s +
                     ((modelId_s == null) ? "" : " WHERE " + modelIdName_s + "='" + modelId_s + "'") +
                     " GROUP BY " + typeName_s + " ORDER BY cnt DESC";
   
      log.info("DBFunctions.getNodeTypeList. SQL = " + sql_s);
      
      DBExecute exec = new DBExecute();
      DBEntry entry = exec.execQuery(conn, sql_s, null);
      
      if (entry != null) {
         entry.setNumericColumns();    // set column types numeric/integer, based on data
      }
      dbConn.close();
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodeTypeList(String modelId_s, String tableName_s)
   {
      return getNodeTypeList(modelId_s, DBTypes.modelId, "nodetype", tableName_s, "graph");
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodesByType(String   modelId_s,
                                        String   type_s,
                                        String[] exclusions, 
                                        String   nodeName_s,
                                        String   modelIdName_s,
                                        String   typeName_s,
                                        String   tableName_s,
                                        String   dbName_s)
   { 
      DBConnection dbConn = new DBConnection(dbName_s);
      Connection conn     = dbConn.getConnection();            // get DB connection
      
      //..... Prepare SQL ......
      
      String sql_s = "SELECT * FROM " + tableName_s + " WHERE " +
                     ((modelId_s == null) ? "" :  modelIdName_s + "='" + modelId_s + "' AND ") +
                     typeName_s + "='" + type_s + "' ORDER BY " + nodeName_s;
      
      DBExecute exec = new DBExecute();
      
      DBEntry entry = exec.execQuery(conn, sql_s, exclusions);
      
      entry.setCompactTable();      // remove columns with all null values
      entry.setNumericColumns();    // set column types numeric/integer, based on data
      
      dbConn.close();
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodesByType(String   tableName,
                                        String   modelId_s,
                                        String   type_s,
                                        String[] exclusions)
   {
      return getNodesByType(modelId_s, type_s, exclusions, DBTypes.nodeName, DBTypes.modelId, "nodetype", tableName, "graph");
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodesByType(String   tableName,
                                        String   modelId_s,
                                        String   type_s)
   {
      return getNodesByType(modelId_s, type_s, calcColumns, DBTypes.nodeName, DBTypes.modelId, "nodetype", tableName, "graph");
   }
   //----------------------------------------------------------------------------------------------
   // Get list of nodes based on NAME (and/or) TYPE
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodes(String   modelUidVal_s,   // model UUID value 
                                  String   nodeTypeVal_s,   // node type value, like 'bus'
                                  String   nodeNameVal_s,   // node value, like 'bus_24'
                                  String[] exclusions, 
                                  String   nodeNameCol_s,   // node column name, like 'bus'
                                  String   modelUidCol_s,   // name of model UUID table: 'modeluid'
                                  String   nodeTypeCol_s,   // node type column name, like 'nodetype'
                                  String   tableName_s,     // model table name, like '_psse'
                                  String   dbName_s,        // Db instance name 'graph'
                                  Boolean  desc_b,          // order: DESC/ASC
                                  Integer  offset,          // SQL offset (skip first records) 
                                  Integer  limit)           // SQL limit show number of records
   {             
      DBConnection dbConn = new DBConnection(dbName_s);
      Connection conn     = dbConn.getConnection();            // get DB connection

      //..... Prepare SQL ......

      String sql_s = "SELECT * FROM " + tableName_s + " WHERE " +
                     ((modelUidVal_s == null || modelUidCol_s == null) ? "1=1" : modelUidCol_s + "='" + modelUidVal_s + "'") + 
                     " AND " +
                     ((nodeTypeVal_s == null || nodeTypeCol_s == null) ? "1=1" : nodeTypeCol_s + "='" + nodeTypeVal_s + "'") + 
                     " AND " + 
                     ((nodeNameVal_s == null || nodeNameCol_s == null) ? "1=1" : nodeNameCol_s + "='" + nodeNameVal_s + "'") +
                     ((nodeNameCol_s == null) ? ""    : (" ORDER BY " + nodeNameCol_s) +
                                                        ((desc_b == null || desc_b == false) ? "" : " DESC")) +                     
                     ((offset == null)        ? ""    : (" OFFSET " + offset))          +
                     ((limit  == null)        ? ""    : (" LIMIT " + limit));

      log.info("DBFunctions.getNodes. SQL = " + sql_s);
      
      DBExecute exec = new DBExecute();
      DBEntry entry  = exec.execQuery(conn, sql_s, exclusions);

      if (entry != null) {
         entry.setCompactTable();         // remove columns with all null values
         entry.setNumericColumns();       // set column types numeric/integer, based on data
      }
      dbConn.close();
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodes(String modelUidVal_s, 
                                  String nodeTypeVal_s,
                                  String nodeNameVal_s,
                                  String nodeNameCol_s,
                                  String tableName_s)
   {
      return getNodes(modelUidVal_s, nodeTypeVal_s, nodeNameVal_s, calcColumns, nodeNameCol_s, 
                      DBTypes.modelId, DBTypes.nodeType, tableName_s, DBProvider.GraphName, null, null, null);
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodes(String  modelUidVal_s, 
                                  String  nodeTypeVal_s,
                                  String  nodeNameVal_s,
                                  String  nodeNameCol_s,
                                  String  tableName_s,
                                  Integer offset,           // SQL offset (skip first records) 
                                  Integer limit)            // SQL limit show number of records
   {
      return getNodes(modelUidVal_s, nodeTypeVal_s, nodeNameVal_s, calcColumns, nodeNameCol_s, 
                      DBTypes.modelId, DBTypes.nodeType, tableName_s, DBProvider.GraphName, 
                      null, offset, limit);
   }
   //----------------------------------------------------------------------------------------------
   // Implemented query : 
   //----------------------------------------------------------------------------------------------
   // with t10 
   // as (
   // select bus,
   //        modeluid,
   //        unnest(linkup) val,
   //        unnest(hopsup) hops,
   //        unnest(distup) dst
   //   from _psse
   // WHERE modeluid='a2a3e826-d786-4f39-9976-ad58de23e18a'
   //    AND bus='bus_29'
   //  ORDER BY hops),
   //-----------------------------------------------------
   // t1 as (
   // select row_number() over() rowid,
   //        t10.*
   //   from t10), 
   //-----------------------------------------------------
   // t20 as (
   // select unnest(linkdown) val,
   //        unnest(hopsdown) hops,
   //        unnest(distdown) dst
   //   from _psse
   // WHERE modeluid='a2a3e826-d786-4f39-9976-ad58de23e18a'
   //    AND bus='bus_29'
   //  ORDER BY hops),
   //-----------------------------------------------------
   // t2 as (
   // select row_number() over() rowid,
   //        t20.*
   //   from t20)
   //-----------------------------------------------------
   // select t1.rowid, bus, modeluid, t1.val, t1.hops, t1.dst, 
   //        t2.val, t2.hops, t2.dst
   //   FROM t1
   //   FULL JOIN t2 ON t1.rowid = t2.rowid
   //  ORDER BY t1.rowid;
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodeStatistics(String   modelId_s,       // model UUID as a string
                                           String   node_s,          // node value, like: 'bus_7'
                                           String   nodeName_s,      // column name, like: 'node' or 'bus'
                                           String   tableName_s,     // table name, like: _psse, _cdf, etc.
                                           String[] commonNames_sa,  // common output column names
                                           String[] colDown_sa,      // columns: 'linkdown', 'hopsdown', 'distdown'
                                           String[] colUp_sa,        // columns: 'linkup', 'hopsup', 'distup'
                                           String[] orderBy_sa,      // 2 elements array" down and up for "order by"
                                           String   typeName_s,      // column name: 'nodetype'
                                           String   modelIdName_s,   // column name: 'modeluid'
                                           String   dbName_s)        // 'graph'
   {
      DBConnection dbConn = new DBConnection(dbName_s);
      Connection conn     = dbConn.getConnection();         // get DB connection
      
      if (colDown_sa == null || colDown_sa.length == 0 ||
          colUp_sa   == null || colUp_sa.length   == 0) {
         log.error("getNodeStatistics. Arrays of column names for Up/Down should not be NULL or empty");
         return null;
      }      
      //..... Prepare SQL ......
      
      String sql_s = "WITH t10 AS (SELECT ";
           
      if (commonNames_sa != null) {
         for (int i = 0; i < commonNames_sa.length; i++) {     // common columns
            sql_s += commonNames_sa[i] + ",";
         }
      }
      //..... DOWN Array's columns ......
      
      for (int i = 0; i < colDown_sa.length; i++) {
         sql_s += " UNNEST(" + colDown_sa[i] + ") " + colDown_sa[i] + ",";
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(","));   // remove last comma
      
      sql_s += " FROM " + tableName_s +
               " WHERE " + modelIdName_s + "='" + modelId_s + "' AND " + nodeName_s +
               "='" + node_s + "' ORDER BY " + orderBy_sa[0] + "),";
      sql_s += "t11 AS (SELECT row_number() over() rowid, * FROM t10),";
      sql_s += "t1 AS (SELECT *, max(rowid) over() lastid FROM t11),";
      
      //..... UP Array's columns ......
      
      sql_s += "t20 AS (SELECT ";
      
      for (int i = 0; i < colUp_sa.length; i++) {
         sql_s += " UNNEST(" + colUp_sa[i] + ") " + colUp_sa[i] + ",";
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(","));   // remove last comma
      
      sql_s += " FROM " + tableName_s +
            " WHERE " + modelIdName_s + "='" + modelId_s + "' AND " + nodeName_s +
            "='" + node_s + "' ORDER BY " + orderBy_sa[1] + "),";
      sql_s += "t21 AS (SELECT row_number() over() rowid, * FROM t20),";
      sql_s += "t2 AS (SELECT *, max(rowid) over() lastid FROM t21)";

      //..... Final select ......
      
      sql_s += " SELECT ";

      if (commonNames_sa != null) {
         for (int i = 0; i < commonNames_sa.length; i++) {  // common columns
            sql_s += "t1." + commonNames_sa[i] + ",";
         }
      }
      for (int i = 0; i < colDown_sa.length; i++) {
         sql_s += " t1." + colDown_sa[i] + ",";
      }
      for (int i = 0; i < colUp_sa.length; i++) {
         sql_s += " t2." + colUp_sa[i] + ",";
      }
      sql_s = sql_s.substring(0, sql_s.lastIndexOf(","));   // remove last comma

      sql_s += " FROM t1 FULL JOIN t2 ON t1.rowid = t2.rowid ORDER BY";
      sql_s += " CASE WHEN t1.lastid > t2.lastid THEN t1.rowid ELSE t2.rowid END";
            
      //log.info("SQL: " + sql_s);
      
      //..... Execute query ......
      
      DBExecute exec = new DBExecute();     
      DBEntry entry = exec.execQuery(conn, sql_s, null);
      
      if (entry != null) {
         entry.setNumericColumns();    // set column types numeric/integer, based on data
      }
      dbConn.close();
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getNodeStatistics(String   modelId_s,    // model UUID as a string
                                           String   node_s,       // node value, like: 'bus_7'
                                           String   nodeName_s,   // column name, like: 'node' or 'bus'
                                           String   tableName_s)  // table name, like: _psse, _cdf, etc.)
   {
      int num = BGModel.LINKS_COLUMN_NAMES.length / 2;
      
      String[] colDown_sa = Arrays.copyOfRange(BGModel.LINKS_COLUMN_NAMES, 0, num);
      String[] colUp_sa   = Arrays.copyOfRange(BGModel.LINKS_COLUMN_NAMES, num, BGModel.LINKS_COLUMN_NAMES.length);
      String[] orderBy_sa = new String[]{BGModel.HOPS_DOWN, BGModel.HOPS_UP};
      
      return getNodeStatistics(modelId_s, node_s, nodeName_s, tableName_s, null, 
                               colDown_sa, colUp_sa, orderBy_sa, nodeType, modelId, DBProvider.GraphDB);
            
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   /*
   public static DBEntry execQuery(String   sql_s,          //
                                   String[] exclusions,
                                   String   dbName_s)       // 'graph'
   {
      DBConnection dbConn = new DBConnection(dbName_s);
      Connection conn     = dbConn.getConnection();         // get DB connection
 
      DBExecute exec  = new DBExecute(); 
      
      NLTranslator nt = new NLTranslator();
      sql_s = nt.sqlBuilder(sql_s);
      
      DBEntry entry = null;
      if (exclusions != null) {
         entry = exec.execQuery(conn, sql_s, exclusions);
      }
      else {
         if (sql_s.contains(BGModel.INFO_TABLE_NAME)) {
            entry =  exec.execQuery(conn, sql_s, queryExclusions);
         }
         else {
            entry =  exec.execQuery(conn, sql_s, modelExclusions);
         }
      }
      if (entry != null) {
         entry.setCompactTable();      // remove columns with all null values
         entry.setNumericColumns();    // set column types numeric/integer, based on data
      }
      dbConn.close();
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry execQuery(String sql_s) 
   {
      return execQuery(sql_s, null, DBProvider.GraphDB);
   }
   */
   //----------------------------------------------------------------------------------------------
   
   public static int execSQL(String sql_s, String dbName_s)
   {   
      //..... Get DB connection ......
   
      DBConnection dbConn = new DBConnection(dbName_s);
      Connection conn     = dbConn.getConnection(); 

      DBExecute exec  = new DBExecute();
      int ret = exec.execSQL(conn,sql_s);
      
      dbConn.close();
      return ret;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry execSelect(String sql_s, String dbName_s)
   {
      //..... Get DB connection ......
      
      DBConnection dbConn = new DBConnection(dbName_s);
      Connection conn     = dbConn.getConnection(); 

      DBExecute exec  = new DBExecute();
      DBEntry   entry = exec.execQuery(conn, sql_s, null);

      dbConn.close();
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   // Get item name and collection name from bitstream (model) UUID
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getDSpaceItemInfo(List<String> modelUid_al)
   {
      //..... SQL request ......

      String modelUids_s = String.join("','", modelUid_al);   // convert list to CSV string
      if (modelUids_s == null || modelUids_s.isEmpty()) {
         return null;
      }
      //..... Get DSpace DB connection ......
      
      DBConnection dbConn = new DBConnection(DBProvider.DSpaceDB);
      Connection conn     = dbConn.getConnection();
      
      String sql_s = "WITH item_info AS " + 
                     "(SELECT c2i.collection_id, i2b.item_id, b2b.bitstream_id," + 
                     "h1.handle collection_handle, h2.handle item_handle " + 
                     "FROM bundle2bitstream b2b, item2bundle i2b, collection2item c2i," + 
                     "handle h1, handle h2 " + 
                     "WHERE h1.resource_id = c2i.collection_id " + 
                     "AND h2.resource_id = c2i.item_id " + 
                     "AND c2i.item_id    = i2b.item_id " + 
                     "AND i2b.bundle_id  = b2b.bundle_id " + 
                     "AND b2b.bitstream_id IN ('" + modelUids_s + "')) " +
                     "SELECT it.bitstream_id modeluid, m1.text_value collection_name, m2.text_value item_name," + 
                     "it.collection_id collection_uid, it.item_id item_uid," + 
                     "it.collection_handle, it.item_handle " +
                     "FROM metadatavalue m1, metadatavalue m2, item_info it " +
                     "WHERE m1.dspace_object_id  = it.collection_id " +
                     "AND m2.dspace_object_id  = it.item_id " +
                     "AND m1.metadata_field_id = 70 " +
                     "AND m2.metadata_field_id = 70";     
      
      DBExecute exec = new DBExecute();
      DBEntry entry  = exec.execQuery(conn, sql_s, null); 
      
      dbConn.close();
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   // Check if bitstream belong only one bundle
   //----------------------------------------------------------------------------------------------
   
   public static boolean isBitstreamInMultBundles(UUID bt_uid)
   {
      if (bt_uid == null) return false;
      
      //..... Get DSpace DB connection ......
      
      DBConnection dbConn = new DBConnection(DBProvider.DSpaceDB);
      Connection conn     = dbConn.getConnection();
      
      String sql_s = "SELECT count(*) cnt FROM bundle2bitstream WHERE bitstream_id ='" + 
                     bt_uid.toString() + "'"; 
      
      DBExecute exec = new DBExecute();
      DBEntry entry  = exec.execQuery(conn, sql_s, null);
      Long num       = (Long)entry.getRow(0).get(0);

      dbConn.close();      
      if (num > 1) return true;
      return false;
   }
   //----------------------------------------------------------------------------------------------
   // Get model name and type, based on bitstream UID 
   //----------------------------------------------------------------------------------------------
   
   public static String[] getModelNameType(String bsUid_s)
   {
      String[] res_sa = new String[2];
      if (bsUid_s == null) return res_sa; 
      
      //..... Get DSpace DB connection ......
      
      DBConnection dbConn = new DBConnection(DBProvider.DSpaceDB);
      Connection conn     = dbConn.getConnection();
      
      String sql_s = "select mv.text_value, bf.short_description" + 
                     " from metadatavalue mv, bitstreamformatregistry bf, bitstream b" + 
                     " where b.bitstream_format_id = bf.bitstream_format_id" + 
                     " and b.uuid = mv.dspace_object_id" + 
                     " and b.deleted = 'f'" + 
                     " and mv.metadata_field_id = 70" + 
                     " and b.uuid ='" + bsUid_s + "'"; 
      
      DBExecute exec  = new DBExecute();
      DBEntry entry   = exec.execQuery(conn, sql_s, null);
      if (entry == null) {
         log.error("getModelNameType. Query result: null");
      }
      else {
         res_sa[0] = (String)entry.getRow(0).get(0);
         res_sa[1] = (String)entry.getRow(0).get(1);
      }
      dbConn.close();      
      return res_sa;
   }
}
//======================================= End of Class ============================================