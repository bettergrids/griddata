package org.dspace.app.webui.parser.grg;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;

public class GrgObject extends BGObject {

   private static final Logger log = Logger.getLogger(GrgObject.class);
   
   //..... Constants .....
   
   public static final String PARENT_CONST = "parent";
   
   //..... Members ......
   
   private GrgModel model;

   LinkedHashMap<String, GrgAttr> attr_hm = new LinkedHashMap<String, GrgAttr>();
   ArrayList<String> attrNames = null; 
   
   //..... Methods ......
   
   @Override
   public BGModel getModel() {
      return model;
   }
   @Override
   public void setModel(BGModel model) {
      this.model = (GrgModel)model;
   }
   public void setModel(GrgModel model) {
      this.model = model;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean addAttr(GrgAttr attr)
   {
      if (attr.getName() != null) {
         attr_hm.put(attr.getName(), attr);
         return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean addAttr(String name_s,
                          String value_s)
   {
      if (name_s != null) {
         GrgAttr attr = new GrgAttr(name_s, value_s);
         attr_hm.put(name_s, attr);
         return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   
   public GrgAttr getAttrObj(String name)
   {
      return attr_hm.get(name);
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public Object getAttr(String name)
   {
      GrgAttr attr = attr_hm.get(name);
      if (attr != null) {
         return attr.getObjValue();
      }
      return null;
   }
   //----------------------------------------------------------------------------------------------

   LinkedHashMap<String, GrgAttr> getAttrsHM() 
   {
      return attr_hm;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public void setAttrNames()
   {
      attrNames = new ArrayList<String>();

      //..... A few columns to display first ......
      
      attrNames.add(GrgParser.NAME_CONST);
      attrNames.add(GrgParser.ATTR_ID_CONST);
//      attrNames.add(GlmParser.FROM_CONST);
//      attrNames.add(GlmParser.TO_CONST);
      
      //..... Add all object attribute names ......
      
      for (String attrName : attr_hm.keySet()) {
         attrNames.add(attrName);
      }
   }
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String[] getAttrNames()
   {
      if (attrNames == null) {
        setAttrNames();
      }
      return attrNames.toArray(new String[attrNames.size()]);
   }
   //----------------------------------------------------------------------------------------------
   // Convert ClmObject to JSON format string
   //----------------------------------------------------------------------------------------------
   
   @Override
   public String toJson()
   {
      StringBuffer json_sb = new StringBuffer();

      //String objTypeId = type + ((id == null) ? "" : "_" + id.toString());
      
      //..... Start with object type, id and name (if any) as attributes ......
      
      json_sb.append("{\t\"object_type\" : \"" + type + "\",\n" );
      if (id != null) {
         json_sb.append("\t\"object_id\" : " + id.toString() + ",\n");
      }
      if (name != null) {
         json_sb.append("\t\"object_name\" : \"" + name + "\",\n");
      }
      //..... For each attribute ......
      
      for (GrgAttr attr : attr_hm.values()) {
         json_sb.append(attr.toJson());
      }
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
      json_sb.deleteCharAt(json_sb.length() - 1);     // delete last comma
      json_sb.append("\n},\n");
      return json_sb.toString();
   }

   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   @Override
   public DBTable getTable() {
      // TODO Auto-generated method stub
      return null;
   }

   @Override
   public Object getAttr(int idx) {
      // TODO Auto-generated method stub
      return null;
   }


   @Override
   public List<Object> getAttrs() {
      // TODO Auto-generated method stub
      return null;
   }
}
