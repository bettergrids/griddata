package org.dspace.app.webui.model;

import java.sql.Types;

public interface DBTypes 
{
   //..... List of columns created by PostgreSQL Graph functions ......
   
   final static String[] calcColumns     = {"_oid", "_paths", "_connections", "_distances", "_hops", "inclusions", 
                                            "nodetype", "modeluid", "tablename"};
   
   //..... List of columns of _model table which should not be demonstrated ......
   
   final static String   modelName        = "modelname";
   final static String   modelId          = "modeluid";
   final static String   nodeType         = "nodetype";
   final static String   tableName        = "tablename";
   final static String   filePath         = "filePath";
   final static String   _fromCol         = "_from";
   final static String   _toCol           = "_to";
   final static String   lengthCol        = "length";
   final static String   nodeName         = "name";
   final static String   modelType        = "format";
   final static String   collectionId     = "collection_uid";
   final static String   itemId           = "item_uid";
   final static String   collectionName   = "collection_name";
   final static String   itemName         = "item_name";
   final static String   collectionHandle = "collection_handle";
   final static String   itemHandle       = "item_handle";
   final static String   description      = "description";
   final static String   visible          = "visible";
   
   //..... Link columns ......
   
   final static String   linkTypeUp       = "linktypeup";
   final static String   linkUp           = "linkup";
   final static String   linkDown         = "linkdown";
   final static String   linkTypeDown     = "linktypedown";
   final static String   hopsUp           = "hopsup";
   final static String   hopsDown         = "hopsdown";
   final static String   distUp           = "distup";
   final static String   distDown         = "distdown";

   //..... Model arrays ......
   
   final static String[] modelExclusions = {"oid", "tablename"}; 
   final static String[] attrExclusions  = {"_oid", modelId, nodeType, tableName}; 
   
   final static String[] queryExclusions = {"oid", "_oid", "_paths", "_connections", 
                                            linkTypeUp, linkTypeDown, linkUp, linkDown, hopsUp, hopsDown, distUp, distDown,
                                            nodeType, tableName, modelId, filePath};

   final static String[] nodeNames     = {"_name", "name", "parent", //"linkup", "linkdown",
                                          "_from", "_to", "from", "to", "nodes", "modeluid", 
                                          "bus", "tap_bus", "z_bus", "area", "zone", "owner", "area_from", "area_to",
                                          "from_bus", "to_bus", "reg_bus", "igreg_bus", "kreg_bus", "iint_bus", "tert_bus",
                                          "substation"};
   
   final static String[] busNames     = {"name", "triplex_node", "meter", 
                                         "_from", "_to", "from", "to", "nodes", "bus", "tap_bus", "z_bus", 
                                         "from_bus", "to_bus", "reg_bus", "igreg_bus", "kreg_bus", "iint_bus", "tert_bus",
                                         "linecode","id", "line", "steps", "generator", "ac_line", "two_winding_transformer",
                                         "substation", "generator", "bus_1", "bus_2"};
   
   final static String[] analysisNames = {"name", "bus"}; 
   
   final static String[] configs       = {"_configuration", "configuration", "conductor_", "_limits_",
                                          "voltage_level"};
   
   final static String[] colNamesList  = {"objectidx", "modelname", "modeltype", "cnt",   "modelcnt", "objectcnt", nodeType,
                                          collectionName, itemName,
                                          linkUp, linkDown, hopsUp, hopsDown, distUp, distDown};
   
   final static String[] colNamesTrans = {"Index", "Model", "Type", "Count", "Model Count", "Objects", "Type",
                                          "Collection", "Item",
                                          "Links Up", "Links Down", "Hops Up", "Hops Down", "Distance Up", "Distance Down"};
   
   final static String[] removeFromName = {"from_", "to_", "reg_", "igreg_", "kreg_", "iint_", "tert_"};   
   final static String[] hiddenColumns = {modelId, collectionId, itemId, collectionHandle, itemHandle, description,
                                          tableName, filePath, visible,
                                          linkTypeUp, linkTypeDown, linkUp, linkDown, hopsUp, hopsDown, distUp, distDown};    
   //..... Specific type names ......
   
   final static String uuidTypeName     = "uuid";
   final static String inetTypeName     = "inet";
   final static String textTypeName     = "text";
   final static String doubleTypeName   = "float8";
   final static String intTypeName      = "int";
   final static String intArrayTypeName = "int[]";
   final static String varcharTypeName  = "varchar";
   final static String uidTypeName      = "uid";
   
   //..... Java to PostgreSQL type mapping ......
   
   final static int typeInt         = Types.INTEGER;
   final static int typeLong        = Types.BIGINT;
   final static int typeBigInt      = Types.BIGINT;
   final static int typeSmallInt    = Types.SMALLINT;
   final static int typeBinary      = Types.BINARY;
   final static int typeLongBinary  = Types.LONGVARBINARY;
   final static int typeBit         = Types.BIT;
   final static int typeBoolean     = Types.BOOLEAN; 
   final static int typeReal        = Types.REAL;
   final static int typeDouble      = Types.DOUBLE;
   final static int typeNumeric     = Types.NUMERIC;

   final static int typeChar        = Types.CHAR;
   final static int typeVarchar     = Types.VARCHAR;
   final static int typeText        = Types.VARCHAR;
   final static int typeLongVarchar = Types.LONGNVARCHAR;
   
   final static int typeDate        = Types.DATE;
   final static int typeTimestamp   = Types.TIMESTAMP;
   final static int typeTimestampTZ = Types.TIMESTAMP_WITH_TIMEZONE;
   
   final static int typeXML         = Types.SQLXML;
   final static int typeRefCursor   = Types.REF_CURSOR;
   final static int typeOther       = Types.OTHER;    // including UUID
   
   final static int typePgArray     = Types.ARRAY;
   final static int typeTextArray   = Types.ARRAY;
   final static int typeBigIntArray = Types.ARRAY;
   final static int typeIntArray    = Types.ARRAY;
   final static int typeDoubleArray = Types.ARRAY;
   
   final static int typeUUID        = 9977;  // Not standard, just my number for setPreparedStatement
   final static int typeInet        = 9978;  // (IP addr) Not standard, just my number for setPreparedStatement
   
   //..... Names of column, which should be created manually ......
   
   final static String[]  colCommonNames = {modelId,  nodeType,    tableName, _fromCol, _toCol, lengthCol};
   final static Integer[] colCommonTypes = {typeUUID, typeVarchar, typeVarchar, typeVarchar, typeVarchar, typeDouble};
}
