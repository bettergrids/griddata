package org.dspace.app.webui.parser;

import java.io.File;
import java.math.BigInteger;
import java.sql.JDBCType;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.dspace.app.webui.backup.BGBackupConfig;
import org.dspace.app.webui.model.DBColumn;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.model.DBTable;
import org.dspace.app.webui.model.DBTypes;
import org.dspace.app.webui.parser.graph.BGGraph;
import org.dspace.app.webui.parser.graph.BGLinkAttr;
import org.dspace.app.webui.parser.graph.BGObjGraph;
import org.dspace.app.webui.parser.grg.GrgModel;
import org.dspace.app.webui.parser.gridlab.GlmModel;
import org.dspace.app.webui.parser.ieee.CdfModel;
import org.dspace.app.webui.parser.ieee.CdfTypes;
import org.dspace.app.webui.parser.matpower.MpcModel;
import org.dspace.app.webui.parser.matpower.MpcTypes;
import org.dspace.app.webui.parser.opendss.DssModel;
import org.dspace.app.webui.parser.powerworld.PowModel;
import org.dspace.app.webui.parser.powerworld.PowObject;
import org.dspace.app.webui.parser.pslf.PlfModel;
import org.dspace.app.webui.parser.pslf.PlfTypes;
import org.dspace.app.webui.parser.psse.PssModel;
import org.dspace.app.webui.parser.psse.PssTypes;
import org.dspace.app.webui.parser.reds.RedModel;
import org.dspace.app.webui.util.BGUtils;

public abstract class BGModel implements DBTypes, BGTypes {

   private static final Logger log = Logger.getLogger(BGModel.class);
   
   //..... Model Formats .....
   
   public static final String MODEL_FORMAT_GRIDLAB    = "GRIDLAB D";
   public static final String MODEL_FORMAT_MATPOWER   = "MATPOWER";
   public static final String MODEL_FORMAT_IEEE_COM   = "IEEE COMMON";
   public static final String MODEL_FORMAT_PSSE       = "PTI PSSE";
   public static final String MODEL_FORMAT_PSLF       = "GE PSLF";
   public static final String MODEL_FORMAT_OPENDSS    = "OPEN DSS";
   public static final String MODEL_FORMAT_GRG        = "GRG";
   public static final String MODEL_FORMAT_REDS       = "REDS";
   public static final String MODEL_FORMAT_POWERWORLD = "POWERWORLD";
   
   //..... Parent/info table/column names "_model2" ......
   
   public static final String    PARENT_TABLE_NAME      = "_model2";
   public static final String[]  PARENT_TABLE_COLUMNS   = DBTypes.colCommonNames;
   public static final Integer[] PARENT_TABLE_TYPES     = DBTypes.colCommonTypes;
   public static final String    PARENT_TABLE_ID_COLUMN = "_oid"; 
   
   //..... Graph (links) column names/types ......
      
   public static final String   HOPS_UP               = "hopsup";
   public static final String   HOPS_DOWN             = "hopsdown";
   public static final String[] LINKS_COLUMN_NAMES    = {"linkdown", HOPS_DOWN, "distdown",
                                                         "linkup",   HOPS_UP,   "distup"};
   
   public static final Integer[] LINKS_COLUMN_TYPES   = {typeVarchar, typeVarchar, typeInt, typeDouble, 
                                                         typeVarchar, typeVarchar, typeInt, typeDouble};
   //..... Info table/column names/types ...... 
   
   public static final String    QUERY_TABLE_NAME     = "_query";      // requests to find specific models 
   
   public static final String    INFO_TABLE_NAME      = "_modelinfo";
   public static final String[]  INFO_TABLE_COLUMNS   = {"modeluid", "modelname", "filepath", "format", "tablename", 
                                                         "description", "visible"};
   public static final Integer[] INFO_TABLE_TYPES     = {typeUUID, typeVarchar, typeVarchar, typeVarchar, typeVarchar, 
                                                         typeText, typeBoolean};  
   //..... Paths table ......
   
   public static final String    PATHS_TABLE_NAME       = "_paths";
   public static final String    PATHS_COLUMN_PATHS     = "paths";
   public static final String[]  PATHS_COLUMN_NAMES     = {DBTypes.modelId, PATHS_COLUMN_PATHS}; 
   public static final Integer[] PATHS_COLUMN_TYPES     = {typeUUID, typeIntArray};   
   
   //..... Model corresponding DB table names ......
   
   public static final String GRIDLAB_TABLE_NAME    = "_gridlab";
   public static final String MATPOWER_TABLE_NAME   = "_matpower";
   public static final String CDF_TABLE_NAME        = "_cdf";
   public static final String PSSE_TABLE_NAME       = "_psse";
   public static final String PSLF_TABLE_NAME       = "_pslf";
   public static final String OPENDSS_TABLE_NAME    = "_opendss";
   public static final String GRG_TABLE_NAME        = "_grg";
   public static final String REDS_TABLE_NAME       = "_reds";
   public static final String POWERWORLD_TABLE_NAME = "_powerworld";
   
   public static final String UNKNOWN_TABLE_NAME  = "_unknown";
      
   //..... File extensions ......
   
   public static final String[] MODEL_FILE_FORMATS_SA = {MODEL_FORMAT_GRIDLAB, MODEL_FORMAT_MATPOWER, 
                                                         MODEL_FORMAT_IEEE_COM, MODEL_FORMAT_PSSE, MODEL_FORMAT_PSLF,
                                                         MODEL_FORMAT_OPENDSS, MODEL_FORMAT_GRG, MODEL_FORMAT_REDS,
                                                         MODEL_FORMAT_POWERWORLD};   
   public static final String[] MODEL_FILE_EXT_SA     = {"gld", "m", "cdf", "raw", "epc", "zip", "grg", "pos", "aux"};
   
   public static final int[]    OBJ_TYPE_ID_BASE      = {100, 200, 300, 400, 500, 600, 700, 800, 900};
   
   //..... Constants ......
   
   public static final String COLLED_BY_CREATOR_CONST     = "called_creator";          // from JSPUploadStep.showModelStatistics
   public static final String COLLED_BITSTREAM_LIST_CONST = "called_bitstream_list";   // from jsptag.listBitstreams
   
   public static final String TYPE_CONST  = "type";
   public static final String COUNT_CONST = "count";
   
   //..... Members ......
   
   private String     name;            // model name
   private String     dspaceId;        // internal_id column in the bitstream table.
   private UUID       uuid;            // model (bitstream) UUID in the DSpace DB
   private String     handle;          // handle column in the handle table
   private BigInteger prefix;          // repository prefix, first part of the handle (like, 123456789)
   private BigInteger handleId;        // second (last) part of the handle.
   private String     format;          // model file format, like "GridLab-D", "MathPower", etc.
   private String     description;     // model description   
   private Boolean    visible = true;  // model visibility (true/false)
   
   protected Double   formatVersion = null;  // version of format, especially for PSS/E and PSLF
   
   private String     path;           // file system path of the model
   
   protected Map<String, Integer> typeCounts = new HashMap<String, Integer>();   // data type (bus, node, etc.) counts
        
   private List<Integer[]> paths;     // typeId paths for deep search
   
   //..... Getters/Setters ......
   
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getDspaceId() {
      return dspaceId;
   }
   public void setDspaceId(String dspaceId) {
      this.dspaceId = dspaceId;
   }
   public String getHandle() {
      return handle;
   }
   public void setHandle(String handle) {
      this.handle = handle;
   }
   public BigInteger getPrefix() {
      return prefix;
   }
   public void setPrefix(BigInteger prefix) {
      this.prefix = prefix;
   }
   public BigInteger getHandleId() {
      return handleId;
   }
   public void setHandleId(BigInteger handleId) {
      this.handleId = handleId;
   }
   public String getFormat() {
      return format;
   }
   public void setFormat(String format) {
      this.format = format;
   }
   public Double getFormatVersion() {
      return formatVersion;
   }
   public void setFormatVersion(Double formatVersion) {
      this.formatVersion = formatVersion;
   }
   public String getDescription() {
      return description;
   }
   public void setDescription(String description) {
      this.description = description;
   }
   public Boolean getVisible() {
      return visible;
   }
   public void setVisible(Boolean visible) {
      this.visible = visible;
   }
   public List<Integer[]> getPaths() {
      return paths;
   }
   public void setPaths(List<Integer[]> paths) {
      this.paths = paths;
   }
   
   public static String getDbTableName(String format)   // DB table name, corresponding to this model
   {
      if (format == null) return null;
      switch(format) {
      case MODEL_FORMAT_GRIDLAB:    return GRIDLAB_TABLE_NAME;
      case MODEL_FORMAT_MATPOWER:   return MATPOWER_TABLE_NAME;
      case MODEL_FORMAT_IEEE_COM:   return CDF_TABLE_NAME;
      case MODEL_FORMAT_PSSE:       return PSSE_TABLE_NAME;
      case MODEL_FORMAT_PSLF:       return PSLF_TABLE_NAME;
      case MODEL_FORMAT_OPENDSS:    return OPENDSS_TABLE_NAME;
      case MODEL_FORMAT_GRG:        return GRG_TABLE_NAME;
      case MODEL_FORMAT_REDS:       return REDS_TABLE_NAME;
      case MODEL_FORMAT_POWERWORLD: return POWERWORLD_TABLE_NAME;
      default:                      return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   
   public String getAttrName_from()
   {
      if (this.getFormat() == null) return null;
      switch(this.getFormat()) {
      case BGModel.MODEL_FORMAT_GRIDLAB:     return GlmModel.FROM_NAME;
      case BGModel.MODEL_FORMAT_MATPOWER:    return MpcTypes.FROM_NAME;
      case BGModel.MODEL_FORMAT_IEEE_COM:    return CdfTypes.FROM_NAME;
      case BGModel.MODEL_FORMAT_PSSE:        return PssTypes.FROM_NAME;
      case BGModel.MODEL_FORMAT_PSLF:        return PlfTypes.FROM_NAME;
      case BGModel.MODEL_FORMAT_OPENDSS:     return DssModel.FROM_NAME;
      case BGModel.MODEL_FORMAT_GRG:         return GrgModel.FROM_NAME;
      case BGModel.MODEL_FORMAT_REDS:        return RedModel.FROM_NAME;
      case BGModel.MODEL_FORMAT_POWERWORLD:  return PowModel.FROM_NAME;
      
      default: return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   
   public String getAttrName_bus()
   {
      if (this.getFormat() == null) return null;
      switch(this.getFormat()) {
      case BGModel.MODEL_FORMAT_GRIDLAB:     return "name";
      case BGModel.MODEL_FORMAT_MATPOWER:    return "bus";
      case BGModel.MODEL_FORMAT_IEEE_COM:    return "bus";
      case BGModel.MODEL_FORMAT_PSSE:        return PssTypes.BUS_NAME;
      case BGModel.MODEL_FORMAT_PSLF:        return "bus";
      case BGModel.MODEL_FORMAT_OPENDSS:     return "name";
      case BGModel.MODEL_FORMAT_GRG:         return "id";
      case BGModel.MODEL_FORMAT_REDS:        return "name";
      case BGModel.MODEL_FORMAT_POWERWORLD:  return "bus";
      default: return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   
   public String getAttrName_to()
   {
      if (this.getFormat() == null) return null;
      switch(this.getFormat()) {
      case BGModel.MODEL_FORMAT_GRIDLAB:     return GlmModel.TO_NAME;
      case BGModel.MODEL_FORMAT_MATPOWER:    return MpcTypes.TO_NAME;
      case BGModel.MODEL_FORMAT_IEEE_COM:    return CdfTypes.TO_NAME;
      case BGModel.MODEL_FORMAT_PSSE:        return PssTypes.TO_NAME;
      case BGModel.MODEL_FORMAT_PSLF:        return PssTypes.TO_NAME;
      case BGModel.MODEL_FORMAT_OPENDSS:     return DssModel.TO_NAME;
      case BGModel.MODEL_FORMAT_GRG:         return GrgModel.TO_NAME;
      case BGModel.MODEL_FORMAT_REDS:        return RedModel.TO_NAME;
      case BGModel.MODEL_FORMAT_POWERWORLD:  return PowModel.TO_NAME;
      default: return null;
      }
   }  
   //----------------------------------------------------------------------------------------------
   
   public String getAttrName_length()
   {
      if (this.getFormat() == null) return null;
      switch(this.getFormat()) {
      case BGModel.MODEL_FORMAT_GRIDLAB:     return GlmModel.LENGTH_NAME;
      case BGModel.MODEL_FORMAT_MATPOWER:    return MpcTypes.LENGTH_NAME;
      case BGModel.MODEL_FORMAT_IEEE_COM:    return CdfTypes.LENGTH_NAME;
      case BGModel.MODEL_FORMAT_PSSE:        return PssTypes.LENGTH_NAME;
      case BGModel.MODEL_FORMAT_PSLF:        return PssTypes.LENGTH_NAME;
      case BGModel.MODEL_FORMAT_OPENDSS:     return DssModel.LENGTH_NAME;
      case BGModel.MODEL_FORMAT_GRG:         return GrgModel.LENGTH_NAME;
      case BGModel.MODEL_FORMAT_REDS:        return RedModel.LENGTH_NAME;
      case BGModel.MODEL_FORMAT_POWERWORLD:  return PowModel.LENGTH_NAME;
      default: return null;
      }
   }   

   //----------------------------------------------------------------------------------------------
   
   public static int getFormatIdx(String format)
   {
      return BGUtils.getStringIdx(format, MODEL_FILE_FORMATS_SA);
   }
   
   public String getDbTableName()
   {
      return getDbTableName(format);
   }
   
   public UUID getUuid() {
      return uuid;
   }
   public void setUuid(UUID uuid) {
      this.uuid = uuid;
   }
   public String getPath() 
   {
      if (path == null) {
         if (dspaceId == null) {
            return null;         
         }
         path = BGBackupConfig.getDspaceHome() + File.separator +
                dspaceId.substring(0,2)        + File.separator +
                dspaceId.substring(2,4)        + File.separator +
                dspaceId.substring(4,6)        + File.separator +
                dspaceId;
      }
      return path;
   }
   public void setPath(String path) {
      this.path = path;
   }
   public void setTypeCounts(Map<String, Integer> typeCounts) {
      this.typeCounts = typeCounts;
   }
   public Map<String, Integer> getTypeCounts() {
      return typeCounts;
   }
   public Integer getTypeCount(String objType_s)
   {
      return typeCounts.get(objType_s);  // return null if objType_s not exists
   }
   //----------------------------------------------------------------------------------------------
   // Instantiate model
   //----------------------------------------------------------------------------------------------
   
   public static BGModel createModel(String format_s)
   {
      switch(format_s) {
      case BGModel.MODEL_FORMAT_GRIDLAB:     return new GlmModel();
      case BGModel.MODEL_FORMAT_MATPOWER:    return new MpcModel();
      case BGModel.MODEL_FORMAT_IEEE_COM:    return new CdfModel();
      case BGModel.MODEL_FORMAT_PSSE:        return new PssModel();
      case BGModel.MODEL_FORMAT_PSLF:        return new PlfModel();
      case BGModel.MODEL_FORMAT_OPENDSS:     return new DssModel();
      case BGModel.MODEL_FORMAT_GRG:         return new GrgModel();
      case BGModel.MODEL_FORMAT_REDS:        return new RedModel();
      case BGModel.MODEL_FORMAT_POWERWORLD:  return new PowModel();
      default: 
         log.info("BGModel.createModel. Unknown model format: " + format_s);
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   // Get attribute name from index
   //----------------------------------------------------------------------------------------------
   
   public String getAttrTypeName(int sectIdx, int attrIdx)
   {
      try {
         Integer attrTypeIdx = getAttrTypes(sectIdx).get(attrIdx);
         String typeName = JDBCType.valueOf(attrTypeIdx).getName().toLowerCase();
         if (typeName.equals("double")) {
            typeName = "double precision";
         }
         return typeName;
      }
      catch(Exception e) {
         //log.error("BGModel.getAttrTypeName. Cannot find attribute type for section index: " + sectIdx + 
         //          " and attribute index: " + attrIdx);
         return "text";
      }
   }
   //----------------------------------------------------------------------------------------------
   // Add type counts per type during the parsing process
   //----------------------------------------------------------------------------------------------
   
   public void addTypeCount(String objType_s, Integer cnt)
   {
      if (typeCounts.containsKey(objType_s) == false) { 
         typeCounts.put(objType_s, 1);
      }
      else {
         typeCounts.merge(objType_s, 1, Integer::sum);
      }
   }
   //----------------------------------------------------------------------------------------------
   // Get array of object of specific type sorted by object attribute value
   //----------------------------------------------------------------------------------------------
   
   public BGObject[] sortObjectByAttr(String objType_s,
                                      String attrName_s)    // if null - return object names
   {
      BGObject[] object_oa = getObjects(objType_s);
    
      Comparator<BGObject> comp = new Comparator<BGObject>() { 
                                     public int compare(BGObject o1, BGObject o2) {
                                        String value1_s = o1.getAttr(attrName_s).toString();
                                        String value2_s = o2.getAttr(attrName_s).toString();
                                        return value2_s.compareToIgnoreCase(value1_s);
                                     }
                                  };     
      Arrays.sort(object_oa, comp);
      return object_oa;
   }
   //----------------------------------------------------------------------------------------------
   // Get sorted names of specific object attributes
   //----------------------------------------------------------------------------------------------
   
   public List<String> getObjNamesSorted(String objType_s,
                                         String attrName_s)    // if null - return object names
   {
      BGObject[] object_oa = getObjects(objType_s);
      
      if (object_oa == null || object_oa.length == 0) {
         log.warn("getObjNamesSorted. Model name: " + name + ". No object type '" +
                  objType_s + "' found");
         return null;
      }
      List<String> value_sa = new ArrayList<String>(); 
      
      if (attrName_s == null) {
         for (int i = 0; i < object_oa.length; i++) {
            value_sa.add(object_oa[i].getName());
         }
      }
      else {
         String value_s = null;
         for (int i = 0; i < object_oa.length; i++) {
            value_s = object_oa[i].getAttr(attrName_s).toString();
            if (value_s == null) {
               log.error("getObjNamesSorted. Model name: " + name + ". No attribute '" + 
                         attrName_s + "' found");
               return null;
            }
            value_sa.add(value_s);
         }
      }
      Collections.sort(value_sa);
      return value_sa;
   }
   //----------------------------------------------------------------------------------------------
   // Populate object link arrays (pre-calculated graphs) for all nodes (buses) 
   //----------------------------------------------------------------------------------------------

   public boolean calculateLinks()
   {
      String   fromName_s  = null;
      String   toName_s    = null;
      String   lenName_s   = null;
      
      if (this instanceof PssModel) {
         fromName_s  = PssTypes.FROM_NAME;
         toName_s    = PssTypes.TO_NAME;
         lenName_s   = PssTypes.LENGTH_NAME;
      }
      else if (this instanceof PlfModel) {
         fromName_s   = PlfTypes.FROM_NAME;
         toName_s     = PlfTypes.TO_NAME;
         lenName_s    = PlfTypes.LENGTH_NAME;
      }
      else if (this instanceof CdfModel) {
         fromName_s   = CdfTypes.FROM_NAME;
         toName_s     = CdfTypes.TO_NAME;
         lenName_s    = CdfTypes.LENGTH_NAME;  
      }
      else if (this instanceof MpcModel) {
         fromName_s   = MpcTypes.FROM_NAME;
         toName_s     = MpcTypes.TO_NAME;
         lenName_s    = MpcTypes.LENGTH_NAME;
      }
      else if (this instanceof GlmModel) {
         fromName_s    = GlmModel.FROM_NAME;
         toName_s      = GlmModel.TO_NAME;
         lenName_s     = GlmModel.LENGTH_NAME;
      }
      else if (this instanceof DssModel) {
         fromName_s    = DssModel.FROM_NAME;
         toName_s      = DssModel.TO_NAME;
         lenName_s     = DssModel.LENGTH_NAME;
      }
      else if (this instanceof GrgModel) {
         fromName_s    = GrgModel.FROM_NAME;
         toName_s      = GrgModel.TO_NAME;
         lenName_s     = GrgModel.LENGTH_NAME;
      }
      else if (this instanceof RedModel) {
         fromName_s    = RedModel.FROM_NAME;
         toName_s      = RedModel.TO_NAME;
         lenName_s     = RedModel.LENGTH_NAME;
      }
      else if (this instanceof PowModel) {
         fromName_s    = PowModel.FROM_NAME;
         toName_s      = PowModel.TO_NAME;
         lenName_s     = PowModel.LENGTH_NAME;
      }            
      BGGraph graph = new BGGraph();
      
      //..... Calculate links in up and down directions ...... 
      
      graph.computeShortestPaths(this, fromName_s, toName_s, lenName_s, true);   // links down
      graph.computeShortestPaths(this, fromName_s, toName_s, lenName_s, false);  // links up
      
      //..... Round distance value to 3 decimal digits ......
      
      for (BGObject obj : this.getObjects()) {
         if (obj != null) {
            if (obj.getLinksDown() != null && obj.getLinksDown().isEmpty() == false) { 
               for (BGLinkAttr link : obj.getLinksDown()) {
                  Double dist = link.getDistance();
                  if (dist != null && dist != 0.0) {
                     link.setDistance((double)Math.round(dist * 1000) / 1000.);
                  }
               }
            }
            if (obj.getLinksUp() != null && obj.getLinksUp().isEmpty() == false) { 
               for (BGLinkAttr link : obj.getLinksUp()) {
                  Double dist = link.getDistance();
                  if (dist != null && dist != 0.0) {
                     link.setDistance((double)Math.round(dist * 1000) / 1000.);
                  }
               }
            }
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Calculate unique typeId paths for the model 
   //----------------------------------------------------------------------------------------------

   public boolean calculateTypePaths()
   {
      //..... Calculate all paths from all nodes to all nodes ......
      
      BGObjGraph objGraph = new BGObjGraph();
      objGraph.computeShortestPaths(this);
      paths = objGraph.getPaths();
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Get table declaration from the model
   //----------------------------------------------------------------------------------------------

   public DBTable getTable(String objType_s) 
   {
      //..... Setup table ......

      if (objType_s == null) return null;
      int typeIdx = BGUtils.getStringIdx(objType_s, getObjTypeNames());
      if (typeIdx == -1) return null;
      
      DBTable table = new DBTable();
      table.setName(objType_s);

      if (getAttrNames(typeIdx) == null) return table;
      
      for (int i = 0; i < getAttrNames(typeIdx).size(); i++) {         
         String  colName_s = getAttrNames(typeIdx).get(i);
         
         List<Integer> attrTypes = getAttrTypes(typeIdx);
         Integer colType = (attrTypes == null) ? Types.VARCHAR : attrTypes.get(i);

         DBColumn col = new DBColumn(colName_s, null, colType, i);
         table.addColumn(i, col);
      }
      return table;
   }
   //----------------------------------------------------------------------------------------------
   // Get DBEntry from the model
   //----------------------------------------------------------------------------------------------

   public DBEntry getEntry(String  nodeType_s, 
                           String  nodeName_s,
                           boolean setNumeric_b)
   {
      if (nodeType_s == null && nodeName_s == null) {    // do not support entry for all objects
         return new DBEntry();                           // return empty entry
      }      
      //..... Setup entry ......

      DBEntry entry = new DBEntry();

      //..... Add column declarations and data for specific object ...... 

      if (nodeName_s != null) {
         BGObject obj = getObject(nodeName_s);
         if (obj == null) {
            entry.setTable(getTable(nodeType_s));
            return entry;
         }
         DBTable table = obj.getTable();
         if (table == null) {
            table = getTable(nodeType_s);
         }
         entry.setTable(table);
         
         //..... Add data ......
         
         Map<Integer, Object> row = entry.newRow();
         for (int i = 0; i < table.getColumnNum(); i++) {
            entry.setRowValue(row, i, obj.getAttr(i));
         }
         entry.addRow(row);
      }
      //..... Add columns declarations for specific type .....
      
      else if (nodeType_s != null) {
         BGObject[] objs = getObjects(nodeType_s);
         if (objs == null || objs.length == 0) {
            entry.setTable(getTable(nodeType_s));
            return entry;
         }
         DBTable table = objs[0].getTable();
         if (table == null) {
            table = getTable(nodeType_s);
         }
         entry.setTable(table);

         for (BGObject obj : objs) {
            
            Map<Integer, Object> row = entry.newRow();
            for (int i = 0; i < table.getColumnNum(); i++) {
               entry.setRowValue(row, i, obj.getAttr(i));
            }
            entry.addRow(row);
         }
      }
      entry.setCompactTable();         // remove columns with all null values
      if (setNumeric_b) {
         entry.setNumericColumns();    // set column types numeric/integer, based on data
      }
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public DBEntry getEntry(String  nodeType_s,
                           String  nodeName_s)                      
   {
      return getEntry(nodeType_s, nodeName_s, true);
   }
   //----------------------------------------------------------------------------------------------
   // Get entry with object types statistics
   //----------------------------------------------------------------------------------------------
   
   public DBEntry getInfoEntry() 
   {
      DBEntry entry = new DBEntry();
      
      //..... Setup table ......

      DBTable table = new DBTable();
      table.setName(getName());
      
      table.addColumn(0, new DBColumn(TYPE_CONST,  null, Types.VARCHAR, 0));   // column index: 0
      table.addColumn(1, new DBColumn(COUNT_CONST, null, Types.INTEGER, 1));   // column index: 1
      
      entry.setTable(table);
      
      //..... Calculate counts of all types ......
      
      for (String typeName : getObjTypeNames()) {
         if (typeName == null) continue;
         BGObject[] objs = getObjects(typeName);
         if (objs == null || objs.length == 0) continue;
         
         Map<Integer, Object> row = entry.newRow();  
         entry.setRowValue(row, 0, typeName);            // column index: 0  (type name)
         entry.setRowValue(row, 1, objs.length);         // column index: 1  (object count)
         entry.addRow(row);
      }
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   // Get entry with object types statistics as one row
   //----------------------------------------------------------------------------------------------
   
   public DBEntry getModelInfoAsRow() 
   {
      DBEntry entry = new DBEntry();
      
      //..... Create table ......

      DBTable table = new DBTable();
      table.setName(INFO_TABLE_NAME);
      entry.setTable(table);
      
      Map<Integer, Object> row = entry.newRow();
      
      for(int i = 0; i < INFO_TABLE_COLUMNS.length; i++) {
         table.addColumn(i, new DBColumn(INFO_TABLE_COLUMNS[i],  null, INFO_TABLE_TYPES[i], i));
      }
      entry.setRowValue(row, 0, this.getUuid());
      entry.setRowValue(row, 1, this.getName());
      entry.setRowValue(row, 2, this.getPath());
      entry.setRowValue(row, 3, this.getFormat());
      entry.setRowValue(row, 4, this.getDbTableName());
      entry.setRowValue(row, 5, this.getDescription());
      entry.setRowValue(row, 6, this.getVisible());
      entry.addRow(row);
      
      //..... Add type columns to the table ......
      
      int colIdx = table.getColumnNum();
      
      for (String typeName : getObjTypeNames()) {
         if (typeName == null) continue;
         BGObject[] objs = getObjects(typeName);
         if (objs == null) continue;
        
         table.addColumn(colIdx, new DBColumn(typeName,  null, Types.INTEGER, colIdx));
         entry.setRowValue(row, colIdx, getTypeCount(typeName));
         colIdx++;
      }
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public BGObject[] getObjects(String[] typeName_sa) 
   {
      List<BGObject> objs = new ArrayList<BGObject>();
      
      if (typeName_sa != null) {
         for (String typeName : typeName_sa) {
            objs.addAll(Arrays.asList(getObjects(typeName)));
         }
      }      
      return objs.toArray(new BGObject[objs.size()]);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String[] getStaticObjTypeNames(String format_s)      // model format, like: "GRIDLAB D"
   {
      switch (format_s) {
      case MODEL_FORMAT_GRIDLAB:    return new GlmModel().getStaticObjTypeNames();
      case MODEL_FORMAT_MATPOWER:   return new MpcModel().getStaticObjTypeNames();
      case MODEL_FORMAT_IEEE_COM:   return new CdfModel().getStaticObjTypeNames();
      case MODEL_FORMAT_PSSE:       return new PssModel().getStaticObjTypeNames();
      case MODEL_FORMAT_PSLF:       return new PlfModel().getStaticObjTypeNames();
      case MODEL_FORMAT_OPENDSS:    return new DssModel().getStaticObjTypeNames();
      case MODEL_FORMAT_GRG:        return new GrgModel().getStaticObjTypeNames();
      case MODEL_FORMAT_REDS:       return new RedModel().getStaticObjTypeNames();
      case MODEL_FORMAT_POWERWORLD: return new PowModel().getStaticObjTypeNames();
      default: return null;  
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public boolean calcTypeCounts() 
   {
      //..... Calculate counts of all types ......
   
      if (typeCounts.isEmpty() == false) return true;
      
      for (String objType_s : this.getObjTypeNames()) {
         Integer objTypeCnt = this.getObjects(objType_s).length;
         typeCounts.put(objType_s, objTypeCnt);
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Abstract methods
   //----------------------------------------------------------------------------------------------
   
   //abstract public boolean       calcTypeCounts();
   abstract public BGObject      getObject(String name_s);
   abstract public BGObject[]    getObjects(int typeIdx);
   abstract public BGObject[]    getObjects();
   abstract public BGObject[]    getObjects(String typeName_s);
   abstract public BGObject[]    getLinkObjects();
   abstract public Integer       getTypesNum();
   abstract public String        toJson();
   abstract public String[]      getObjTypeNames();
   abstract public String[]      getStaticObjTypeNames();
   abstract public String[]      getNodeObjTypeNames();
   abstract public String[]      getLinkObjTypeNames();
   abstract public String        getObjTypeName(int sectIdx);
   abstract public List<String>  getAttrNames(int typeIdx);
   abstract public List<Integer> getAttrTypes(int typeIdx);
   abstract public Integer       getAttrIdx(int sectIdx, String attrName);
}
//======================================= End of Class ============================================

