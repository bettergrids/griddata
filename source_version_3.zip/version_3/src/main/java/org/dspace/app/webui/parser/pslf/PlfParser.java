package org.dspace.app.webui.parser.pslf;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.util.Arrays;
import java.util.UUID;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBConnection;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.model.DBExecute;
import org.dspace.app.webui.model.DBProvider;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGParser;
import org.dspace.app.webui.util.BGUtils;

public class PlfParser extends BGParser implements PlfTypes {

   private static final Logger log = Logger.getLogger(PlfParser.class);
   
   //..... Constants ......
   
   private static final String  COMENT_SIGN        = "!";
   private static final String  CONTINUE_SIGN      = "/";
   private static final String  OBJ_NUM_OPEN_SIGN  = "[";
   private static final String  OBJ_NUM_CLOSE_SIGN = "]";
   private static final String  OBJ_SEPARATOR_SIGN = ":";
   private static final String  FILE_END           = "end";
   private static final Integer SOLUTION_COL_NUM   = 4;

   //..... Constructor ......
   
   public PlfParser(String file_s) throws FileNotFoundException 
   {
      super(file_s);
   }
   //----------------------------------------------------------------------------------------------
   // Parse model file
   //----------------------------------------------------------------------------------------------
   
   public static PlfModel parseFile(String file_s) 
   {
      PlfModel model = new PlfModel();
      
      Boolean[] done = new Boolean[SECT_KEYWORD_SA.length];
      for (int i = 0; i < done.length; i++) {
         done[i] = false;
      }
      
      try {
         PlfParser parser = new PlfParser(file_s);
         //parser.setDoNormalize(true);
         parser.setSkipEmpty(true);
      
         do {
            String line_s = parser.getLine().trim();                 // get section name
            if (line_s.equalsIgnoreCase(FILE_END)) break;
         
            Integer sectIdx = getSectIdx(line_s);
            if (sectIdx == -1) {
               log.error("PslParser.parseFile. Unexpected section name: " + line_s);
               return model;
            }
            //..... Get number of object lines (in the [ num ] token) ......
            
            if (sectIdx == SECT_TITLE_IDX || sectIdx == SECT_COMMENTS_IDX) {
               parseHeader(sectIdx, parser, model);
               
            }
            else if (sectIdx == SECT_SOLUTION_IDX ) {
               parseSolutions( parser, model);
            }
            else {
               int objNum = getObjNum(line_s);
               parseSection(sectIdx, objNum, parser, model);
            }
         }
         while (true);
      }
      catch (FileNotFoundException e) {
         log.error("PslParser.parseFile. File " + file_s + " not found. " + e.getMessage() +
                   "; Trace: " + ExceptionUtils.getStackTrace(e));
         return null;
      } 
      catch (IOException e) {
         log.error("PslParser.parseFile. General I/O error in parsing file " + file_s + ". " +
                   e.getMessage() + "; Trace: " + ExceptionUtils.getStackTrace(e));
         return null;
      }
      catch (Exception e) {
         log.error("PslParser.parseFile. File: " + file_s + ". " + e.getMessage() +
                   "; Trace: " + ExceptionUtils.getStackTrace(e));
         return null;
      }
      //..... Model attributes ......
      
      //model.setDspaceId(BGUtils.getNameFromFile(file_s));
      model.setName(BGUtils.getNameFromFile(file_s));
      model.setPath(file_s);
      model.calcTypeCounts();
      model.setFormat(BGModel.MODEL_FORMAT_PSLF);
      
      return model;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static Integer getSectIdx(String line_s)
   {
      //..... Extract section name ......
      
      int pos = line_s.indexOf(OBJ_NUM_OPEN_SIGN);
      if (pos > 0) {
         line_s = line_s.substring(0, pos);
      }
      line_s = line_s.trim();
      
      //..... Find exact match ......
      
      for (int i = 0; i < SECT_KEYWORD_SA.length; i++) {
         if (line_s.equalsIgnoreCase(SECT_KEYWORD_SA[i])) {
            return i;
         }
      }
      return -1;
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static Integer getObjNum(String line_s)
   {
      int startIdx = line_s.indexOf(OBJ_NUM_OPEN_SIGN);
      int endIdx   = line_s.indexOf(OBJ_NUM_CLOSE_SIGN);
      
      if (startIdx == -1 || endIdx == -1 || endIdx < startIdx + 1) {
         log.error("PslParser.getObjNum. Number of objects not specified: " + line_s);
         return -1;
      }
      return (Integer)BGUtils.stringToInteger(line_s.substring(startIdx + 1, endIdx));
   }
   //----------------------------------------------------------------------------------------------
   // 0/1. Parse TITLE (0) and COMMENTS (1) lines
   //----------------------------------------------------------------------------------------------
   
   private static Boolean parseHeader(int       sectIdx,
                                      PlfParser parser,
                                      PlfModel  model) throws IOException
   {
      int idx = 0;
      if (sectIdx != SECT_TITLE_IDX && sectIdx != SECT_COMMENTS_IDX) {
         log.error("PslParser.parseHeader. Unexpected section ID (not TITLE or COMMENTS): " + sectIdx);
         return false;
      }
      do {
         String line_s = parser.getLine().trim();
         if (line_s == null) return null;
         if (line_s.equals(COMENT_SIGN)) return true; 
         
         PlfObject obj = new PlfObject(model, sectIdx);
         
         obj.setType(SECT_NAMES_SA[sectIdx]);
         obj.setId(idx++);
         obj.setName(SECT_NAMES_SA[sectIdx] + obj.getId());
         obj.setModel(model);
         
         String[] line_sa = {line_s};
         obj.addAttrs(line_sa, sectIdx);
         model.addObject(sectIdx, obj);
      }
      while(true);
   }
   //----------------------------------------------------------------------------------------------
   // 2. Parse SOLUTION PARAMETERS lines
   //----------------------------------------------------------------------------------------------
      
   private static Boolean parseSolutions(PlfParser parser,
                                         PlfModel  model) throws IOException
   {
      int idx = 0;

      do {
         String line_s = parser.getLine().trim();
         if (line_s == null) return null;
         if (line_s.equals(COMENT_SIGN)) return true; 
         line_s = line_s.replaceAll("\\s+"," ");         // replace all duplicate white spaces and LFs
         String[] line_sa = line_s.split(" ");

         PlfObject obj = new PlfObject(model, SECT_SOLUTION_IDX);
         
         obj.setType(SECT_NAMES_SA[SECT_SOLUTION_IDX]);
         obj.setId(idx++);
         obj.setName(SECT_NAMES_SA[SECT_SOLUTION_IDX] + obj.getId());
         obj.setModel(model);

         for (int i = 0; i < SOLUTION_COL_NUM; i++) {
            if (BGUtils.getIndexOf(line_sa[0], SOL_PARAMS_SA) >= 0) {
               if (i == 2) {
                  for (int j = 3; j < line_sa.length; j++) {
                     line_sa[2] += " " + line_sa[j];
                  }
               }
               else if (i > 2) {
                  line_sa[i] = "";
               }
            }  
         }
         obj.addAttrs(Arrays.copyOf(line_sa, SOLUTION_COL_NUM), SECT_SOLUTION_IDX);;
         model.addObject(SECT_SOLUTION_IDX, obj);
      }
      while(true);
   }
   //----------------------------------------------------------------------------------------------
   // 3+. Parse ALL SECTIONS lines
   //----------------------------------------------------------------------------------------------
   
   private static Integer parseSection(Integer   sectIdx,
                                       int       objNum,     // number of objects (lines) to parse
                                       PlfParser parser,
                                       PlfModel  model) throws IOException
   {
      if (objNum == 0) return sectIdx + 1;
      
      for (int idx = 0; idx < objNum; idx++) {
         String line_s = "";
         String tmp_s = parser.getLine().trim();
         if (tmp_s == null) return null;

         //..... Process multi-line object ......
         
         while (tmp_s.substring(tmp_s.length() - 1).equals(CONTINUE_SIGN)) {
            line_s += tmp_s.substring(0, tmp_s.length() - 1) + " "; 
            
            tmp_s = parser.getLine().trim();           
            if (tmp_s == null) return null;
         }
         line_s += tmp_s;

         //..... Parse final (or only) line ......
         
         line_s = line_s.replaceAll("\\s+", " ");              // replace all duplicate white spaces and LFs
         
         //..... Find how many attrs before separator ":" ......
         
         if (idx == 0 && HEAD_ATTR_NUM_A[sectIdx] != null) {
            int sepIdx = line_s.indexOf(OBJ_SEPARATOR_SIGN);
            if (sepIdx > 0) {
               String   head_s  = line_s.substring(0, sepIdx).trim();
               String[] head_sa = BGUtils.splitQuoted(head_s);
            
               int attrIdx = HEAD_ATTR_NUM_A[sectIdx];
               while (attrIdx < head_sa.length) {
                  model.getAttrNames(sectIdx).add(attrIdx, "attr_" + attrIdx);
                  attrIdx++;
               }
            }
         }
         //..... Parse object line ......
         
         line_s = line_s.replaceAll(OBJ_SEPARATOR_SIGN, "");   // remove separator ":"
         String[] line_sa  = BGUtils.splitQuoted(line_s);      // split by " ", but not inside quotes, trimmed

         //..... Change BUS objects from/to attrs, say from "1" to "bus_1" ......
         // find index of attributes: bus, from_bus, to_bus
         
         if (sectIdx == SECT_BUS_IDX) {
            int busAttrIdx = BGUtils.getStringIdx(PlfTypes.BUS_NAME, PlfTypes.BUS_ATTR_NAMES_SA);
            if (busAttrIdx != -1) {
               line_sa[busAttrIdx] = SECT_NAMES_SA[SECT_BUS_IDX] + "_" + line_sa[busAttrIdx];
            } 
         }
         else {
            int fromAttrIdx = BGUtils.getStringIdx(FROM_NAME, ATTR_NAMES_SAA[sectIdx]);
            int toAttrIdx   = BGUtils.getStringIdx(TO_NAME,   ATTR_NAMES_SAA[sectIdx]);
            if (fromAttrIdx != -1 && toAttrIdx != -1) {
               line_sa[fromAttrIdx] = SECT_NAMES_SA[SECT_BUS_IDX] + "_" + line_sa[fromAttrIdx];
               line_sa[toAttrIdx]   = SECT_NAMES_SA[SECT_BUS_IDX] + "_" + line_sa[toAttrIdx];
            }
         }
         //..... Create object and add attributes ......
         
         PlfObject obj = new PlfObject(model, sectIdx);
         obj.setType(SECT_NAMES_SA[sectIdx]);
         obj.setId(idx);
         
         obj.setModel(model);
         obj.addAttrs(line_sa, sectIdx);
         
         //..... Build object name ......
         
         switch (sectIdx) {
         case SECT_SUBSTATION_IDX:
         case SECT_AREA_IDX:
         case SECT_ZONE_IDX:
         case SECT_INTERFACE_IDX:
         case SECT_OWNER_IDX:
            obj.setName(SECT_NAMES_SA[sectIdx] + "_" + obj.getAttr(0));
            break;
         case SECT_BUS_IDX:
            obj.setName(obj.getAttr(0).toString());
            break;
         default:
            obj.setName(SECT_NAMES_SA[sectIdx] + "_" + obj.getId());
         }        
         //..... Add to model ......
         
         model.addObject(sectIdx, obj);
      }
      return 0;
   }
}
//======================================= End of Class ============================================
