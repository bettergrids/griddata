package org.dspace.app.webui.parser.grg;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.util.BGUtils;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class GrgParser {

   private static final Logger log = Logger.getLogger(GrgParser.class);

   //..... Constants ......
   
   public static final String OPEN_CONST            = "{";
   public static final String CLOSE_CONST           = "}";
   public static final String END_LINE_CONST        = ",";
   public static final String COMPLEX_DELIM_CONST   = "/";
   public static final String RANGE_SPLITTER_CONST  = " : ";
   
   public static final String NAME_CONST            = "name";
   public static final String OBJECT_CONST          = "object";
   
   public static final String STEPS_CONST           = "steps";
   public static final String ARGUMENTS_CONST       = "arguments";
   public static final String VALUES_CONST          = "values";
   public static final String PARENT_CONST          = "parent";
   public static final String ATTR_ID_CONST         = "id";
   public static final String ATTR_TYPE_CONST       = "type";
   
   public static final String SHUNT_CONST           = "shunt";
   public static final String SHUNT_1_CONST         = "shunt_1";
   public static final String SHUNT_2_CONST         = "shunt_2";
   public static final String IMPEDANCE_CONST       = "impedance";
   public static final String TAP_RATIO_CONST       = "tap_ratio";
   public static final String ANGLE_SHIFT_CONST     = "angle_shift";
   public static final String VOLTAGE_CONST         = "voltage";
   public static final String OUTPUT_CONST          = "output";
   public static final String POSITION_CONST        = "position";
   public static final String DEMAND_CONST          = "demand";
   
   public static final String CUR_LIMITS_1_CONST    = "current_limits_1";
   public static final String CUR_LIMITS_2_CONST    = "current_limits_2";
   public static final String THER_LIMITS_1_CONST   = "thermal_limits_1";
   public static final String THER_LIMITS_2_CONST   = "thermal_limits_2";
   public static final String VOLT_LEVEL_CONST      = "voltage_level";
   public static final String TAP_CHANGER_CONST     = "tap_changer";
   public static final String BUS_CONST             = "bus";
   public static final String GENERATOR_CONST       = "generator";
   public static final String TRANSFORMER_CONST     = "transformer";
   public static final String LOAD_CONST            = "load";
   public static final String AC_LINE_CONST         = "ac_line";
   
   public static final String UNITS_CONST           = "units";
   public static final String MAPPINGS_CONST        = "mappings";
   public static final String MARKET_CONST          = "market";
   public static final String OP_CONSTRAINTS_CONST  = "operation_constraints";
   public static final String TIME_SERIES_CONST     = "network_time_series";
   
   public static final String VERSION_CONST         = "grg_version";
   public static final String NETWORK_CONST         = "network";
   public static final String COMPONENTS_CONST      = "components";
   public static final String VOLT_COMPONENTS_CONST = "voltage_level_components";   
   public static final String SUBS_COMPONENTS_CONST = "substation_components";
   public static final String STARTING_POINTS_CONST = "starting_points";
   public static final String VAR_CONST             = "var";
   public static final String LOWER_BOUND_CONST     = "lb";
   public static final String UPPER_BOUND_CONST     = "ub";
   public static final String ONE_OF_CONST          = "oneOf";
   
   public static final String LOWER_LIMIT_CONST     = "lower_limit";
   public static final String UPPER_LIMIT_CONST     = "upper_limit";
   public static final String NOMINAL_VALUE_CONST   = "nominal_value";
   
   public static final String ACTIVE_CONST          = "active";
   public static final String REACTIVE_CONST        = "reactive";
   public static final String RESISTANCE_CONST      = "resistance";
   public static final String REACTANCE_CONST       = "reactance";
   public static final String CONDUCTANCE_CONST     = "conductance";
   public static final String SUSCEPTANCE_CONST     = "susceptance";
   
   public static final String[] COMPLEX_SA     = {ACTIVE_CONST, REACTIVE_CONST, RESISTANCE_CONST, 
                                                  REACTANCE_CONST, CONDUCTANCE_CONST, SUSCEPTANCE_CONST};
   //..... Members ......
   
   static JsonParser parser = new JsonParser();
   static Gson gson = new Gson();
   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static GrgModel parseFile(String filePath_s) 
   {
      //..... Read file to string ......
      
      String json_s  = BGUtils.readFile(filePath_s);
      
      //..... Parse JSON file to GrgModel ......
      
      GrgModel model = new GrgModel();      
      boolean res_b = parseObject(model, null, json_s);
      
      //..... Model attributes ......
      
      model.setName(BGUtils.getNameFromFile(filePath_s));
      model.setPath(filePath_s);
      model.calcTypeCounts();
      model.setFormat(BGModel.MODEL_FORMAT_GRG);
      model.setFormatVersion(null);
      
      return model;
   }
   //----------------------------------------------------------------------------------------------
   // Parse GRG object recursively
   //----------------------------------------------------------------------------------------------
      
   public static boolean parseObject(GrgModel model,
                                     String   parent_s,    // parent name
                                     String   json_s) 
   {  
      boolean res_b = true;
      if (json_s == null) {
         return res_b;
      }      
      //..... Parse the input string to the JSON object ......
      
      try {
         Object object = parser.parse(json_s);        
         JsonObject jobject = getJsonObject((JsonObject)object);
         
         Set<Map.Entry<String, JsonElement>> set = jobject.entrySet();
         Iterator<Map.Entry<String, JsonElement>> iterator = set.iterator();
         GrgObject obj = null;

         GrgObject parentObj = model.getObject(parent_s);
         String value_s = null;
         
         //..... Iterate attributes ......
         
         while (iterator.hasNext()) {
            Map.Entry<String, JsonElement> entry = iterator.next();
            String name_s     = entry.getKey().toLowerCase().trim();       // attr.name
            JsonElement value = entry.getValue();                          // attr.value

            switch(name_s) {
            
            case MAPPINGS_CONST:             // Skip these objects (for now)
            case MARKET_CONST:
            case OP_CONSTRAINTS_CONST:
            case TIME_SERIES_CONST:   
               continue;
            
            case COMPONENTS_CONST:           // Do not create objects for these names (these are just wrappers)
            case STARTING_POINTS_CONST:
            case VOLT_COMPONENTS_CONST:
            case SUBS_COMPONENTS_CONST:
               res_b    = parseObject(model, parent_s, value.toString());
               parent_s = null;
               continue;
            
            case VERSION_CONST:
               obj = getGrgObject(model, parent_s, name_s);
               obj.setType(name_s);
               obj.addAttr(name_s, value.toString());
               break;
               
            case VAR_CONST:
               obj = getGrgObject(model, parent_s, name_s);
               value_s = buildBoundString(value);
               obj.addAttr(parent_s, value_s);
               continue;
               
            case VOLTAGE_CONST:
            case OUTPUT_CONST:
            case POSITION_CONST:
            case SHUNT_CONST:
            case SHUNT_1_CONST:
            case SHUNT_2_CONST:
            case IMPEDANCE_CONST:
            case TAP_RATIO_CONST:
            case ANGLE_SHIFT_CONST:
            case DEMAND_CONST:
               
               if (parent_s != null) {
                  obj = model.getObject(parent_s);
                  String objType_s = obj.getType();                  
                  switch (objType_s) {
                  case VOLT_LEVEL_CONST:
                     value_s = buildBoundString(value);
                     obj.addAttr(name_s, value_s);
                     break;
                  case BUS_CONST:
                  case GENERATOR_CONST:
                  case TAP_CHANGER_CONST:
                  case LOAD_CONST:
                  case AC_LINE_CONST:
                     res_b &= parseComplexAttrs(obj, name_s, value);
                  }
               }
               else {
                  //**** TBD *****
               }
               continue;
            
            case CUR_LIMITS_1_CONST:
            case CUR_LIMITS_2_CONST:
            case THER_LIMITS_1_CONST:
            case THER_LIMITS_2_CONST:
            case TAP_CHANGER_CONST:
            case STEPS_CONST:
               
               //..... Create object for these structures ......
               
               String uniqueName_s = model.getNextObjectName(name_s);
               obj = getGrgObject(model, parent_s, uniqueName_s);
               obj.setType(name_s);
               res_b &= parseComplexValue(model, parent_s, uniqueName_s, value);
               break;
               
            case ARGUMENTS_CONST:
               
               // Take "values" for arguments presented by "value"
               
               Map.Entry<String, JsonElement> entryVal = iterator.next();
               String nameVal_s     = entryVal.getKey();                   // attr.name for value
               JsonElement valueVal = entryVal.getValue();                 // attr.value for value

               if (nameVal_s.equalsIgnoreCase(VALUES_CONST)) {
                  res_b &= parseTableObject(parentObj, value, valueVal);
               }
               continue;           
               
            case UNITS_CONST:
               obj = getGrgObject(model, parent_s, name_s);
               obj.setType(name_s);
               res_b &= parseGenericObject(model, name_s, value.toString());
               break;
               
            default:       
               res_b &= parseDefaultObject(model, parent_s, name_s, value);
               continue;
            }
         }
      }
      catch(Exception e) {
         log.error("parseObject. Error in parsing JSON object: " + 
                   json_s.substring(0, Math.min(json_s.length(), 60)) + 
                   "...\nStack Trace: " + ExceptionUtils.getStackTrace(e));
         return false;
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Parse GRG object recursively
   //----------------------------------------------------------------------------------------------
      
   public static boolean parseGenericObject(GrgModel model,
                                            String   parent_s,    // parent name
                                            String   json_s) 
   {  
      boolean res_b = true;
      if (json_s == null) {
         return res_b;
      }      
      //..... Parse the input string to the JSON object ......
      
      try {
         Object object = parser.parse(json_s);        
         JsonObject jobject = getJsonObject((JsonObject)object);
         
         Set<Map.Entry<String, JsonElement>> set = jobject.entrySet();
         Iterator<Map.Entry<String, JsonElement>> iterator = set.iterator();
         
         //..... Iterate attributes ......
         
         while (iterator.hasNext()) {
            Map.Entry<String, JsonElement> entry = iterator.next();
            String name_s     = entry.getKey().toLowerCase().trim();       // attr.name
            JsonElement value = entry.getValue();                          // attr.value
               
            res_b &= parseDefaultObject(model, parent_s, name_s, value);
         }
      }
      catch(Exception e) {
         log.error("parseGenericObject. Error in parsing JSON object: " + 
                   json_s.substring(0, Math.min(json_s.length(), 60)) + 
                   "...\nStack Trace: " + ExceptionUtils.getStackTrace(e));
         return false;
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static boolean parseDefaultObject(GrgModel    model,
                                             String      parent_s,   // parent name
                                             String      name_s,     // JSON object name
                                             JsonElement value_e)    // JSON object value
   {
      boolean res_b = true;
      GrgObject obj = getGrgObject(model, null, parent_s);
      
      //..... This is just a new attribute ......
      
      if (value_e.isJsonPrimitive()) {
         res_b &= parsePrimitiveValue(obj, name_s, value_e);
      }
      //..... Process complex number ......
      
      else if (isComplexNumber(value_e)) {
         GrgAttr attr = new GrgAttr(name_s, parseComplexNumber(value_e));
         obj.addAttr(attr);         
      }
      //..... Process pair of values, like a primitive object ......
      
      else if (isPair(value_e)) {
         GrgAttr attr = new GrgAttr(name_s, elementAsString(value_e));
         obj.addAttr(attr);
      }
      //..... Complex value: Create new object ......
      
      else {
         res_b &= parseComplexValue(model, parent_s, name_s, value_e);
      }
      return res_b;
   }   
   //----------------------------------------------------------------------------------------------
   // Parse attribute
   //----------------------------------------------------------------------------------------------
   
   private static boolean parsePrimitiveValue(GrgObject   obj,
                                              String      name_s,
                                              JsonElement value)
   {
      boolean res_b = true;
      
      //..... Value is a primitive element (just attribute) ...... 

      GrgAttr attr = new GrgAttr(name_s, value.getAsString());
      obj.addAttr(attr);

      // Object related attributes
      
      if (attr.getName().equalsIgnoreCase(ATTR_ID_CONST)) {
         obj.setName(value.getAsString());
      }
      else if (attr.getName().equalsIgnoreCase(ATTR_TYPE_CONST)) {
         obj.setType(value.getAsString());
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static boolean parseComplexAttrs(GrgObject   obj,
                                            String      name_s,
                                            JsonElement value_e)
   {
      boolean res_b = true;
      
      //..... Process pair of values, like a complex number ......
      
      if (isComplexNumber(value_e)) {
         String value_s = parseComplexNumber(value_e);
         GrgAttr attr = new GrgAttr(name_s, value_s);
         obj.addAttr(attr);
      }
      //..... General complex attribute ......
      
      else if (value_e.isJsonObject()) {
         JsonObject jobject = getJsonObject(value_e);
         
         Set<Map.Entry<String, JsonElement>> set = jobject.entrySet();
         Iterator<Map.Entry<String, JsonElement>> iterator = set.iterator();

         //..... Iterate attributes ......
         
         while (iterator.hasNext()) {
            Map.Entry<String, JsonElement> entry = iterator.next();
            String attrName_s       = entry.getKey().toLowerCase().trim();    // attr.name
            JsonElement attValue_je = entry.getValue();                       // attr.value

            if (attrName_s.equals(VAR_CONST)) {
               String attrValue_s = buildBoundString(attValue_je);
               obj.addAttr(name_s, attrValue_s);
               return true;
            }
            else {
               attrName_s = name_s + "_" + attrName_s;
               res_b &= parseComplexAttrs(obj, attrName_s, attValue_je);
            }
         }
      }
      else if (value_e.isJsonPrimitive()) {
         return parsePrimitiveValue(obj, name_s, value_e);
         
      }
      //..... Convert JSON value to string ......
      
      else {
         String value_s = buildBoundString(value_e);
         obj.addAttr(name_s, value_s);
      }
      return res_b;    
   }
   //----------------------------------------------------------------------------------------------
   // Parse attribute
   //----------------------------------------------------------------------------------------------
   
   private static boolean parseComplexValue(GrgModel    model,
                                            String      parent_s,
                                            String      name_s,
                                            JsonElement value)
   {
      boolean res_b = true;
   
      if (value.isJsonObject()) {         
         JsonObject value_jo = value.getAsJsonObject();
         
         //..... Get object "type" and "id" as a name if exists ......
         
         JsonElement id_e = value_jo.get(ATTR_ID_CONST);
         if (id_e != null && id_e.isJsonPrimitive()) {
            name_s = id_e.getAsString();
         }
         String type_s = null;
         JsonElement type_e = value_jo.get(ATTR_TYPE_CONST);
         if (type_e != null && type_e.isJsonPrimitive()) {
            type_s = type_e.getAsString();
         }
         //..... Link this new object name to the parent object ......
         
         GrgObject parentObj = getGrgObject(model, null, parent_s);
         GrgObject obj       = getGrgObject(model, parent_s, name_s);
         if (type_s != null) obj.setType(type_s);
         
         if (parentObj != null && type_s != null) {
            GrgAttr attr = new GrgAttr(type_s, name_s);
            parentObj.addAttr(attr);
         }
         //..... Create and parse the new object ......
               
         getGrgObject(model, parent_s, name_s);
         res_b &= parseObject(model, name_s, value.toString());         // recursive operation
      }
      //..... Value is array of complex objects ......
        
      else if (value.isJsonArray() && value.toString().contains(":")) {
         JsonArray json_a = value.getAsJsonArray();
         if (json_a != null) {
            for (JsonElement element : json_a) {
               res_b &= parseObject(model, name_s, element.toString());    // recursive operation
            }
         }
      }
      //..... Value is array of primitive elements ......
        
      else if (value.isJsonArray() && !value.toString().contains(":")) {
         GrgObject obj = getGrgObject(model, null, parent_s);
         GrgAttr attr = new GrgAttr(name_s, value.getAsJsonArray());
         obj.addAttr(attr);
//         if (parent_s != null) {
//            GrgAttr parAttr = new GrgAttr(GrgObject.PARENT_CONST, parent_s);
//            obj.addAttr(parAttr);
//         }
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static boolean parseTableObject(GrgObject   obj,
                                           JsonElement args_jo,
                                           JsonElement vals_jo)
   {
      boolean res_b = true;
      
      //..... Verifications ......
      
      if (obj == null) {
         log.error("parseTableObject. GrgObject obj is null");
         return false;
      }
      if (args_jo == null || !args_jo.isJsonArray()) {
         log.error("parseTableObject. '" + ARGUMENTS_CONST + "' is null or not a JsonArray");
         return false;
      }
      if (vals_jo == null || !vals_jo.isJsonArray()) {
         log.error("parseTableObject. '" + VALUES_CONST + "' is null or not a JsonArray");
         return false;
      }
      //..... Create object(s) from args_jo and vals_jo ......
      
      try {         
         JsonArray args_ja = args_jo.getAsJsonArray();
         String[] args_sa  = GrgAttr.toStringArray(args_ja);   // attribute names (arguments)
         
         //..... Parse table column values ......
         
         JsonArray vals_ja = vals_jo.getAsJsonArray();         // array of attribute values (rows)
         for (JsonElement row_je : vals_ja) {                  // iterate on set of attributes (row)

            // It's a pair (like complex number)
            
            if (isPair(row_je)) {
               String value_s = GrgParser.parseComplexNumber(row_je);
               obj.addAttr(args_sa[0], value_s);
            }
            // It's an array
            
            else if (row_je.isJsonArray()) {
               JsonArray row_ja = row_je.getAsJsonArray();     // iterate on attributes
               for (int i = 0; i < row_ja.size(); i++) {                  
                  JsonElement elem_e = row_ja.get(i);
                  if (elem_e.isJsonPrimitive()) {
                     obj.addAttr(args_sa[i], elementAsString(elem_e));
                  }
                  else {
                     res_b &= parseComplexAttrs(obj, args_sa[i], elem_e);
                  }
               }               
            }
            // It's a primitive type (table includes only one column)
            
            else if (row_je.isJsonPrimitive() && args_sa.length == 1) {
               obj.addAttr(args_sa[0], row_je.toString());
            }
            else {
               log.error("parseTableObject. Cannot parse values: " + vals_jo.toString());
               return false;
            }
         }
      }
      catch (Exception e) {
         log.error("parseTableObject. Error in parsing JSON objects: " + args_jo + " and/or" + vals_jo +
                   "\nStack Trace: " + ExceptionUtils.getStackTrace(e));
      }
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Parse complex attribute name, like "transformer_46/tap_changer/position"
   //----------------------------------------------------------------------------------------------
   /*
   private static String[] getAttrName(GrgModel model,
                                       String complexName)
   {
      String[] name_sa = complexName.split(COMPLEX_DELIM_CONST);
      if (name_sa.length == 1) {
         return name_sa;
      }
      for (int i = 0; i < name_sa.length; i++) {
         String name_s = name_sa[i];
         GrgObject obj = model.getObject(complexName);
         if (obj == null) {
            
            log.error("getAttrName. Cannot find object for );
         }
         
         
      }
      
   }
   */
   //----------------------------------------------------------------------------------------------
   // Process "mappings", separated by "/"
   //----------------------------------------------------------------------------------------------
/*
   private static boolean parsePath(GrgModel    model,
                                    String      parent_s,
                                    String      name_s,
                                    JsonElement value_e)
   {
      //..... Parse name ......
      
      String[] name_sa = name_s.split(MAPPING_DELIM_CONST);
      
      for (int i = 0; i < name_sa.length; i++) {
         
         
         
      }
      
      
      for (int i = name_sa.length - 1; i >= 0; i--) {
         if (i == name_sa.length - 1) {
            String attrName = name_sa[i];
         }
         else {
            
         }
      }
         
 
         
         
         String o
      
      
      
      
   }
*/
   //----------------------------------------------------------------------------------------------
   // Present Json Element as a simple string
   //----------------------------------------------------------------------------------------------
   
   private static String elementAsString(JsonElement elem_e)
   {
      String elem_s = elem_e.toString();
      elem_s = elem_e.toString().replaceAll("[{}\"]", "").replace(",", "; ");
      return elem_s;
   }   
   //----------------------------------------------------------------------------------------------
   // Parse variable bounds, like  "var": {"lb": 0.0,"ub": 0.0} to "0.0 - 0.0" 
   // as weel as other JSON objects which can be presented as a string, like:
   // {"lower_limit": 450.0, "upper_limit": 550.0, "nominal_value": 500.0} will be converted to
   // "450.0 - 550.0 (500.0)"
   //----------------------------------------------------------------------------------------------
   
   private static String buildBoundString(JsonElement var_e)
   {
      JsonObject jobject = getJsonObject(var_e);   
      if (jobject == null) return null;
      
      Set<Map.Entry<String, JsonElement>> set = jobject.entrySet();
      Iterator<Map.Entry<String, JsonElement>> iterator = set.iterator();
      
      String value_s = "";
      while (iterator.hasNext()) {
         Map.Entry<String, JsonElement> entry = iterator.next();
         String name_s     = entry.getKey();                            // attr.name
         JsonElement value = entry.getValue();                          // attr.value
         
         //..... Variable: Bounds: "lb", "up" ......
         
         switch (name_s) {
         case LOWER_BOUND_CONST:
         case LOWER_LIMIT_CONST:
            value_s += value.toString().trim() + RANGE_SPLITTER_CONST;
            break;

         case UPPER_BOUND_CONST:
         case UPPER_LIMIT_CONST:
            value_s += value.toString().trim();
            break;

         case NOMINAL_VALUE_CONST:
            value_s += " (" + value.toString().trim() + ")";
            
         case ONE_OF_CONST:
            //*** TBD ****
         
         default:
         
         }
      }
      return value_s;
   }
   //----------------------------------------------------------------------------------------------
   // Check if JsonElement is a pair, like: {"resistance": 0.0, "reactance": 13.09}
   //----------------------------------------------------------------------------------------------
   
   private static boolean isPair(JsonElement jpair_e)
   {
      try {
         JsonObject jobject = getJsonObject(jpair_e);
         Set<Map.Entry<String, JsonElement>> set = jobject.entrySet();
         if (set.size() != 2) return false;
         
         Iterator<Map.Entry<String, JsonElement>> iterator = set.iterator();
         while (iterator.hasNext()) {
            Map.Entry<String, JsonElement> entry = iterator.next();
            if (entry.getValue().isJsonPrimitive() == false) return false;
         }
      }
      catch(Exception e) {
         return false;
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Check if JsonElement is a pair, like: {"resistance": 0.0, "reactance": 13.09}
   //----------------------------------------------------------------------------------------------
   
   private static boolean isComplexNumber(JsonElement complex_e)
   {
      try {
         String complex_s = complex_e.toString();
         int cnt = StringUtils.countMatches(complex_s, ",");
         if (cnt != 1) return false;
         if (BGUtils.getIndexOf(complex_s, COMPLEX_SA) == -1) return false;
         return true;
      }
      catch(Exception e) {
         return false;
      }
   }
   //----------------------------------------------------------------------------------------------
   // Parse complex number, like: jpair_e = {"active": 226.8419, "reactive": -37.472}
   //----------------------------------------------------------------------------------------------
 
   private static String parseComplexNumber (JsonElement jpair_e)
   {
      JsonObject jobject = getJsonObject(jpair_e);
      if (jobject == null) return null;
      
      Set<Map.Entry<String, JsonElement>> set = jobject.entrySet();
      if (set.size() != 2) {
         log.error("parseComplexNumber. Expect two json elements, received: " + jobject.toString());
         return jobject.toString();
      }      
      Iterator<Map.Entry<String, JsonElement>> iterator = set.iterator();

      //..... Iterate attributes ......

      String complex_s = "";
      int num = 0;
      while (iterator.hasNext()) {
         Map.Entry<String, JsonElement> entry = iterator.next();
         String  name_s    = entry.getKey();                         // attr.name
         JsonElement value = entry.getValue();                       // attr.value

         if (BGUtils.getStringIdx(name_s, COMPLEX_SA) == -1) break; 
         
         if (num++ == 0) {
            complex_s = value.toString();
         }
         else {
            String sign_s = "+";
            try {
               Double value_d = Double.parseDouble(value.toString());
               if (value_d < 0) sign_s = "";
            }
            catch (Exception e) {};

            complex_s += sign_s + value.toString() + "i";
            return complex_s;
         }
      }
      return jobject.toString();
   }
   //----------------------------------------------------------------------------------------------
   // get Json object
   //----------------------------------------------------------------------------------------------

   private static JsonObject getJsonObject(JsonElement elem_e)
   {
      JsonObject jobject = null;
      try {
         jobject = (JsonObject)elem_e;
      }
      catch (Exception e2) {
         String js_s = elem_e.getAsString();
         jobject = gson.fromJson(js_s, JsonObject.class);
      }
      return jobject;
   }
   //----------------------------------------------------------------------------------------------
   // get GRG object
   //----------------------------------------------------------------------------------------------

   private static GrgObject getGrgObject(GrgModel model,
                                         String   parent_s,
                                         String   name_s)
   {
      if (name_s == null) return null;
      
      GrgObject obj = model.getObject(name_s);
      if (obj == null) {
         obj = new GrgObject();
         obj.setName(name_s);
         obj.addAttr(NAME_CONST, name_s);
         
         obj.setModel(model);
         model.addObject(obj);
    
         if (parent_s != null) {
            GrgAttr parAttr = new GrgAttr(GrgObject.PARENT_CONST, parent_s);
            obj.addAttr(parAttr);
         }
      }
      return obj;
   }
   //----------------------------------------------------------------------------------------------
   // Build object name for objects which have parent and don't have unique name
   //----------------------------------------------------------------------------------------------
   
   private static String buildObjName (String parent_s,
                                       String name_s)
   {
      int pos = parent_s.lastIndexOf("_");
      if (pos > parent_s.length() - 2) return null;
      
      String parent_id = parent_s.substring(pos);
      return name_s + parent_id;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {
      org.apache.log4j.BasicConfigurator.configure();
      
      String fileName_s = "D:\\tmp_share\\GRG\\grg_test_1.grg";
      
      GrgModel model = parseFile(fileName_s);
      if (model == null) {
         log.error("main. Cannot parse file: " + fileName_s);
         return;
      }
      model.setUuid(UUID.randomUUID());
      
      //..... To JSON ......
      
      String json_s = model.toJson();
      BGUtils.stringToFile(json_s, "D:\\tmp_share\\GRG\\grg_test_1.json");

      //..... Print entry data ......
         
      System.out.println("=== GRG ========================= " + fileName_s + " ==========================");                 
      
      DBEntry entry;
      entry = model.getInfoEntry();
      entry.printContent();
   
      for (int i = 0; i < model.getTypesNum(); i++) {
         String sectName = model.getObjTypeNames()[i];
          
         System.out.println("---------------- Section: " + sectName + " ---------------------");
            
         entry = model.getEntry(sectName, null); 
         if (entry != null) {
            entry.printContent();
         }
      }
   }
}
