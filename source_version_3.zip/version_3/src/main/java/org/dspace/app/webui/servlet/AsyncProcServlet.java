package org.dspace.app.webui.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.time.Instant;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBModelProcess;
import org.dspace.app.webui.util.BGUtils;
import org.dspace.app.webui.util.JSPManager;
import org.dspace.app.webui.util.UIUtil;
import org.dspace.authorize.AuthorizeException;
import org.dspace.content.Item;
import org.dspace.content.factory.ContentServiceFactory;
import org.dspace.content.service.ItemService;
import org.dspace.core.Context;
import org.dspace.core.LogManager;

/**
 * Servlet implementation class AsyncProcServlet
 */
public class AsyncProcServlet extends DSpaceServlet
{
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(AsyncProcServlet.class);
       
   private final transient ItemService itemService = ContentServiceFactory.getInstance().getItemService();

   private static final int MAX_THREAD_NUM = 4;
   private static final Queue<DBModelProcess> queue = new ConcurrentLinkedQueue<DBModelProcess>();
   
   private static int runningNum = 0;
   
   //----------------------------------------------------------------------------------------------
   // Implementation of doDSPost function in asynchronous mode.
   //----------------------------------------------------------------------------------------------
   
   @Override
   protected void doDSPost(Context             context, 
                           HttpServletRequest  request,
                           HttpServletResponse response) throws ServletException, IOException,
                                                                SQLException, AuthorizeException
   {
      //..... Get item ......
      
      String itemID_s = request.getParameter("item_id");
      
      log.info("doDSPost. Prepare to process item ID: " + itemID_s);
      
      if (itemID_s != null) {
         Item item = null;
         try {
            item = itemService.find(context, UUID.fromString(request.getParameter("item_id")));
         } 
         catch (Exception e) {
            log.warn(LogManager.getHeader(context, "integrity_error", UIUtil.getRequestLogInfo(request)));
            JSPManager.showIntegrityError(request, response);
            return;
         }
         if (item == null) {
            log.warn(LogManager.getHeader(context, "integrity_error", UIUtil.getRequestLogInfo(request)));
            JSPManager.showIntegrityError(request, response);
            return;
         }
         log.info("doDSPost. Item found UID: " + item.getID());
         
         DBModelProcess proc = new DBModelProcess(context, item);
         proc.prepareFilesToProcess();
         
         //..... Add task to queue ......
         
         queue.add(proc);
         
         //..... Run all queue tasks if not busy ......
         
         int coresNum = BGUtils.getSystemCoreNum();  // number of system CPU
         
         if (runningNum == 0 || (runningNum < coresNum/2 && runningNum < MAX_THREAD_NUM)) {
            
            //..... Start asynchronous thread ......

            AsyncContext asyncContext = request.startAsync(request, response);
            asyncContext.start(()->{
               execQueueTasks();         
               asyncContext.complete();
            });
         }
         else {
            log.info("doDSPost. Executor is busy (" + coresNum + " CPU). Item: " + item.getName() + 
                     " added to the queue. Queue size: " + queue.size() + "; Running items = " + runningNum);
         }
      }
      //..... Asynchronous thread finished .....
      
      JSPManager.showJSP(request, response, "/mydspace/task-complete.jsp");
      context.complete();
	}
   //----------------------------------------------------------------------------------------------
   // Execute all processes from the queue
   //----------------------------------------------------------------------------------------------
   
   private boolean execQueueTasks()
   {
      boolean resTotal_b = true;
      
      while (queue.size() > 0) {
         try {
            DBModelProcess proc = queue.remove();         
            log.info("execQueueTasks. Got item from the queue. Remain in the queue: " + queue.size() + " items.");
            
            if (proc != null) {
               
               //..... Process item's bitstreams ......
         
               Long startStamp = Instant.now().toEpochMilli();
               log.info("execQueueTasks. Start processing item: " + proc.getItem().getName() + 
                        "; Start stamp: " + startStamp);
         
               runningNum++;
               boolean itemRes_b = proc.processModels();
               resTotal_b &= itemRes_b;
         
               Double spentSec1 = new Double(Instant.now().toEpochMilli() - startStamp) / 1000.0;
               log.info("execQueueTasks. Finish processing item: " + proc.getItem().getName() + "; Total time: " +
                        spentSec1 + " sec; result: " + itemRes_b);
               
               runningNum--;
            }
         }
         catch (Exception e) {
            log.error("execQueueTasks.Error in model processing. Msg:" + e.getMessage() +
                      "; Stack Trace: " + ExceptionUtils.getStackTrace(e));
         }
      }
      return resTotal_b;
   }
}
//======================================= End of Class ============================================ 
