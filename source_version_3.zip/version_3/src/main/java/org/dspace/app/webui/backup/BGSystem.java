package org.dspace.app.webui.backup;

import java.lang.reflect.Method;
import java.util.Locale;

import org.apache.log4j.Logger;

public class BGSystem {
 
   private static final Logger log = Logger.getLogger(BGSystem.class);
   
   public static final String _WINDOWS = "Windows";
   public static final String _MACOS   = "Mac";
   public static final String _LINUX   = "Linux";
   public static final String _OTHER   = "Other";

   protected static String nameOS = null;    // cached result of OS detection

   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String getOSType() 
   {
      if (nameOS == null) {
         String OS = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
     
         if ((OS.indexOf(_MACOS.toLowerCase()) >= 0) || (OS.indexOf("darwin") >= 0)) {
            nameOS = _MACOS;
         }
         else if (OS.indexOf(_WINDOWS.toLowerCase()) >= 0) {
            nameOS = _WINDOWS;
         } 
         else if (OS.indexOf(_LINUX.toLowerCase()) >= 0) {
            nameOS = _LINUX;
         } 
         else {
            nameOS = _OTHER;
         }
      }
      return nameOS;
   }
   //----------------------------------------------------------------------------------------------
   // Change file/folder mode in Linux
   //----------------------------------------------------------------------------------------------
   
   public static int chmod(String filename, int mode) 
   {
      try {
         Class<?> fspClass  = Class.forName("java.util.prefs.FileSystemPreferences");
         Method chmodMethod = fspClass.getDeclaredMethod("chmod", String.class, Integer.TYPE);
         chmodMethod.setAccessible(true);
         
         return (Integer)chmodMethod.invoke(null, filename, mode);
      } 
      catch (Throwable ex) {
         return -1;
      }
   }
}




