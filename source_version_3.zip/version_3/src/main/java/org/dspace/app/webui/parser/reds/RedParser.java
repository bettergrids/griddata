package org.dspace.app.webui.parser.reds;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.dspace.app.webui.model.DBEntry;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGParser;
import org.dspace.app.webui.util.BGUtils;

public class RedParser extends BGParser
{
   private static final Logger log = Logger.getLogger(RedParser.class);
   
   //..... Constants ......
   
   private static final String SECT_SIGN = ".";
   public static final String NAME_CONST = "name";

   //..... Constructor .....
   
   public RedParser(String file_s) throws FileNotFoundException 
   {
      super(file_s);
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static RedModel parseFile(String file_s) 
   {
      RedModel  model     = new RedModel(); 
      
      RedObject headObj   = null;
      boolean   isHeader  = true;
      String    objType_s = null;
      String    line0_s   = null;
      String    line1_s   = null;
      
      //..... Read input file ......

      try {
         RedParser parser = new RedParser(file_s);
         parser.setDoNormalize(true);
         parser.setSkipEmpty(true);
      
         do {
            if (line0_s == null && line1_s == null) {
               line0_s = parser.getLine();
            }
            else {
               line0_s = line1_s;
            }
            if (line0_s == null) break;
            line1_s = parser.getLine();
            
            //..... Skip presentation section "grid_size" ......
            
            if (line1_s != null && isIgnore(line1_s)) {
               line1_s = parser.getLine();
            }
            //..... Parse object description ......
            
            if (line0_s.startsWith(SECT_SIGN)) {
               
               // Parse header
               
               if (line1_s != null && line1_s.startsWith(SECT_SIGN) && isHeader) {
                  if (headObj == null) {
                     headObj = new RedObject(model);
                     headObj.setType(RedObject.OBJECT_TYPE_HEADER);
                     headObj.setName(RedObject.OBJECT_TYPE_HEADER);
                  }
                  addHeaderAttr(model, headObj, line0_s);
                  continue;
               }
               // Done with header:
               model.addObject(headObj);
               isHeader = false;
               
               // line0 - is a column description
               // line1 - is a first data string
               
               objType_s = setAttrDescription(model, objType_s, line0_s, line1_s);
               continue;
            }
            //..... Data line ......
            
            else {
               parseObjectLine(model, objType_s, line0_s);
            }
         }
         while(true);
      }
      catch (FileNotFoundException e) {
         log.error("RedParser.parseFile. File " + file_s + " not found. " + e.getMessage());
         return null;
      } 
      catch (IOException e) {
         log.error("RedParser.parseFile. General I/O error in parsing file " + file_s + ". " + e.getMessage());
         return null;
      }
      catch (Exception e) {
         log.error("RedParser.parseFile. File: " + file_s + ". " + e.getMessage());
         return null;
      }
      //..... Model attributes ......
      
      //model.setDspaceId(BGUtils.getNameFromFile(file_s));
      model.setName(BGUtils.getNameFromFile(file_s));
      model.setPath(file_s);
      model.calcTypeCounts();
      model.setFormat(BGModel.MODEL_FORMAT_REDS);
      
      return model;
   }
   //----------------------------------------------------------------------------------------------
   // Parse header
   //----------------------------------------------------------------------------------------------
   
   private static boolean addHeaderAttr(RedModel  model,
                                        RedObject headObj,
                                        String    line_s)
   {
      String[] line_sa = BGUtils.splitQuoted(line_s);
      String attrName  = line_sa[0].substring(1).trim();
      if (line_sa.length > 1) {
         String value_s  = line_s.substring(line_s.indexOf(" ")).trim();
         headObj.addAttr(attrName, value_s);
      }
      else {
         log.error("addHeaderAttr. Header attribute " + attrName + " does not have value." + 
                  "Consider it as a comment");
         return false;
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Parse attribute description. REturn object type
   //----------------------------------------------------------------------------------------------
   
   private static String setAttrDescription(RedModel model,
                                            String   curObjectType_s,   // current object type
                                            String   line0_s,           // line with attr. names
                                            String   line1_s)           // 
   {
      String descLine_s = BGUtils.trim(line0_s, SECT_SIGN.charAt(0), ' ');
      
      //..... Split with handling quoted names ......
      
      String[] line_sa = BGUtils.splitQuoted(descLine_s);
      String objType_s = null;
      
      //..... Replace "Src_bus" and "Rec_bus" to the standard _from, _to ......
      
      for (int i = 0; i < line_sa.length; i++) {
         switch (line_sa[i].toLowerCase()) {
         case RedModel.SRC_BUS_NAME: line_sa[i] = RedModel.FROM_NAME; break;
         case RedModel.REC_BUS_NAME: line_sa[i] = RedModel.TO_NAME;   break;
         }
      }     
      //..... Add attributes for this object type ......
      
      ArrayList<String> attrNames_al;
      if (isAttrDescription(line0_s, line1_s)) {         
         objType_s = line_sa[0].toLowerCase();                          // Object type name
         attrNames_al = new ArrayList<String>(Arrays.asList(line_sa));
         attrNames_al.set(0, RedModel.NAME_NAME);                       // 1st column: "name" 
      }
      //..... Otherwise, modify current value ......
      
      else {
         objType_s = descLine_s.replace(" ", "_").toLowerCase();
         Integer attrNum  = line1_s.split(" ").length;
         List<String>curAttrNames_al = model.getAttrNames(curObjectType_s);
         if (attrNum <= curAttrNames_al.size()) {
            attrNames_al = new ArrayList<String>(curAttrNames_al.subList(0, attrNum));
         }
         else {
            log.error("setAttrDescription. Attr.num of subtype " + objType_s + " = " + attrNum +
                      " is larger than size on the main type: " + curObjectType_s + " = " + 
                      curAttrNames_al.size());
            attrNames_al = new ArrayList<String>(Arrays.asList(line_sa));
         }
      }
      model.setAttrNames(objType_s, attrNames_al);

      return objType_s;
   }
   //----------------------------------------------------------------------------------------------
   // Parse object data line
   //----------------------------------------------------------------------------------------------

   private static boolean parseObjectLine(RedModel model,
                                          String   objType_s,
                                          String   line_s)
   {
      String[] attrVal_sa = BGUtils.splitQuoted(line_s);
      RedObject obj    = new RedObject(model);
      obj.setType(objType_s);
 
      obj.setAttrs(mapAttrValues(model, objType_s, attrVal_sa));
      obj.setName(attrVal_sa[0]);
      
      model.addObject(obj);
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Special case: if parsed line does not contain attr.descrioptions (e.g. tie switches)
   //----------------------------------------------------------------------------------------------
   
   private static boolean isAttrDescription(String line0_s,
                                            String line1_s)
   {
      if (line0_s.startsWith(SECT_SIGN) && line1_s != null && !line1_s.startsWith(SECT_SIGN) &&
          BGUtils.splitQuoted(line0_s).length != BGUtils.splitQuoted(line1_s).length) {
         return false;
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Special case: ignore some presentation objects
   //----------------------------------------------------------------------------------------------
   
   private static boolean isIgnore(String line_s)
   {
      if (line_s != null) { 
         String[] line_sa = BGUtils.splitQuoted(line_s);
         if (line_sa[0].startsWith(SECT_SIGN)) {
            line_sa[0] = BGUtils.trim(line_sa[0], SECT_SIGN.charAt(0), ' ').toLowerCase().replace(" ", "_");
            if (line_sa[0].equals(RedModel.TYPE_NAME_GRID_SIZE)) return true;
         }
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   // Mapper. Return attribute value, like "node_1" from attr.name ="node" and value = 1
   //----------------------------------------------------------------------------------------------
   
   private static String[] mapAttrValues(RedModel model,
                                         String   objType_s,
                                         String[] val_sa)
   {
      for (int i = 0; i < val_sa.length; i++) {
         
         // Special case: 1st column is "name" now, so we use
         // object type name to generate column value
         
         if (i == 0) {
            val_sa[i] = mapName(objType_s, val_sa[i]);
         }
         else {
            val_sa[i] = mapName(model.getAttrNames(objType_s).get(i), val_sa[i]);
         }
      }
      return val_sa;
   }   
   //----------------------------------------------------------------------------------------------
   // Mapper.
   //----------------------------------------------------------------------------------------------
   
   private static String mapName(String name_s,
                                 String value_s)
   {  
      switch (name_s.toLowerCase()) {
      case RedModel.SRC_BUS_NAME:
      case RedModel.REC_BUS_NAME:
      case RedModel.FROM_NAME:
      case RedModel.TO_NAME:
      case RedModel.TYPE_NAME_NODE:
         value_s = RedModel.TYPE_NAME_NODE + "_" + value_s;
         break;
      case RedModel.TYPE_NAME_BRANCH:
         value_s = RedModel.TYPE_NAME_BRANCH + "_" + value_s;
         break;
      case RedModel.TYPE_NAME_TIE_SWITCHES:
         value_s = RedModel.SWITCH_NAME + "_" + value_s;
         break;
      default:           
      }
      return value_s;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {
      org.apache.log4j.BasicConfigurator.configure();
      
      String fileName_s = "D:\\tmp_share\\REDS\\bus_13_3.pos";
      
      RedModel model = parseFile(fileName_s);
      if (model == null) {
         log.error("main. Cannot parse file: " + fileName_s);
         return;
      }
      model.setUuid(UUID.randomUUID());
      
      //..... To JSON ......
      
      String json_s = model.toJson();
      BGUtils.stringToFile(json_s, "D:\\tmp_share\\REDS\\bus_13_3.json");

      //..... Print entry data ......
         
      System.out.println("=== GRG ========================= " + fileName_s + " ==========================");                 
      
      DBEntry entry;
      entry = model.getInfoEntry();
      entry.printContent();
   
      for (int i = 0; i < model.getTypesNum(); i++) {
         String sectName = model.getObjTypeNames()[i];
          
         System.out.println("---------------- Section: " + sectName + " ---------------------");
            
         entry = model.getEntry(sectName, null); 
         if (entry != null) {
            entry.printContent();
         }
      }
   }
}
//======================================= End of Class ============================================
