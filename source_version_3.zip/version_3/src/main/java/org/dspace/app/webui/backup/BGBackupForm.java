package org.dspace.app.webui.backup;

import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

public class BGBackupForm 
{
   private static final Logger log = Logger.getLogger(BGBackupForm.class);
   
   private static String    serviceStatus = null;
   private static Boolean[] options_ba    = new Boolean[BGBackup.getOptionNames().length];
   private static int       numOfDays;
   private static int       startHour;
   private static int       startMin;
   private static int       keepArchivesNum;
     
   protected static final BGBackupForm INSTANCE = new BGBackupForm();

   public static final BGBackupForm getInstance() {
      if (options_ba == null) {
         BGBackup.getInstance();
         options_ba = BGBackup.getOptionsBoolean();
      }
      return INSTANCE;
   }

   public static String getServiceStatus() {
      return serviceStatus;
   }
   public static void setServiceStatus(String serviceStatus) {
      BGBackupForm.serviceStatus = serviceStatus;
   }
   public static Boolean[] getOptions() {
      return options_ba;
   }
   
   public static void setOption(int idx, Boolean options_b) 
   {
      BGBackupForm.options_ba[idx] = options_b;
   }
   public static void setOptions(Boolean options_b) 
   {
      for (int i = 0; i < options_ba.length; i++) {
         BGBackupForm.options_ba[i] = options_b;
      }
   }   
   public static void setOptions(Boolean[] options_ba) 
   {
      for (int i = 0; i < options_ba.length; i++) {
         BGBackupForm.options_ba[i] = options_ba[i];
      }
   }
   
   public static void setOptionsFromForm(String[] option_sa) 
   {
      setOptions(false);
      
      if (option_sa != null) {
         List<String> options_l = Arrays.asList(BGBackup.getOptionNames());     
      
         // Array options_sa - values from checkbox controls. 
         // Returns names only those are checked
      
         for (int i = 0; i < option_sa.length; i++) {
            int idx = options_l.indexOf(option_sa[i]);
            if (idx >= 0) setOption(idx, true); 
         }
      }
   }

   public static int getNumOfDays() {
      return numOfDays;
   }
   public static void setNumOfDays(int numOfDays) {
      BGBackupForm.numOfDays = numOfDays;
   }
   public static int getStartHour() {
      return startHour;
   }
   public static void setStartHour(int startHour) {
      BGBackupForm.startHour = startHour;
   }
   public static int getStartMin() {
      return startMin;
   }
   public static void setStartMin(int startMin) {
      BGBackupForm.startMin = startMin;
   }
   public static int getKeepArchivesNum() {
      return keepArchivesNum;
   }
   public static void setKeepArchivesNum(int keepArchivesNum) {
      BGBackupForm.keepArchivesNum = keepArchivesNum;
   }
}
