package org.dspace.app.webui.model;

import java.util.Map;

import org.apache.log4j.Logger;

public abstract class DBSingleEntry implements DBTypes{
   
   private static final Logger log = Logger.getLogger(DBSingleEntry.class);
   
   //----------------------------------------------------------------------------------------------
   // Convert single row class object to DBEntry
   //----------------------------------------------------------------------------------------------
   
   public DBEntry getEntry()
   {
      DBEntry entry = new DBEntry();
      DBTable table = new DBTable();
      
      //..... Setup entry ......
      
      table.setName(getTableName());
      
      for (int i = 0; i < getColumnNames().length; i++) {
         DBColumn column = new DBColumn(getColumnNames()[i], null, getColumnTypes()[i], i);
         if (getAutoIncrement() != null && getAutoIncrement()[i]) {
            column.setAutoIncrement(true);
         }
         table.addColumn(i, column);
      }
      entry.setTable(table);
      
      //..... Add data set ......
      
      Map <Integer, Object> row = entry.newRow();
      entry.addRow(row);
      
      for (int i = 0; i < getValues().length; i++) {
         entry.setRowValue(row, i, getValues()[i]);        
      }
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   // Abstract methods
   //----------------------------------------------------------------------------------------------
   
   abstract public String    getTableName();
   abstract public String[]  getColumnNames();
   abstract public Integer[] getColumnTypes();
   abstract public Boolean[] getAutoIncrement();
   abstract public Object[]  getValues();
}
//======================================= End of Class ============================================

