package org.dspace.app.webui.backup;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.dspace.app.webui.util.BGUtils;

public class BGConfig 
{
   private static final Logger log = Logger.getLogger(BGConfig.class);
   
   private static final String _BGConfigFileName = "betterGrids.cfg";
   private static final String _BGConfigPath_Windows = "C:\\dspace\\config\\" + _BGConfigFileName;
   private static final String _BGConfigPath_Linux   = "/home/dspace/dspace/config/" + _BGConfigFileName;
   
   private static Properties props = null;

   //----------------------------------------------------------------------------------------------
   // Generic class to provide BetterGrids property service
   //----------------------------------------------------------------------------------------------
   
   private static final String getBGConfigPath()
   {
      try {
         String OSType_s = BGSystem.getOSType();
      
         if (BGSystem._WINDOWS.equalsIgnoreCase(OSType_s)) {
            return _BGConfigPath_Windows;
         }
         else if (BGSystem._LINUX.equalsIgnoreCase(OSType_s)) {
            return _BGConfigPath_Linux;
         }
         else {
            log.error("Operating system : " + OSType_s + " is not supported");
            return null;
         }
      }
      catch (Exception e) {
         log.error("Cannot determine the type of Operating System. " + e.getMessage());
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static boolean loadProperties()
   {
      if (props != null) return true;
      
      String propFile_s = getBGConfigPath();
      if (propFile_s == null) return false;
      
      props = new Properties();
      InputStream input = null;
      try {
         input = new FileInputStream(propFile_s);
         props.load(input);                              // load a properties file
      } 
      catch (Exception e) {
         log.error("Cannot load the BetterGrids property file: " + propFile_s + ". " + e.getMessage());
         return false;
      } 
      finally {
         if (input != null) {
            try {
               input.close();
            } 
            catch (IOException e) {
               log.error("Cannot close the input stream for the property file: " + propFile_s + ". " + e.getMessage());
               return false;
            }
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String getBgProperty(String property_s)
   {
      try {
         if (props == null) {
            boolean status = loadProperties();
            if (!status) return null;
         }
         return (props.getProperty(property_s)).trim();
      }
      catch (Exception e) {
         log.error("Cannot retrieve the property " + property_s + ". " + e.getMessage());
         return null;
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String[] getBgArrayProperty(String property_s)
   {
      try {
         if (props == null) {
            boolean status = loadProperties();
            if (!status) return null;
         }
         String array_s = props.getProperty(property_s).trim();
         return array_s.replaceAll(" ", "").split(",");
      }
      catch (Exception e) {
         log.error("Cannot retrieve the property " + property_s + ". " + e.getMessage());
         return null;
      }
   }  
   //----------------------------------------------------------------------------------------------
   // 
   //----------------------------------------------------------------------------------------------

   public static Double getDoubleProperty(String property_s)
   {
      String val_s = getBgProperty(property_s);
      if (val_s == null) return null;
      
      return BGUtils.stringToDouble(val_s);
   }
}
//======================================= End of File =============================================
