package org.dspace.app.webui.nlidb;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class NLAttribute implements NLLexicon {

   private static final Logger log = Logger.getLogger(NLAttribute.class);
   
   //..... Common members ......
   
   private String parentName;
   private String name;
   private String value;
   private String operator;
   private NLAttrDesc attrDesc;
   
   private String message;          // needed for returning result of parsing (especially, if failed)
   
   //..... Used for condition attribute ......
   
   private String tableName;           // table name, like '_psse', _cdf', etc.
   private String unit;                // units of attribute value, like 'KV'  
   
   private List<NLAttribute> cond_al = new ArrayList<NLAttribute>();  // result of deep learning inside model tables
   
   private NLAttribute betweenOut;     // object type of "in" in the ".. object X between objects Y"
   
   //..... Methods ......
   
   public String getParentName() {
      return parentName;
   }
   public void setParentName(String parentName) {
      this.parentName = parentName;
   }
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getValue() {
      return value;
   }
   public void setValue(String value) {
      this.value = value;
   }
   public String getOperator() {
      return operator;
   }
   public void setOperator(String operator) {
      this.operator = operator;
   }
   public NLAttrDesc getAttrDescription()
   {
      return attrDesc;
   }
   public void setAttrDescription(NLAttrDesc attrDesc)
   {
      this.attrDesc = attrDesc;
   }
   //..... Condition functions ......
   
   public List<NLAttribute> getConditions() {
      return cond_al;
   }
   public void setConditions(List<NLAttribute> cond_al) {
      this.cond_al = cond_al;
   }
   public void addCondition(NLAttribute condition)
   {
      cond_al.add(condition);
   }
   public String getTableName() {
      return tableName;
   }
   public void setTableName(String tableName) {
      this.tableName = tableName;
   }
   public String getUnit() {
      return unit;
   }
   public void setUnit(String unit) {
      this.unit = unit;
   }
   //..... Bteween functions ......
   
   public NLAttribute getBetweenOut() {
      return betweenOut;
   }
   public void setBetweenOut(NLAttribute betweenOut) {
      this.betweenOut = betweenOut;
   }
   //..... Error message ......
   
   public String getMessage()
   {
      return message;
   }
   public void setMessage(String message)
   {
      this.message = message;
   }
   //----------------------------------------------------------------------------------------------
   
   public boolean isEmpty()
   {
      if (name == null && 
          (cond_al.isEmpty() || cond_al.get(0) == null || 
           cond_al.get(0).getName() == null || cond_al.get(0).getName().isEmpty())) {
         return true;
      }
      return false;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public String toSQL ()
   {
      return getName() + " " + getOperator() + " " + getValue();
   }
   
   
   
   
   
}
//======================================= End of Class ============================================
