package org.dspace.app.webui.model;

import java.net.InetAddress;
import java.sql.Connection;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.nlidb.NLAttribute;
import org.dspace.app.webui.nlidb.NLDeepSearch;
import org.dspace.app.webui.nlidb.NLIPAddress;
import org.dspace.app.webui.nlidb.NLLexicon;
import org.dspace.app.webui.nlidb.NLMapper;
import org.dspace.app.webui.nlidb.NLQuery;
import org.dspace.app.webui.nlidb.NLTranslator;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGObject;
import org.dspace.app.webui.util.BGUtils;

public class DBSearchFunctions implements DBTypes, NLLexicon, NLMapper
{
   private static final Logger log = Logger.getLogger(DBSearchFunctions.class);
     
   
   //----------------------------------------------------------------------------------------------
   //  Get model entry based on Natural Language query
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry getModelsBySearch(String query_s) 
   {
      String res_s = null;
      
      //..... Get entry from the NLI query (graph DB) ......
      
      DBConnection dbConn = new DBConnection(DBProvider.GraphDB);
      Connection conn     = dbConn.getConnection();                  // get DB connection
      DBExecute exec      = new DBExecute(); 
      DBEntry dspaceEntry = null;
      
      // Catch all exception to avoid "Internal System Error" page
      
      log.info("getModelsBySearch. Received query: " + query_s);
      
      try {
         NLTranslator trans = new NLTranslator(conn, exec);
         res_s = trans.parseQuery(query_s);
         if (res_s != null && res_s.equals(NLTranslator.RES_OK)== false) {
            dbConn.close();            
            DBEntry errorEntry = DBEntry.getErrorEntry(res_s.replace(NLTranslator.RES_ERROR, ""));
            return errorEntry;                                    // return error message in the entry
         }
         String sql_s = DBSearchFunctions.buildSQL(trans, null);
         if (sql_s.startsWith(NLTranslator.RES_ERROR)) {
            dbConn.close();            
            DBEntry errorEntry = DBEntry.getErrorEntry(sql_s.replace(NLTranslator.RES_ERROR, ""));
            return errorEntry;                                    // return error message in the entry            
         }      
         DBEntry graphEntry = exec.execQuery(conn, sql_s, null);
         if (graphEntry == null || graphEntry.getRowNum() == 0) {
            dbConn.close();
            return graphEntry;
         }      
         //..... Collect UUIDs of all found models as a list of strings ......
      
         List<Object> modelUid_oal = graphEntry.getColumnValues(DBTypes.modelId);      
         List<String> modelUid_sal = modelUid_oal.stream().map(Object::toString).collect(Collectors.toList());
            
         //..... Get data from DSpace DB ......
            
         dspaceEntry = DBFunctions.getDSpaceItemInfo(modelUid_sal);
         int sortColumnIdx = dspaceEntry.getTable().getColumnNum() + 2;     // 2 columns from graphEntry: modelname, format
      
         //..... Merge two entries on model UUID ......
      
         dspaceEntry.extendEntry(graphEntry, DBTypes.modelId); 
         
         try {            
            if (sortColumnIdx >= dspaceEntry.getTable().getColumnNum()) {
               sortColumnIdx = dspaceEntry.getTable().getColumnNum() - 1;
            }
            dspaceEntry.setColIdxToSort(sortColumnIdx);
            dspaceEntry.sortRows();
         }
         catch(Exception e) {
            log.error("getModelsBySearch. Cannot sort entry by column Idx = " + sortColumnIdx + 
                      ". Stack Trace: " + ExceptionUtils.getStackTrace(e));
         }
         // These lines are not needed because we hide required columns in JSP
         //String[] exclusions = {DBTypes.modelId};
         //dspaceEntry.applyExclusions(exclusions);      // remove column modeluid from the entry
      
         dspaceEntry.setCompactTable();
      }
      catch (Exception e) {
         log.error("getModelsBySearch. Stack Trace: " + ExceptionUtils.getStackTrace(e));
         dspaceEntry = null;
      }
      dbConn.close();
      
      return dspaceEntry;
   }
   //----------------------------------------------------------------------------------------------
   // Save query in the graph DB for further analysis
   //----------------------------------------------------------------------------------------------
   
   public static boolean saveQuery(String userUid_s,
                                   String ipAddr_s,
                                   String query_s,
                                   String status_s)
   {
      UUID userUid   = null;
      Integer status = null;
      try {
         if (userUid_s != null && !userUid_s.trim().isEmpty()) {
            userUid = UUID.fromString(userUid_s);
         }
         status = Integer.valueOf(status_s);
      }
      catch (Exception e) {
         log.warn("saveQuery. Cannot convert " + userUid_s + " to UUID and/or " + status_s + " to Integer. " +
                   ExceptionUtils.getStackTrace(e));
      }
      return saveQuery(userUid, ipAddr_s, query_s, status);
   }
   //----------------------------------------------------------------------------------------------
   // Save query in the graph DB for further analysis
   //----------------------------------------------------------------------------------------------
   
   public static boolean saveQuery(UUID   userUid,
                                   String ipAddr_s,
                                   String query_s,
                                   int    status)
   {
      boolean res_b = true;
      
      //..... Get entry from the NLI query (graph DB) ......
      
      DBConnection dbConn = new DBConnection(DBProvider.GraphDB);
      Connection conn     = dbConn.getConnection();                  // get DB connection
      if (conn == null) return false;
      
      DBExecute exec = new DBExecute();
      NLQuery query  = new NLQuery();
      
      try {
         query.setUserUid(userUid);
         query.setIpAddr(InetAddress.getByName(ipAddr_s));
         query.setCreated(Instant.now());
         query.setQuery(query_s);
         query.setStatus(status);

         DBEntry entry = query.getEntry();
      
         res_b = exec.execInsert(conn, entry);
      }
      catch (Exception e) {
         log.error("saveQuery. Cannot insert query record. Stack Trace: " + 
                   ExceptionUtils.getStackTrace(e));
         res_b = false;
      }
      dbConn.close();
      return res_b;
   }
   //----------------------------------------------------------------------------------------------
   // Insert information about IP address to the _ipaddr table if it does not exist
   //----------------------------------------------------------------------------------------------
   
   public static boolean saveIPAddressInfo(String ipAddr_s)
   {
      boolean res_b = true;
      
      //..... Get connection ......
      
      DBConnection dbConn = new DBConnection(DBProvider.GraphDB);
      Connection conn     = dbConn.getConnection();                  // get DB connection
      DBExecute exec      = new DBExecute();

      //..... Save IP Address info in the graph database ......
      
      NLIPAddress ip = new NLIPAddress();
      ip.setGeoInfo(ipAddr_s);
      
      int num = exec.execInsertNotExists(conn, ip.getEntry());
      if (num != 1 && num != 0) res_b = false;
      
      dbConn.close();
      return res_b;
   }   
   //----------------------------------------------------------------------------------------------
   // Build SQL query for searching in the _model2 tables
   //----------------------------------------------------------------------------------------------
   
   public static String buildModelSQL()
   {
      return null;
   }
   
   //----------------------------------------------------------------------------------------------
   // Main function to search in the _modelinfo table
   //----------------------------------------------------------------------------------------------
   
   public static String buildSQL(String[] modelFormats,      // search for all models format if null
                                 String[] nodeTypes,         // types of nodes in condition part, like (bus, load)
                                 String[] ops,               // operations: <,>,=, etc.
                                 String[] condValues,        // condition values (count of nodetypes)    
                                 String[] logics,            // logical condition: AND, OR 
                                 String   modelUid,          // search for all models if null                                
                                 String   modelName_s,       // 'modelname'
                                 String   modelUidName_s,    // 'modeluid'
                                 String   modelFormatName_s, // 'format'
                                 String   nodetypeName_s,    // 'nodetype'
                                 String   tableInfoName_s,   // '_modelinfo'
                                 String   dbName_s)          // 'graph'
   {
      //..... Processing of conditions ......
      
      int    i;
      String what_s  = "";
      String where_s = "";
      
      //..... Verification ......

      if (nodeTypes != null) {
         if (ops == null || condValues == null        ||
             nodeTypes.length != ops.length           || 
             nodeTypes.length != condValues.length    ||
             (nodeTypes.length > 2 && (logics == null || nodeTypes.length != logics.length + 1))) 
         {
            String error_s = "Arrays of attribute names, operations and values are not equal";
            log.error("buildSQL. Error in the input data: " + error_s);            
            return NLTranslator.RES_ERROR + error_s;
         }
      }
      //..... Build conditions ......
      
      if (modelFormats != null && modelFormats.length > 0) {
         where_s = " AND " + modelFormatName_s + " IN (";
         for (i = 0; i < modelFormats.length; i++) {
            where_s += "'" + modelFormats[i] + "'";
            where_s += (i == modelFormats.length - 1) ? ")" : ",";
         }  
      }
      what_s = modelUidName_s + "," + modelName_s + "," + modelFormatName_s;
      
      if (nodeTypes != null && nodeTypes.length > 0) {
         where_s += " AND (";
         
         for (i = 0; i < nodeTypes.length; i++) { 
            String common_s = mapCommonNodeType(nodeTypes[i]);
            String logic_s = "";
            if (logics != null && logics.length - 1 >= i && logics[i] != null) {
               logic_s = " " + logics[i] + " ";
            }
            if (nodeTypes[i] != null) {
               nodeTypes[i] = nodeTypes[i].replace(" ", "_");     // for 2+ word column names
               what_s += ", " + common_s + nodeTypes[i];
            }
            //..... Add "between" clause ......
            // function "buildBetweenClause" has it's own mechanism of
            // synonym processing, so we should use "common_s" only for "what" clause
            
            if (logic_s.trim().equalsIgnoreCase(_BETWEEN_S)) {
               String typeIn_s  = nodeTypes[i];
               if (typeIn_s == null || i + 1 >= nodeTypes.length || nodeTypes[i + 1] == null) {
                  String error_s = "Cannot parse 'between' clause";
                  log.error("buildSQL. Error in the input data: " + error_s);
                  return NLTranslator.RES_ERROR + error_s;
               }
               String typeOut_s = nodeTypes[i + 1]; 
               
               common_s = mapCommonNodeType(typeOut_s);
               what_s  += ", " + common_s + typeOut_s;
               where_s += buildBetweenClause(modelFormats, typeIn_s, typeOut_s, ops[i], condValues[i]);              
               i++;
            }
            //..... Regular AND/OR logic ...... 
            
            else {
               where_s += ((common_s.isEmpty()) ? nodeTypes[i] : common_s);
               where_s += ops[i] + condValues[i] + logic_s;
            }
         }
         where_s += ")";
      }
      //..... Find 1st non-common column name for sorting ......
      
      String order_s = "";
      String[] what_sa = what_s.split(",");
      if (what_sa.length > 3 && what_sa[3].trim().equals("1") == false) {
         order_s = " ORDER BY 3 DESC";
      }
      //..... Build query ......     
      
      String sql_s = "SELECT " + what_s + " FROM " + tableInfoName_s + " mi WHERE 1=1" + where_s +
                     order_s;
      return sql_s;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String buildSQL(String[] modelFormats,      // search for all models format if null
                                 String[] nodeTypes,         // types of nodes in condition part
                                 String[] ops,               // operations: <,>,=, etc.
                                 String[] values,            // condition values (count of nodetypes)    
                                 String[] logics,            // logical condition: AND, OR 
                                 String   modelUid)          // search for all models if null
                                 
   {   
      return buildSQL(modelFormats, nodeTypes, ops, values, logics, modelUid, modelName, modelId, 
                      modelType, nodeType, BGModel.INFO_TABLE_NAME, DBProvider.GraphDB);
   } 
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String buildSQL(NLTranslator trans,           // NLTranslator object 
                                 String       modelUid)        // search for all models if null
                                 
   {
      String[] modelFormats = trans.getModelFormats();
      
      //..... Verify that there are some valid formats ......
      
      if (modelFormats != null && modelFormats.length > 0) {
         modelFormats = trans.getValidModelFormats();
         if (modelFormats == null || modelFormats.length == 0) {            
            String error_s = "Unknown data format(s)";
            log.error("buildModelSQL. " + error_s);
            return NLTranslator.RES_ERROR + error_s;
         }
      }
      //..... Get Attributes ......
      
      boolean condQuery_b = false;
      String[] logics = trans.getLogics();

      int attrNum = trans.getAttributes().length;
      String[] nodeTypes = new String[attrNum];
      String[] ops       = new String[attrNum];
      String[] values    = new String[attrNum];
      
      for (int i = 0; i < attrNum; i++) {
         NLAttribute attr = trans.getAttributes()[i];
         if (attr != null) {
            nodeTypes[i] = attr.getName();
            ops[i]       = attr.getOperator();
            values[i]    = attr.getValue();
            
            if (attr.getConditions() != null && attr.getConditions().isEmpty() == false) {
               condQuery_b = true;
            }
         }
      }
      if (condQuery_b) {
         return buildModelSQL(trans, modelUid);
      }
      return buildSQL(modelFormats, nodeTypes, ops, values, logics, modelUid);
   }
   //----------------------------------------------------------------------------------------------
   // Build SQL based on model format tables (_gridlab, _psse, etc.)
   //----------------------------------------------------------------------------------------------
   
   public static String buildModelSQL2(NLTranslator trans,           // NLTranslator object 
                                       String       modelUid)        // search for all models if null
   
   {   
      String[] modelFormats  = trans.getValidModelFormats();
      int attrNum            = trans.getAttributes().length;
      boolean condition_b    = false;
      
      if (modelFormats == null || modelFormats.length == 0) {        // for all tables
         modelFormats = _FORMAT_KEY_SA;
      }
      String sqlTotal_s = "";
      
      //..... For each attribute ......
      
      int sqlIdx = 0;
      
      for (int i = 0; i < attrNum; i++) {
         NLAttribute attr = trans.getAttributes()[i];
         
         // Check if at least one condition specified (per attribute)

         if (attr.getConditions() != null && attr.getConditions().isEmpty() == false) {
            condition_b = true;
         }
         else {
            condition_b = false;
         }
         //..... For each model format ......
      
         String sql_s = null;
         
         for (int idx = 0; idx < modelFormats.length; idx++) {
            String attrSql_s = getAttrSQL(trans.getAttributes()[i], modelFormats[idx], condition_b);
            
            if (attrSql_s != null && !attrSql_s.isEmpty()) {
               if (idx == 0) {
                  sql_s = " (" + attrSql_s;
               }
               else {
                  sql_s += " UNION " + attrSql_s; 
               }               
            }
         }
         if (sql_s != null) {
            sqlTotal_s += sql_s + ") t" + sqlIdx++ + ",";
         }
      }      
      if (!sqlTotal_s.isEmpty()) {
         sqlTotal_s = ", " + sqlTotal_s.substring(0, sqlTotal_s.length() - 1);    // remove last comma
      }
      //..... SQL wrapper ......
            
      String querySQL_s = "SELECT mi." + modelId + ", mi." + modelName + ", tt." + modelType + 
                          " FROM " +  BGModel.INFO_TABLE_NAME + " mi" + sqlTotal_s + " WHERE 1=1";
      
      String finalSql_s = "";
      for (int i = 0; i < sqlIdx; i++) {
         finalSql_s += " AND mi." + modelId + "= t" + i + "." + modelId;
      }
      querySQL_s += finalSql_s;
            
      return querySQL_s;
   }
   //----------------------------------------------------------------------------------------------
   // Build SQL query for attribute with condition(s) and for specific format
   //----------------------------------------------------------------------------------------------
   
   private static String getAttrSQL(NLAttribute attr,
                                    String      format_s,
                                    boolean     condition_b)
   {
      if (attr == null || attr.isEmpty() || attr.getName() == null) return null;
      
      String attrName          = attr.getName();
      String attrOp            = attr.getOperator();
      String attrValue         = attr.getValue();
      List<NLAttribute>cond_al = attr.getConditions();
      int formatIdx            = BGModel.getFormatIdx(format_s);
      
      boolean addToSQl_b = false;    

      String sql_s = "SELECT " + modelId + ",'" + format_s + "' " + modelType + 
                     " FROM " + BGModel.getDbTableName(format_s) + " WHERE 1=1 ";
      
      String nodeTypes_s = NLDeepSearch.getNodeTypeSyns(attrName);
      if (nodeTypes_s != null) {
         sql_s += " AND " + nodeType + " in " + nodeTypes_s;
      }
      if (cond_al != null) {
         for (NLAttribute cond : cond_al) {
            String condName  = cond.getName();
            String condOp    = cond.getOperator();
            String condValue = cond.getValue() + "/" + NLDeepSearch.getValueCoeff(condName, formatIdx);
               
            if (condName != null && condValue != null) {
               String condColName = NLDeepSearch.getCondColumnName(condName, formatIdx);
               if (condColName != null) {
                  sql_s += " AND " + condColName + "::DOUBLE PRECISION " + condOp + condValue;
                  addToSQl_b = true;
               }
            }
         }
      }
      sql_s += " GROUP BY " + modelId + " HAVING count(*) " + attrOp + attrValue;
      
      if (condition_b == false || condition_b & addToSQl_b) {
         return sql_s;
      }         
      return null;
   }
   //----------------------------------------------------------------------------------------------
   // Build SQL based on model format tables (_gridlab, _psse, etc.)
   //----------------------------------------------------------------------------------------------
   
   public static String buildModelSQL(NLTranslator trans,           // NLTranslator object 
                                      String       modelUid)        // search for all models if null
   
   {   
      String[] modelFormats = trans.getValidModelFormats();
      int attrNum           = trans.getAttributes().length; 
      boolean condition_b   = false;
      boolean addFormat_b   = false;
      
      if (modelFormats == null || modelFormats.length == 0) {        // for all tables
         modelFormats = _FORMAT_KEY_SA;
      }
      //..... Check if conditions specified (at least for one attribute) ......
      
      for (int i = 0; i < attrNum; i++) {
         NLAttribute attr = trans.getAttributes()[i];
         if (attr.getConditions() != null && attr.getConditions().isEmpty() == false) {
            condition_b = true;
            break;
         }
      }
      //..... For each model format ......

      String sqlTotal_s = "";
      
      for (int idx = 0; idx < modelFormats.length; idx++) {

         int formatIdx = BGModel.getFormatIdx(modelFormats[idx]);
         if (formatIdx == -1) continue;
         
         addFormat_b   = false;
         String sql_s  = "";
         
         //..... For each attribute ......
         
         for (int i = 0; i < attrNum; i++) {
            NLAttribute attr = trans.getAttributes()[i];
            if (attr == null || attr.isEmpty()) continue;
            
            String attrName          = attr.getName();
            String attrOp            = attr.getOperator();
            String attrValue         = attr.getValue();
            List<NLAttribute>cond_al = attr.getConditions();
            
            if (idx > 0 && sqlTotal_s.length() > 0) {
               sql_s += " UNION "; 
            }
            if (i == 0) {
               sql_s += "SELECT " + modelId + ",'" + modelFormats[idx] + "' " + modelType + 
                        ", count(*) node_cnt FROM " + BGModel.getDbTableName(modelFormats[idx]) + 
                        " WHERE 1=1 ";
            }
            if (attrName != null) {
               String nodeTypes_s = NLDeepSearch.getNodeTypeSyns(attrName);
               if (nodeTypes_s != null) {
                  sql_s += " AND " + nodeType + " in " + nodeTypes_s;
               }
               if (cond_al != null) {
                  for (NLAttribute cond : cond_al) {
                     String condName  = cond.getName();
                     String condOp    = cond.getOperator();
                     String condValue = cond.getValue() + "/" + NLDeepSearch.getValueCoeff(condName, formatIdx);
                     
                     if (condName != null && condValue != null) {
                        String condColName = NLDeepSearch.getCondColumnName(condName, formatIdx);
                        if (condColName != null) {
                           sql_s += " AND " + condColName + "::DOUBLE PRECISION " + condOp + condValue;
                           addFormat_b = true;
                        }
                     }
                  }
               }
               sql_s += " GROUP BY " + modelId + " HAVING count(*) " + attrOp + attrValue;
            }
         }
         if (condition_b == false || condition_b & addFormat_b) {
            sqlTotal_s += sql_s;
         }         
      }
      //..... SQL wrapper ......
            
      String querySQL_s = "SELECT mi." + modelId + ", mi." + modelName + ", t1." + modelType + 
                          ", t1.node_cnt FROM " +  BGModel.INFO_TABLE_NAME + " mi, (" + sqlTotal_s + ") t1 WHERE 1=1"  +
                           " AND mi." + modelId + "= t1." + modelId + " ORDER BY t1.node_cnt DESC";
            
      return querySQL_s;
   }
   //----------------------------------------------------------------------------------------------
   // Map common node type to real column names, like 'node' to 'node' + 'bus' + 'dc_bus' 
   //----------------------------------------------------------------------------------------------
   
   public static String mapCommonNodeType(String nodeType)
   {
      String result_s = " (";
      int idx = BGUtils.getStringIdx(nodeType, _NODETYPE_KEY_SA);
      if (idx >= 0) {
         String[] existingTypes = NLTranslator.getSynonims().get(_NODE_TYPE_KEY_S);
         
         for (int i = 0; i < _NODETYPE_SYNS_SAA[idx].length; i++) {
            String word_s = (_NODETYPE_SYNS_SAA[idx][i]);
           
            // Check that synonym exist among columns of DB _modelinfo table

            if (BGUtils.getStringIdx(word_s, existingTypes) >= 0) {
               word_s = word_s.replace(" ", "_");
               result_s += "COALESCE(" + word_s +",0) +";
            }
         }
         result_s = result_s.substring(0, result_s.length() - 1) + ") ";
         return result_s;
      }
      return "";
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static DBEntry execNLQuery(String   query_s,        // Natural language query
                                     String[] exclusions,     // columns which should not be shown
                                     String   dbName_s)       // 'graph'
   {
      DBConnection dbConn = new DBConnection(dbName_s);
      Connection conn     = dbConn.getConnection();         // get DB connection
 
      DBExecute exec  = new DBExecute(); 
      
      NLTranslator trans = new NLTranslator(conn, exec);
      trans.parseQuery(query_s);
      String sql_s = buildSQL(trans, null);
      
      DBEntry entry = null;
      if (exclusions != null) {
         entry = exec.execQuery(conn, sql_s, exclusions);
      }
      else {
         if (sql_s.contains(BGModel.INFO_TABLE_NAME)) {
            entry =  exec.execQuery(conn, sql_s, queryExclusions);
         }
         else {
            entry =  exec.execQuery(conn, sql_s, modelExclusions);
         }
      }
      if (entry != null) {
         entry.setCompactTable();      // remove columns with all null values
         entry.setNumericColumns();    // set column types numeric/integer, based on data
      }
      dbConn.close();
      return entry;
   }
   //----------------------------------------------------------------------------------------------
   // 
   //----------------------------------------------------------------------------------------------

   public static String buildBetweenClause(String[] format_sa,  // model formats 
                                           String   typeIn_s,   // name of type surrounded type typeIn
                                           String   typeOut_s,  // name of type surrounded by type typeOut
                                           String   op_s,       // operations: <,>,=, etc.   
                                           String   inNum_s)    // number of typeIn surrounded by typeOut
   {
      // Build SQL clause as an addition to the main query. It is after WHERE keyword as one (or few) 
      // of AND operators
      
      // Used PostgreSQL function:
      //-------------------------------------------------------------------------------------------
      // CREATE OR REPLACE FUNCTION getInsideCntInt(p_array   int[],
      //                                            p_elemOut int,
      //                                            p_elenIn  int)   
      // RETURNS int
      // AS '
      // SELECT coalesce(cardinality(array_positions(p_array[(array_positions(p_array, p_elemOut))[1]:
      //                (array_positions(p_array, p_elemOut))[array_length((array_positions(p_array, p_elemOut)), 1)]], 
      //                 p_elenIn)), 0);
      // ' LANGUAGE SQL;
      //-------------------------------------------------------------------------------------------
            
      String sql_s = " EXISTS (SELECT 1 FROM " + BGModel.PATHS_TABLE_NAME + " WHERE 1=1" + 
                     " AND mi.modeluid = modeluid AND (";
      
      //..... Get all type synonyms for typeOut and typeIn ......
      
      List<Integer> typeOut_al = getTypeIdices(format_sa, typeOut_s);
      List<Integer> typeIn_al  = getTypeIdices(format_sa, typeIn_s);
      
      for (Integer typeOut : typeOut_al) {
         for (Integer typeIn : typeIn_al) {
            sql_s += "getInsideCntInt(" + BGModel.PATHS_COLUMN_PATHS + "," + typeOut +
                     "," + typeIn + ")" + op_s + inNum_s + " OR ";
         }
      }
      sql_s += "1 <> 1))";
      
      return sql_s;
   }
   //----------------------------------------------------------------------------------------------
   // Find type indices for all synonyms and all model formats
   //----------------------------------------------------------------------------------------------
               
   private static List<Integer> getTypeIdices(String[] format_sa,    // model formats
                                              String   type_s)       // node type
   {
      List<Integer> typeIdx_al = new ArrayList<Integer>();
   
      //..... There are synonyms for that type ......
      
      int synIdx = BGUtils.getStringIdx(type_s, _NODETYPE_KEY_SA);     // index of type in syn.array
      if (synIdx >= 0) {
         for (int i = 0; i < _NODETYPE_SYNS_SAA[synIdx].length; i++) {
            String syn_s = (_NODETYPE_SYNS_SAA[synIdx][i]).replace(" ", "_");
            
            //..... For each model type ......
            
            for (String format_s : BGModel.MODEL_FILE_FORMATS_SA) {
               if (format_sa != null && format_sa.length > 0 && 
                   BGUtils.getStringIdx(format_s, format_sa) == -1) continue;
               
               Integer typeIdx = BGObject.getObjTypeId(format_s, syn_s);
               if (typeIdx != null && typeIdx >= 0 && typeIdx_al.indexOf(typeIdx) == -1) {
                  typeIdx_al.add(typeIdx);
               }
            }
         }
      }
      //..... There is no synonyms ......
      
      else {
         for (String format_s : BGModel.MODEL_FILE_FORMATS_SA) {
            if (format_sa != null && format_sa.length > 0 && 
                BGUtils.getStringIdx(format_s, format_sa) == -1) continue;
            
            type_s = type_s.replace(" ", "_");
            Integer typeIdx = BGObject.getObjTypeId(format_s, type_s);
            if (typeIdx != null && typeIdx >= 0 && typeIdx_al.indexOf(typeIdx) == -1) {
               typeIdx_al.add(typeIdx);
            }
         }
      }
      return typeIdx_al; 
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   /*
   public DBEntry searchGraphInside(String   outName_s,    // outer node type, like: 'switch'
                                    String   inName_s,     // inner node type, like: 'capacitor'
                                    String[] modelFormats, // search for all models format if null                
                                    String   modelName_s,       // 'modelname'
                                    String   modelUidName_s,    // 'modeluid'
                                    String   modelFormatName_s, // 'format'
                                    String   nodetypeName_s,    // 'nodetype'
                                    String   tableName_s,      // '_modelinfo'
                                    String   dbName_s)          // 'graph'
                                    String   fromName,     // FROM column name: _from 
                                    String   toName        // TO column name: _to
   */
   //----------------------------------------------------------------------------------------------
   // Main function for testing
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) {
      // TODO Auto-generated method stub

   }
}
//======================================= End of Class ============================================
