package org.dspace.app.webui.nlidb;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class NLAttrDesc
{
   private static final Logger log = Logger.getLogger(NLAttrDesc.class);
   
   //..... Members ......
   
   String format;
   String nodeType;     // common name, like "bus" for all buses, nodes, etc.
   String nodeName;     // concrete name, like "node" for GridLab-D format
   String name;         // attribute name, like "voltage"
   String columnName;   // concrete attribute (column) name, like "nominal_voltage" for GridLab-D
   
   List<String> synonyms = new ArrayList<String>();
   String unit;
   
   //..... Methods ......
   
   public String getFormat()
   {
      return format;
   }
   public void setFormat(String format)
   {
      this.format = format;
   }
   public String getNodeType()
   {
      return nodeType;
   }
   public void setNodeType(String nodeType)
   {
      this.nodeType = nodeType;
   }
   public String getName()
   {
      return name;
   }
   public void setName(String name)
   {
      this.name = name;
   }
   public List<String> getSynonyms()
   {
      return synonyms;
   }
   public void setSynonyms(List<String> synonyms)
   {
      this.synonyms = synonyms;
   }
   public String getUnit()
   {
      return unit;
   }
   public void setUnit(String unit)
   {
      this.unit = unit;
   }
   public String getColumnName()
   {
      return columnName;
   }
   public void setColumnName(String columnName)
   {
      this.columnName = columnName;
   }
   public String getNodeName()
   {
      return nodeName;
   }
   public void setNodeName(String nodeName)
   {
      this.nodeName = nodeName;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   
   
}
