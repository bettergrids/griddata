package org.dspace.app.webui.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.dspace.app.webui.nlidb.NLIPAddress;
import org.dspace.app.webui.parser.BGModel;
import org.dspace.app.webui.parser.BGParser;
import org.dspace.authorize.AuthorizeException;
import org.dspace.core.Context;
import org.dspace.core.LogManager;

public class FileExportServlet extends DSpaceServlet
{
   private static final long serialVersionUID = 5126946261578326389L;
   private static Logger log = Logger.getLogger(FileExportServlet.class);

   public static final String original_form = "original";
   public static final String json_form     = "JSON";
   
   //----------------------------------------------------------------------------------------------
   // Modified doPost (see DSpaceServlet)
   //----------------------------------------------------------------------------------------------
   
   @Override
   protected void doDSPost(Context             context, 
                           HttpServletRequest  request,
                           HttpServletResponse response) throws ServletException, IOException,
                                                                SQLException, AuthorizeException
   {
       doDSGet(context, request, response);
   }
   //----------------------------------------------------------------------------------------------
   // Modified doGet (see DSpaceServlet)
   //----------------------------------------------------------------------------------------------

   @Override
   protected void doDSGet(Context             context, 
                          HttpServletRequest  request,
                          HttpServletResponse response) throws IOException, AuthorizeException
   {
      //..... Fetch parameters from HTTP request ......

      String download_form_s = (String)request.getParameter("download_form");
      
      String ip_addr   = request.getRemoteAddr();
      NLIPAddress ip   = new NLIPAddress();
      boolean res_b    = ip.setGeoInfo(ip_addr);
      
      String userInfo_s;
      if (res_b) {
         String country_s  = ip.getCountry();
         String state_s    = ip.getState();
         String city_s     = ip.getCity();
         userInfo_s = "; Country:" + country_s + "; State:" + state_s + "; City:" + city_s;
      }
      else {
         userInfo_s = "; User location cannot be determined";
      }                
      switch (download_form_s) {
      case original_form:
         sendOriginalFile(context, request, response);
         log.info("doDSPost/doDSGet. File downloading. IP:" + ip_addr + userInfo_s + "; Format: " + download_form_s);
         return;
      case json_form:
         sendJsonFile(context, request, response);
         log.info("doDSPost/doDSGet. File downloading. IP:" + ip_addr + userInfo_s + "; Format: " + download_form_s);
         return;
      default:
         log.error("doDSPost/doDSGet. Invalid format: " + download_form_s + userInfo_s);
         response.sendError(HttpServletResponse.SC_NOT_FOUND);
         return;         
      }
   }
   //----------------------------------------------------------------------------------------------
   // Download file in the original format
   //----------------------------------------------------------------------------------------------
   
   private boolean sendOriginalFile(Context             context,
                                    HttpServletRequest  request,
                                    HttpServletResponse response) throws IOException, AuthorizeException
   {
      String outputFileName_s;
      
      //..... Fetch parameters from HTTP request ......

      String filePath_s = (String)request.getParameter("file_path");
      String fileName_s = (String)request.getParameter("file_name");
      
      log.info("FileExportServlet.sendOriginalFile. File Path = " + filePath_s);
      log.info("FileExportServlet.sendOriginalFile. File Name = " + fileName_s);
       
      if (filePath_s == null) {
         log.error(LogManager.getHeader(context, "FileExportServlet.sendOriginalFile.", "File Path = " + filePath_s));
         response.sendError(HttpServletResponse.SC_NOT_FOUND);
         return false;
      }
      if (fileName_s == null) {
         outputFileName_s = "modelFile.dat";
         log.warn(LogManager.getHeader(context, "FileExportServlet.sendOriginalFile.", 
                  "File Name = " + fileName_s + ". Generic name: " + outputFileName_s + 
                  " will be sent to browser as a suggestion"));
      }
      else {
         outputFileName_s = fileName_s;
      }
      //..... Configure servlet response ...... 
   
      response.setContentType("application/octet-stream");
      response.setHeader("Content-disposition", "attachment; filename=\""+ outputFileName_s +"\"");
      response.setHeader("Cache-Control", "no-cache");
      response.setHeader("Expires", "-1");
   
      //..... Send file to browser ......
      
      File            file_f = new File(filePath_s);
      OutputStream    out    = response.getOutputStream();
      FileInputStream in     = new FileInputStream(file_f);
      
      byte[] buffer = new byte[8192];
      int len;
      while ((len = in.read(buffer)) > 0){
         out.write(buffer, 0, len);
      }
      //..... Close streams ......
      
      if (in != null) in.close();
      out.flush();     
      if (out != null) out.close();
      
      return true;
   }
   //----------------------------------------------------------------------------------------------
   // Download file in the JSON format
   //----------------------------------------------------------------------------------------------
   
   private boolean sendJsonFile(Context             context,
                                HttpServletRequest  request,
                                HttpServletResponse response) throws IOException, AuthorizeException
   {
      String outputFileName_s;
      String jsonText_s = null;
      
      //..... Fetch parameters from HTTP request ......

      String filePath_s      = (String)request.getParameter("file_path");
      String fileFormat_s    = (String)request.getParameter("file_format");
      String modelName_s     = (String)request.getParameter("model_name");
      
      log.info("FileExportServlet.sendJsonFile. File Path   = " + filePath_s);
      log.info("FileExportServlet.sendJsonFile. Model Name  = " + modelName_s);
      log.info("FileExportServlet.sendJsonFile. File Format = " + fileFormat_s);
       
      if (filePath_s == null || fileFormat_s == null) {
         log.error(LogManager.getHeader(context, "FileExportServlet.sendJsonFile.", 
                                        "File Path = " + filePath_s + "; File Format = " + fileFormat_s));
         response.sendError(HttpServletResponse.SC_NOT_FOUND);
         return false;
      }
      if (modelName_s == null) {
         outputFileName_s = "modelConvertedToJson.json";
         log.warn(LogManager.getHeader(context, "FileExportServlet.sendJsonFile.", 
                  "Model Name = " + modelName_s + ". Generic name: " + outputFileName_s + 
                  " will be sent to browser as a suggestion"));
      }
      else {
         outputFileName_s = modelName_s + ".json";
      }
      //..... Convert original files to JSON format ......

      BGModel model = BGParser.parseFile(fileFormat_s, filePath_s);
      if (model != null) {
         jsonText_s = model.toJson();
      }
      else {
         log.error(LogManager.getHeader(context, "FileExportServlet.sendJsonFile.", 
            "Error in file parsing. File = " + filePath_s + "; Format = " + fileFormat_s));
      }
      //..................................................
   
      if (jsonText_s == null) {
         log.error(LogManager.getHeader(context, "FileExportServlet.sendJsonFile.", 
                   "Error in file-to-JSON conversion. File = " + filePath_s));
         response.sendError(HttpServletResponse.SC_NOT_FOUND);
         return false;
      }      
      //..... Configure servlet response ...... 
   
      response.setContentType("application/json");
      //response.setContentType("text/json");
      response.setCharacterEncoding("UTF-8");
   
      response.setHeader("Content-disposition", "attachment; filename=\""+ outputFileName_s +"\"");
      response.setHeader("Cache-Control", "no-cache");
      response.setHeader("Expires", "-1");
   
      //..... Actually send result bytes ......
   
      OutputStream out = response.getOutputStream();
      out.write(jsonText_s.getBytes());
      
      if (out != null) {
         out.flush();
         out.close();
      }
      return true;
   }
}
//======================================= End of Class ============================================

