package org.dspace.app.webui.spellcheck;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.dspace.app.webui.backup.BGConfig;
import org.dspace.app.webui.backup.BGSystem;
import org.dspace.app.webui.model.DBConnection;
import org.dspace.app.webui.model.DBExecute;
import org.dspace.app.webui.model.DBProvider;
import org.dspace.app.webui.nlidb.NLLexicon;
import org.dspace.app.webui.nlidb.NLMapper;
import org.dspace.app.webui.nlidb.NLTranslator;
import org.dspace.app.webui.util.BGUtils;

public class Dictionary implements NLLexicon, NLMapper
{
   private static String dictFilePath_s = null;
   
   private static final Logger log = Logger.getLogger(Dictionary.class);
   
   //----------------------------------------------------------------------------------------------
   // Add all necessary local terms to the dictionary
   //----------------------------------------------------------------------------------------------

   public static List<String> getLocalTerms()
   {
      List<String> term_al = new ArrayList<String>();
      
      //..... Get all terms from NLLexicon ......
      
      try {
         Field[] fields  = NLLexicon.class.getFields();
         Field[] fields2 = NLMapper.class.getFields();         
         fields = ArrayUtils.addAll(fields, fields2);
         
         Class<?> clazz; 
         List<String> val_al = null;
      
         for (Field field : fields) {         
            clazz = field.getType();
            
            if (clazz.isAssignableFrom(String.class)) {
               String word_s = (String)field.get(null);
               val_al = getWords(word_s);               
            }
            else if (clazz.isAssignableFrom(String[].class)) {
               String[] word_sa = (String[])field.get(null);
               val_al = getWords(word_sa);
            }
            else if (clazz.isAssignableFrom(String[][].class)) {
               String[][] word_saa = (String[][])field.get(null);
               val_al = getWords(word_saa);
            }
            else {
               val_al = null;
            }
            if (val_al != null && val_al.isEmpty() == false) {
               term_al.addAll(val_al);
            }
         }
      }
      catch (Exception e) {
         log.error("getLocalTerms. Cannot parse NLLexicon interface. Stack Trace: " +
                   ExceptionUtils.getStackTrace(e));
         return null;
      }
      return term_al;
   }
   //----------------------------------------------------------------------------------------------
   // Split string or string arrays to separate words 
   //----------------------------------------------------------------------------------------------
   
   private static List<String> getWords(String[][] word_saa)
   {
      List<String> res_al = new ArrayList<String>();
      if (word_saa != null && word_saa.length > 0) {      
         for (String[] word_sa : word_saa) {
            List<String> word_al = getWords(word_sa);           
            if (word_sa != null && word_sa.length > 0) {
               res_al.addAll(word_al);
            }
         }
      }
      return res_al;
   }
   //----------------------------------------------------------------------------------------------

   private static List<String> getWords(String[] word_sa)
   {
      List<String> res_al = new ArrayList<String>();
      if (word_sa != null) {
         for (String word_s : word_sa) {
            List<String> word_al = getWords(word_s);
            if (word_al.isEmpty() == false) {
               res_al.addAll(word_al);
            }
         }
      }
      return res_al;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private static List<String> getWords(String word_s)
   {
      List<String> res_al = new ArrayList<String>();
      if (word_s != null && word_s.length() > 0) {
         String[] res_sa = word_s.split(" ");
         for (String res_s : res_sa) {
            if (res_s.length() > 0 || BGUtils.isAlpha(res_s) == false) {
               res_al.add(res_s.replace("_", "").toLowerCase().trim());
            }
         }
      }
      return res_al;
   }
   //----------------------------------------------------------------------------------------------
   // Get terms from the GraphDB (table: _modelinfo)
   //----------------------------------------------------------------------------------------------

   public static List<String> getDBNodeNames()
   {
      DBConnection dbConn      = new DBConnection(DBProvider.GraphDB);
      Connection conn          = dbConn.getConnection();
      List<String> nodeName_al = null;
   
      if (conn != null) { 
         DBExecute exec = new DBExecute();
         String[] nodeName_sa = NLTranslator.getAllNodeNames(conn, exec, _NODE_TYPE_EXCEPTIONS_SA);
      
         if (nodeName_sa != null) {
            nodeName_al = new ArrayList<String>();
            for (int i = 0; i < nodeName_sa.length; i++) {
               String[] term_sa = nodeName_sa[i].split(" ");
               for (int j = 0; j < term_sa.length; j++) {
                  if (term_sa[j].length() > 3) {
                     nodeName_al.add(term_sa[j].trim());
                  }
               }
            }
         }
      }
      dbConn.close();
      return nodeName_al;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String getDictionaryFilePath() 
   {
      if (dictFilePath_s != null) return dictFilePath_s;
      
      if (BGSystem._WINDOWS.equalsIgnoreCase(BGSystem.getOSType())) {
         dictFilePath_s = BGConfig.getBgProperty("spellchecker.dictionary.filePath.windows");
      }
      else if (BGSystem._LINUX.equalsIgnoreCase(BGSystem.getOSType())) {
         dictFilePath_s = BGConfig.getBgProperty("spellchecker.dictionary.filePath.linux");
      }
      else {
         log.error("Operating system : " + BGSystem.getOSType() + " is not supported");
         return null;
      }
      return dictFilePath_s;
   }
   //----------------------------------------------------------------------------------------------
   // Get dictionary. Main function
   //----------------------------------------------------------------------------------------------
   
   public static Set<String> getDictionary()
   {
      return getDictionary(getDictionaryFilePath());
   }
   //----------------------------------------------------------------------------------------------
   
   public static Set<String> getDictionary(String dictFilePath_s)
   {
      Set<String> dict_hs = new HashSet<String>();
            
      //..... Get common words from file dictionary (if any) ......
         
      if (dictFilePath_s != null) {
         String dict_s =  BGUtils.readFile(dictFilePath_s);
         if (dict_s != null) {
            dict_s = dict_s.replace("\r", "\n").replace("\n\n", "\n");
            String[] dict_sa = dict_s.split("\n");
            dict_hs.addAll(Arrays.asList(dict_sa));
         }
      }
      //..... Add terms from lexicon ......
         
      List<String> term_al = getLocalTerms();
      if (term_al != null && term_al.isEmpty() == false) {
         dict_hs.addAll(term_al);
      }
      //..... Add terms from _modelinfo Graph DB ......
         
      term_al = getDBNodeNames();
      if (term_al != null && term_al.isEmpty() == false) {
         dict_hs.addAll(term_al);
      }
      //..... All terms -> to lower case ......
      
      dict_hs = dict_hs.stream().map(String::toLowerCase).collect(Collectors.toSet());
      
      return dict_hs;
   }
}
//======================================= End of Class ============================================

