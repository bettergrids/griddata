package org.dspace.app.webui.parser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

public abstract class BGAttr {
   
   //..... Members ......

   protected String  name;
   protected String  value;
   protected Object  valueObj;
   protected String  units = null;
   protected Integer type;
   
   //..... Getters and Setters ......
   
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getValue() {
      return value;
   }
   public void setValue(String value) {
      this.value = value;
   }
   public Object getObjValue() {
      return valueObj;
   }
   public void setObjValue(Object valueObj) {
      this.valueObj = valueObj;
   }
   public void setUnits(String units) {
      this.units = units;
   }
   public String getUnits() {
      return units;
   }
   //----------------------------------------------------------------------------------------------
   // Convert JsonArray to array of String
   //----------------------------------------------------------------------------------------------
   
   public static String[] toStringArray(JsonArray json_ja) 
   {
      List<String> json_al = new ArrayList<String>();
      
      for (int i = 0; i < json_ja.size(); i++) {
         JsonElement elem = json_ja.get(i);
         if (elem.isJsonPrimitive()) {
            json_al.add(json_ja.get(i).getAsString());
         }
         else if (elem.isJsonArray()) {
            JsonArray js_a = elem.getAsJsonArray();
            String[] js_sa = toStringArray(js_a);
            json_al.addAll(Arrays.asList(js_sa));
         }
      }
      String[] json_sa = json_al.toArray(new String[json_al.size()]);
      return json_sa;
   }
   //----------------------------------------------------------------------------------------------
   // Convert to the JSON string/object
   //----------------------------------------------------------------------------------------------
   
   @SuppressWarnings("unchecked")
   public String toJson()
   {
      StringBuffer json_sb = new StringBuffer();      
      if (name.toCharArray()[0] == '_') {
         json_sb.append("\t\"" + name.substring(1) + "\" : ");
      }
      else {
         json_sb.append("\t\"" + name + "\" : ");
      }  
      //..... String array ......
         
      if (valueObj instanceof String[]) {
         String[] val_sa = (String[])valueObj;
         json_sb.append("[");  
            
         for (int i = 0; i < val_sa.length; i++) {
            if (i < val_sa.length - 1) {
               json_sb.append("\"" + val_sa[i] + "\",");
            }
            else {
               json_sb.append("\"" + val_sa[i] + "\"]");
            }
         }
         json_sb.append(",\n");
      }
      //..... Numeric array ......
         
      else if (valueObj instanceof Double[]) {
         Double[] val_da = (Double[])valueObj;
         json_sb.append("[");  
            
         for (int i = 0; i < val_da.length; i++) {
            if (i < val_da.length - 1) {
               json_sb.append(val_da[i] + ",");
            }
            else {
               json_sb.append(val_da[i] + "]");
            }
         }
         json_sb.append(",\n");
      }
      //..... Property type ......

      else if (valueObj instanceof HashMap) {
         json_sb.append("{\n");
            
         HashMap<String,ArrayList<Object>> val_hm = (HashMap<String,ArrayList<Object>>)valueObj;
         for (Map.Entry<String,ArrayList<Object>> entry : val_hm.entrySet()) {
            String elemName           = entry.getKey();
            ArrayList<Object> elemVal = entry.getValue(); 
            json_sb.append("\t\"" + elemName + "\" : ");
             
            if (elemVal.size() > 1) {              // it's an array
               json_sb.append("[");
            }
            for (Object val : elemVal) {
               if (val instanceof Double) {
                  json_sb.append(val.toString() + ",");
               }
               else {
                  json_sb.append("\"" + val.toString() + "\",");
               }
            }
            json_sb.deleteCharAt(json_sb.length() - 1);     // delete last ","
            json_sb.append("],\n");
         }
         json_sb.deleteCharAt(json_sb.length() - 1);     // delete last \n
         json_sb.deleteCharAt(json_sb.length() - 1);     // delete last ","
         json_sb.append("\n\t},\n");
      }
      //..... Numeric data ......
         
      else if (valueObj instanceof Double || valueObj instanceof Integer) {
            
         if (units != null) {    // create sub-object
            json_sb.append("{\"value\" : " + valueObj.toString());
            json_sb.append(", \"units\" : \"" + units + "\"}");
         }
         else {
            json_sb.append(valueObj.toString());
         }
         json_sb.append(",\n");
      }
      //..... Complex number ......
      
      else if (valueObj instanceof Object[]) {
         json_sb.append("{\"real\" : " + ((Object[])valueObj)[0] + ", \"imag\" : " + ((Object[])valueObj)[1]);        
         json_sb.append(", \"form\" : \"" + ((Object[])valueObj)[2] + "\"},\n");        
      }
      //..... Just string ......
         
      else {
         value = value.replaceAll(":", "-");
         if (value.startsWith("\"")) {
            json_sb.append(value + ",\n");
         }
         else {
            json_sb.append("\"" + value + "\",\n");
         }
      }      
      return json_sb.toString();
   }
}
//======================================= End of Class ============================================