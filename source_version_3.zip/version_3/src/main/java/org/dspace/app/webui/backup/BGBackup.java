package org.dspace.app.webui.backup;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.comparator.NameFileComparator;
import org.apache.log4j.Logger;


/*-------------------------------------------------------------------------------------------------
 1. Backup AIP: 
    - Full repository: 
      dspace packager -r -a -f -t AIP -e admin@bettergrids.org <file path>

 2. Backup metadata: 
    ./dspace metadata-export -a -f <file>, where <file> is a cvs file containing metadata 
    
    Import metadata: As an admin -> Content->Import metadata
       
 3. Export usage statistics data from Solr for back-up purpouses:
    dspace solr-export-statistics 

 4. Dump the entire database and schema:
    pg_dump -h localhost -U dspace -d dspace -v -c --if-exists > <sql file path>

 5. Backup critical folders:
    - ./dspace/config
    - ./dspace/assetstore
    - ./dspace/solr/statistics

---------------------------------------------------------------------------------------------------*/

public class BGBackup
{
   private static final Logger log = Logger.getLogger(BGBackup.class);
   
   //..... Singleton ......

   private BGBackup(){};
   
   protected static final BGBackup INSTANCE = new BGBackup();

   public static final BGBackup getInstance() 
   {
      BGBackupConfig.getInstance();
      initOptions();
      return INSTANCE;
   }
   //..... Static members ......
      
   private static final String _aipCmd       = "aipCmd";
   private static final String _dbCmd        = "dbCmd";
   private static final String _configFolder = "configFolder";
   private static final String _solrFolder   = "solrFolder";
   private static final String _solrCmd      = "solrCmd";
   private static final String _assetFolder  = "assetFolder";
   private static final String _metaCmd      = "metaCmd";
   
   private static final String _dateFormat   = "MM/dd/yyyy HH:mm";
   private static final String _folderFormat = "yyyy-MM-dd-HH-mm";
         
   private static Date   lastArchiveDate = null;
   private static Date   nextArchiveDate = null;
      
   private static final String[] optionNames_sa = {_aipCmd, _dbCmd, _configFolder, _solrFolder, 
                                                   _solrCmd, _assetFolder, _metaCmd};

   private static LinkedHashMap<String,Boolean> options_hm = null;
   
   private static int keepArchivesNum    = 3;
   private static Boolean muteMode       = null;
   
   public static Boolean isMuteMode() 
   {
      if (muteMode != null) return muteMode;
      muteMode = ("true".equalsIgnoreCase(BGConfig.getBgProperty("execCommand.mute"))) ? true : false;
      return muteMode;
   }
   public static Date getLastArchiveDate() {
      if (lastArchiveDate == null) {
         return getLastArchiveDateFromFolders();
      }
      return lastArchiveDate;
   }
   public static void setLastArchiveDate(Date lastArchiveDate) {
      BGBackup.lastArchiveDate = lastArchiveDate;
   }
   public static Date getNextArchiveDate() {
      return nextArchiveDate;
   }
   public static void setNextArchiveDate(Date nextArchiveDate) {
      BGBackup.nextArchiveDate = nextArchiveDate;
   }   
   public static int getKeepArchivesNum() {
      return keepArchivesNum;
   }
   public static void setKeepArchivesNum(int keepArchivesNum) {
      BGBackup.keepArchivesNum = keepArchivesNum;
   }
   //..... Options ......
   
   public static String[] getOptionNames()
   {
      return optionNames_sa;
   }

   public static void initOptions()
   {
      if (options_hm == null) {
         options_hm = new LinkedHashMap<String,Boolean>();
     
         for (int i = 0; i < optionNames_sa.length; i++) {
            options_hm.put(optionNames_sa[i], false);
         }
      }
   }
   
   public static LinkedHashMap<String,Boolean> getOptions()
   {
      return options_hm;
   }
   
   public static Boolean[] getOptionsBoolean()
   {
      return options_hm.values().toArray(new Boolean[options_hm.size()]);
   }
   
   public static Boolean getOption(int idx)
   {
      return (Boolean)options_hm.values().toArray()[idx];
   }
   
   public static void setOption(int idx, Boolean status)
   {
      options_hm.put(optionNames_sa[idx], status);
   }
   
   public static void setOptions(Boolean[] options_ba)
   {
      for (int i = 0; i < optionNames_sa.length; i++) {
         setOption(i, options_ba[i]);
      }
   }

   public static void setOptions(Boolean options_b)
   {
      for (int i = 0; i < optionNames_sa.length; i++) {
         setOption(i, options_b);
      }
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public static void reset()
   {
      setOptions(false);
      nextArchiveDate = null;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean doBackup() 
   {
      boolean status = true;
      boolean result = true;
      
      String targetFolder = createTargetFolder(BGBackupConfig.getArchiveFolder());
      
      //..... Backaup DSpace AIP (full repository) ......
      
      if (options_hm.get(_aipCmd) != null && options_hm.get(_aipCmd) == true) {
         String aipFolder = targetFolder + File.separator + BGBackupConfig.dspaceAipNameConst;
         if (createDirectory(aipFolder) == false) {
            aipFolder = targetFolder;
         }
         String aipExportCmd = BGBackupConfig.getFullAIPCmd(BGBackupConfig.userEmail,
                                                            BGBackupConfig.getRepPrefix(),
                                                            aipFolder,
                                                            BGBackupConfig.aipArchive);
         result = execCommand(aipExportCmd, true);
         if (result == false) status = false;
      }
      //..... Backup Dspace metadata ......
      
      if (options_hm.get(_metaCmd) != null && options_hm.get(_metaCmd) == true) {
         String metadataCmd = BGBackupConfig.getMetadataExportCmd(targetFolder,
                                                                  BGBackupConfig.dspaceMetadataArchive);
         result = execCommand(metadataCmd, true);
         if (result == false) status = false;
      }
      //..... Backup Dspace Solr Statistics ......
      
      if (options_hm.get(_solrCmd) != null && options_hm.get(_solrCmd) == true) {
         String solrStatTargetFolder = targetFolder + File.separator + BGBackupConfig.statNameConst;
         if (createDirectory(solrStatTargetFolder) == false) {
            solrStatTargetFolder = targetFolder;
         } 
         String solrStatCmd = BGBackupConfig.getSolrStatExportCmd(targetFolder);
         result = execCommand(solrStatCmd, true);
         if (result == false) status = false;
      }
      //..... Backup DSpace PostgreSQL DB ......      
      
      if (options_hm.get(_dbCmd) != null && options_hm.get(_dbCmd) == true) {
         String dbExportCmd = BGBackupConfig.getFullDBExportCmd(BGBackupConfig.getDbUser(),
                                                                BGBackupConfig.getDbPass(),
                                                                BGBackupConfig.getDbName(),
                                                                targetFolder,
                                                                BGBackupConfig.getDbArchive());
         result = execCommand(dbExportCmd, true);
         if (result == false) status = false;
      }
      //..... Archive folders ......
      
      result = backupFolders(targetFolder);
      if (result == false) status = false;
      
      //..... Set Last Archive Date ......
      
      setLastArchiveDate(new Date());
      
      //..... Cleanup archive ......
      
      result = cleanupArchive();
      if (result == false) status = false;
      
      return status;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public String createTargetFolder(String archivePath)
   {      
      Calendar now = Calendar.getInstance();    
      
      SimpleDateFormat fmt = new SimpleDateFormat(_folderFormat);
      String folderPath = archivePath + File.separator + fmt.format(now.getTime());
      
      if (createDirectory(folderPath) == false) {
         return null;
      }
      return folderPath;
   } 
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static String getFormattedDate(Date date)
   {      
      if (date == null) {
         return "Not specified";
      }
      else {
         return new SimpleDateFormat(_dateFormat).format(date);
      }
   }   
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public boolean backupFolders(String targetFolder)
   {
      boolean status = true;
      boolean result = true;
      String target  = targetFolder + File.separator;
      
      BGArchiver ba  = new BGArchiver();
      
      if (options_hm.get(_configFolder) != null && options_hm.get(_configFolder) == true) {
         result = ba.zipFolder(BGBackupConfig.getDspaceConfigFolder(), 
                               target + BGBackupConfig.getDspaceConfigArchive());
         if (result == false) status = result;
      }
      if (options_hm.get(_assetFolder) != null && options_hm.get(_assetFolder) == true) {
         result = ba.zipFolder(BGBackupConfig.getDspaceAssetFolder(),  
                               target + BGBackupConfig.dspaceAssetArchive);
         if (result == false) status = result;
      }
      // Solr directory is actively used by dsapce, so some file are "in use", so zipFolder 
      // generate exceptions. To fix it first copy solr directory to the destination folder
      // and pack it.

      if (options_hm.get(_solrFolder) != null && options_hm.get(_solrFolder) == true) {
         String solrCopyFolder = targetFolder + File.separator + BGBackupConfig.statCSVNameConst;
         if (createDirectory(solrCopyFolder) == false) {
            return false;
         }
         try {
            File solrDir   = new File(BGBackupConfig.getDspaceSolrFolder());
            File targetDir = new File(solrCopyFolder); 

            FileUtils.copyDirectory (solrDir, targetDir);
            status = ba.zipFolder(solrCopyFolder,  target + BGBackupConfig.dspaceSolrArchive);
         } 
         catch (Exception e) {
            log.error("Cannot copy: " + BGBackupConfig.getDspaceSolrFolder() + " to " + targetFolder + 
                      "; Exception: " + e.getMessage());
            status = false;
         }
         //..... Delete temporary Solr directory ......
      
         try {
            File solrCopyDir = new File(solrCopyFolder);
            FileUtils.deleteDirectory(solrCopyDir);
         }
         catch (Exception e) {
            log.error("Cannot delete directory: " + solrCopyFolder + "; Exception: " + e.getMessage());
            status = false;
         }
      }
      return status;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------

   public boolean execCommand(String cmd, 
                              boolean split_b)
   {
      if (cmd == null) return false;
      
      Process process = null;
      try {     
         ProcessBuilder builder = null;
         String OSType_s = BGSystem.getOSType();
         
         if (BGSystem._WINDOWS.equalsIgnoreCase(OSType_s)) {
            builder = new ProcessBuilder("cmd.exe", "/C", cmd);
         }
         else if (BGSystem._LINUX.equalsIgnoreCase(OSType_s)) {
            if (split_b) {
               List<String> cmdList = Arrays.asList(cmd.split(" "));    // Split Linux command to List of tokens
               builder = new ProcessBuilder(cmdList);
            }
            else {
               builder = new ProcessBuilder(cmd);
            }
         }
         else {
            builder = new ProcessBuilder(cmd);
         }
         builder.redirectErrorStream(true);
         
         process = builder.start();
         
         BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
         BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));

         //..... Read command standard output ......
         
         String s;
         while ((s = stdInput.readLine()) != null) {
            if (isMuteMode() == false) {
               log.info(s);
            }
         }
         //..... Read command errors ......
         
         while ((s = stdError.readLine()) != null) {
            if (isMuteMode() == false) {
               log.error(s);
            }
         }
         //..... Finalize process ......
         
         process.waitFor();
         log.info("exit: " + process.exitValue() + "; cmd: " + cmd);
         process.destroy();
      } 
      catch (Exception e) {
         log.error("Executing command: " + cmd + "; Exception: " + e.getMessage());
         if (process != null) {
            process.destroy();
         }
         return false;
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   private boolean createDirectory(String folderPath_s)
   {
      Path path = Paths.get(folderPath_s);
      if (!Files.exists(path)) {
         try {
            Files.createDirectories(path);
            
            File createdDir = new File(folderPath_s);
            createdDir.setReadable(true, false);
            createdDir.setWritable(true, false);
         }
         catch(Exception e) {
            log.error("Cannot create directory: " + folderPath_s + "; Exception: " + e.getMessage());
            return false;
         }
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //
   //----------------------------------------------------------------------------------------------
   
   public static long getNumberOfBackups() 
   {
      String archiveFolder = BGBackupConfig.getArchiveFolder(); 
      long   archiveNum = 0;
      try {
         archiveNum = Files.list(Paths.get(archiveFolder)).count();
      } 
      catch (IOException e) {
         log.error("Cannot open directory: " + archiveFolder + "; Exception: " + e.getMessage());
      }
      return archiveNum;
   }
   //----------------------------------------------------------------------------------------------
   // Get the last backup based on a folder names
   //----------------------------------------------------------------------------------------------

   public static Date getLastArchiveDateFromFolders() 
   {
      //..... Get all sub-directories, not files (Java 8+ only) ......
      
      String folderName_s = null;
      try {         
         File[] backups = new File(BGBackupConfig.getArchiveFolder()).listFiles(File::isDirectory);       
         if (backups == null || backups.length == 0) return null;
         
         Arrays.sort(backups, NameFileComparator.NAME_COMPARATOR);
         folderName_s = backups[backups.length - 1].getName();
         
         String folderPath = BGBackupConfig.getArchiveFolder() + File.separator + folderName_s;        
         File[] backupFiles = new File(folderPath).listFiles();
         
         if (backupFiles.length > 0) {
            DateFormat folderFormat = new SimpleDateFormat(_folderFormat);
            lastArchiveDate = folderFormat.parse(folderName_s);
         
            log.info("Found latest archive from folder: " + folderName_s);
         }
         else {
            log.info("Latest archive folder: " + folderPath + " is empty. It will be deleted");
            FileUtils.deleteDirectory(new File(folderPath));
            return getLastArchiveDateFromFolders();
         }
      } 
      catch (Exception e) {
         log.error("Cannot get the Date from folder: " + folderName_s + ". "+ e.getMessage());
         return null;
      }
      return lastArchiveDate;
   }
   //----------------------------------------------------------------------------------------------
   // keep N latest backups only and delete others
   //----------------------------------------------------------------------------------------------

   public static boolean cleanupArchive() 
   {
      //..... Get all sub-directories, not files (Java 8+ only) ......
      
      try {
         long archiveNum = getNumberOfBackups();
         int  keepNum    = getKeepArchivesNum();
         
         if (archiveNum <= keepNum) return true;   // no need to delete
         
         File[] backups = new File(BGBackupConfig.getArchiveFolder()).listFiles(File::isDirectory);
         Arrays.sort(backups, NameFileComparator.NAME_COMPARATOR);
         
         for (int i = 0; i < archiveNum - keepNum; i++) {
            FileUtils.deleteDirectory(backups[i]);
         }
         log.info("Deleted " + (archiveNum - keepNum) + " old archive(s)");
      } 
      catch (IOException e) {
         log.error("Cannot cleanup backup archive. Exception: " + e.getMessage());
         return false;
      }
      return true;
   }
   //----------------------------------------------------------------------------------------------
   //  Main function for testing
   //----------------------------------------------------------------------------------------------
   
   public static void main(String[] args) 
   {
      org.apache.log4j.BasicConfigurator.configure();
      
      BGBackup bp = BGBackup.getInstance();
      
      String dspaceHome    = BGBackupConfig.getDspaceHome();
      String archiveFolder = BGBackupConfig.getArchiveFolder();
      String repPrefix     = BGBackupConfig.getRepPrefix();
      
      BGBackupConfig.setDspaceHome("C:\\dspace");
      BGBackupConfig.setArchiveFolder("C:\\tmp_share\\backup");      
      BGBackupConfig.setRepPrefix("123456789");
      
      Date date = getLastArchiveDateFromFolders();
      
      BGBackup.setOptions(true);
      BGBackup.setKeepArchivesNum(3);
      
      BGBackup.cleanupArchive();
      
      long archiveNum = getNumberOfBackups();
      
      Boolean[] test_ba = {true, true, true, true, true, true, true};
      BGBackup.setOptions(test_ba);
      
      Boolean[] test2_ba = BGBackup.getOptionsBoolean();
      
      bp.doBackup();
      log.info("Done!");
   }
}
//======================================= End of File =============================================