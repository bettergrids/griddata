
------------------------------ Create User "graph" ---------------------------------------
 As root:

# adduser graph

    ----- Set and confirm the new user's password at the prompt ------

    Set password prompts:
    Enter new UNIX password:
    Retype new UNIX password:
    passwd: password updated successfully

    ----- Follow the prompts to set the new user's information ------
          (It is fine to accept the defaults to leave all of this
           information blank)

    User information prompts:
    Changing the user information for username
    Enter the new value, or press ENTER for the default
        Full Name []:
        Room Number []:
        Work Phone []:
        Home Phone []:
        Other []:
    Is the information correct? [Y/n]

------ Create folder ------

# mkdir /home/dspace/postgresql
# chown postgres postgresql

-------------------------------- Create database -----------------------------------------

-- in postgres#

CREATE ROLE graph WITH LOGIN ENCRYPTED PASSWORD 'graph';
ALTER USER graph with superuser;
ALTER USER graph with createrole;
ALTER USER graph with createDB;
CREATE TABLESPACE graphts OWNER graph LOCATION '/home/dspace/postgresql';

DROP DATABASE graph;
CREATE DATABASE graph OWNER graph TABLESPACE graphts;

-- in graph

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS pg_prewarm;
CREATE EXTENSION IF NOT EXISTS plpgsql;

------------------------------- Create base tables ----------------------------

create table  _modelInfo(
 modeluid     uuid    PRIMARY KEY,  -- bitstream UID
 modelname    varchar,
 filepath     varchar,
 format       varchar,
 tablename    varchar,
 visible      boolean,
 description  text
);

create table  _model2(
 _oid         bigserial PRIMARY KEY,
 modeluid     uuid      REFERENCES _modelinfo(modeluid),
 nodetype     varchar,
 tablename    varchar,
 _from        varchar,
 _to          varchar,
 length       double precision,
 linkup       text[],
 hopsup       int[],
 distup       double precision[],
 linkdown     text[],
 hopsdown     int[],  
 distdown     double precision[]
);

CREATE TABLE _paths(
 modeluid UUID    REFERENCES _modelinfo(modeluid),
 paths    int[]
);

CREATE INDEX path_modeluid_idx ON _paths(modeluid);

create table  _ipaddr(
 ipaddr       inet    PRIMARY KEY,  
 country      text,
 state        text,
 city         text,
 postal       text,
 latitude     double precision,
 longitude    double precision
);

create table  _query(
 _oid         bigserial PRIMARY KEY,
 useruid      uuid,
 ipaddr       inet      REFERENCES _ipaddr(ipaddr),
 created      timestamp with time zone,
 query        text,
 status       integer  -- 0- not recognized; 1- recognized
);

------------------------------------------------------------------------------------------
--                           B a s e    F  u  n  c  t  i  o  n  s 
------------------------------------------------------------------------------------------

--========================================================================================
-- Returns common information about models by types
--========================================================================================

CREATE OR REPLACE FUNCTION getRepositoryInfo(p_modelTabName text default '_modelinfo',
                                             p_tableName    text default 'tablename',
                                             p_format       text default 'format',
                                             p_columnType   text default 'integer')
RETURNS TABLE (format    text,
               modelcnt  bigint,
               objectcnt bigint) AS
$func$
DECLARE
   columnNum    int;
   sql_s        text     := 'SUM(';
   schemaName_s text     := 'public';
   columnNames_sa text[] := null;

BEGIN
   EXECUTE format('SELECT array_agg(column_name::text) FROM information_schema.columns
                   WHERE table_schema = %L AND table_name = %L AND data_type = %L',
                   schemaName_s, p_modelTabName, p_columnType)
   INTO columnNames_sa;

   IF columnNames_sa IS NULL THEN 
      RETURN;
   END IF; 

   --- Build SQL query -----

   columnNum = array_length(columnNames_sa, 1);

   FOR i IN 1..columnNum LOOP        
      sql_s := sql_s || 'coalesce(' || columnNames_sa[i] || '::bigint,0)+';
   END LOOP;

   sql_s := substring(sql_s, 1, length(sql_s) - 1) || ')';  -- remove last comma and close SUM

   sql_s := 'SELECT ' || p_format || '::text, count(*)::bigint modelcnt,' || sql_s || 
            '::bigint objectcnt ' || 'FROM ' || p_modelTabName || ' GROUP BY ' || 
            p_format || ' ORDER BY modelcnt desc';
 
   RETURN QUERY EXECUTE sql_s;
END;
$func$ LANGUAGE 'plpgsql';

--------------------------------------------------------------------
--------------------------------------------------------------------

CREATE OR REPLACE FUNCTION getInsideCntInt(p_array   int[],
                                           p_elemOut int,
                                           p_elenIn  int)   
RETURNS int
AS '
SELECT coalesce(cardinality(array_positions(p_array[(array_positions(p_array, p_elemOut))[1]:
               (array_positions(p_array, p_elemOut))[array_length((array_positions(p_array, p_elemOut)), 1)]], 
               p_elenIn)), 0);
' LANGUAGE SQL;
